package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ChpVideo v9: el video de encima se prepara UNA sola vez.
 * Se lee seguido (no foto por foto), a cada cuadro se le quita el fondo y se guarda
 * en la memoria interna como imagen transparente. Después, para verlo o para guardar,
 * solo se toma el cuadro ya listo: así se mueve de verdad y se guarda rápido.
 * Si es más corto que el video de abajo, se repite.
 */
public final class CapaCache {

    public interface Avance { void en(int pct); }

    static final int FPS = 15;        // cuadros por segundo del video de encima
    static final int LADO = 480;      // tamaño máximo de cada cuadro

    private final Context ctx;
    private final Uri uri;
    private final boolean green;
    private final long durMs;
    private final File dir;

    private volatile boolean listo, cancelado;
    private volatile int n;
    private volatile double pasoMs = 1000.0 / FPS;
    public volatile int pct;
    public volatile String error;

    private final Map<Integer, Bitmap> lru = new LinkedHashMap<Integer, Bitmap>(8, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Integer, Bitmap> e) { return size() > 6; }
    };

    public CapaCache(Context c, Uri u, boolean green, long durMs) {
        this.ctx = c.getApplicationContext();
        this.uri = u;
        this.green = green;
        this.durMs = Math.max(1, durMs);
        this.dir = new File(ctx.getCacheDir(), "capa_" + Integer.toHexString(u.toString().hashCode()) + (green ? "_v" : "_a"));
    }

    public boolean listo() { return listo; }
    public void cancelar() { cancelado = true; }

    /** Trabajo largo: llamar en un hilo aparte. */
    public void preparar(Avance av) {
        try {
            if (leerHecho()) { listo = true; pct = 100; if (av != null) av.en(100); return; }
            borrarDir();
            dir.mkdirs();
            hacer(av);
            if (cancelado) { borrarDir(); return; }
            escribirHecho();
            listo = true;
            pct = 100;
            if (av != null) av.en(100);
        } catch (Throwable t) {
            error = String.valueOf(t.getMessage());
        }
    }

    private void hacer(Avance av) throws Exception {
        MediaMetadataRetriever r = Frames.open(ctx, uri);
        Seg seg = new Seg(true);
        try {
            int total = (int) Frames.parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT));
            int rawW = (int) Frames.parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int rawH = (int) Frames.parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            int rot = (int) Frames.parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            int salida = Math.max(1, (int) (durMs * FPS / 1000L));
            boolean seguido = total > 0;
            if (seguido) {
                // leer los cuadros seguidos, de a pocos, y quedarse con ~15 por segundo
                double fpsVideo = total * 1000.0 / durMs;
                int paso = Math.max(1, (int) Math.round(fpsVideo / FPS));
                pasoMs = paso * (double) durMs / total;
                MediaMetadataRetriever.BitmapParams bp = new MediaMetadataRetriever.BitmapParams();
                bp.setPreferredConfig(Bitmap.Config.RGB_565);
                int k = 0;
                int lote = paso * 4;
                try {
                    for (int s = 0; s < total && !cancelado; s += lote) {
                        int cuantos = Math.min(lote, total - s);
                        List<Bitmap> fs = r.getFramesAtIndex(s, cuantos, bp);
                        for (int j = 0; j < fs.size(); j++) {
                            Bitmap f = fs.get(j);
                            if ((s + j) % paso == 0 && !cancelado) {
                                guardar(k++, recortar(seg, girar(f, rot, rawW, rawH)));
                            }
                            if (f != null) f.recycle();
                        }
                        pct = (int) Math.min(99, (long) (s + cuantos) * 100 / total);
                        if (av != null) av.en(pct);
                    }
                    n = k;
                } catch (Throwable t) {
                    // algunos celulares no dejan leer seguido: se hace por tiempo
                    seguido = false;
                }
            }
            if (!seguido && !cancelado) {
                pasoMs = 1000.0 / FPS;
                int k = 0;
                for (int i = 0; i < salida && !cancelado; i++) {
                    long t = (long) (i * pasoMs);
                    Bitmap f = Frames.grab(r, t, LADO, LADO);
                    if (f != null) guardar(k, recortar(seg, f));
                    else if (k > 0) copiarAnterior(k);
                    else continue;
                    k++;
                    pct = (int) Math.min(99, (long) (i + 1) * 100 / salida);
                    if (av != null) av.en(pct);
                }
                n = k;
            }
            if (n <= 0 && !cancelado) throw new Exception("No pude leer el video de encima");
        } finally {
            try { r.release(); } catch (Exception ignored) {}
            seg.close();
        }
    }

    private static Bitmap girar(Bitmap f, int rot, int rawW, int rawH) {
        if (f == null) return null;
        // si el celular entregó el cuadro sin girar, se gira aquí
        if ((rot == 90 || rot == 270 || rot == 180) && rawW != rawH
                && f.getWidth() == rawW && f.getHeight() == rawH) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            return Bitmap.createBitmap(f, 0, 0, f.getWidth(), f.getHeight(), m, true);
        }
        return f;
    }

    private Bitmap recortar(Seg seg, Bitmap f) throws Exception {
        if (f == null) return null;
        float sc = Math.min(1f, (float) LADO / Math.max(f.getWidth(), f.getHeight()));
        Bitmap p = sc < 1f
                ? Bitmap.createScaledBitmap(f, Math.max(1, Math.round(f.getWidth() * sc)), Math.max(1, Math.round(f.getHeight() * sc)), true)
                : f;
        return seg.cutout(p, green);
    }

    @SuppressWarnings("deprecation")
    private void guardar(int k, Bitmap b) throws Exception {
        if (b == null) return;
        Bitmap.CompressFormat fmt = Build.VERSION.SDK_INT >= 30 ? Bitmap.CompressFormat.WEBP_LOSSY : Bitmap.CompressFormat.WEBP;
        try (FileOutputStream o = new FileOutputStream(archivo(k))) {
            b.compress(fmt, 80, o);
        }
        b.recycle();
    }

    private void copiarAnterior(int k) {
        try {
            java.nio.file.Files.copy(archivo(k - 1).toPath(), archivo(k).toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ignored) {}
    }

    private File archivo(int k) { return new File(dir, String.format(java.util.Locale.US, "f%05d.webp", k)); }

    /** El cuadro sin fondo para ese momento (ms desde que empieza el video de encima). Se repite solo. */
    public synchronized Bitmap cuadro(long ms) {
        if (!listo || n <= 0) return null;
        long m = ms % durMs;
        if (m < 0) m += durMs;
        int k = (int) Math.min(n - 1, Math.max(0, (long) (m / pasoMs)));
        Bitmap b = lru.get(k);
        if (b != null) return b;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        b = BitmapFactory.decodeFile(archivo(k).getAbsolutePath(), o);
        if (b == null && k > 0) b = BitmapFactory.decodeFile(archivo(k - 1).getAbsolutePath(), o);
        if (b != null) lru.put(k, b);
        return b;
    }

    // ---- recordar que ya se hizo (si vuelve a meter el mismo video, no se repite el trabajo)

    private boolean leerHecho() {
        try {
            File f = new File(dir, "listo.txt");
            if (!f.exists()) return false;
            String[] p = new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).trim().split(";");
            int nn = Integer.parseInt(p[0]);
            double ps = Double.parseDouble(p[1]);
            if (nn <= 0 || !archivo(nn - 1).exists()) return false;
            n = nn; pasoMs = ps;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void escribirHecho() {
        try (FileOutputStream o = new FileOutputStream(new File(dir, "listo.txt"))) {
            o.write((n + ";" + pasoMs).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    private void borrarDir() {
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }

    /** Borra los videos de encima viejos de la memoria interna (deja el que está en uso). */
    public static void limpiarViejos(Context c, CapaCache usar) {
        File[] ds = c.getCacheDir().listFiles((d, nm) -> nm.startsWith("capa_"));
        if (ds == null) return;
        for (File d : ds) {
            if (usar != null && d.equals(usar.dir)) continue;
            File[] fs = d.listFiles();
            if (fs != null) for (File f : fs) f.delete();
            d.delete();
        }
    }
}
