package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/**
 * Versión 5: la cinta como en InShot.
 * - La RAYA BLANCA queda fija en el centro; con el dedo se corre la cinta por debajo.
 * - Dos dedos: acercar o alejar.
 * - Varias filas (pistas): 0 = video (gris, con fotitos), 1 = sonidos (morado), 2 = textos (amarillo).
 * - Tocar un pedazo lo escoge: marco blanco y agarraderas [ ] en las puntas para alargar o recortar.
 */
public class CintaView extends View {

    /** De dónde salen los pedazos de cada fila. Tiempos en milisegundos de la cinta. */
    public interface Fuente {
        int filas();
        int cuantos(int fila);
        long ini(int fila, int i);
        long fin(int fila, int i);
        String nombre(int fila, int i);
        Bitmap foto(int fila, int i);
        long total();
    }

    public interface Oyente {
        void onMover(long ms);
        void onEscoger(int fila, int i);
        /** Arrastró una agarradera: inicio = true la de la izquierda. Devuelve el tiempo que quedó. */
        void onAgarradera(int fila, int i, boolean inicio, long ms);
        void onSoltar();
        /** Versión 6.3: dejó el dedo quieto en un video y lo arrastró a otro puesto. */
        default void onReordenar(int de, int a) {}
        /** Versión 6.3: ¿se pueden mover los videos de la fila 0? (solo con varios pedazos) */
        default boolean puedeReordenar() { return false; }
    }

    public Fuente fuente;
    public Oyente oyente;
    public long posMs;
    private long lastT;
    public int selFila = -1, selIdx = -1;

    private float msPorPx = 40f;
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    // toque
    private float x0, y0, lastX;
    private boolean movio, pinch, arrastrandoCinta;
    private int agarrada; // 0 nada, 1 inicio, 2 fin
    private float pd0, mp0, pinchX;
    private long pinchMs, ultimoTotal = -1;
    private boolean zoomUsuario;
    // Versión 6.3: dejar el dedo quieto sobre un video = levantarlo para pasarlo a otro puesto
    private int levantado = -1;
    private float dragX;
    private final Runnable levantar = new Runnable() {
        @Override public void run() {
            if (fuente == null || movio || pinch || agarrada != 0) return;
            if (oyente == null || !oyente.puedeReordenar() || filaEn(y0) != 0) return;
            int n = fuente.cuantos(0);
            if (n < 2) return;
            long ms = msEn(x0);
            for (int i = 0; i < n; i++) if (ms >= fuente.ini(0, i) && ms <= fuente.fin(0, i)) { levantado = i; break; }
            if (levantado < 0) return;
            dragX = x0;
            selFila = 0; selIdx = levantado;
            performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            invalidate();
        }
    };

    /** A qué puesto quedaría el video levantado si lo suelta en dragX. */
    private int puestoDestino() {
        long ms = msEn(dragX);
        int pos = 0;
        for (int j = 0; j < fuente.cuantos(0); j++) {
            if (j == levantado) continue;
            long mid = (fuente.ini(0, j) + fuente.fin(0, j)) / 2;
            if (ms > mid) pos++;
        }
        return pos;
    }

    private static final int[] FONDO = {0xFF607D8B, 0xFF7E57C2, 0xFFF9A825, 0xFFEF6C00};
    private static final int[] FONDO_SEL = {0xFF78909C, 0xFF9575CD, 0xFFFBC02D, 0xFFFF9800};

    public CintaView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private float alto(int fila) { return fila == 0 ? 54 * dp : fila == 3 ? 22 * dp : 30 * dp; }

    private float arriba(int fila) {
        float y = 18 * dp;
        for (int f = 0; f < fila; f++) y += alto(f) + 6 * dp;
        return y;
    }

    public int altoTotal(int filas) {
        float y = 18 * dp;
        for (int f = 0; f < filas; f++) y += alto(f) + 6 * dp;
        return Math.round(y + 4 * dp);
    }

    // Versión 6.1: la cinta queda quieta mostrando todo el video; la raya roja es la que se mueve
    private long vista0 = 0;
    private float pad() { return 8 * dp; }
    private float x(long ms) { return pad() + (ms - vista0) / msPorPx; }
    private long msEn(float xx) { return vista0 + (long) ((xx - pad()) * msPorPx); }

    /** Que la vista no se salga del video. */
    private void encajar() {
        if (fuente == null || getWidth() <= 0) return;
        float ancho = (getWidth() - 2 * pad()) * msPorPx;
        long max = Math.max(0, fuente.total() - (long) ancho);
        vista0 = Math.max(0, Math.min(max, vista0));
    }

    /** Si la raya roja se sale (con zoom), la vista la sigue. */
    private void seguirRaya() {
        if (getWidth() <= 0) return;
        float xr = x(posMs), W = getWidth();
        if (xr < pad() + 24 * dp) vista0 = posMs - (long) (24 * dp * msPorPx);
        else if (xr > W - pad() - 24 * dp) vista0 = posMs - (long) ((W - 2 * pad() - 24 * dp) * msPorPx);
        encajar();
    }

    /** Mueve la raya roja (para moverla desde la pantalla de arriba). */
    public void moverPor(long dms) {
        if (fuente == null) return;
        posMs = Math.max(0, Math.min(fuente.total(), posMs + dms));
        seguirRaya();
        if (oyente != null) oyente.onMover(posMs);
        invalidate();
    }

    @Override
    public void invalidate() {
        if (!arrastrandoCinta && agarrada == 0 && !pinch) seguirRaya();
        super.invalidate();
    }

    /** Que todo el video quepa en la pantalla al abrirlo. */
    public void ajustar() {
        if (fuente == null || getWidth() <= 0) return;
        long t = Math.max(1000, fuente.total());
        msPorPx = Math.max(1f, t / Math.max(1f, getWidth() - 2 * pad()));
        vista0 = 0;
        zoomUsuario = false;
        ultimoTotal = fuente.total();
        invalidate();
    }

    public void acercar() { msPorPx = Math.max(1f, msPorPx / 2f); invalidate(); }

    public void alejar() { msPorPx = Math.min(20000f, msPorPx * 2f); invalidate(); }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (ow == 0) ajustar();
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF1B1B1B);
        if (fuente == null) return;
        // si cambia lo que dura (insertar, borrar), se vuelve a ver todo de 0 al final
        if (fuente.total() != ultimoTotal && !zoomUsuario) { ultimoTotal = fuente.total(); long t = Math.max(1000, ultimoTotal); msPorPx = Math.max(1f, t / Math.max(1f, getWidth() - 2 * pad())); vista0 = 0; }
        int filas = fuente.filas();
        float W = getWidth();
        // reglita de tiempo arriba
        p.setColor(0xFFB0BEC5);
        p.setTextSize(10 * dp);
        long paso = pasoRegla();
        long t0 = Math.max(0, (long) (vista0 / paso) * paso);
        for (long t = t0; x(t) < W; t += paso) {
            float xx = x(t);
            c.drawRect(xx, 12 * dp, xx + dp, 16 * dp, p);
            c.drawText(TimelineView.fmt(t).replace(".0", ""), xx + 2 * dp, 10 * dp, p);
        }
        for (int f = 0; f < filas; f++) {
            float top = arriba(f), bot = top + alto(f);
            int n = fuente.cuantos(f);
            for (int i = 0; i < n; i++) {
                float a = x(fuente.ini(f, i)), b = x(fuente.fin(f, i));
                if (b < 0 || a > W) continue;
                boolean sel = f == selFila && i == selIdx;
                p.setStyle(Paint.Style.FILL);
                p.setColor(sel ? FONDO_SEL[Math.min(3, f)] : FONDO[Math.min(3, f)]);
                dst.set(a + dp, top, b - dp, bot);
                c.drawRoundRect(dst, 5 * dp, 5 * dp, p);
                Bitmap fo = f == 0 ? fuente.foto(f, i) : null;
                if (fo != null && !fo.isRecycled()) {
                    // fotitos repetidas a lo largo del pedazo
                    float lado = bot - top;
                    c.save();
                    c.clipRect(Math.max(0, a + dp), top, Math.min(W, b - dp), bot);
                    src.set(0, 0, fo.getWidth(), fo.getHeight());
                    for (float xx = a; xx < b && xx < W; xx += lado) {
                        if (xx + lado < 0) continue;
                        dst.set(xx, top, xx + lado, bot);
                        c.drawBitmap(fo, src, dst, null);
                    }
                    c.restore();
                }
                String nm = fuente.nombre(f, i);
                if (nm != null && b - a > 30 * dp) {
                    p.setTextSize(11 * dp);
                    p.setColor(f == 2 ? Color.BLACK : Color.WHITE);
                    if (f == 0) { p.setColor(0x99000000); c.drawRect(Math.max(a, 0) + 2 * dp, top + 2 * dp, Math.max(a, 0) + 6 * dp + p.measureText(nm), top + 16 * dp, p); p.setColor(Color.WHITE); }
                    c.save();
                    c.clipRect(a, top, b, bot);
                    c.drawText(nm, Math.max(a, 0) + 4 * dp, f == 0 ? top + 13 * dp : top + (bot - top) / 2f + 4 * dp, p);
                    c.restore();
                }
                if (sel) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(3 * dp);
                    p.setColor(Color.WHITE);
                    dst.set(a + dp, top, b - dp, bot);
                    c.drawRoundRect(dst, 5 * dp, 5 * dp, p);
                    agarradera(c, a, top, bot, true);
                    agarradera(c, b, top, bot, false);
                }
            }
        }
        // Versión 6.3: el video levantado flota con el dedo; la raya amarilla dice dónde cae
        if (levantado >= 0 && levantado < fuente.cuantos(0)) {
            int dest = puestoDestino();
            long msMarca;
            int k = 0;
            msMarca = fuente.total();
            for (int j = 0; j < fuente.cuantos(0); j++) {
                if (j == levantado) continue;
                if (k == dest) { msMarca = fuente.ini(0, j); break; }
                k++;
            }
            float xm = x(msMarca);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFEB3B);
            c.drawRect(xm - 2.5f * dp, arriba(0) - 6 * dp, xm + 2.5f * dp, arriba(0) + alto(0) + 6 * dp, p);
            float largo = Math.max(60 * dp, Math.min(140 * dp, x(fuente.fin(0, levantado)) - x(fuente.ini(0, levantado))));
            float top = arriba(0) - 8 * dp, bot = top + alto(0);
            dst.set(dragX - largo / 2f, top, dragX + largo / 2f, bot);
            p.setColor(0xEE455A64);
            c.drawRoundRect(dst, 6 * dp, 6 * dp, p);
            Bitmap fo = fuente.foto(0, levantado);
            if (fo != null && !fo.isRecycled()) {
                src.set(0, 0, fo.getWidth(), fo.getHeight());
                RectF d2 = new RectF(dst.left + 3 * dp, top + 3 * dp, dst.left + 3 * dp + (bot - top - 6 * dp), bot - 3 * dp);
                c.drawBitmap(fo, src, d2, null);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * dp);
            p.setColor(0xFFFFEB3B);
            c.drawRoundRect(dst, 6 * dp, 6 * dp, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            p.setTextSize(13 * dp);
            String nn = "Video " + (levantado + 1) + " → " + (dest + 1);
            c.drawText(nn, dst.right - p.measureText(nn) - 6 * dp, bot - 8 * dp, p);
        }
        // Versión 6.1: la raya roja que se mueve hasta donde se quiere cortar
        float xr = x(posMs);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFF1744);
        c.drawRect(xr - 0.75f * dp, 12 * dp, xr + 0.75f * dp, getHeight(), p);
        p.setTextSize(11 * dp);
        String tt = TimelineView.fmt(posMs);
        float tw = p.measureText(tt);
        float lx = Math.max(tw / 2f + 4 * dp, Math.min(W - tw / 2f - 4 * dp, xr));
        c.drawRoundRect(lx - tw / 2f - 4 * dp, 0, lx + tw / 2f + 4 * dp, 13 * dp, 3 * dp, 3 * dp, p);
        p.setColor(Color.WHITE);
        c.drawText(tt, lx - tw / 2f, 10.5f * dp, p);
    }

    private long pasoRegla() {
        long[] pasos = {500, 1000, 2000, 5000, 10000, 30000, 60000, 120000, 300000, 600000};
        for (long s : pasos) if (s / msPorPx > 60 * dp) return s;
        return 1200000;
    }

    private void agarradera(Canvas c, float xx, float top, float bot, boolean izq) {
        float w = 14 * dp;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        dst.set(izq ? xx - w + 2 * dp : xx - 2 * dp, top - 2 * dp, izq ? xx + 2 * dp : xx + w - 2 * dp, bot + 2 * dp);
        c.drawRoundRect(dst, 4 * dp, 4 * dp, p);
        p.setColor(Color.BLACK);
        p.setTextSize(14 * dp);
        String s = izq ? "[" : "]";
        c.drawText(s, dst.centerX() - p.measureText(s) / 2f, dst.centerY() + 5 * dp, p);
    }

    private int filaEn(float yy) {
        if (fuente == null) return -1;
        for (int f = 0; f < fuente.filas(); f++) if (yy >= arriba(f) - 4 * dp && yy <= arriba(f) + alto(f) + 4 * dp) return f;
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (fuente == null) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                x0 = lastX = e.getX(); y0 = e.getY(); lastT = e.getEventTime();
                movio = false; pinch = false; arrastrandoCinta = false; agarrada = 0;
                levantado = -1;
                removeCallbacks(levantar);
                // ¿agarró una agarradera del pedazo escogido?
                if (selFila >= 0 && selIdx >= 0 && selIdx < fuente.cuantos(selFila) && filaEn(y0) == selFila) {
                    float a = x(fuente.ini(selFila, selIdx)), b = x(fuente.fin(selFila, selIdx));
                    float tol = 22 * dp;
                    if (Math.abs(x0 - a) < tol && Math.abs(x0 - a) <= Math.abs(x0 - b)) agarrada = 1;
                    else if (Math.abs(x0 - b) < tol) agarrada = 2;
                }
                if (agarrada == 0 && filaEn(y0) == 0) postDelayed(levantar, 450);
                break;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    pinch = true;
                    agarrada = 0;
                    removeCallbacks(levantar);
                    levantado = -1;
                    pd0 = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
                    mp0 = msPorPx;
                    pinchMs = msEn((e.getX(0) + e.getX(1)) / 2f);
                    pinchX = (e.getX(0) + e.getX(1)) / 2f;
                    zoomUsuario = true;
                }
                break;
            case MotionEvent.ACTION_MOVE: {
                float xx = e.getX();
                if (levantado >= 0) {
                    dragX = xx;
                    // cerca de los bordes, la cinta se corre sola
                    if (xx < 30 * dp) { vista0 -= (long) (8 * dp * msPorPx); encajar(); }
                    else if (xx > getWidth() - 30 * dp) { vista0 += (long) (8 * dp * msPorPx); encajar(); }
                    super.invalidate();
                    lastX = xx;
                    break;
                }
                if (Math.abs(xx - x0) > 8 * dp) { movio = true; removeCallbacks(levantar); }
                if (pinch && e.getPointerCount() >= 2) {
                    float d = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
                    float maxMp = Math.max(1f, fuente.total() / Math.max(1f, getWidth() - 2 * pad()));
                    msPorPx = Math.max(1f, Math.min(maxMp, mp0 * pd0 / d));
                    vista0 = pinchMs - (long) ((pinchX - pad()) * msPorPx);
                    encajar();
                    invalidate();
                } else if (agarrada != 0 && movio) {
                    long ms = Math.max(0, msEn(xx));
                    if (oyente != null) oyente.onAgarradera(selFila, selIdx, agarrada == 1, ms);
                    invalidate();
                } else if (!pinch && movio) {
                    arrastrandoCinta = true;
                    // Versión 6: sigue al dedo; si el dedo va despacito, se mueve más fino
                    float dx = xx - lastX;
                    long dt = Math.max(1, e.getEventTime() - lastT);
                    float vel = Math.abs(dx) / dt / dp; // dp por milisegundo
                    float gan = vel < 0.08f ? 0.3f : vel < 0.25f ? 0.6f : 1f;
                    // la raya roja va hacia donde va el dedo
                    posMs = Math.max(0, Math.min(fuente.total(), posMs + (long) (dx * gan * msPorPx)));
                    seguirRaya();
                    if (oyente != null) oyente.onMover(posMs);
                    invalidate();
                }
                lastX = xx;
                lastT = e.getEventTime();
                break;
            }
            case MotionEvent.ACTION_UP: {
                removeCallbacks(levantar);
                if (levantado >= 0) {
                    int de = levantado, a = puestoDestino();
                    levantado = -1;
                    if (oyente != null) { if (a != de) oyente.onReordenar(de, a); else oyente.onEscoger(0, de); }
                    invalidate();
                    break;
                }
                if (!movio && !pinch) {
                    escogerEn(e.getX(), e.getY());
                    // tocar la cinta lleva la raya roja a ese punto
                    posMs = Math.max(0, Math.min(fuente.total(), msEn(e.getX())));
                    if (oyente != null) oyente.onMover(posMs);
                    invalidate();
                }
                if ((agarrada != 0 || arrastrandoCinta) && oyente != null) oyente.onSoltar();
                agarrada = 0; pinch = false; arrastrandoCinta = false;
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(levantar);
                levantado = -1;
                agarrada = 0; pinch = false; arrastrandoCinta = false;
                break;
        }
        return true;
    }

    private void escogerEn(float xx, float yy) {
        int f = filaEn(yy);
        int esc = -1;
        if (f >= 0) {
            long ms = msEn(xx);
            for (int i = fuente.cuantos(f) - 1; i >= 0; i--)
                if (ms >= fuente.ini(f, i) && ms <= fuente.fin(f, i)) { esc = i; break; }
        }
        if (esc < 0) { selFila = -1; selIdx = -1; } else { selFila = f; selIdx = esc; }
        if (oyente != null) oyente.onEscoger(selFila, selIdx);
        invalidate();
    }

    public String info() { return String.format(Locale.US, "%.0f", msPorPx); }
}
