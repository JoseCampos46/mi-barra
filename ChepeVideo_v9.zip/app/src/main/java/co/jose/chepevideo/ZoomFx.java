package co.jose.chepevideo;

import android.graphics.Matrix;

import androidx.media3.effect.MatrixTransformation;

/** Versión 6.1: el zoom grabado en el video final (acerca la parte escogida por el tiempo escogido). */
public final class ZoomFx implements MatrixTransformation {

    private final long trimStartMs;
    private long firstTs = -1;
    private boolean absoluto;

    public ZoomFx(long trimStartMs) { this.trimStartMs = trimStartMs; }

    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        if (firstTs < 0) {
            firstTs = presentationTimeUs;
            absoluto = trimStartMs > 500 && presentationTimeUs >= (trimStartMs - 500) * 1000L;
        }
        long t = absoluto ? presentationTimeUs / 1000L : trimStartMs + presentationTimeUs / 1000L;
        Matrix m = new Matrix();
        float[] z = Proj.zoomEn(t);
        if (z == null || z[0] <= 1.001f) return m;
        float ncx = z[1] * 2f - 1f, ncy = 1f - z[2] * 2f;
        m.setTranslate(-ncx, -ncy);
        m.postScale(z[0], z[0]);
        return m;
    }
}
