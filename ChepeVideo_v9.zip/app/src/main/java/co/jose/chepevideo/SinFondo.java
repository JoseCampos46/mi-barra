package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import androidx.media3.effect.BitmapOverlay;

/**
 * Versión 6: ✂ Quitar fondo de un video y guardarlo.
 * Cada cuadro se vuelve: fondo verde parejo + la persona encima.
 * (El MP4 no guarda transparencia; al traerlo "Encima" el verde se borra solo.)
 */
public final class SinFondo extends BitmapOverlay {

    public static final int VERDE = 0xFF00D000;

    private final MediaMetadataRetriever ret;
    private final Seg seg = new Seg(true);
    private final int W, H;
    private final Bitmap buf;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

    public SinFondo(Context ctx, Uri uri, int w, int h) {
        ret = Frames.open(ctx, uri);
        W = w; H = h;
        buf = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    }

    @Override
    public Bitmap getBitmap(long presentationTimeUs) {
        Canvas c = new Canvas(buf);
        c.drawColor(VERDE);
        try {
            Bitmap f = Frames.grab(ret, presentationTimeUs / 1000L, W, H);
            if (f != null) c.drawBitmap(seg.cutout(f, false), null, new RectF(0, 0, W, H), paint);
        } catch (Throwable ignored) {}
        return buf;
    }

    public void release() {
        try { ret.release(); } catch (Exception ignored) {}
        seg.close();
    }

    /** ¿Es un video ya recortado (orillas verdes)? */
    public static boolean esVerde(Bitmap b) {
        if (b == null) return false;
        int w = b.getWidth(), h = b.getHeight(), n = 0, v = 0;
        for (int i = 0; i < 40; i++) {
            int[][] pts = {{i * w / 40, 2}, {i * w / 40, h - 3}, {2, i * h / 40}, {w - 3, i * h / 40}};
            for (int[] p : pts) {
                int c = b.getPixel(Math.max(0, Math.min(w - 1, p[0])), Math.max(0, Math.min(h - 1, p[1])));
                int r = (c >> 16) & 255, g = (c >> 8) & 255, bb = c & 255;
                n++;
                if (g > 120 && g - Math.max(r, bb) > 60) v++;
            }
        }
        return v * 100 / Math.max(1, n) > 70;
    }
}
