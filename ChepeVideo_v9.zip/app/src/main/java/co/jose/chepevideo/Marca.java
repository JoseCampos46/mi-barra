package co.jose.chepevideo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import androidx.media3.effect.BitmapOverlay;

/**
 * Versión 4: «Suavizar marca» de TikTok. TikTok pone su marca arriba a la izquierda y, más o menos a la
 * mitad del video, la pasa abajo a la derecha. Aquí se pone encima un parche oscuro y difuminado en el
 * sitio que toca según el momento, con la fuerza que él escoja (no se borra: se le baja la intensidad).
 */
public final class Marca {

    private Marca() {}

    /** 0 = arriba a la izquierda, 1 = abajo a la derecha. */
    public static int zona(long t, long durMs, boolean arribaPrimero) {
        return 0; // Versión 6: siempre las dos zonas, el parche no cambia
    }

    public static RectF caja(int zona, float left, float top, float W, float H) {
        // Versión 6: medido en su video de TikTok: primero a la izquierda a media altura,
        // luego abajo a la derecha. No toca el letrero "generado con IA" de abajo a la izquierda.
        if (zona == 0) return new RectF(left + W * 0.0f, top + H * 0.40f, left + W * 0.32f, top + H * 0.56f);
        return new RectF(left + W * 0.66f, top + H * 0.70f, left + W * 1.0f, top + H * 0.97f);
    }

    /** Dibuja el parche: varias capas que se van aclarando hacia el borde (se ve difuminado, no un cuadro duro). */
    public static void draw(Canvas c, float left, float top, float W, float H, long t, long durMs, float fuerza, boolean arribaPrimero) {
        if (fuerza <= 0.01f) return;
        // Versión 6: las dos zonas todo el tiempo (la marca salta de sitio y así nunca se escapa)
        parche(c, caja(0, left, top, W, H), W, H, fuerza);
        parche(c, caja(1, left, top, W, H), W, H, fuerza);
    }

    private static void parche(Canvas c, RectF r, float W, float H, float fuerza) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        int capas = 6;
        float crece = Math.min(W, H) * 0.012f;
        for (int i = capas - 1; i >= 0; i--) {
            float a = fuerza * 235f * (i == 0 ? 1f : 0.35f / i);
            p.setColor(Color.argb(Math.max(0, Math.min(255, (int) a)), 22, 22, 22));
            RectF q = new RectF(r.left - crece * i, r.top - crece * i, r.right + crece * i, r.bottom + crece * i);
            c.drawRoundRect(q, crece * (2 + i), crece * (2 + i), p);
        }
    }

    /** La capa que se pega al video de una capa (al unir), con sus propios tiempos. */
    public static final class Overlay extends BitmapOverlay {
        private final int W, H;
        private final long a, durMs;
        private final float fuerza;
        private final boolean arriba;
        private final Bitmap[] bufs = new Bitmap[2];
        private int idx, ultima = -1;
        private long firstTs = -1;
        private boolean absoluto;

        public Overlay(int w, int h, long a, long durMs, float fuerza, boolean arriba) {
            W = Math.max(2, w); H = Math.max(2, h);
            this.a = a; this.durMs = durMs; this.fuerza = fuerza; this.arriba = arriba;
            bufs[0] = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
            bufs[1] = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        }

        @Override
        public Bitmap getBitmap(long presentationTimeUs) {
            if (firstTs < 0) {
                firstTs = presentationTimeUs;
                absoluto = a > 500 && presentationTimeUs >= (a - 500) * 1000L;
            }
            long t = absoluto ? presentationTimeUs / 1000L : a + presentationTimeUs / 1000L;
            int z = zona(t, durMs, arriba);
            if (z == ultima) return bufs[idx];
            ultima = z;
            idx = 1 - idx;
            Bitmap b = bufs[idx];
            b.eraseColor(Color.TRANSPARENT);
            draw(new Canvas(b), 0, 0, W, H, t, durMs, fuerza, arriba);
            return b;
        }
    }
}
