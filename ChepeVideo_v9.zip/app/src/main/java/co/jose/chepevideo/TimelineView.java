package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Versión 4: cinta del video con LÍNEA AZUL (inicio) y LÍNEA ROJA (final).
 * - Punto de ABAJO de cada línea: la línea salta a donde está el video ("aquí corto").
 * - Punto de ARRIBA: candado. Fija la línea (se oculta y no se mueve); otro toque la suelta.
 * - Si una línea queda fuera de la vista (video largo con lupa), aparece una flechita en el borde:
 *   al tocarla el video salta a esa línea.
 * - Lo que queda fuera de las líneas se ve oscuro (es lo que se quita).
 * Acercar / alejar con + y − o con dos dedos.
 */
public class TimelineView extends View {

    public interface Listener {
        void onSeek(long ms);
        void onTrim(long startMs, long endMs);
        default void onLock(boolean lockA, boolean lockB) {}
    }

    public Listener listener;
    public long durMs, posMs, startMs, endMs;
    public boolean lockA, lockB;
    public float zoom = 1f;
    public boolean dark;
    public final List<long[]> ranges = new ArrayList<>();

    private static final int AZUL = 0xFF2979FF, AZUL_O = 0xFF0D47A1, ROJO = 0xFFFF1744, ROJO_O = 0xFFB71C1C;

    private long viewStart;
    private int drag;           // 1 línea azul, 2 línea roja, 3 mover el video
    private int toque;          // lo que se tocó al bajar el dedo (para saber si fue un toque corto)
    private float downX, downY;
    private boolean movio, pinch;
    private float pz0, ps0;
    private long pm0;
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TimelineView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private long vis() { return Math.max(1, (long) (durMs / zoom)); }

    private void window() {
        long v = vis();
        viewStart = Math.max(0, Math.min(posMs - v / 2, durMs - v));
    }

    private float pad() { return 18 * dp; }

    private float x(long ms) {
        float w = getWidth() - 2 * pad();
        return pad() + (float) (ms - viewStart) / vis() * w;
    }

    private long ms(float xx) {
        float w = Math.max(1, getWidth() - 2 * pad());
        long m = viewStart + (long) ((xx - pad()) / w * vis());
        return Math.max(0, Math.min(durMs, m));
    }

    public void zoomIn() { zoom = Math.min(256f, zoom * 2f); window(); invalidate(); }

    public void zoomOut() { zoom = Math.max(1f, zoom / 2f); window(); invalidate(); }

    /** Lleva la vista a un momento (para «Ir a la línea»). */
    public void verEn(long ms) { posMs = ms; window(); invalidate(); }

    public void setPos(long ms) {
        posMs = ms;
        if (drag == 0) {
            long v = vis();
            if (ms < viewStart || ms > viewStart + v) window();
        }
        invalidate();
    }

    private float cl(float v) { return Math.max(pad(), Math.min(getWidth() - pad(), v)); }

    // medidas de la cinta
    private float yTop() { return 30 * dp; }          // arriba de la cinta (debajo del punto de arriba)
    private float yBot() { return getHeight() - 30 * dp; } // abajo de la cinta (encima del punto de abajo)
    private float rArriba() { return 11 * dp; }
    private float rAbajo() { return 14 * dp; }
    private float yArriba() { return 14 * dp; }
    private float yAbajo() { return getHeight() - 15 * dp; }

    @Override
    protected void onDraw(Canvas c) {
        float top = yTop(), bot = yBot(), L = pad(), R = getWidth() - pad();
        p.setStyle(Paint.Style.FILL);
        p.setColor(dark ? 0xFF2C2C2A : 0xFFCFD8DC);
        c.drawRoundRect(L, top, R, bot, 6 * dp, 6 * dp, p);
        p.setTextSize(12f * dp);
        if (durMs <= 0) {
            p.setColor(dark ? Color.WHITE : Color.BLACK);
            c.drawText("Abra un video", L, top + 20 * dp, p);
            return;
        }
        // lo que se quita, oscuro
        float sx = cl(x(startMs)), ex = cl(x(endMs));
        p.setColor(0x99000000);
        if (sx > L) c.drawRect(L, top, sx, bot, p);
        if (ex < R) c.drawRect(ex, top, R, bot, p);
        // capas de textos y fotos (rayitas de colores)
        for (long[] r : ranges) {
            p.setColor((int) r[2]);
            float a = cl(x(r[0])), b = cl(x(r[1]));
            if (b > a) c.drawRect(a, bot - 7 * dp, b, bot - 2 * dp, p);
        }
        // donde está el video: raya blanca con borde negro
        float px = x(posMs);
        if (px >= L - 1 && px <= R + 1) {
            p.setColor(Color.BLACK);
            c.drawRect(px - 2.5f * dp, top - 2 * dp, px + 2.5f * dp, bot + 2 * dp, p);
            p.setColor(Color.WHITE);
            c.drawRect(px - 1.2f * dp, top - 2 * dp, px + 1.2f * dp, bot + 2 * dp, p);
        }
        linea(c, x(startMs), lockA, AZUL, AZUL_O, true);
        linea(c, x(endMs), lockB, ROJO, ROJO_O, false);
        // textos de arriba: tiempo y cuánto queda
        p.setStyle(Paint.Style.FILL);
        p.setColor(dark ? Color.WHITE : Color.BLACK);
        p.setTextSize(11.5f * dp);
        String izq = fmt(posMs) + " / " + fmt(durMs);
        String der = "Queda " + fmt(endMs - startMs) + (zoom > 1.05f ? String.format(Locale.US, " · lupa x%.0f", zoom) : "");
        c.drawText(izq, L + 26 * dp, yArriba() + 4 * dp, p);
        c.drawText(der, R - 26 * dp - p.measureText(der), yArriba() + 4 * dp, p);
    }

    /** Una línea con su punto abajo (cortar aquí) y su punto arriba (candado). Si está fuera de vista: flecha al borde. */
    private void linea(Canvas c, float lx, boolean fija, int color, int oscuro, boolean azul) {
        float L = pad(), R = getWidth() - pad();
        if (lx < L - 1 || lx > R + 1) {
            // fuera de la vista: flecha en el borde para que no se pierda
            float bx = lx < L ? L - 4 * dp : R + 4 * dp;
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawCircle(bx, (yTop() + yBot()) / 2f, 12 * dp, p);
            p.setColor(Color.WHITE);
            p.setTextSize(13 * dp);
            String f = lx < L ? "◀" : "▶";
            c.drawText(f, bx - p.measureText(f) / 2f, (yTop() + yBot()) / 2f + 5 * dp, p);
            return;
        }
        if (!fija) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawRect(lx - 3 * dp, yArriba(), lx + 3 * dp, yAbajo(), p);
            // punto de abajo: cortar aquí
            c.drawCircle(lx, yAbajo(), rAbajo(), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * dp);
            p.setColor(Color.WHITE);
            c.drawCircle(lx, yAbajo(), rAbajo(), p);
        }
        // punto de arriba: candado
        p.setStyle(Paint.Style.FILL);
        p.setColor(oscuro);
        float r = fija ? rArriba() * 0.85f : rArriba();
        c.drawCircle(lx, yArriba(), r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * dp);
        p.setColor(Color.WHITE);
        c.drawCircle(lx, yArriba(), r, p);
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(11 * dp);
        String ic = fija ? "🔒" : "🔓";
        c.drawText(ic, lx - p.measureText(ic) / 2f, yArriba() + 4 * dp, p);
    }

    /** Qué hay debajo del dedo: 11/12 punto abajo azul/rojo, 21/22 candado azul/rojo, 1/2 línea, 31/32 flecha de borde, 3 cinta. */
    private int queToca(float tx, float ty) {
        float xa = x(startMs), xb = x(endMs), L = pad(), R = getWidth() - pad();
        float tol = 24 * dp;
        boolean va = xa >= L - 1 && xa <= R + 1, vb = xb >= L - 1 && xb <= R + 1;
        if (!va && Math.abs(tx - (xa < L ? L : R)) < tol) return 31;
        if (!vb && Math.abs(tx - (xb < L ? L : R)) < tol) return 32;
        float da = Math.abs(tx - xa), db = Math.abs(tx - xb);
        boolean azul = va && da < tol && (da <= db || !vb);
        boolean rojo = vb && db < tol && !azul;
        if (ty <= yTop()) {
            if (azul) return 21;
            if (rojo) return 22;
        }
        if (ty >= yBot()) {
            if (azul && !lockA) return 11;
            if (rojo && !lockB) return 12;
        }
        if (azul && !lockA) return 1;
        if (rojo && !lockB) return 2;
        return 3;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (durMs <= 0) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                downX = e.getX(); downY = e.getY();
                movio = false;
                toque = queToca(downX, downY);
                drag = (toque == 1 || toque == 2 || toque == 3) ? toque : 0;
                if (drag == 3) move(e.getX());
                break;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    pinch = true;
                    drag = 0;
                    toque = 0;
                    pz0 = zoom;
                    ps0 = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
                    pm0 = ms((e.getX(0) + e.getX(1)) / 2f);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(e.getX() - downX) > 8 * dp) movio = true;
                if (pinch) {
                    if (e.getPointerCount() >= 2) pinchTo(e);
                } else if (drag != 0 && (drag == 3 || movio)) move(e.getX());
                break;
            case MotionEvent.ACTION_UP:
                if (!pinch && !movio) tocar(toque);
                pinch = false;
                drag = 0;
                toque = 0;
                break;
            case MotionEvent.ACTION_CANCEL:
                drag = 0;
                toque = 0;
                pinch = false;
                break;
        }
        return true;
    }

    /** Un toque corto sobre un punto. */
    private void tocar(int t) {
        switch (t) {
            case 11: // punto azul de abajo: la línea azul salta a donde está el video
                startMs = Math.max(0, Math.min(posMs, endMs - 100));
                avisarCorte();
                break;
            case 12: // punto rojo de abajo
                endMs = Math.min(durMs, Math.max(posMs, startMs + 100));
                avisarCorte();
                break;
            case 21:
                lockA = !lockA;
                if (listener != null) listener.onLock(lockA, lockB);
                break;
            case 22:
                lockB = !lockB;
                if (listener != null) listener.onLock(lockA, lockB);
                break;
            case 31:
                verEn(startMs);
                if (listener != null) listener.onSeek(startMs);
                break;
            case 32:
                verEn(endMs);
                if (listener != null) listener.onSeek(endMs);
                break;
        }
        invalidate();
    }

    private void avisarCorte() {
        if (listener != null) listener.onTrim(startMs, endMs);
        performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
    }

    /** Dos dedos: el momento que quedó entre los dedos se queda debajo de ellos mientras acerca o aleja. */
    private void pinchTo(MotionEvent e) {
        float sp = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
        zoom = Math.max(1f, Math.min(256f, pz0 * sp / ps0));
        float fx = (e.getX(0) + e.getX(1)) / 2f;
        float w = Math.max(1, getWidth() - 2 * pad());
        long v = vis();
        long st = pm0 - (long) ((fx - pad()) / w * v);
        viewStart = Math.max(0, Math.min(st, durMs - v));
        invalidate();
    }

    private void move(float xx) {
        long m = ms(xx);
        if (drag == 1 && !lockA) {
            startMs = Math.max(0, Math.min(m, endMs - 100));
            if (listener != null) { listener.onTrim(startMs, endMs); listener.onSeek(startMs); }
        } else if (drag == 2 && !lockB) {
            endMs = Math.min(durMs, Math.max(m, startMs + 100));
            if (listener != null) { listener.onTrim(startMs, endMs); listener.onSeek(endMs); }
        } else if (drag == 3) {
            posMs = m;
            if (listener != null) listener.onSeek(m);
        }
        invalidate();
    }

    public static String fmt(long ms) {
        if (ms < 0) ms = 0;
        return String.format(Locale.US, "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10);
    }
}
