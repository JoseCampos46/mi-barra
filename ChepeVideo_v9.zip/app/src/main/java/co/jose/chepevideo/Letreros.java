package co.jose.chepevideo;

import android.content.Context;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Versión 4: letreros con Gemini. Se le manda el sonido del video (por pedazos de 4 minutos) y Gemini
 * devuelve lo que dicen, con su tiempo y su traducción. Mucho mejor que el reconocimiento del celular
 * con canciones y música de fondo. Necesita internet y la llave gratis de Gemini (la misma de Mi Barra).
 */
final class Letreros {

    static final String PAGINA_LLAVE = "https://aistudio.google.com/apikey";
    private static final String[] MODELOS = {"gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash"};

    private Letreros() {}

    static String llave(Context c) {
        return limpiar(c.getSharedPreferences("gemini", Context.MODE_PRIVATE).getString("llave", ""));
    }

    static void guardarLlave(Context c, String k) {
        c.getSharedPreferences("gemini", Context.MODE_PRIVATE).edit().putString("llave", limpiar(k)).apply();
    }

    /** Las llaves nuevas empiezan por «AQ.» (con punto) y las viejas por «AIza»; se quitan espacios y puntos sueltos al final. */
    static String limpiar(String k) {
        if (k == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("AIza[0-9A-Za-z_\\-]{35}").matcher(k);
        if (m.find()) return m.group();
        m = java.util.regex.Pattern.compile("AQ\\.[0-9A-Za-z_\\-.]+").matcher(k);
        String r = m.find() ? m.group() : k.replaceAll("\\s+", "");
        while (r.endsWith(".")) r = r.substring(0, r.length() - 1);
        return r;
    }

    interface Avance { void decir(String s); }

    /** pcm = sonido a 16 000 por segundo, de un canal. inicioMs = dónde empieza ese sonido en el video. */
    static List<Proj.Sub> hacer(Context c, short[] pcm, long inicioMs, boolean ingles, Avance av) throws Exception {
        String llave = llave(c);
        if (llave.length() < 20) throw new Exception("Falta la llave de Gemini");
        List<Proj.Sub> todos = new ArrayList<>();
        int pedazo = 16000 * 240; // 4 minutos
        int n = (pcm.length + pedazo - 1) / pedazo;
        for (int k = 0; k < n; k++) {
            int a = k * pedazo, b = Math.min(pcm.length, a + pedazo);
            if (av != null) av.decir("💬 Gemini escuchando " + (k + 1) + " de " + n + "…");
            byte[] wav = wav(pcm, a, b);
            long base = inicioMs + a * 1000L / 16000L;
            JSONArray arr = pedir(llave, wav, ingles);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String t = o.optString("texto", "").trim();
                if (t.isEmpty()) continue;
                long s0 = base + Math.round(o.optDouble("inicio", 0) * 1000);
                long s1 = base + Math.round(o.optDouble("fin", o.optDouble("inicio", 0) + 2) * 1000);
                if (s1 <= s0) s1 = s0 + 1500;
                todos.add(new Proj.Sub(s0, s1, t, o.optString("traduccion", "").trim()));
            }
        }
        return todos;
    }

    private static JSONArray pedir(String llave, byte[] wav, boolean ingles) throws Exception {
        String orden = "Escucha este audio (puede tener música o ser una canción). Escribe lo que se dice o se canta, "
                + "en frases cortas de máximo 8 palabras, con su tiempo exacto en segundos desde el inicio de este audio. "
                + (ingles ? "El audio está en inglés: 'texto' en inglés y 'traduccion' al español de Colombia, natural."
                          : "El audio está en español: 'texto' en español y 'traduccion' al inglés.")
                + " Si no hay voz, devuelve una lista vacía. Responde SOLO con JSON: "
                + "[{\"inicio\":0.0,\"fin\":2.5,\"texto\":\"...\",\"traduccion\":\"...\"}]";
        JSONObject cuerpo = new JSONObject();
        JSONArray partes = new JSONArray()
                .put(new JSONObject().put("inline_data", new JSONObject().put("mime_type", "audio/wav")
                        .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
                .put(new JSONObject().put("text", orden));
        cuerpo.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", partes)));
        cuerpo.put("generationConfig", new JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"));
        String ultimo = "No se pudieron hacer los letreros";
        for (String modelo : MODELOS) {
            for (int forma = 0; forma < 2; forma++) {
                String dir = "https://generativelanguage.googleapis.com/v1beta/models/" + modelo + ":generateContent";
                if (forma == 1) dir += "?key=" + java.net.URLEncoder.encode(llave, "UTF-8");
                HttpURLConnection con = (HttpURLConnection) new URL(dir).openConnection();
                con.setConnectTimeout(15000);
                con.setReadTimeout(120000);
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                if (forma == 0) con.setRequestProperty("x-goog-api-key", llave);
                try (OutputStream o = con.getOutputStream()) { o.write(cuerpo.toString().getBytes(StandardCharsets.UTF_8)); }
                int cod = con.getResponseCode();
                String resp = leer(cod >= 400 ? con.getErrorStream() : con.getInputStream());
                if (cod == 404) { ultimo = "Gemini cambió los modelos (404)"; break; }
                if ((cod == 400 || cod == 401 || cod == 403) && forma == 0 && llave.startsWith("AQ.")) continue;
                if (cod == 401 || cod == 403 || resp.contains("API_KEY_INVALID")) throw new Exception("Google no aceptó la llave de Gemini");
                if (cod == 429) throw new Exception("Gemini está ocupado o se acabó el permiso gratis del momento; espere un minuto");
                if (cod >= 400) { ultimo = "Gemini respondió " + cod; break; }
                JSONObject r = new JSONObject(resp);
                JSONArray cand = r.optJSONArray("candidates");
                if (cand == null || cand.length() == 0) return new JSONArray();
                JSONArray ps = cand.getJSONObject(0).optJSONObject("content") == null ? null
                        : cand.getJSONObject(0).getJSONObject("content").optJSONArray("parts");
                StringBuilder sb = new StringBuilder();
                if (ps != null) for (int i = 0; i < ps.length(); i++) if (!ps.getJSONObject(i).optBoolean("thought")) sb.append(ps.getJSONObject(i).optString("text"));
                String t = sb.toString().trim();
                int i0 = t.indexOf('['), i1 = t.lastIndexOf(']');
                if (i0 < 0 || i1 < i0) return new JSONArray();
                return new JSONArray(t.substring(i0, i1 + 1));
            }
        }
        throw new Exception(ultimo);
    }

    /** Arma un WAV (16 bits, un canal, 16 000 por segundo) del pedazo [a, b). */
    private static byte[] wav(short[] pcm, int a, int b) {
        int n = Math.max(0, b - a), datos = n * 2;
        byte[] out = new byte[44 + datos];
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(out).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        bb.put("RIFF".getBytes(StandardCharsets.US_ASCII)).putInt(36 + datos).put("WAVE".getBytes(StandardCharsets.US_ASCII));
        bb.put("fmt ".getBytes(StandardCharsets.US_ASCII)).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(16000).putInt(32000).putShort((short) 2).putShort((short) 16);
        bb.put("data".getBytes(StandardCharsets.US_ASCII)).putInt(datos);
        for (int i = a; i < b; i++) bb.putShort(pcm[i]);
        return out;
    }

    private static String leer(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (InputStream i = in) {
            byte[] buf = new byte[8192];
            int k;
            while ((k = i.read(buf)) > 0) bo.write(buf, 0, k);
        }
        return bo.toString("UTF-8");
    }
}
