package co.jose.chepevideo;

import androidx.media3.common.C;
import androidx.media3.common.audio.BaseAudioProcessor;

import java.nio.ByteBuffer;

/** Versión 5: pone silencio antes del sonido, para que un pedazo de la pista morada empiece donde él lo puso. */
public final class Retraso extends BaseAudioProcessor {

    private final long ms;
    private boolean hecho;

    public Retraso(long ms) { this.ms = Math.max(0, ms); }

    @Override
    protected AudioFormat onConfigure(AudioFormat in) throws UnhandledAudioFormatException {
        if (in.encoding != C.ENCODING_PCM_16BIT) throw new UnhandledAudioFormatException(in);
        return in;
    }

    @Override
    public void queueInput(ByteBuffer in) {
        int ch = Math.max(1, inputAudioFormat.channelCount);
        int silencio = 0;
        if (!hecho) {
            hecho = true;
            silencio = (int) (ms * inputAudioFormat.sampleRate / 1000L) * 2 * ch;
        }
        int n = in.remaining();
        ByteBuffer out = replaceOutputBuffer(silencio + n);
        for (int i = 0; i < silencio; i++) out.put((byte) 0);
        out.put(in);
        out.flip();
    }

    @Override
    protected void onReset() { hecho = false; }
}
