package co.jose.djchepe;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** El DJ en vivo: dos platos, empate en el golpe, botonera, frenar plato, eco, scratch, su voz y grabar. */
public final class Engine implements Runnable {

    public static final int SR = 44100;

    public static final class Deck {
        public final short[] d;
        public final int frames, sr;
        public final String name;
        public final float bpm;
        public final double firstBeat, lead, end;
        public final float[] wave; // picos cada 100 ms
        volatile double pos;
        volatile double rate = 1, rateTarget = 1;

        public Deck(String n, Dec.Pcm p) {
            name = n;
            d = p.d;
            frames = p.frames;
            sr = p.sr;
            double[] a = Beat.analyze(p.d, p.frames, p.sr);
            bpm = (float) a[0];
            firstBeat = a[1];
            lead = a[2];
            end = a[3];
            int bin = Math.max(1, sr / 10);
            int nb = Math.max(1, frames / bin);
            wave = new float[nb];
            for (int b = 0; b < nb; b++) {
                int m = 0;
                int s0 = b * bin * 2, s1 = Math.min(frames * 2, s0 + bin * 2);
                for (int k = s0; k < s1; k += 4) m = Math.max(m, Math.abs(d[k]));
                wave[b] = m / 32768f;
            }
        }

        public double lenSec() { return (double) frames / sr; }
        public double posSec() { return pos / sr; }
    }

    private final Object lock = new Object();
    private volatile boolean running = true, playing = false;
    public volatile Deck cur, nxt, inc;
    private volatile int incDelay = 0;
    private int xfPos = 0, xfLen = 1;
    public volatile float xfSec = 6f;
    private volatile boolean mixReq, brakeReq, scratchReq, echoReq, voiceReq;
    private boolean braking;
    private double brake = 1;
    private int brakeHold, scratchLeft, scratchTotal, echoLeft;
    private final float[] dl = new float[SR * 2], dr = new float[SR * 2];
    private int di = 0, delayLen = SR / 2;
    private final int vdLen = (int) (SR * 0.23);
    private final float[] vd = new float[vdLen];
    private int vi = 0;
    private volatile short[] voice;
    private int voicePos = -1;
    private float duck = 1f;
    private final short[][] padData;
    private final ConcurrentLinkedQueue<Integer> padQueue = new ConcurrentLinkedQueue<>();
    private final ArrayList<int[]> padsOn = new ArrayList<>();
    private volatile Recorder rec;
    private final Thread th;

    public Engine(short[][] pads) {
        padData = pads;
        th = new Thread(this, "dj");
        th.setPriority(Thread.MAX_PRIORITY);
        th.start();
    }

    // ---------------- órdenes desde la pantalla

    public void setVoice(short[] v) { voice = v; }
    public boolean hasVoice() { return voice != null; }
    public void setNext(Deck d) { nxt = d; }
    public boolean isPlaying() { return playing; }
    public boolean isMixing() { return inc != null; }
    public boolean isRecording() { return rec != null; }

    public void play() { synchronized (lock) { playing = true; lock.notifyAll(); } }
    public void pause() { playing = false; }
    public void mixNow() { mixReq = true; }
    public void brakeNow() { brakeReq = true; }
    public void scratch() { scratchReq = true; }
    public void echo() { echoReq = true; }
    public void sonar() { voiceReq = true; }

    public void pad(int i) {
        if (i == Synth.SCRATCH && cur != null && playing) { scratch(); return; }
        padQueue.add(i);
        if (!playing) play();
    }

    /** Si nada sonaba, deja el plato listo para arrancar con la siguiente. */
    public void skipToNext() {
        cur = null;
        inc = null;
    }

    public void startRec(File f) throws Exception {
        if (rec != null) return;
        Recorder r = new Recorder(f);
        rec = r;
        r.start();
    }

    public File stopRec() {
        Recorder r = rec;
        rec = null;
        if (r == null) return null;
        r.stopAndWait();
        return r.file;
    }

    public void release() {
        running = false;
        synchronized (lock) { lock.notifyAll(); }
        stopRec();
    }

    // ---------------- motor

    @Override
    public void run() {
        int n = 1024;
        int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack at = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(Math.max(min, n * 4 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        short[] out = new short[n * 2];
        boolean trackPlaying = false;
        while (running) {
            if (!playing) {
                if (trackPlaying) { at.pause(); at.flush(); trackPlaying = false; }
                synchronized (lock) {
                    while (!playing && running) {
                        try { lock.wait(); } catch (InterruptedException ignored) {}
                    }
                }
                if (!running) break;
            }
            if (!trackPlaying) { at.play(); trackPlaying = true; }
            render(out, n);
            at.write(out, 0, n * 2);
            Recorder r = rec;
            if (r != null) r.feed(out.clone());
        }
        try { at.stop(); } catch (Exception ignored) {}
        at.release();
    }

    private float rl, rr;

    private void read(Deck d, double r) {
        double p = d.pos;
        int i = (int) p;
        if (i < 0) { i = 0; p = 0; }
        if (i + 1 >= d.frames) { rl = 0; rr = 0; d.pos = d.frames; return; }
        float t = (float) (p - i);
        int b = i * 2;
        rl = (d.d[b] + (d.d[b + 2] - d.d[b]) * t) / 32768f;
        rr = (d.d[b + 1] + (d.d[b + 3] - d.d[b + 1]) * t) / 32768f;
        double np = p + r * d.sr / SR;
        d.pos = Math.max(0, np);
    }

    private static double closeRatio(double r) {
        double best = r;
        for (double c : new double[]{r, r * 2, r / 2})
            if (Math.abs(c - 1) < Math.abs(best - 1)) best = c;
        return best;
    }

    private void startMix() {
        Deck a = cur, b = nxt;
        if (a == null || b == null || inc != null) return;
        nxt = null;
        double ratio = closeRatio(a.bpm * a.rate / b.bpm);
        b.rate = (ratio > 0.92 && ratio < 1.08) ? ratio : 1.0;
        b.rateTarget = b.rate;
        double period = 60.0 / a.bpm;
        double t = a.posSec();
        double k = Math.ceil((t - a.firstBeat) / period + 0.001);
        double nextBeat = a.firstBeat + k * period;
        double delay = (nextBeat - t) / Math.max(0.05, a.rate);
        if (delay < 0.05) delay += period / Math.max(0.05, a.rate);
        b.pos = b.firstBeat * b.sr;
        xfLen = Math.max(SR / 4, (int) (xfSec * SR));
        xfPos = 0;
        incDelay = (int) (delay * SR);
        inc = b;
    }

    private void endBrake() {
        braking = false;
        brakeHold = 0;
        brake = 1;
        inc = null;
        Deck b = nxt;
        cur = null;
        if (b != null) {
            nxt = null;
            b.rate = 1;
            b.rateTarget = 1;
            b.pos = b.firstBeat * b.sr;
            cur = b;
        }
    }

    private void render(short[] out, int n) {
        if (cur == null && inc == null && nxt != null && !braking) {
            Deck b = nxt;
            nxt = null;
            b.pos = b.lead * b.sr;
            b.rate = 1;
            b.rateTarget = 1;
            cur = b;
        }
        if (mixReq) { mixReq = false; startMix(); }
        Deck c0 = cur;
        if (inc == null && c0 != null && nxt != null && !braking) {
            double remain = (c0.end - c0.posSec()) / Math.max(0.05, c0.rate);
            if (remain <= xfSec + 0.6) startMix();
        }
        if (brakeReq) { brakeReq = false; if (cur != null && !braking) { braking = true; brake = 1; brakeHold = 0; } }
        if (scratchReq) { scratchReq = false; scratchTotal = scratchLeft = (int) (SR * 0.9); }
        if (echoReq) {
            echoReq = false;
            echoLeft = SR * 3;
            Deck c = cur;
            double beat = c != null ? 60.0 / (c.bpm * c.rate) : 0.5;
            delayLen = Math.max(2000, Math.min(SR * 2 - 1, (int) (SR * beat * 0.75)));
            di %= delayLen;
        }
        if (voiceReq) { voiceReq = false; if (voice != null) voicePos = 0; }
        Integer pq;
        while ((pq = padQueue.poll()) != null) padsOn.add(new int[]{pq, 0});

        for (int i = 0; i < n; i++) {
            float L = 0, R = 0;
            double bf = 1;
            if (braking) {
                brake -= 1.0 / (SR * 1.7);
                if (brake <= 0) {
                    brake = 0;
                    if (++brakeHold > SR / 4) endBrake();
                }
                bf = brake * brake;
            }
            double sf = 1;
            if (scratchLeft > 0) {
                double t = (double) (scratchTotal - scratchLeft) / SR;
                sf = 1 + 2.4 * Math.sin(2 * Math.PI * 3.4 * t);
                scratchLeft--;
            }
            Deck a = cur;
            Deck b = inc;
            if (a != null) {
                float g = 1f;
                if (b != null && incDelay <= 0) g = (float) Math.cos(Math.min(1.0, (double) xfPos / xfLen) * Math.PI / 2);
                read(a, a.rate * bf * sf);
                L += rl * g;
                R += rr * g;
                if (a.pos >= a.frames - 2) {
                    if (b != null) { incDelay = 0; cur = b; inc = null; b.rateTarget = 1; }
                    else cur = null;
                }
            }
            if (b != null && inc == b) {
                if (incDelay > 0) incDelay--;
                else {
                    float g = (float) Math.sin(Math.min(1.0, (double) xfPos / xfLen) * Math.PI / 2);
                    read(b, b.rate);
                    L += rl * g;
                    R += rr * g;
                    if (++xfPos >= xfLen) { cur = b; inc = null; b.rateTarget = 1; }
                }
            }
            for (int k = padsOn.size() - 1; k >= 0; k--) {
                int[] p = padsOn.get(k);
                short[] s = padData[p[0]];
                if (p[1] >= s.length) { padsOn.remove(k); continue; }
                float v = s[p[1]++] / 32768f * 0.85f;
                L += v;
                R += v;
            }
            float v = 0;
            if (voicePos >= 0) {
                short[] vo = voice;
                if (vo != null && voicePos < vo.length) v = vo[voicePos++] / 32768f * 1.25f;
                else voicePos = -1;
            }
            float vy = v + vd[vi] * 0.38f;
            vd[vi] = vy;
            if (++vi >= vdLen) vi = 0;
            float duckT = voicePos >= 0 ? 0.33f : 1f;
            duck += (duckT - duck) * 0.0006f;
            L = L * duck + vy;
            R = R * duck + vy;
            float el = dl[di], er = dr[di];
            float inL = 0, inR = 0;
            if (echoLeft > 0) { inL = L; inR = R; echoLeft--; }
            dl[di] = inL + er * 0.45f;
            dr[di] = inR + el * 0.45f;
            if (++di >= delayLen) di = 0;
            L += el * 0.55f;
            R += er * 0.55f;
            out[2 * i] = clip(L * 0.85f);
            out[2 * i + 1] = clip(R * 0.85f);
        }
        Deck c = cur;
        if (c != null && inc == null && !braking && Math.abs(c.rate - c.rateTarget) > 1e-4) {
            double stepR = (double) n / (SR * 10.0) * 0.08;
            double diff = c.rateTarget - c.rate;
            c.rate += Math.signum(diff) * Math.min(Math.abs(diff), stepR);
        }
    }

    private static short clip(float x) {
        if (x > 1f) x = 1f; else if (x < -1f) x = -1f;
        return (short) (x * 32767f);
    }

    // ---------------- grabar la mezcla

    static final class Recorder implements Runnable {
        final File file;
        final Aac aac;
        final LinkedBlockingQueue<short[]> q = new LinkedBlockingQueue<>();
        volatile boolean stop;
        Thread t;

        Recorder(File f) throws Exception { file = f; aac = new Aac(f, 192000); }

        void start() { t = new Thread(this, "grabar"); t.start(); }

        void feed(short[] b) { q.add(b); }

        void stopAndWait() {
            stop = true;
            try { t.join(15000); } catch (InterruptedException ignored) {}
        }

        @Override
        public void run() {
            try {
                while (!stop || !q.isEmpty()) {
                    short[] b = q.poll(100, TimeUnit.MILLISECONDS);
                    if (b != null) aac.write(b, 0, b.length / 2);
                }
            } catch (Exception ignored) {
            } finally {
                aac.finish();
            }
        }
    }
}
