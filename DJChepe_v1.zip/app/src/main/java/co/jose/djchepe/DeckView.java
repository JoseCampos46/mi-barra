package co.jose.djchepe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;

/** Los dos platos: el que suena y el que sigue. */
public class DeckView extends View {

    public String curName = "—", nxtName = "—", center = "";
    public float curBpm, nxtBpm;
    public boolean playing, mixing;
    public Runnable onTap;
    private float angle = 0;
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);

    public DeckView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        tp.setTypeface(Typeface.DEFAULT_BOLD);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF26215C);
        c.drawRoundRect(0, 0, w, h, 10 * dp, 10 * dp, p);
        if (playing) angle += 9f;
        float r = Math.min(h * 0.34f, w * 0.17f);
        float cy = h * 0.42f;
        drawPlate(c, w * 0.22f, cy, r, 0xFFAFA9EC, playing && !mixing ? angle : (mixing ? angle : 0));
        drawPlate(c, w * 0.78f, cy, r, 0xFFED93B1, mixing ? angle * 1.02f : 0);
        tp.setTextSize(12 * dp);
        tp.setColor(0xFFCECBF6);
        drawLabel(c, curName, (curBpm > 0 ? String.format(java.util.Locale.US, "Ritmo %.0f", curBpm) : ""), w * 0.22f, cy + r + 16 * dp, w * 0.42f);
        tp.setColor(0xFFF4C0D1);
        drawLabel(c, "Sigue: " + nxtName, (nxtBpm > 0 ? String.format(java.util.Locale.US, "Ritmo %.0f", nxtBpm) : ""), w * 0.78f, cy + r + 16 * dp, w * 0.42f);
        tp.setColor(0xFFFAC775);
        tp.setTextSize(13 * dp);
        float cw = tp.measureText(center);
        c.drawText(center, (w - cw) / 2f, cy + 5 * dp, tp);
        if (playing) postInvalidateOnAnimation();
    }

    private void drawLabel(Canvas c, String a, String b, float cx, float y, float maxW) {
        CharSequence s = TextUtils.ellipsize(a, tp, maxW, TextUtils.TruncateAt.END);
        float sw = tp.measureText(s, 0, s.length());
        c.drawText(s, 0, s.length(), cx - sw / 2f, y, tp);
        float bw = tp.measureText(b);
        c.drawText(b, cx - bw / 2f, y + 15 * dp, tp);
    }

    private void drawPlate(Canvas c, float cx, float cy, float r, int col, float ang) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3 * dp);
        p.setColor(col);
        c.drawCircle(cx, cy, r, p);
        p.setStrokeWidth(1 * dp);
        p.setColor(0x55FFFFFF);
        c.drawCircle(cx, cy, r * 0.72f, p);
        c.drawCircle(cx, cy, r * 0.5f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        c.drawCircle(cx, cy, r * 0.24f, p);
        double a = Math.toRadians(ang);
        p.setColor(Color.WHITE);
        c.drawCircle(cx + (float) Math.cos(a) * r * 0.85f, cy + (float) Math.sin(a) * r * 0.85f, 3 * dp, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_UP && onTap != null) onTap.run();
        return true;
    }
}
