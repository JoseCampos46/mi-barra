package co.jose.djchepe;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SonicAudioProcessor;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Trabajos que se hacen aparte: mezclar dos, cortar discos, convertir, guardar un pedazo. */
public final class Jobs {

    public interface Prog { void p(String msg); }

    static final int SR = 44100;

    // ---------------------------------------------------------------- Mezclar 2

    /** Junta dos canciones al mismo ritmo y las va intercalando cada segBeats tiempos. Devuelve segundos. */
    public static double mashup(Context ctx, Uri ua, Uri ub, int segBeats, File out, Prog pr) throws Exception {
        pr.p("Abriendo canción A…");
        Dec.Pcm A = Dec.decodeStereo(ctx, ua, 480);
        pr.p("Abriendo canción B…");
        Dec.Pcm B = Dec.decodeStereo(ctx, ub, 480);
        if (A.frames < SR || B.frames < SR) throw new Exception("una de las canciones está vacía");
        pr.p("Buscando el ritmo…");
        double[] a = Beat.analyze(A.d, A.frames, A.sr);
        double[] b = Beat.analyze(B.d, B.frames, B.sr);
        double r = a[0] / b[0];
        double best = r;
        for (double c : new double[]{r, r * 2, r / 2}) if (Math.abs(c - 1) < Math.abs(best - 1)) best = c;
        r = Math.max(0.8, Math.min(1.25, best));
        double posA = a[1] * A.sr, posB = b[1] * B.sr;
        double stepA = (double) A.sr / SR, stepB = r * B.sr / SR;
        double beatOut = 60.0 / a[0];
        long segF = Math.max(SR, (long) (segBeats * beatOut * SR));
        double h = 0.05 * SR;
        Aac w = new Aac(out, 192000);
        short[] buf = new short[4096 * 2];
        long o = 0;
        int bi = 0;
        long lastMsg = 0;
        try {
            while (posA < A.frames - 2 && posB < B.frames - 2) {
                long k = (long) (o + h) % (2 * segF);
                double x = k;
                double gA;
                double d2 = x - segF;
                if (Math.abs(d2) < h) gA = 0.5 - 0.5 * (d2 / h);
                else if (x < h) gA = 0.5 + 0.5 * (x / h);
                else if (x > 2 * segF - h) gA = 0.5 - 0.5 * ((2 * segF - x) / h);
                else gA = x < segF ? 1 : 0;
                float ga = (float) Math.sin(gA * Math.PI / 2), gb = (float) Math.cos(gA * Math.PI / 2);
                float fade = o < SR / 2 ? (float) o / (SR / 2f) : 1f;
                int ia = (int) posA, ib = (int) posB;
                float ta = (float) (posA - ia), tb = (float) (posB - ib);
                float la = lerp(A.d[2 * ia], A.d[2 * ia + 2], ta), ra = lerp(A.d[2 * ia + 1], A.d[2 * ia + 3], ta);
                float lb = lerp(B.d[2 * ib], B.d[2 * ib + 2], tb), rb = lerp(B.d[2 * ib + 1], B.d[2 * ib + 3], tb);
                buf[2 * bi] = sat((la * ga + lb * gb) * fade);
                buf[2 * bi + 1] = sat((ra * ga + rb * gb) * fade);
                if (++bi == 4096) { w.write(buf, 0, bi); bi = 0; }
                posA += stepA;
                posB += stepB;
                o++;
                if (o - lastMsg > SR * 10L) { lastMsg = o; pr.p("Mezclando… " + (o / SR) + " s"); }
            }
            if (bi > 0) w.write(buf, 0, bi);
        } finally {
            w.finish();
        }
        return (double) o / SR;
    }

    private static float lerp(short x, short y, float t) { return x + (y - x) * t; }

    private static short sat(float v) {
        if (v > 32767f) v = 32767f; else if (v < -32768f) v = -32768f;
        return (short) v;
    }

    // ---------------------------------------------------------------- Cortar discos

    public static final class Disc {
        public float[] env; // cada 50 ms
        public long durMs;
        public final List<Long> cuts = new ArrayList<>();
    }

    /** Busca dónde termina cada canción. */
    public static Disc findCuts(Context ctx, Uri uri) throws Exception {
        Disc d = new Disc();
        d.env = Dec.envelope(ctx, uri, 50);
        d.durMs = d.env.length * 50L;
        int n = d.env.length;
        if (n < 200) return d;
        float peak = 0;
        for (float v : d.env) peak = Math.max(peak, v);
        float[] s = d.env.clone();
        Arrays.sort(s);
        float floor = s[(int) (n * 0.05f)];
        float thr = Math.max(Math.max(peak * 0.025f, floor * 1.8f), 0.002f);
        int run = 0;
        for (int i = 0; i < n; i++) {
            if (d.env[i] < thr) run++;
            else {
                if (run >= 18) {
                    long mid = (i - run / 2) * 50L;
                    if (mid > 20000 && mid < d.durMs - 20000) d.cuts.add(mid);
                }
                run = 0;
            }
        }
        if (d.cuts.isEmpty() && d.durMs > 8 * 60_000L) {
            // disco sin silencios: busca donde baja más el volumen, cada 2 minutos o más
            int win = 40;
            float[] sm = new float[n];
            for (int i = 0; i < n; i++) {
                float a = 0;
                int c = 0;
                for (int k = Math.max(0, i - win); k < Math.min(n, i + win); k++) { a += d.env[k]; c++; }
                sm[i] = a / Math.max(1, c);
            }
            float med = s[n / 2];
            int i = 2400;
            while (i < n - 2400) {
                int bestI = -1;
                float bestV = med * 0.55f;
                for (int k = i; k < Math.min(n - 1200, i + 2400); k++) if (sm[k] < bestV) { bestV = sm[k]; bestI = k; }
                if (bestI < 0) { i += 2400; continue; }
                d.cuts.add(bestI * 50L);
                i = bestI + 2400;
            }
        }
        return d;
    }

    /** Corta el disco en canciones. Devuelve los archivos (en caché) listos para guardar. */
    public static List<File> cutDisc(Context ctx, Uri uri, List<Long> cuts, long durMs, File dir, String base, Prog pr) throws Exception {
        List<Long> b = new ArrayList<>();
        b.add(0L);
        for (Long c : cuts) if (c > 0 && c < durMs) b.add(c);
        b.add(durMs + 2000);
        java.util.Collections.sort(b);
        Dec.Info info = Dec.info(ctx, uri);
        boolean lossless = "audio/mp4a-latm".equals(info.mime);
        List<File> files = new ArrayList<>();
        for (int i = 0; i + 1 < b.size(); i++) {
            long s = b.get(i), e = b.get(i + 1);
            if (e - s < 1000) continue;
            File f = new File(dir, String.format(java.util.Locale.US, "%s_%02d.m4a", base, files.size() + 1));
            pr.p("Cortando canción " + (files.size() + 1) + " de " + (b.size() - 1) + "…");
            if (lossless) copyAac(ctx, uri, s * 1000, e * 1000, f);
            else saveRange(ctx, uri, s, e, false, 192000, f);
            files.add(f);
        }
        return files;
    }

    private static void copyAac(Context ctx, Uri uri, long sUs, long eUs, File out) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(ctx, uri, null);
        int ti = -1;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if (m != null && m.startsWith("audio/")) { ti = i; break; }
        }
        if (ti < 0) { ex.release(); throw new Exception("sin sonido"); }
        ex.selectTrack(ti);
        MediaFormat f = ex.getTrackFormat(ti);
        if (out.exists()) out.delete();
        MediaMuxer mx = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int t = mx.addTrack(f);
        mx.start();
        ex.seekTo(sUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
        ByteBuffer buf = ByteBuffer.allocate(1 << 20);
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        long first = -1;
        try {
            while (true) {
                int sz = ex.readSampleData(buf, 0);
                if (sz < 0) break;
                long ts = ex.getSampleTime();
                if (ts >= eUs) break;
                if (ts >= sUs - 25000) {
                    if (first < 0) first = ts;
                    int fl = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    bi.set(0, sz, ts - first, fl);
                    mx.writeSampleData(t, buf, bi);
                }
                ex.advance();
            }
        } finally {
            try { mx.stop(); } catch (Exception ignored) {}
            mx.release();
            ex.release();
        }
    }

    // ---------------------------------------------------------------- guardar un pedazo (tonos y su voz)

    public static void saveRange(Context ctx, Uri uri, long sMs, long eMs, boolean fades, int bitrate, File out) throws Exception {
        final Aac w = new Aac(out, bitrate);
        final Resampler rs = new Resampler();
        final long total = Math.max(1, (eMs - sMs) * SR / 1000);
        final long[] done = {0};
        final int fadeF = fades ? (int) (SR * 0.4) : 0;
        try {
            Dec.stream(ctx, uri, sMs * 1000, eMs * 1000, (buf, frames, ch, sr) -> {
                short[] o = rs.process(buf, frames, ch, sr);
                int n = rs.frames;
                if (fadeF > 0) {
                    for (int i = 0; i < n; i++) {
                        long p = done[0] + i;
                        float g = 1f;
                        if (p < fadeF) g = (float) p / fadeF;
                        if (total - p < fadeF) g = Math.min(g, Math.max(0f, (float) (total - p) / fadeF));
                        o[2 * i] = (short) (o[2 * i] * g);
                        o[2 * i + 1] = (short) (o[2 * i + 1] * g);
                    }
                }
                done[0] += n;
                w.write(o, 0, n);
            });
        } finally {
            w.finish();
        }
    }

    // ---------------------------------------------------------------- Convertir y limpiar silencios

    /** Devuelve {segundosAntes, segundosDespués}. */
    public static double[] convert(Context ctx, Uri uri, float speed, boolean clean, float pauseSec, int bitrate, File out, Prog pr) throws Exception {
        float thr = 0;
        if (clean) {
            pr.p("Buscando los silencios…");
            float[] env = Dec.envelope(ctx, uri, 20);
            if (env.length > 0) {
                float[] s = env.clone();
                Arrays.sort(s);
                float peak = s[s.length - 1];
                thr = Math.max(Math.max(s[(int) (s.length * 0.1f)] * 1.8f, peak * 0.012f), 0.003f);
                thr = Math.min(thr, peak * 0.2f);
            }
        }
        final float fthr = thr;
        final Aac w = new Aac(out, bitrate);
        final Resampler rs = new Resampler();
        final SonicAudioProcessor son = speed != 1f ? new SonicAudioProcessor() : null;
        if (son != null) {
            son.setSpeed(speed);
            son.configure(new AudioProcessor.AudioFormat(SR, 2, C.ENCODING_PCM_16BIT));
            son.flush();
        }
        final int block = SR / 50; // 20 ms
        final int keepF = (int) (pauseSec * SR);
        final short[] acc = new short[block * 2];
        final int[] accN = {0};
        final long[] silent = {0};
        final long[] inFrames = {0};
        final long[] lastMsg = {0};
        pr.p("Convirtiendo…");
        try {
            Dec.stream(ctx, uri, 0, 0, (buf, frames, ch, sr) -> {
                short[] o = rs.process(buf, frames, ch, sr);
                int n = rs.frames;
                inFrames[0] += n;
                for (int i = 0; i < n; i++) {
                    acc[2 * accN[0]] = o[2 * i];
                    acc[2 * accN[0] + 1] = o[2 * i + 1];
                    if (++accN[0] == block) {
                        boolean keep = true;
                        if (fthr > 0) {
                            double e = 0;
                            for (int k = 0; k < block * 2; k++) e += (double) acc[k] * acc[k];
                            float rms = (float) (Math.sqrt(e / (block * 2)) / 32768.0);
                            if (rms < fthr) { silent[0] += block; keep = silent[0] <= keepF; }
                            else silent[0] = 0;
                        }
                        if (keep) push(acc, block, son, w);
                        accN[0] = 0;
                    }
                }
                if (inFrames[0] - lastMsg[0] > SR * 30L) { lastMsg[0] = inFrames[0]; pr.p("Convirtiendo… " + (inFrames[0] / SR / 60) + " min"); }
            });
            if (accN[0] > 0) push(acc, accN[0], son, w);
            if (son != null) {
                son.queueEndOfStream();
                int guard = 0;
                while (!son.isEnded() && guard++ < 10000) drainSonic(son, w);
            }
        } finally {
            w.finish();
        }
        return new double[]{(double) inFrames[0] / SR, (double) w.framesWritten() / SR};
    }

    private static void push(short[] d, int frames, SonicAudioProcessor son, Aac w) {
        if (son == null) { w.write(d, 0, frames); return; }
        ByteBuffer in = ByteBuffer.allocateDirect(frames * 4).order(ByteOrder.nativeOrder());
        for (int k = 0; k < frames * 2; k++) in.putShort(d[k]);
        in.flip();
        son.queueInput(in);
        drainSonic(son, w);
    }

    private static void drainSonic(SonicAudioProcessor son, Aac w) {
        ByteBuffer o = son.getOutput();
        int n = o.remaining() / 2;
        if (n <= 0) return;
        short[] s = new short[n];
        ShortBuffer sb = o.order(ByteOrder.nativeOrder()).asShortBuffer();
        sb.get(s, 0, n);
        o.position(o.limit());
        w.write(s, 0, n / 2);
    }

    private Jobs() {}
}
