package co.jose.djchepe;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final int P_L = 0xFFEEEDFE, P_D = 0xFF534AB7, P_T = 0xFF3C3489, P_DARK = 0xFF26215C;
    static final int REQ_FOLDER = 1, REQ_TONE = 2, REQ_DISC = 3, REQ_A = 4, REQ_B = 5, REQ_CONV = 6, REQ_VOICE = 7;
    static final String[] TABS = {"🎛 DJ", "🔀 Mezclar 2", "✂ Cortar discos", "🔔 Tonos", "🧹 Convertir"};

    private Engine engine;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private boolean landscape, padsVisible = true, loading, busy, keepOn;
    private int tab = 0;

    private final List<Uri> songs = new ArrayList<>();
    private final List<String> names = new ArrayList<>();
    private final List<Integer> order = new ArrayList<>();
    private int orderPos = 0;
    private String nxtLoadingName = null;

    private LinearLayout root, tabsRow, djBox, padsBox;
    private FrameLayout content;
    private TextView statusView;
    private final List<TextView> tabBtns = new ArrayList<>();
    private final LinearLayout[] panels = new LinearLayout[5];
    private ScrollView padsScroll;

    private DeckView deck;
    private WaveView djWave, toneWave, discWave;
    private TextView bSonar, bPlay, bMix, bRec;
    private GridLayout padsGrid;
    private Engine.Deck shownDeck;

    // tonos / mi voz
    private Uri toneUri;
    private String toneName = "";
    private boolean voiceMode;
    private boolean toneFades = true;
    private Uri lastTone;
    // discos
    private Uri discUri;
    private String discName = "";
    private Jobs.Disc disc;
    // mezclar 2
    private Uri uA, uB;
    private String nA = "", nB = "";
    private int segBeats = 16;
    private Uri lastMix;
    // convertir
    private Uri convUri;
    private String convName = "";
    private float convSpeed = 1f, convPause = 0.3f;
    private boolean convClean = true;
    private int convKbps = 160;
    private String convResult = "";
    // vista previa
    private MediaPlayer prev;
    private long prevStopAt = -1;
    private WaveView prevWave;

    // ------------------------------------------------------------ inicio

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("dj", MODE_PRIVATE);
        engine = new Engine(Synth.all());
        engine.xfSec = prefs.getFloat("xf", 6f);
        landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        buildViews();
        showTab(0);
        loadVoice();
        String tree = prefs.getString("tree", null);
        if (tree != null) listFolder(Uri.parse(tree));
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() { onTick(); ui.postDelayed(this, 100); }
    };

    @Override protected void onResume() { super.onResume(); ui.removeCallbacks(tick); ui.post(tick); }

    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(tick); stopPreview(); }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        final File f = engine.isRecording() ? engine.stopRec() : null;
        engine.release();
        if (f != null) saveRecording(f);
        exec.shutdown();
        loader.shutdown();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        landscape = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        buildDj();
    }

    // ------------------------------------------------------------ ayudas de pantalla

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    private TextView chip(String label, boolean active, Runnable r) {
        TextView t = tv(label, 14, active ? Color.WHITE : P_T, true);
        t.setBackground(round(active ? P_D : P_L, 18));
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView lab(String s) {
        TextView t = tv(s, 13, Color.BLACK, true);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        return t;
    }

    /** Fila de botones que se desliza de lado si no cabe. */
    private View row(View... vs) {
        LinearLayout r = hbox();
        r.setPadding(dp(8), dp(4), dp(8), dp(4));
        for (View v : vs) if (v != null) { detach(v); r.addView(v); }
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(r);
        return h;
    }

    private static void detach(View v) {
        ViewParent p = v.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(v);
    }

    private View waveRow(WaveView w) {
        LinearLayout r = hbox();
        r.setPadding(dp(6), dp(2), dp(6), dp(2));
        TextView minus = bigBtn("−", P_L, P_T, w::zoomOut);
        TextView plus = bigBtn("+", P_L, P_T, w::zoomIn);
        detach(w);
        r.addView(minus, new LinearLayout.LayoutParams(dp(38), dp(56)));
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(0, dp(86), 1f);
        wl.setMargins(dp(4), 0, dp(4), 0);
        r.addView(w, wl);
        r.addView(plus, new LinearLayout.LayoutParams(dp(38), dp(56)));
        return r;
    }

    private TextView bigBtn(String s, int bg, int fg, Runnable r) {
        TextView t = tv(s, 20, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(bg, 10));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void status(String s) {
        if (s == null || s.isEmpty()) { statusView.setVisibility(View.GONE); return; }
        statusView.setText(s);
        statusView.setVisibility(View.VISIBLE);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }

    private static String fmt(long ms) { return WaveView.fmt(ms); }

    private String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        String s = u.getLastPathSegment();
        return s == null ? "audio" : s;
    }

    private static String base(String n) {
        int i = n.lastIndexOf('.');
        String b = i > 0 ? n.substring(0, i) : n;
        return b.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    // ------------------------------------------------------------ armar pantalla

    private void buildViews() {
        root = vbox();
        root.setBackgroundColor(Color.WHITE);
        LinearLayout top = hbox();
        top.setPadding(dp(10), dp(6), dp(8), dp(4));
        top.addView(tv("🎛 DJ Chepe Gallego", 18, Color.BLACK, true));
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        statusView = tv("", 12, P_T, true);
        statusView.setBackground(round(P_L, 8));
        statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
        statusView.setVisibility(View.GONE);
        top.addView(statusView);
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        tabsRow = hbox();
        tabsRow.setPadding(dp(8), dp(2), dp(8), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            TextView t = chip(TABS[i], i == 0, () -> showTab(k));
            tabBtns.add(t);
            tabsRow.addView(t);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(tabsRow);
        root.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        for (int i = 0; i < 5; i++) panels[i] = vbox();

        deck = new DeckView(this);
        deck.onTap = () -> { if (landscape) { padsVisible = !padsVisible; padsScroll.setVisibility(padsVisible ? View.VISIBLE : View.GONE); } };
        djWave = new WaveView(this);
        djWave.mode = WaveView.PLAY;
        djWave.listener = new WaveView.Listener() {
            @Override public void onSeek(long ms) {}
            @Override public void onChanged() {}
        };
        bSonar = bigBtn("📣 Sonar", 0xFFEF9F27, 0xFF412402, this::onSonar);
        bSonar.setTextSize(17);
        bPlay = bigBtn("▶ Tocar", P_L, P_T, this::onPlay);
        bPlay.setTextSize(14);
        bMix = bigBtn("⏭ Mezclar ya", P_L, P_T, this::onMixNow);
        bMix.setTextSize(14);
        bRec = bigBtn("⏺ Grabar", 0xFFE24B4A, Color.WHITE, this::onRec);
        bRec.setTextSize(14);

        padsGrid = new GridLayout(this);
        String[] pn = {"Bombo", "Redoblante", "Platillo", "Maracas", "Silbato", "Corneta", "Scratch", "Sirena", "Frenar plato", "Eco", "📁 Carpeta", "🎙 Mi voz"};
        int[] pid = {Synth.BOMBO, Synth.REDOBLANTE, Synth.PLATILLO, Synth.MARACAS, Synth.SILBATO, Synth.CORNETA, Synth.SCRATCH, Synth.SIRENA, -1, -2, -3, -4};
        for (int i = 0; i < pn.length; i++) {
            final int id = pid[i];
            int bg, fg;
            if (i < 4) { bg = 0xFFFAECE7; fg = 0xFF712B13; }
            else if (i < 8) { bg = 0xFFE1F5EE; fg = 0xFF085041; }
            else { bg = P_L; fg = P_T; }
            TextView t = bigBtn(pn[i], bg, fg, () -> onPad(id));
            t.setTextSize(13);
            if (i == 8 || i == 9) {
                GradientDrawable g = round(bg, 10);
                g.setStroke(dp(2), P_D);
                t.setBackground(g);
            }
            padsGrid.addView(t);
        }
        padsScroll = new ScrollView(this);
        djBox = vbox();
        panels[0].addView(djBox, new LinearLayout.LayoutParams(-1, -1));
        buildDj();

        toneWave = new WaveView(this);
        toneWave.mode = WaveView.RANGE;
        toneWave.dark = false;
        toneWave.listener = new WaveView.Listener() {
            @Override public void onSeek(long ms) { if (prev != null && prevWave == toneWave) stopPreview(); }
            @Override public void onChanged() { refreshTone(); }
        };
        discWave = new WaveView(this);
        discWave.mode = WaveView.MARKS;
        discWave.dark = false;
        discWave.listener = new WaveView.Listener() {
            @Override public void onSeek(long ms) {}
            @Override public void onChanged() { refreshDisc(); }
        };
        setContentView(root);
    }

    private void buildDj() {
        if (djBox == null) return;
        djBox.removeAllViews();
        detach(padsGrid);
        padsScroll.removeAllViews();
        for (View v : new View[]{deck, bSonar, bPlay, bMix, bRec}) detach(v);
        int cols = landscape ? 3 : 4;
        padsGrid.setColumnCount(cols);
        for (int i = 0; i < padsGrid.getChildCount(); i++) {
            View v = padsGrid.getChildAt(i);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(landscape ? 48 : 54);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            v.setLayoutParams(lp);
        }
        LinearLayout tr = hbox();
        tr.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, dp(56), 2f);
        l2.setMarginEnd(dp(5));
        tr.addView(bSonar, l2);
        for (TextView t : new TextView[]{bPlay, bMix, bRec}) {
            LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, dp(56), 1.3f);
            l1.setMarginEnd(dp(5));
            tr.addView(t, l1);
        }
        View xf = row(chip("Empate: " + Math.round(engine.xfSec) + " s", false, this::cycleXf),
                lab(songs.isEmpty() ? "Toque 📁 Carpeta para escoger la música" : songs.size() + " canciones en la carpeta"));
        if (!landscape) {
            ScrollView sv = new ScrollView(this);
            LinearLayout col = vbox();
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(170));
            dl.setMargins(dp(8), dp(4), dp(8), dp(2));
            col.addView(deck, dl);
            col.addView(waveRow(djWave));
            col.addView(tr);
            col.addView(xf);
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
            gl.setMargins(dp(5), 0, dp(5), dp(8));
            col.addView(padsGrid, gl);
            sv.addView(col);
            djBox.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        } else {
            LinearLayout h = hbox();
            h.setGravity(Gravity.TOP);
            LinearLayout left = vbox();
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 0, 1f);
            dl.setMargins(dp(8), dp(2), dp(4), dp(2));
            left.addView(deck, dl);
            left.addView(waveRow(djWave));
            left.addView(tr);
            h.addView(left, new LinearLayout.LayoutParams(0, -1, 1f));
            LinearLayout right = vbox();
            right.addView(xf);
            right.addView(padsGrid, new LinearLayout.LayoutParams(-1, -2));
            padsScroll.addView(right);
            padsScroll.setVisibility(padsVisible ? View.VISIBLE : View.GONE);
            h.addView(padsScroll, new LinearLayout.LayoutParams(dp(300), -1));
            djBox.addView(h, new LinearLayout.LayoutParams(-1, -1));
        }
    }

    private void showTab(int k) {
        tab = k;
        for (int i = 0; i < tabBtns.size(); i++) {
            TextView t = tabBtns.get(i);
            t.setBackground(round(i == k ? P_D : P_L, 18));
            t.setTextColor(i == k ? Color.WHITE : P_T);
        }
        content.removeAllViews();
        detach(panels[k]);
        if (k == 0) {
            content.addView(panels[0], new FrameLayout.LayoutParams(-1, -1));
        } else {
            ScrollView sv = new ScrollView(this);
            sv.addView(panels[k]);
            content.addView(sv, new FrameLayout.LayoutParams(-1, -1));
            if (k == 1) refreshMix2();
            else if (k == 2) refreshDisc();
            else if (k == 3) refreshTone();
            else refreshConv();
        }
    }

    // ------------------------------------------------------------ DJ

    private void onTick() {
        Engine.Deck c = engine.cur;
        Engine.Deck n = engine.nxt;
        Engine.Deck in = engine.inc;
        deck.playing = engine.isPlaying() && c != null;
        deck.mixing = in != null;
        deck.curName = c != null ? c.name : (engine.isPlaying() ? "Cargando…" : "—");
        deck.curBpm = c != null ? c.bpm * (float) c.rate : 0;
        Engine.Deck shownNext = in != null ? in : n;
        deck.nxtName = shownNext != null ? shownNext.name : (nxtLoadingName != null ? "cargando…" : "—");
        deck.nxtBpm = shownNext != null ? shownNext.bpm : 0;
        deck.center = in != null ? "Mezclando…" : "Empate " + Math.round(engine.xfSec) + " s";
        deck.invalidate();
        if (c != null) {
            if (c != shownDeck) { shownDeck = c; djWave.setWave(c.wave, 100, (long) (c.lenSec() * 1000)); }
            djWave.setPos((long) (c.posSec() * 1000));
        }
        bPlay.setText(engine.isPlaying() ? "⏸ Pausa" : "▶ Tocar");
        if (engine.isPlaying() && n == null && !loading && !songs.isEmpty()) loadNext();
        if (prev != null && prevWave != null) {
            try {
                if (prev.isPlaying()) {
                    long p = prev.getCurrentPosition();
                    prevWave.setPos(p);
                    if (prevStopAt > 0 && p >= prevStopAt) stopPreview();
                }
            } catch (Exception ignored) {}
        }
        boolean on = engine.isPlaying();
        if (on != keepOn) {
            keepOn = on;
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        if (engine.isRecording()) bRec.setText("⏹ Parar");
        else bRec.setText("⏺ Grabar");
    }

    private void onPlay() {
        if (songs.isEmpty()) { toast("Primero escoja la carpeta de música 📁"); pickFolder(); return; }
        stopPreview();
        if (engine.isPlaying()) engine.pause();
        else { engine.play(); if (engine.nxt == null && engine.cur == null) loadNext(); }
    }

    private void onMixNow() {
        if (engine.cur == null) { onPlay(); return; }
        if (engine.nxt == null) { toast("Todavía estoy cargando la siguiente canción"); return; }
        engine.mixNow();
    }

    private void onSonar() {
        if (!engine.hasVoice()) { toast("Primero escoja su voz en 🎙 Mi voz"); startVoice(); return; }
        engine.sonar();
        if (!engine.isPlaying()) engine.play();
    }

    private void onRec() {
        if (engine.isRecording()) {
            final File f = engine.stopRec();
            if (f != null) saveRecording(f);
            return;
        }
        try {
            engine.startRec(new File(getCacheDir(), "grabando.m4a"));
            toast("⏺ Grabando la mezcla. Toque ⏹ Parar para guardarla");
            if (!engine.isPlaying()) onPlay();
        } catch (Exception e) {
            toast("No se pudo grabar: " + e.getMessage());
        }
    }

    private void saveRecording(final File f) {
        final String name = "MiMezcla_" + stamp() + ".m4a";
        exec.execute(() -> {
            String msg;
            try {
                Store.saveFile(this, f, "Mezclas", name, "audio/mp4");
                msg = "✅ Mezcla guardada en Descargas/MiBarra/DJChepeGallego/Mezclas";
            } catch (Exception e) {
                msg = "No se pudo guardar la mezcla: " + e.getMessage();
            }
            f.delete();
            final String m = msg;
            ui.post(() -> toast(m));
        });
    }

    private void cycleXf() {
        float[] v = {3f, 6f, 9f, 12f};
        int i = 0;
        for (int k = 0; k < v.length; k++) if (Math.abs(v[k] - engine.xfSec) < 0.1f) i = k;
        engine.xfSec = v[(i + 1) % v.length];
        prefs.edit().putFloat("xf", engine.xfSec).apply();
        buildDj();
    }

    private void onPad(int id) {
        if (id >= 0) { engine.pad(id); return; }
        if (id == -1) { if (engine.cur == null) toast("No hay canción sonando"); else engine.brakeNow(); }
        else if (id == -2) engine.echo();
        else if (id == -3) pickFolder();
        else startVoice();
    }

    private void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        try { startActivityForResult(i, REQ_FOLDER); } catch (Exception e) { toast("No se pudo abrir el escogedor de carpetas"); }
    }

    private void listFolder(final Uri tree) {
        status("📁 Buscando canciones…");
        loader.execute(() -> {
            final List<Uri> us = new ArrayList<>();
            final List<String> ns = new ArrayList<>();
            try {
                walk(tree, DocumentsContract.getTreeDocumentId(tree), us, ns, 0);
            } catch (Exception ignored) {}
            ui.post(() -> {
                status(null);
                songs.clear();
                names.clear();
                songs.addAll(us);
                names.addAll(ns);
                order.clear();
                orderPos = 0;
                if (songs.isEmpty()) toast("No encontré canciones en esa carpeta");
                else toast("🎵 " + songs.size() + " canciones listas");
                buildDj();
            });
        });
    }

    private void walk(Uri tree, String docId, List<Uri> us, List<String> ns, int depth) {
        if (depth > 4 || us.size() > 3000) return;
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        try (Cursor c = getContentResolver().query(kids, new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String id = c.getString(0), mime = c.getString(1), name = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) { walk(tree, id, us, ns, depth + 1); continue; }
                String low = name == null ? "" : name.toLowerCase(Locale.US);
                boolean audio = (mime != null && mime.startsWith("audio/")) || low.endsWith(".mp3") || low.endsWith(".m4a")
                        || low.endsWith(".aac") || low.endsWith(".wav") || low.endsWith(".ogg") || low.endsWith(".flac") || low.endsWith(".opus");
                if (audio) { us.add(DocumentsContract.buildDocumentUriUsingTree(tree, id)); ns.add(base(name)); }
            }
        } catch (Exception ignored) {}
    }

    private void loadNext() {
        if (loading || songs.isEmpty()) return;
        if (orderPos >= order.size()) {
            order.clear();
            for (int i = 0; i < songs.size(); i++) order.add(i);
            Collections.shuffle(order);
            orderPos = 0;
        }
        final int idx = order.get(orderPos++);
        final Uri u = songs.get(idx);
        final String nm = names.get(idx);
        loading = true;
        nxtLoadingName = nm;
        loader.execute(() -> {
            Engine.Deck d = null;
            try { d = new Engine.Deck(nm, Dec.decodeStereo(this, u, 600)); } catch (Throwable ignored) {}
            final Engine.Deck fd = d;
            ui.post(() -> {
                loading = false;
                nxtLoadingName = null;
                if (fd != null && fd.frames > Engine.SR * 5) engine.setNext(fd);
                else if (songs.size() > 1) loadNext();
            });
        });
    }

    // ------------------------------------------------------------ Mi voz

    private void startVoice() {
        voiceMode = true;
        toneUri = null;
        toneName = "";
        toneWave.setWave(null, 100, 0);
        showTab(3);
        pick(REQ_VOICE, "audio/*");
    }

    private File voiceFile() { return new File(getFilesDir(), "mivoz.m4a"); }

    private void loadVoice() {
        final File f = voiceFile();
        if (!f.exists()) return;
        loader.execute(() -> {
            try {
                Dec.Pcm p = Dec.decodeStereo(this, Uri.fromFile(f), 20);
                Resampler rs = new Resampler();
                short[] st = rs.process(p.d, p.frames, 2, p.sr);
                int n = rs.frames;
                short[] mono = new short[n];
                for (int i = 0; i < n; i++) mono[i] = (short) ((st[2 * i] + st[2 * i + 1]) / 2);
                engine.setVoice(mono);
            } catch (Exception ignored) {}
        });
    }

    // ------------------------------------------------------------ archivos

    private void pick(int req, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        try { startActivityForResult(i, req); } catch (Exception e) { toast("No se pudo abrir el escogedor de archivos"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == REQ_FOLDER) {
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            prefs.edit().putString("tree", u.toString()).apply();
            listFolder(u);
            return;
        }
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        switch (req) {
            case REQ_TONE: case REQ_VOICE: openTone(u); break;
            case REQ_DISC: openDisc(u); break;
            case REQ_A: uA = u; nA = nameOf(u); refreshMix2(); break;
            case REQ_B: uB = u; nB = nameOf(u); refreshMix2(); break;
            case REQ_CONV: convUri = u; convName = nameOf(u); convResult = ""; refreshConv(); break;
        }
    }

    // ------------------------------------------------------------ vista previa

    private void preview(Uri u, long fromMs, long toMs, WaveView w) {
        stopPreview();
        try {
            MediaPlayer m = new MediaPlayer();
            m.setDataSource(this, u);
            m.prepare();
            m.seekTo(fromMs, MediaPlayer.SEEK_CLOSEST);
            m.start();
            m.setOnCompletionListener(mp -> stopPreview());
            prev = m;
            prevWave = w;
            prevStopAt = toMs;
        } catch (Exception e) {
            toast("No se pudo oír: " + e.getMessage());
        }
    }

    private void stopPreview() {
        if (prev != null) {
            try { prev.stop(); } catch (Exception ignored) {}
            try { prev.release(); } catch (Exception ignored) {}
        }
        prev = null;
        prevWave = null;
        prevStopAt = -1;
    }

    private void loadWave(final Uri u, final WaveView w, final Runnable after) {
        status("Leyendo el sonido…");
        busy = true;
        exec.execute(() -> {
            float[] env = null;
            try { env = Dec.envelope(this, u, 50); } catch (Exception ignored) {}
            final float[] fe = env;
            ui.post(() -> {
                busy = false;
                status(null);
                if (fe == null || fe.length == 0) { toast("No pude leer ese archivo"); return; }
                float m = 1e-6f;
                for (float v : fe) m = Math.max(m, v);
                float[] nw = new float[fe.length];
                for (int i = 0; i < fe.length; i++) nw[i] = fe[i] / m * 0.62f;
                w.setWave(nw, 50, fe.length * 50L);
                if (after != null) after.run();
            });
        });
    }

    // ------------------------------------------------------------ Tonos

    private void openTone(Uri u) {
        toneUri = u;
        toneName = nameOf(u);
        lastTone = null;
        loadWave(u, toneWave, () -> {
            long d = toneWave.durMs;
            if (voiceMode) { toneWave.selStart = 0; toneWave.selEnd = Math.min(d, 4000); }
            else { toneWave.selStart = Math.min(d / 3, Math.max(0, d - 30000)); toneWave.selEnd = Math.min(d, toneWave.selStart + 30000); }
            toneWave.posMs = toneWave.selStart;
            refreshTone();
        });
        refreshTone();
    }

    private void refreshTone() {
        LinearLayout p = panels[3];
        p.removeAllViews();
        p.addView(row(chip(voiceMode ? "🎙 Mi voz" : "🔔 Tono", true, null),
                chip(voiceMode ? "Cambiar a: hacer tono" : "Cambiar a: mi voz", false, () -> { voiceMode = !voiceMode; refreshTone(); })));
        p.addView(row(chip(voiceMode ? "📂 Escoger audio de mi voz" : "📂 Escoger canción", toneUri == null,
                () -> pick(voiceMode ? REQ_VOICE : REQ_TONE, "audio/*")), lab(toneName)));
        if (voiceMode) p.addView(row(lab("Deje solo donde usted dice \"DJ Chepe Gallego\"")));
        p.addView(waveRow(toneWave));
        if (toneUri == null) return;
        p.addView(row(
                chip("⏮ Inicio aquí", false, () -> { toneWave.selStart = Math.min(toneWave.posMs, toneWave.selEnd - 200); toneWave.invalidate(); refreshTone(); }),
                chip("Fin aquí ⏭", false, () -> { toneWave.selEnd = Math.max(toneWave.posMs, toneWave.selStart + 200); toneWave.invalidate(); refreshTone(); }),
                chip("▶ Oír pedazo", false, () -> preview(toneUri, toneWave.selStart, toneWave.selEnd, toneWave)),
                chip("⏹", false, this::stopPreview)));
        p.addView(row(lab("Desde " + fmt(toneWave.selStart) + " hasta " + fmt(toneWave.selEnd) + " · dura " + fmt(toneWave.selEnd - toneWave.selStart)),
                voiceMode ? null : chip(toneFades ? "Suave al empezar y terminar: Sí" : "Suave al empezar y terminar: No", false, () -> { toneFades = !toneFades; refreshTone(); })));
        if (voiceMode) {
            p.addView(row(chip("💾 Guardar como mi voz", true, this::saveVoice)));
        } else {
            p.addView(row(chip("💾 Guardar tono", true, this::saveTone)));
            if (lastTone != null) {
                p.addView(row(chip("📞 De llamada", false, () -> setTone(RingtoneManager.TYPE_RINGTONE)),
                        chip("⏰ De alarma", false, () -> setTone(RingtoneManager.TYPE_ALARM)),
                        chip("🔔 De mensajes", false, () -> setTone(RingtoneManager.TYPE_NOTIFICATION))));
                p.addView(row(lab("Para WhatsApp: abra WhatsApp › Ajustes › Notificaciones › Tono y escoja este tono")));
            }
        }
    }

    private void saveTone() {
        if (toneUri == null || busy) return;
        final Uri u = toneUri;
        final long s = toneWave.selStart, e = toneWave.selEnd;
        final boolean fades = toneFades;
        final String name = "Tono_" + base(toneName) + "_" + stamp() + ".m4a";
        busy = true;
        status("💾 Guardando el tono…");
        exec.execute(() -> {
            String msg;
            Uri tone = null;
            File f = new File(getCacheDir(), "tono.m4a");
            try {
                Jobs.saveRange(this, u, s, e, fades, 160000, f);
                Store.saveFile(this, f, "Tonos", name, "audio/mp4");
                tone = Store.saveTone(this, f, name);
                msg = "✅ Tono guardado en Descargas/MiBarra/DJChepeGallego/Tonos";
            } catch (Exception ex) {
                msg = "No se pudo guardar el tono: " + ex.getMessage();
            }
            f.delete();
            final String m = msg;
            final Uri ft = tone;
            ui.post(() -> { busy = false; status(null); toast(m); lastTone = ft; refreshTone(); });
        });
    }

    private void setTone(int type) {
        if (lastTone == null) return;
        if (!Settings.System.canWrite(this)) {
            toast("Dele permiso a DJ Chepe Gallego para cambiar los tonos y vuelva a tocar el botón");
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) {}
            return;
        }
        try {
            RingtoneManager.setActualDefaultRingtoneUri(this, type, lastTone);
            toast("✅ Listo, quedó puesto");
        } catch (Exception e) {
            toast("No se pudo poner: " + e.getMessage());
        }
    }

    private void saveVoice() {
        if (toneUri == null || busy) return;
        final Uri u = toneUri;
        final long s = toneWave.selStart, e = Math.min(toneWave.selEnd, toneWave.selStart + 20000);
        busy = true;
        status("🎙 Guardando su voz…");
        exec.execute(() -> {
            String msg;
            File f = voiceFile();
            try {
                Jobs.saveRange(this, u, s, e, false, 160000, f);
                Store.saveFile(this, f, "MiVoz", "MiVoz_" + stamp() + ".m4a", "audio/mp4");
                msg = "✅ Su voz quedó lista. Toque 📣 Sonar en el DJ";
            } catch (Exception ex) {
                msg = "No se pudo guardar su voz: " + ex.getMessage();
            }
            final String m = msg;
            ui.post(() -> { busy = false; status(null); toast(m); loadVoice(); voiceMode = false; showTab(0); });
        });
    }

    // ------------------------------------------------------------ Cortar discos

    private void openDisc(final Uri u) {
        discUri = u;
        discName = nameOf(u);
        disc = null;
        busy = true;
        status("✂ Buscando dónde termina cada canción…");
        refreshDisc();
        exec.execute(() -> {
            Jobs.Disc d = null;
            String err = null;
            try { d = Jobs.findCuts(this, u); } catch (Exception e) { err = e.getMessage(); }
            final Jobs.Disc fd = d;
            final String fe = err;
            ui.post(() -> {
                busy = false;
                status(null);
                if (fd == null) { toast("No pude leer el disco: " + fe); return; }
                disc = fd;
                float m = 1e-6f;
                for (float v : fd.env) m = Math.max(m, v);
                float[] nw = new float[fd.env.length];
                for (int i = 0; i < fd.env.length; i++) nw[i] = fd.env[i] / m * 0.62f;
                discWave.setWave(nw, 50, fd.durMs);
                discWave.marks.clear();
                discWave.marks.addAll(fd.cuts);
                toast("Encontré " + (fd.cuts.size() + 1) + " canciones. Revise las marcas");
                refreshDisc();
            });
        });
    }

    private void refreshDisc() {
        LinearLayout p = panels[2];
        p.removeAllViews();
        p.addView(row(chip("📂 Escoger disco", discUri == null, () -> pick(REQ_DISC, "audio/*")), lab(discName)));
        p.addView(waveRow(discWave));
        if (disc == null) {
            p.addView(row(lab("Escoja un archivo con varias canciones seguidas")));
            return;
        }
        p.addView(row(
                chip("▶ Oír aquí", false, () -> preview(discUri, Math.max(0, discWave.posMs - 1500), -1, discWave)),
                chip("⏹", false, this::stopPreview),
                chip("➕ Marca aquí", false, () -> {
                    discWave.marks.add(discWave.posMs);
                    Collections.sort(discWave.marks);
                    discWave.selMark = discWave.marks.indexOf(discWave.posMs);
                    discWave.invalidate();
                    refreshDisc();
                }),
                chip("🗑 Quitar marca", false, () -> {
                    int i = discWave.selMark;
                    if (i >= 0 && i < discWave.marks.size()) { discWave.marks.remove(i); discWave.selMark = -1; discWave.invalidate(); refreshDisc(); }
                    else toast("Primero toque una marca amarilla");
                })));
        p.addView(row(chip("✂ Cortar todo (" + (discWave.marks.size() + 1) + " canciones)", true, this::cutDisc)));
        p.addView(row(lab("Toque una marca amarilla para escogerla y muévala con el dedo")));
    }

    private void cutDisc() {
        if (discUri == null || disc == null || busy) return;
        final Uri u = discUri;
        final List<Long> cuts = new ArrayList<>(discWave.marks);
        final long dur = disc.durMs;
        final String b = base(discName);
        busy = true;
        status("✂ Cortando…");
        exec.execute(() -> {
            String msg;
            File dir = new File(getCacheDir(), "disco");
            dir.mkdirs();
            try {
                List<File> fs = Jobs.cutDisc(this, u, cuts, dur, dir, b, t -> ui.post(() -> status(t)));
                for (File f : fs) { Store.saveFile(this, f, "Discos/" + b, f.getName(), "audio/mp4"); f.delete(); }
                msg = "✅ " + fs.size() + " canciones en Descargas/MiBarra/DJChepeGallego/Discos/" + b;
            } catch (Exception e) {
                msg = "No se pudo cortar: " + e.getMessage();
            }
            final String m = msg;
            ui.post(() -> { busy = false; status(null); toast(m); });
        });
    }

    // ------------------------------------------------------------ Mezclar 2

    private void refreshMix2() {
        LinearLayout p = panels[1];
        p.removeAllViews();
        p.addView(row(chip("🎵 Canción A", uA == null, () -> pick(REQ_A, "audio/*")), lab(nA)));
        p.addView(row(chip("🎵 Canción B", uB == null, () -> pick(REQ_B, "audio/*")), lab(nB)));
        p.addView(row(lab("Cambia cada:"),
                chip("8 tiempos", segBeats == 8, () -> { segBeats = 8; refreshMix2(); }),
                chip("16 tiempos", segBeats == 16, () -> { segBeats = 16; refreshMix2(); }),
                chip("32 tiempos", segBeats == 32, () -> { segBeats = 32; refreshMix2(); })));
        p.addView(row(chip("🎛 Armar mezcla", true, this::doMashup)));
        p.addView(row(lab("La app iguala el ritmo de B al de A y las va alternando")));
        if (lastMix != null) {
            final Uri m = lastMix;
            p.addView(row(chip("▶ Oír", false, () -> preview(m, 0, -1, null)), chip("⏹", false, this::stopPreview),
                    chip("📤 Compartir", false, () -> share(m))));
        }
    }

    private void doMashup() {
        if (uA == null || uB == null) { toast("Escoja la canción A y la canción B"); return; }
        if (busy) return;
        final Uri a = uA, b = uB;
        final int seg = segBeats;
        final String name = "Mezcla2_" + stamp() + ".m4a";
        busy = true;
        status("🎛 Armando la mezcla…");
        exec.execute(() -> {
            String msg;
            Uri saved = null;
            File f = new File(getCacheDir(), "mezcla2.m4a");
            try {
                double secs = Jobs.mashup(this, a, b, seg, f, t -> ui.post(() -> status(t)));
                saved = Store.saveFile(this, f, "Mezclas", name, "audio/mp4");
                msg = "✅ Mezcla de " + fmt((long) (secs * 1000)) + " guardada en Descargas/MiBarra/DJChepeGallego/Mezclas";
            } catch (Throwable e) {
                msg = "No se pudo mezclar: " + e.getMessage();
            }
            f.delete();
            final String m = msg;
            final Uri fs = saved;
            ui.post(() -> { busy = false; status(null); toast(m); if (fs != null) lastMix = fs; refreshMix2(); });
        });
    }

    private void share(Uri u) {
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("audio/mp4");
        s.putExtra(Intent.EXTRA_STREAM, u);
        s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(s, "Compartir")); } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ Convertir

    private void refreshConv() {
        LinearLayout p = panels[4];
        p.removeAllViews();
        p.addView(row(chip("📂 Escoger audio", convUri == null, () -> pick(REQ_CONV, "audio/*")), lab(convName)));
        p.addView(row(lab("Velocidad:"),
                chip("0.75x", convSpeed == 0.75f, () -> { convSpeed = 0.75f; refreshConv(); }),
                chip("Normal", convSpeed == 1f, () -> { convSpeed = 1f; refreshConv(); }),
                chip("1.25x", convSpeed == 1.25f, () -> { convSpeed = 1.25f; refreshConv(); }),
                chip("1.5x", convSpeed == 1.5f, () -> { convSpeed = 1.5f; refreshConv(); })));
        p.addView(row(chip(convClean ? "🧹 Limpiar silencios: Sí" : "🧹 Limpiar silencios: No", convClean, () -> { convClean = !convClean; refreshConv(); })));
        if (convClean) {
            p.addView(row(lab("Pausa que deja:"),
                    chip("0 s", convPause == 0f, () -> { convPause = 0f; refreshConv(); }),
                    chip("0,3 s", convPause == 0.3f, () -> { convPause = 0.3f; refreshConv(); }),
                    chip("0,5 s", convPause == 0.5f, () -> { convPause = 0.5f; refreshConv(); })));
        }
        p.addView(row(lab("Calidad:"),
                chip("96", convKbps == 96, () -> { convKbps = 96; refreshConv(); }),
                chip("128", convKbps == 128, () -> { convKbps = 128; refreshConv(); }),
                chip("160 ★", convKbps == 160, () -> { convKbps = 160; refreshConv(); }),
                chip("192", convKbps == 192, () -> { convKbps = 192; refreshConv(); })));
        p.addView(row(chip("✅ Convertir", true, this::doConvert)));
        if (!convResult.isEmpty()) {
            TextView r = lab(convResult);
            r.setPadding(dp(14), dp(8), dp(14), dp(8));
            p.addView(r);
        }
    }

    private void doConvert() {
        if (convUri == null) { toast("Escoja el audio"); return; }
        if (busy) return;
        final Uri u = convUri;
        final float sp = convSpeed, pause = convPause;
        final boolean clean = convClean;
        final int br = convKbps * 1000;
        final String name = base(convName) + (clean ? "_limpio" : "") + (sp != 1f ? "_" + sp + "x" : "") + ".m4a";
        busy = true;
        status("🧹 Trabajando…");
        exec.execute(() -> {
            String res;
            File f = new File(getCacheDir(), "convertido.m4a");
            long before = -1;
            try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst()) before = c.getLong(0);
            } catch (Exception ignored) {}
            try {
                double[] r = Jobs.convert(this, u, sp, clean, pause, br, f, t -> ui.post(() -> status(t)));
                long after = f.length();
                Store.saveFile(this, f, "Limpios", name, "audio/mp4");
                res = "✅ Listo: " + name + "\nDuraba " + fmt((long) (r[0] * 1000)) + " → quedó de " + fmt((long) (r[1] * 1000))
                        + (before > 0 ? "\nPesaba " + mb(before) + " → pesa " + mb(after) : "\nPesa " + mb(after))
                        + "\nEn Descargas/MiBarra/DJChepeGallego/Limpios";
            } catch (Throwable e) {
                res = "No se pudo convertir: " + e.getMessage();
            }
            f.delete();
            final String fr = res;
            ui.post(() -> { busy = false; status(null); convResult = fr; refreshConv(); });
        });
    }

    private static String mb(long b) { return String.format(Locale.US, "%.1f MB", b / 1_000_000.0); }
}
