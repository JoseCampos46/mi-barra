package co.jose.djchepe;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.Arrays;

/** Abre cualquier audio (MP3, M4A, AAC, WAV, OGG…) y entrega el sonido crudo. */
public final class Dec {

    public interface Sink { void pcm(short[] buf, int frames, int ch, int sr) throws Exception; }

    public static final class Pcm { public short[] d = new short[0]; public int frames; public int sr = 44100; }

    static final class Stop extends Exception { Stop() { super("stop"); } }

    public static final class Info { public long durUs; public String mime; public int sr, ch; }

    public static Info info(Context ctx, Uri uri) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(ctx, uri, null);
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) {
                    Info in = new Info();
                    in.mime = m;
                    in.durUs = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) : 0;
                    in.sr = f.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
                    in.ch = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
                    return in;
                }
            }
            throw new Exception("el archivo no tiene sonido");
        } finally {
            try { ex.release(); } catch (Exception ignored) {}
        }
    }

    /** Decodifica entre startUs y endUs (endUs <= 0 = hasta el final). */
    public static void stream(Context ctx, Uri uri, long startUs, long endUs, Sink sink) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(ctx, uri, null);
        int ti = -1;
        MediaFormat fmt = null;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat f = ex.getTrackFormat(i);
            String m = f.getString(MediaFormat.KEY_MIME);
            if (m != null && m.startsWith("audio/")) { ti = i; fmt = f; break; }
        }
        if (ti < 0) { ex.release(); throw new Exception("el archivo no tiene sonido"); }
        ex.selectTrack(ti);
        if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        MediaCodec codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
        codec.configure(fmt, null, null, 0);
        codec.start();
        int sr = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
        int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
        boolean isFloat = false;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inDone = false, outDone = false;
        int idle = 0;
        short[] tmp = new short[8192];
        try {
            while (!outDone && idle < 500) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer buf = codec.getInputBuffer(ii);
                        int sz = buf == null ? -1 : ex.readSampleData(buf, 0);
                        long t = ex.getSampleTime();
                        if (sz < 0 || (endUs > 0 && t > endUs)) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, t, 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (of.containsKey(MediaFormat.KEY_PCM_ENCODING))
                        isFloat = of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT;
                } else if (oi >= 0) {
                    idle = 0;
                    long pts = info.presentationTimeUs;
                    if (info.size > 0 && pts >= startUs - 1000 && (endUs <= 0 || pts <= endUs)) {
                        ByteBuffer ob = codec.getOutputBuffer(oi);
                        if (ob != null) {
                            ob.position(info.offset);
                            ob.limit(info.offset + info.size);
                            ByteBuffer s = ob.slice().order(ByteOrder.nativeOrder());
                            int cc = Math.max(1, ch);
                            int n;
                            if (isFloat) {
                                FloatBuffer fb = s.asFloatBuffer();
                                n = fb.remaining();
                                if (tmp.length < n) tmp = new short[n];
                                for (int k = 0; k < n; k++) {
                                    float v = fb.get();
                                    if (v > 1f) v = 1f; else if (v < -1f) v = -1f;
                                    tmp[k] = (short) (v * 32767f);
                                }
                            } else {
                                ShortBuffer sb = s.asShortBuffer();
                                n = sb.remaining();
                                if (tmp.length < n) tmp = new short[n];
                                sb.get(tmp, 0, n);
                            }
                            sink.pcm(tmp, n / cc, cc, sr);
                        }
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                } else if (inDone) {
                    idle++;
                }
            }
        } finally {
            try { codec.stop(); } catch (Exception ignored) {}
            try { codec.release(); } catch (Exception ignored) {}
            try { ex.release(); } catch (Exception ignored) {}
        }
    }

    /** Toda la canción en estéreo (máximo maxSec segundos). */
    public static Pcm decodeStereo(Context ctx, Uri uri, int maxSec) throws Exception {
        final Pcm p = new Pcm();
        p.d = new short[44100 * 2 * 60];
        try {
            stream(ctx, uri, 0, 0, (buf, frames, ch, sr) -> {
                p.sr = sr;
                if ((p.frames + frames) * 2 > p.d.length)
                    p.d = Arrays.copyOf(p.d, Math.max(p.d.length * 2, (p.frames + frames) * 2));
                for (int f = 0; f < frames; f++) {
                    short l = buf[f * ch];
                    short r = ch > 1 ? buf[f * ch + 1] : l;
                    p.d[p.frames * 2] = l;
                    p.d[p.frames * 2 + 1] = r;
                    p.frames++;
                }
                if (p.frames >= (long) maxSec * sr) throw new Stop();
            });
        } catch (Stop ignored) {
        }
        return p;
    }

    /** Fuerza del sonido (0 a 1) cada hopMs milisegundos. */
    public static float[] envelope(Context ctx, Uri uri, final int hopMs) throws Exception {
        final float[][] out = {new float[4096]};
        final int[] n = {0};
        final double[] acc = {0};
        final int[] cnt = {0};
        stream(ctx, uri, 0, 0, (buf, frames, ch, sr) -> {
            int hop = Math.max(1, sr * hopMs / 1000);
            for (int f = 0; f < frames; f++) {
                double v = buf[f * ch];
                if (ch > 1) v = (v + buf[f * ch + 1]) * 0.5;
                acc[0] += v * v;
                if (++cnt[0] >= hop) {
                    if (n[0] >= out[0].length) out[0] = Arrays.copyOf(out[0], out[0].length * 2);
                    out[0][n[0]++] = (float) (Math.sqrt(acc[0] / cnt[0]) / 32768.0);
                    acc[0] = 0;
                    cnt[0] = 0;
                }
            }
        });
        return Arrays.copyOf(out[0], n[0]);
    }

    private Dec() {}
}
