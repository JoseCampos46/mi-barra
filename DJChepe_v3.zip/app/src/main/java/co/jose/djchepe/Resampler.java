package co.jose.djchepe;

/** Pasa cualquier sonido a estéreo de 44.100 Hz, pedazo por pedazo. */
public final class Resampler {

    public static final int OUT = 44100;
    private double frac = 0;
    private short pl, pr;
    private boolean has = false;
    public int frames;

    public short[] process(short[] in, int n, int ch, int sr) {
        double step = (double) sr / OUT;
        int est = (int) ((n + 2) / step) + 4;
        short[] out = new short[est * 2];
        int o = 0;
        double p = has ? frac : 0;
        while (n > 0) {
            int i0 = (int) Math.floor(p);
            if (i0 + 1 > n - 1) break;
            float t = (float) (p - i0);
            float l0 = left(in, i0, ch), l1 = left(in, i0 + 1, ch);
            float r0 = right(in, i0, ch), r1 = right(in, i0 + 1, ch);
            if (o + 1 >= out.length) break;
            out[o++] = (short) (l0 + (l1 - l0) * t);
            out[o++] = (short) (r0 + (r1 - r0) * t);
            p += step;
        }
        if (n > 0) {
            frac = p - n;
            pl = in[(n - 1) * ch];
            pr = ch > 1 ? in[(n - 1) * ch + 1] : pl;
            has = true;
        }
        frames = o / 2;
        return out;
    }

    private float left(short[] in, int i, int ch) { return i < 0 ? pl : in[i * ch]; }

    private float right(short[] in, int i, int ch) { return i < 0 ? pr : (ch > 1 ? in[i * ch + 1] : in[i * ch]); }
}
