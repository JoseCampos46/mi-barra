package co.jose.djchepe;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Guarda en Descargas/MiBarra/DJChepeGallego (si la carpeta no existe, se crea sola). */
public final class Store {

    public static final String BASE = "MiBarra/DJChepeGallego";

    public static Uri saveFile(Context ctx, File src, String sub, String name, String mime) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/" + BASE + (sub.isEmpty() ? "" : "/" + sub));
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        return write(ctx, MediaStore.Downloads.EXTERNAL_CONTENT_URI, v, src);
    }

    /** Copia para que el celular lo pueda usar como tono. */
    public static Uri saveTone(Context ctx, File src, String name) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES + "/DJChepeGallego");
        v.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, 1);
        v.put(MediaStore.Audio.AudioColumns.IS_ALARM, 1);
        v.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, 1);
        v.put(MediaStore.Audio.AudioColumns.IS_MUSIC, 0);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        return write(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v, src);
    }

    private static Uri write(Context ctx, Uri col, ContentValues v, File src) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        Uri u = cr.insert(col, v);
        if (u == null) throw new IOException("no se pudo crear el archivo");
        try (InputStream in = new FileInputStream(src); OutputStream os = cr.openOutputStream(u)) {
            if (os == null) throw new IOException("no se pudo escribir");
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(u, done, null, null);
        return u;
    }

    private Store() {}
}
