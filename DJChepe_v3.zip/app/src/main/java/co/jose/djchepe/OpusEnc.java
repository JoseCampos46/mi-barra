package co.jose.djchepe;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Guarda sonido estéreo como Opus (archivo .opus que WhatsApp lee). Trabaja a 48.000 Hz. */
public final class OpusEnc {

    private static final int SR = 48000;
    private final MediaCodec enc;
    private final MediaMuxer mux;
    private final MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
    private int track = -1;
    private boolean started = false;
    private long framesIn = 0;

    public OpusEnc(File out, int bitrate) throws Exception {
        MediaFormat f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_OPUS, SR, 2);
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS);
        enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        enc.start();
        if (out.exists()) out.delete();
        mux = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG);
    }

    public long framesWritten() { return framesIn; }

    /** d: estéreo intercalado. */
    public void write(short[] d, int offFrames, int frames) {
        int i = 0;
        int guard = 0;
        while (i < frames && guard < 100000) {
            guard++;
            int ii = enc.dequeueInputBuffer(10000);
            if (ii >= 0) {
                ByteBuffer b = enc.getInputBuffer(ii);
                if (b == null) continue;
                b.clear();
                b.order(ByteOrder.nativeOrder());
                int cap = b.remaining() / 4;
                int n = Math.min(cap, frames - i);
                int base = (offFrames + i) * 2;
                for (int k = 0; k < n * 2; k++) b.putShort(d[base + k]);
                long pts = framesIn * 1_000_000L / SR;
                enc.queueInputBuffer(ii, 0, n * 4, pts, 0);
                framesIn += n;
                i += n;
            }
            drain(false);
        }
    }

    private void drain(boolean eos) {
        int guard = 0;
        while (guard++ < 2000) {
            int oi = enc.dequeueOutputBuffer(bi, eos ? 10000 : 0);
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = mux.addTrack(enc.getOutputFormat());
                mux.start();
                started = true;
            } else if (oi >= 0) {
                ByteBuffer ob = enc.getOutputBuffer(oi);
                if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0;
                if (bi.size > 0 && started && ob != null) {
                    ob.position(bi.offset);
                    ob.limit(bi.offset + bi.size);
                    mux.writeSampleData(track, ob, bi);
                }
                enc.releaseOutputBuffer(oi, false);
                if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
            } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!eos) return;
            }
        }
    }

    /** Pasa un M4A (44.100 Hz) a Opus. Si el celular no tiene codificador Opus, lanza error. */
    public static void desdeM4a(android.content.Context ctx, File m4a, File out) throws Exception {
        final OpusEnc e = new OpusEnc(out, 96000);
        final double[] pos = {0};
        final short[][] prev = {null};
        try {
            Dec.stream(ctx, android.net.Uri.fromFile(m4a), 0, 0, (buf, frames, ch, sr) -> {
                // pasa de sr a 48.000 Hz (lineal) en estéreo
                double step = (double) sr / SR;
                int cc = Math.max(1, ch);
                int outN = (int) Math.floor((frames - pos[0]) / step);
                if (outN <= 0) { pos[0] -= frames; return; }
                short[] o = new short[outN * 2];
                for (int k = 0; k < outN; k++) {
                    double p = pos[0] + k * step;
                    int i = (int) p;
                    float t = (float) (p - i);
                    int i2 = Math.min(i + 1, frames - 1);
                    for (int c = 0; c < 2; c++) {
                        int cs = Math.min(c, cc - 1);
                        float a = buf[i * cc + cs], b = buf[i2 * cc + cs];
                        o[k * 2 + c] = (short) (a + (b - a) * t);
                    }
                }
                pos[0] = pos[0] + outN * step - frames;
                e.write(o, 0, outN);
            });
        } finally {
            e.finish();
        }
    }

    public void finish() {
        try {
            int guard = 0;
            while (guard++ < 500) {
                int ii = enc.dequeueInputBuffer(10000);
                if (ii >= 0) {
                    enc.queueInputBuffer(ii, 0, 0, framesIn * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    break;
                }
                drain(false);
            }
            drain(true);
        } catch (Exception ignored) {
        }
        try { enc.stop(); } catch (Exception ignored) {}
        try { enc.release(); } catch (Exception ignored) {}
        try { if (started) mux.stop(); } catch (Exception ignored) {}
        try { mux.release(); } catch (Exception ignored) {}
    }
}
