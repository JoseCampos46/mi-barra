package co.jose.djchepe;

/** Encuentra el ritmo (golpes por minuto), el primer golpe y dónde empieza y termina el sonido. */
public final class Beat {

    /** Devuelve {bpm, primerGolpeSeg, inicioSonidoSeg, finSonidoSeg}. d = estéreo intercalado. */
    public static double[] analyze(short[] d, int frames, int sr) {
        int hop = Math.max(1, sr / 100); // 10 ms
        int nh = frames / hop;
        double len = (double) frames / sr;
        if (nh < 300) return new double[]{120, 0, 0, len};
        float[] e = new float[nh];
        float max = 0;
        for (int h = 0; h < nh; h++) {
            long s = 0;
            int b = h * hop * 2;
            for (int k = 0; k < hop; k++) s += Math.abs(d[b + 2 * k] + d[b + 2 * k + 1]);
            e[h] = s / (float) hop;
            if (e[h] > max) max = e[h];
        }
        float thr = max * 0.04f;
        int lead = 0;
        while (lead < nh && e[lead] < thr) lead++;
        int end = nh - 1;
        while (end > lead && e[end] < thr) end--;

        float[] o = new float[nh];
        for (int h = 1; h < nh; h++) o[h] = Math.max(0, e[h] - e[h - 1]);
        for (int h = nh - 1; h >= 2; h--) o[h] = (o[h] + o[h - 1] + o[h - 2]) / 3f;

        int start = nh > 6000 ? Math.max(lead, nh / 5) : lead;
        int span = Math.min(nh - start - 2, 9000);
        if (span < 300) { start = lead; span = Math.max(300, Math.min(nh - start - 2, 9000)); }
        double bestScore = -1, bestBpm = 120;
        int bestPhase = 0;
        for (int t = 800; t <= 1700; t++) {
            double bpm = t / 10.0;
            double P = 6000.0 / bpm;
            int ip = (int) P;
            for (int ph = 0; ph < ip; ph++) {
                double s = 0;
                for (double k = start + ph; k < start + span; k += P) {
                    int idx = (int) Math.round(k);
                    if (idx >= nh) break;
                    s += o[idx];
                }
                if (s > bestScore) { bestScore = s; bestBpm = bpm; bestPhase = ph; }
            }
        }
        double period = 60.0 / bestBpm;
        double tb = (start + bestPhase) * 0.01;
        double leadS = lead * 0.01;
        double fb = tb - Math.floor((tb - leadS) / period) * period;
        while (fb < leadS - 0.02) fb += period;
        while (fb - period >= leadS - 0.02) fb -= period;
        return new double[]{bestBpm, Math.max(0, fb), leadS, Math.min(len, (end + 1) * 0.01)};
    }

    private Beat() {}
}
