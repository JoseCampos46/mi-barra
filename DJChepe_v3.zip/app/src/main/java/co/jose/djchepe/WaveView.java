package co.jose.djchepe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Dibujo del sonido (ondas) con acercar / alejar.
 * Modo PLAY: solo muestra por dónde va. Modo RANGE: dos manijas (inicio y fin). Modo MARKS: marcas de corte.
 */
public class WaveView extends View {

    public static final int PLAY = 0, RANGE = 1, MARKS = 2;

    public interface Listener {
        void onSeek(long ms);
        void onChanged();
    }

    public Listener listener;
    public int mode = PLAY;
    public float[] wave;
    public long binMs = 100, durMs, posMs, selStart, selEnd;
    public final List<Long> marks = new ArrayList<>();
    public int selMark = -1;
    public int zoom = 1;
    public boolean dark = true;

    private long viewStart;
    private int drag; // 1 inicio, 2 fin, 3 posición, 4 marca
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public WaveView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
    }

    public void setWave(float[] w, long bin, long dur) {
        wave = w;
        binMs = Math.max(1, bin);
        durMs = dur;
        zoom = 1;
        viewStart = 0;
        selStart = 0;
        selEnd = dur;
        selMark = -1;
        invalidate();
    }

    private long vis() { return Math.max(1, durMs / zoom); }

    private void window() {
        long v = vis();
        viewStart = Math.max(0, Math.min(posMs - v / 2, durMs - v));
    }

    private float pad() { return 10 * dp; }

    private float x(long ms) { return pad() + (float) (ms - viewStart) / vis() * (getWidth() - 2 * pad()); }

    private long ms(float xx) {
        long m = viewStart + (long) ((xx - pad()) / Math.max(1, getWidth() - 2 * pad()) * vis());
        return Math.max(0, Math.min(durMs, m));
    }

    public void zoomIn() { if (zoom < 256) zoom *= 2; window(); invalidate(); }

    public void zoomOut() { if (zoom > 1) zoom /= 2; window(); invalidate(); }

    public void setPos(long ms) {
        posMs = ms;
        if (drag == 0 && (ms < viewStart || ms > viewStart + vis())) window();
        invalidate();
    }

    private float cl(float v) { return Math.max(pad(), Math.min(getWidth() - pad(), v)); }

    @Override
    protected void onDraw(Canvas c) {
        float top = 18 * dp, bot = getHeight() - 4 * dp, L = pad(), R = getWidth() - pad();
        float mid = (top + bot) / 2f, half = (bot - top) / 2f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(dark ? 0xFF26215C : 0xFFEEEDFE);
        c.drawRoundRect(L, top, R, bot, 6 * dp, 6 * dp, p);
        p.setTextSize(12.5f * dp);
        p.setColor(dark ? Color.WHITE : Color.BLACK);
        if (wave == null || durMs <= 0) {
            c.drawText("Escoja un archivo", L, 14 * dp, p);
            return;
        }
        if (mode == RANGE) {
            p.setColor(0x445DCAA5);
            c.drawRect(cl(x(selStart)), top, cl(x(selEnd)), bot, p);
        }
        int cols = (int) Math.max(1, (R - L) / (2 * dp));
        for (int i = 0; i < cols; i++) {
            long t0 = viewStart + (long) ((double) i / cols * vis());
            long t1 = viewStart + (long) ((double) (i + 1) / cols * vis());
            int b0 = (int) (t0 / binMs), b1 = (int) Math.max(b0 + 1, t1 / binMs);
            float m = 0;
            for (int b = b0; b < b1 && b < wave.length; b++) m = Math.max(m, wave[b]);
            float hh = Math.max(1 * dp, Math.min(1f, m * 1.6f) * half);
            float xx = L + i * 2 * dp;
            boolean in = mode != RANGE || (t0 >= selStart && t0 <= selEnd);
            p.setColor(in ? (posMs > t0 ? 0xFFED93B1 : 0xFF7F77DD) : 0xFF534AB7);
            c.drawRect(xx, mid - hh, xx + 1.4f * dp, mid + hh, p);
        }
        if (mode == RANGE) {
            p.setColor(0xFF5DCAA5);
            float sx = x(selStart), ex = x(selEnd);
            if (sx >= L - 1 && sx <= R + 1) c.drawRoundRect(sx - 4 * dp, top - 2 * dp, sx + 4 * dp, bot, 2 * dp, 2 * dp, p);
            if (ex >= L - 1 && ex <= R + 1) c.drawRoundRect(ex - 4 * dp, top - 2 * dp, ex + 4 * dp, bot, 2 * dp, 2 * dp, p);
        }
        if (mode == MARKS) {
            for (int i = 0; i < marks.size(); i++) {
                float mx = x(marks.get(i));
                if (mx < L || mx > R) continue;
                p.setColor(i == selMark ? 0xFFEF9F27 : 0xFFFAC775);
                c.drawRect(mx - (i == selMark ? 2.5f : 1.5f) * dp, top, mx + (i == selMark ? 2.5f : 1.5f) * dp, bot, p);
                p.setColor(Color.BLACK);
                c.drawCircle(mx, top + 9 * dp, 8 * dp, p);
                p.setColor(Color.WHITE);
                p.setTextSize(10 * dp);
                String s = String.valueOf(i + 2);
                c.drawText(s, mx - p.measureText(s) / 2, top + 12.5f * dp, p);
                p.setTextSize(12.5f * dp);
            }
        }
        float px = x(posMs);
        if (px >= L && px <= R) {
            p.setColor(0xFFE24B4A);
            c.drawRect(px - 1.5f * dp, top - 4 * dp, px + 1.5f * dp, bot, p);
        }
        p.setColor(dark ? Color.WHITE : Color.BLACK);
        c.drawText(fmt(posMs) + " / " + fmt(durMs), L, 14 * dp, p);
        String r = mode == RANGE ? "Pedazo " + fmt(selEnd - selStart) : mode == MARKS ? (marks.size() + 1) + " canciones" : "";
        if (zoom > 1) r += "  ·  x" + zoom;
        c.drawText(r, R - p.measureText(r), 14 * dp, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (durMs <= 0) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                float tol = 22 * dp;
                drag = 3;
                if (mode == RANGE) {
                    float ds = Math.abs(e.getX() - x(selStart)), de = Math.abs(e.getX() - x(selEnd));
                    if (ds < tol && ds <= de) drag = 1;
                    else if (de < tol) drag = 2;
                } else if (mode == MARKS) {
                    int best = -1;
                    float bd = tol;
                    for (int i = 0; i < marks.size(); i++) {
                        float d = Math.abs(e.getX() - x(marks.get(i)));
                        if (d < bd) { bd = d; best = i; }
                    }
                    if (best >= 0) { selMark = best; drag = 4; }
                }
                move(e.getX());
                break;
            }
            case MotionEvent.ACTION_MOVE:
                move(e.getX());
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (drag == 4) java.util.Collections.sort(marks);
                if (drag != 0 && listener != null) listener.onChanged();
                drag = 0;
                break;
        }
        return true;
    }

    private void move(float xx) {
        long m = ms(xx);
        if (drag == 1) { selStart = Math.min(m, selEnd - 200); if (selStart < 0) selStart = 0; posMs = selStart; }
        else if (drag == 2) { selEnd = Math.max(m, selStart + 200); if (selEnd > durMs) selEnd = durMs; posMs = selEnd; }
        else if (drag == 4 && selMark >= 0 && selMark < marks.size()) { marks.set(selMark, m); posMs = m; }
        else if (drag == 3) posMs = m;
        if (listener != null) listener.onSeek(posMs);
        invalidate();
    }

    public static String fmt(long ms) {
        if (ms < 0) ms = 0;
        return String.format(Locale.US, "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10);
    }
}
