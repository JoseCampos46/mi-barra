package co.jose.djchepe;

import java.util.Random;

/** Fabrica los sonidos de la botonera (mono, 44.100 Hz). Hechos aquí mismo: son suyos. */
public final class Synth {

    public static final int SR = 44100;
    public static final int BOMBO = 0, REDOBLANTE = 1, PLATILLO = 2, MARACAS = 3, SILBATO = 4, CORNETA = 5, SIRENA = 6, SCRATCH = 7;

    public static short[][] all() {
        return new short[][]{bombo(), redoblante(), platillo(), maracas(), silbato(), corneta(), sirena(), scratch()};
    }

    private static short[] out(float[] f, float vol) {
        float m = 1e-6f;
        for (float v : f) m = Math.max(m, Math.abs(v));
        short[] s = new short[f.length];
        for (int i = 0; i < f.length; i++) s[i] = (short) (f[i] / m * vol * 32000f);
        return s;
    }

    static short[] bombo() {
        int n = (int) (SR * 0.5);
        float[] f = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            double fr = 45 + 95 * Math.exp(-t * 28);
            ph += 2 * Math.PI * fr / SR;
            f[i] = (float) (Math.sin(ph) * Math.exp(-t * 6.5) + (i < 60 ? 0.4 * (1 - i / 60.0) : 0));
        }
        return out(f, 0.95f);
    }

    static short[] redoblante() {
        Random r = new Random(7);
        int n = (int) (SR * 0.3);
        float[] f = new float[n];
        float prev = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            float nz = r.nextFloat() * 2 - 1;
            float hp = nz - prev * 0.6f;
            prev = nz;
            f[i] = (float) (hp * Math.exp(-t * 17) * 0.8 + Math.sin(2 * Math.PI * 185 * t) * Math.exp(-t * 28) * 0.6);
        }
        return out(f, 0.8f);
    }

    static short[] platillo() {
        Random r = new Random(11);
        int n = (int) (SR * 1.3);
        float[] f = new float[n];
        float p1 = 0, p2 = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            float nz = r.nextFloat() * 2 - 1;
            float hp = nz - 2 * p1 + p2;
            p2 = p1;
            p1 = nz;
            f[i] = (float) (hp * Math.exp(-t * 3.2));
        }
        return out(f, 0.55f);
    }

    static short[] maracas() {
        Random r = new Random(3);
        int n = (int) (SR * 0.3);
        float[] f = new float[n];
        float prev = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            double t2 = t - 0.13;
            double env = Math.exp(-t * 45) + (t2 > 0 ? Math.exp(-t2 * 45) * 0.8 : 0);
            float nz = r.nextFloat() * 2 - 1;
            float hp = nz - prev;
            prev = nz;
            f[i] = (float) (hp * env);
        }
        return out(f, 0.6f);
    }

    static short[] silbato() {
        Random r = new Random(5);
        int n = (int) (SR * 0.75);
        float[] f = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            boolean on = t < 0.16 || (t > 0.24 && t < 0.72);
            double env = on ? 1 : 0;
            if (t < 0.01) env = t / 0.01;
            double fr = 2950 * (1 + 0.035 * Math.sin(2 * Math.PI * 28 * t));
            ph += 2 * Math.PI * fr / SR;
            f[i] = (float) ((Math.sin(ph) + (r.nextFloat() - 0.5) * 0.15) * env);
        }
        return out(f, 0.55f);
    }

    static short[] corneta() {
        int n = (int) (SR * 1.5);
        float[] f = new float[n];
        double[] fr = {415, 418.5, 207.5, 622};
        double[] ph = new double[4];
        double[][] blasts = {{0, 0.2}, {0.27, 0.47}, {0.55, 1.4}};
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            double env = 0;
            for (double[] b : blasts) {
                if (t >= b[0] && t < b[1]) {
                    double a = Math.min(1, (t - b[0]) / 0.015) * Math.min(1, (b[1] - t) / 0.03);
                    env = Math.max(env, a);
                }
            }
            double s = 0;
            for (int k = 0; k < 4; k++) {
                ph[k] += fr[k] / SR;
                ph[k] -= Math.floor(ph[k]);
                s += (2 * ph[k] - 1) * (k == 3 ? 0.4 : 1);
            }
            f[i] = (float) (Math.tanh(s * 0.8) * env);
        }
        return out(f, 0.6f);
    }

    static short[] sirena() {
        int n = (int) (SR * 2.4);
        float[] f = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            double fr = 900 + 450 * Math.sin(2 * Math.PI * 1.25 * t);
            ph += 2 * Math.PI * fr / SR;
            double env = Math.min(1, t / 0.05) * Math.min(1, (2.4 - t) / 0.2);
            f[i] = (float) ((Math.sin(ph) + 0.3 * Math.sin(2 * ph)) * env);
        }
        return out(f, 0.5f);
    }

    /** Scratch de respaldo cuando no hay canción sonando. */
    static short[] scratch() {
        Random r = new Random(9);
        int n = (int) (SR * 0.7);
        float[] f = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = (double) i / SR;
            double sp = Math.sin(2 * Math.PI * 3.4 * t);
            double fr = 200 + 900 * Math.abs(sp);
            ph += 2 * Math.PI * fr / SR;
            f[i] = (float) ((Math.sin(ph) * 0.5 + (r.nextFloat() - 0.5)) * Math.abs(sp));
        }
        return out(f, 0.5f);
    }

    private Synth() {}
}
