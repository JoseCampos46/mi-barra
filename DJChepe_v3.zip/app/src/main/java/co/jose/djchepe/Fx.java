package co.jose.djchepe;

/** Efectos de sonido hechos aquí mismo: ecualizador, filtro, salón grande (reverberación), avión (flanger) y la voz de locutor. */
public final class Fx {

    /** Filtro de dos polos para dos canales (izquierdo y derecho). */
    public static final class Biquad {
        double b0 = 1, b1, b2, a1, a2;
        double l1, l2, r1, r2;
        boolean on;

        void set(double nb0, double nb1, double nb2, double a0, double na1, double na2) {
            b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0;
        }

        public void off() { on = false; }

        public void lowShelf(double f, double db) {
            double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), s = Math.sin(w);
            double al = s / 2 * Math.sqrt(2), sa = 2 * Math.sqrt(A) * al;
            set(A * ((A + 1) - (A - 1) * c + sa), 2 * A * ((A - 1) - (A + 1) * c), A * ((A + 1) - (A - 1) * c - sa),
                    (A + 1) + (A - 1) * c + sa, -2 * ((A - 1) + (A + 1) * c), (A + 1) + (A - 1) * c - sa);
            on = Math.abs(db) > 0.2;
        }

        public void highShelf(double f, double db) {
            double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), s = Math.sin(w);
            double al = s / 2 * Math.sqrt(2), sa = 2 * Math.sqrt(A) * al;
            set(A * ((A + 1) + (A - 1) * c + sa), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - sa),
                    (A + 1) - (A - 1) * c + sa, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - sa);
            on = Math.abs(db) > 0.2;
        }

        public void peak(double f, double q, double db) {
            double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), al = Math.sin(w) / (2 * q);
            set(1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
            on = Math.abs(db) > 0.2;
        }

        public void lowPass(double f, double q) {
            double w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), al = Math.sin(w) / (2 * q);
            set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al);
            on = true;
        }

        public void highPass(double f, double q) {
            double w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), al = Math.sin(w) / (2 * q);
            set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
            on = true;
        }

        public float left(float x) {
            if (!on) return x;
            double y = b0 * x + l1;
            l1 = b1 * x - a1 * y + l2;
            l2 = b2 * x - a2 * y;
            return (float) y;
        }

        public float right(float x) {
            if (!on) return x;
            double y = b0 * x + r1;
            r1 = b1 * x - a1 * y + r2;
            r2 = b2 * x - a2 * y;
            return (float) y;
        }
    }

    /** Salón grande: reverberación tipo Freeverb (8 peines y 4 pasa-todo). */
    public static final class Reverb {
        private final float[][] comb = new float[8][];
        private final int[] ci = new int[8];
        private final float[] cf = new float[8];
        private final float[][] ap = new float[4][];
        private final int[] ai = new int[4];
        public float room = 0.84f, damp = 0.25f;

        public Reverb() {
            int[] cl = {1116, 1188, 1277, 1356, 1139, 1211, 1300, 1379};
            for (int i = 0; i < 8; i++) comb[i] = new float[cl[i]];
            int[] al = {556, 441, 579, 464};
            for (int i = 0; i < 4; i++) ap[i] = new float[al[i]];
        }

        private float combAt(int k, float in) {
            float[] b = comb[k];
            float o = b[ci[k]];
            cf[k] = o * (1 - damp) + cf[k] * damp;
            b[ci[k]] = in + cf[k] * room;
            if (++ci[k] >= b.length) ci[k] = 0;
            return o;
        }

        private float apAt(int k, float in) {
            float[] b = ap[k];
            float o = b[ai[k]];
            b[ai[k]] = in + o * 0.5f;
            if (++ai[k] >= b.length) ai[k] = 0;
            return o - in;
        }

        public float outL, outR;

        public void process(float in) {
            in *= 0.015f;
            float l = 0, r = 0;
            for (int k = 0; k < 4; k++) l += combAt(k, in);
            for (int k = 4; k < 8; k++) r += combAt(k, in);
            l = apAt(0, l); l = apAt(1, l);
            r = apAt(2, r); r = apAt(3, r);
            outL = l * 3f;
            outR = r * 3f;
        }
    }

    /** Avión: retraso cortico que sube y baja. */
    public static final class Flanger {
        private final float[] bl = new float[2048], br = new float[2048];
        private int w;
        private double ph;

        public float outL, outR;

        public void process(float l, float r) {
            ph += 0.22 / Engine.SR;
            if (ph >= 1) ph -= 1;
            double d = (0.0008 + 0.0035 * (1 + Math.sin(2 * Math.PI * ph)) / 2) * Engine.SR;
            double rp = w - d;
            if (rp < 0) rp += bl.length;
            int i0 = (int) rp, i1 = (i0 + 1) % bl.length;
            float t = (float) (rp - i0);
            float dl = bl[i0] + (bl[i1] - bl[i0]) * t;
            float dr = br[i0] + (br[i1] - br[i0]) * t;
            bl[w] = l + dl * 0.55f;
            br[w] = r + dr * 0.55f;
            if (++w >= bl.length) w = 0;
            outL = (l + dl) * 0.6f;
            outR = (r + dr) * 0.6f;
        }
    }

    /** Cambia el tono sin cambiar la velocidad (semitonos negativos = más grave). */
    static float[] cambiarTono(float[] x, double semitonos) {
        if (Math.abs(semitonos) < 0.05) return x;
        double r = Math.pow(2, semitonos / 12.0);
        int n = x.length;
        // 1) se lee más despacio (o más rápido): cambia tono y duración
        int m = (int) (n / r);
        float[] y = new float[m];
        for (int j = 0; j < m; j++) {
            double p = j * r;
            int i = (int) p;
            float a = x[Math.min(i, n - 1)], b = x[Math.min(i + 1, n - 1)];
            y[j] = a + (b - a) * (float) (p - i);
        }
        // 2) se vuelve a la duración original sin cambiar el tono (WSOLA)
        int N = 1024, hs = N / 2, tol = 256;
        float[] win = new float[N];
        for (int i = 0; i < N; i++) win[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / N));
        float[] out = new float[n + N];
        int prev = 0;
        for (int k = 0; (long) k * hs < n; k++) {
            int target = (int) ((long) k * hs / r);
            int pos;
            if (k == 0) pos = 0;
            else {
                int nat = prev + hs;
                pos = Math.max(0, Math.min(target, m - N - 1));
                if (nat + N < m) {
                    double bestC = -1e30;
                    for (int d = -tol; d <= tol; d += 2) {
                        int p = target + d;
                        if (p < 0 || p + N >= m) continue;
                        double c = 0;
                        for (int i = 0; i < hs; i += 2) c += y[p + i] * y[nat + i];
                        if (c > bestC) { bestC = c; pos = p; }
                    }
                }
            }
            if (pos < 0) pos = 0;
            int o = k * hs;
            for (int i = 0; i < N && pos + i < m && o + i < out.length; i++) out[o + i] += y[pos + i] * win[i];
            prev = pos;
        }
        return java.util.Arrays.copyOf(out, n);
    }

    /**
     * Voz de DJ: más grave (sin ponerla lenta), con cuerpo en el pecho, brillo, compresor fuerte,
     * saturación de radio, doble voz a los lados, salón grande y eco que repite el final.
     * eco y grave van de 0 a 1. Devuelve estéreo intercalado (izquierdo, derecho, izquierdo…).
     */
    public static short[] locutor(short[] in, float eco, float grave) {
        int n = in.length;
        if (n == 0) return in;
        eco = Math.max(0f, Math.min(1f, eco));
        grave = Math.max(0f, Math.min(1f, grave));
        float[] x = new float[n];
        for (int i = 0; i < n; i++) x[i] = in[i] / 32768f;
        x = cambiarTono(x, -3.0 * grave);
        Biquad hp = new Biquad();
        hp.highPass(85, 0.7);
        Biquad pecho = new Biquad();
        pecho.lowShelf(170, 2 + 5 * grave);
        Biquad barro = new Biquad();
        barro.peak(400, 1.2, -3);
        Biquad pres = new Biquad();
        pres.peak(3200, 1.0, 5.5);
        Biquad air = new Biquad();
        air.highShelf(9000, 3);
        float peak = 1e-6f;
        for (int i = 0; i < n; i++) {
            float v = air.left(pres.left(barro.left(pecho.left(hp.left(x[i])))));
            x[i] = v;
            peak = Math.max(peak, Math.abs(v));
        }
        for (int i = 0; i < n; i++) x[i] *= 0.5f / peak;
        // compresor fuerte: todo lo que pase de -22 dB se aplasta 6 a 1
        float env = 0, thr = 0.08f;
        float atk = (float) Math.exp(-1.0 / (0.003 * Engine.SR)), rel = (float) Math.exp(-1.0 / (0.12 * Engine.SR));
        peak = 1e-6f;
        for (int i = 0; i < n; i++) {
            float a = Math.abs(x[i]);
            env = a > env ? atk * env + (1 - atk) * a : rel * env + (1 - rel) * a;
            float g = env > thr ? (float) (thr * Math.pow(env / thr, 1 / 6.0) / env) : 1f;
            x[i] *= g;
            peak = Math.max(peak, Math.abs(x[i]));
        }
        // saturación de radio (le da fuerza sin que se rompa)
        float drive = 1.6f + 1.6f * grave;
        float norm = (float) Math.tanh(drive);
        peak = Math.max(peak, 1e-6f);
        for (int i = 0; i < n; i++) x[i] = (float) Math.tanh(drive * x[i] / peak * 0.9f) / norm;

        int tail = (int) (Engine.SR * (1.5 + 2.5 * eco));
        int total = n + tail;
        float[] L = new float[total], R = new float[total];
        int dLen = (int) (Engine.SR * 0.30);
        float[] dl = new float[dLen];
        int di = 0;
        float fb = 0.30f + 0.32f * eco, wetE = 0.30f + 0.40f * eco, wetR = 0.15f + 0.20f * eco;
        int endZone = (int) (Engine.SR * 0.9);
        int dbl = (int) (Engine.SR * 0.016);
        Reverb rv = new Reverb();
        rv.room = 0.80f + 0.08f * eco;
        Biquad echoTone = new Biquad();
        echoTone.lowPass(4500, 0.7);
        peak = 1e-6f;
        for (int i = 0; i < total; i++) {
            float dry = i < n ? x[i] : 0f;
            float dd = i - dbl >= 0 && i - dbl < n ? x[i - dbl] : 0f; // la doble voz
            float w = i < n - endZone ? 0.12f : 1f;
            float e = dl[di];
            dl[di] = echoTone.left(dry * w + e * fb);
            if (++di >= dLen) di = 0;
            rv.process(dry + e * 0.5f);
            float l = dry + dd * 0.35f + e * wetE + rv.outL * wetR;
            float r = dd + dry * 0.35f + e * wetE * 0.9f + rv.outR * wetR;
            L[i] = l;
            R[i] = r;
            peak = Math.max(peak, Math.max(Math.abs(l), Math.abs(r)));
        }
        int last = total - 1;
        float floor = peak * 0.004f;
        while (last > n && Math.abs(L[last]) < floor && Math.abs(R[last]) < floor) last--;
        short[] res = new short[(last + 1) * 2];
        float k = 0.97f / peak;
        for (int i = 0; i <= last; i++) {
            float f = i > last - 2000 ? (last - i) / 2000f : 1f;
            res[2 * i] = (short) Math.max(-32767, Math.min(32767, L[i] * k * f * 32767f));
            res[2 * i + 1] = (short) Math.max(-32767, Math.min(32767, R[i] * k * f * 32767f));
        }
        return res;
    }

    /** La misma voz de DJ pero en vivo, muestra por muestra (para "Al aire"). Sin cambio de tono, para que no se demore. */
    public static final class Vivo {
        private final Biquad hp = new Biquad(), pecho = new Biquad(), pres = new Biquad();
        private float env, genv;
        private final float atk = (float) Math.exp(-1.0 / (0.003 * Engine.SR)), rel = (float) Math.exp(-1.0 / (0.12 * Engine.SR));
        private final float[] dl = new float[(int) (Engine.SR * 0.32)];
        private int di;
        private final Reverb rv = new Reverb();
        public float outL, outR;

        public Vivo() {
            hp.highPass(100, 0.7);
            pecho.lowShelf(170, 5);
            pres.peak(3200, 1.0, 5);
        }

        public void process(float x) {
            x = pres.left(pecho.left(hp.left(x * 2.2f)));
            float a = Math.abs(x);
            // puerta: si no está hablando, calla el ruido de fondo
            genv = a > genv ? 0.01f * a + 0.99f * genv : 0.9995f * genv;
            float gate = genv < 0.01f ? genv / 0.01f : 1f;
            env = a > env ? atk * env + (1 - atk) * a : rel * env + (1 - rel) * a;
            float thr = 0.08f;
            float g = env > thr ? (float) (thr * Math.pow(env / thr, 1 / 6.0) / env) : 1f;
            x = (float) Math.tanh(x * g * 4f) * 0.8f * gate;
            float e = dl[di];
            dl[di] = x * 0.6f + e * 0.32f;
            if (++di >= dl.length) di = 0;
            rv.process(x + e * 0.4f);
            outL = x + e * 0.35f + rv.outL * 0.18f;
            outR = x + e * 0.32f + rv.outR * 0.18f;
        }
    }

    private Fx() {}
}
