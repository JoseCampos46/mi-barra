package co.jose.djchepe;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Gran mezcla: escucha todas las canciones de la carpeta "A mezclar", escoge las partes más fuertes
 * de cada una, las pone al mismo ritmo y las intercala (una, otra, otra…) con efectos de DJ en cada cambio.
 */
public final class Gran {

    static final int SR = 44100;
    static final int X = 4;                 // tiempos (golpes) que dura cada cambio
    static final int BARRIDO = 0, REDOBLE = 1, ECO = 2, FRENO = 3, MEZCLA = 4;
    static final String[] NOMBRE_EFECTO = {"barrido", "redoble", "eco", "freno", "mezcla"};
    static final int LARGO = 16;            // golpes del cruce profesional (4 compases)

    public interface Prog { void p(String msg); }

    static final class Seg {
        int song;
        double t;          // segundo donde empieza la parte fuerte (antes de ajustar al golpe)
        double bpm = 120;
        double down;       // segundo exacto del golpe donde arranca (en la canción)
        double rate = 1;   // velocidad para quedar al ritmo de la mezcla
        boolean ritmoIgual = true;
        int efecto;        // efecto del cambio hacia la siguiente parte
        int cruce = X;     // golpes que dura el cambio hacia la siguiente parte
    }

    public static final class Resultado { public double seg; public int partes; public int canciones; public double bpm; }

    /** Arma la gran mezcla y la guarda en out (M4A). */
    public static Resultado crear(Context ctx, List<Uri> uris, List<String> names, File out, Prog pr) throws Exception {
        int n = Math.min(uris.size(), 15);
        if (n < 2) throw new Exception("escoja al menos 2 canciones");

        // 1. Escuchar cada canción: fuerza del sonido cada 100 ms
        List<float[]> env = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            final int k = i;
            pr.p("Escuchando canción " + (i + 1) + " de " + n + "…");
            float[] e = Dec.envelope(ctx, uris.get(i), 100, f -> { pr.p("Escuchando canción " + (k + 1) + " de " + n + "… " + Math.round(f * 100) + "%"); return true; });
            if (e.length < 200) throw new Exception("la canción " + (i + 1) + " es muy corta");
            env.add(e);
        }

        // 2. Cuántas partes de cada una y de qué largo (la app lo calcula según cuántas canciones haya)
        // v6: partes largas (como un DJ de verdad), no pedacitos
        int per = n == 2 ? 2 : 1;
        double segSec = n <= 3 ? 52 : (n <= 6 ? 44 : 36);

        // 3. Buscar las partes más contundentes de cada canción
        List<List<Seg>> porCancion = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int want = per;
            porCancion.add(fuertes(env.get(i), segSec, want, i));
        }
        env.clear();

        // 4. Orden intercalado: una parte de cada canción, y vuelta
        List<Seg> plan = new ArrayList<>();
        int maxPer = 0;
        for (List<Seg> l : porCancion) maxPer = Math.max(maxPer, l.size());
        for (int r = 0; r < maxPer; r++)
            for (int i = 0; i < n; i++) {
                List<Seg> l = porCancion.get(i);
                if (r < l.size()) {
                    Seg s = l.get(r);
                    if (!plan.isEmpty() && plan.get(plan.size() - 1).song == s.song) continue;
                    plan.add(s);
                }
            }

        // 5. Encontrar el ritmo de cada parte
        double[] bpms = new double[plan.size()];
        for (int i = 0; i < plan.size(); i++) {
            Seg s = plan.get(i);
            pr.p("Buscando el ritmo… parte " + (i + 1) + " de " + plan.size());
            double w0 = Math.max(0, s.t - 4);
            Dec.Pcm p = decodeRange(ctx, uris.get(s.song), w0, w0 + 22);
            if (p.frames < p.sr * 4) { s.down = s.t; bpms[i] = 120; continue; }
            double[] b = Beat.analyze(p.d, p.frames, p.sr);
            s.bpm = b[0];
            double per1 = 60.0 / s.bpm;
            double fb = w0 + b[1];
            double k = Math.round((s.t - fb) / per1);
            double d = fb + k * per1;
            // v6: arrancar donde la canción "entra con todo" (inicio de frase), no en cualquier golpe
            d = mejorEntrada(p, w0, d, per1);
            while (d - LARGO * per1 * 1.05 < 0) d += 4 * per1;
            s.down = d;
            bpms[i] = s.bpm;
        }
        double[] sorted = bpms.clone();
        Arrays.sort(sorted);
        double master = sorted[sorted.length / 2];
        for (Seg s : plan) {
            double r = master / s.bpm, best = r;
            for (double c : new double[]{r, r * 2, r / 2}) if (Math.abs(c - 1) < Math.abs(best - 1)) best = c;
            if (Math.abs(best - 1) <= 0.08) { s.rate = best; s.ritmoIgual = true; } else { s.rate = 1; s.ritmoIgual = false; }
        }

        // 6. El cambio: si el ritmo cuadra, cruce largo de DJ (16 golpes, cambiando los bajos en el compás);
        //    si no cuadra, eco o freno cortos que lo disimulan. Muy de vez en cuando un barrido o redoble.
        for (int i = 0; i < plan.size() - 1; i++) {
            Seg a = plan.get(i), b = plan.get(i + 1);
            if (a.ritmoIgual && b.ritmoIgual) {
                a.efecto = (i % 4 == 3) ? (i % 8 == 3 ? BARRIDO : REDOBLE) : MEZCLA;
                a.cruce = a.efecto == MEZCLA ? LARGO : X;
            } else {
                a.efecto = (i % 2 == 0) ? ECO : FRENO;
                a.cruce = X;
            }
        }

        // 7. Largo de cada parte en golpes (frases de 8)
        double bf = SR * 60.0 / master;                         // cuadros por golpe en la mezcla
        int beats = (int) Math.max(48, Math.round(segSec * master / 60.0 / 16.0) * 16);
        int xfEnd = (int) Math.round(8 * bf);
        Lim limiter = new Lim();

        short[][] drums = Synth.all();
        Aac w = new Aac(out, 128000);
        long written = 0;
        float[] carry = null;
        try {
            for (int i = 0; i < plan.size(); i++) {
                Seg s = plan.get(i);
                pr.p("Mezclando parte " + (i + 1) + " de " + plan.size() + "…");
                boolean first = i == 0, last = i == plan.size() - 1;
                Seg prev = first ? null : plan.get(i - 1);
                int pre = first ? 0 : (int) Math.round(prev.cruce * bf);
                int xf = last ? xfEnd : (int) Math.round(s.cruce * bf);
                int body = (int) Math.round(beats * bf);
                int tail = last ? (int) Math.round(8 * bf) : 0;  // espacio para el eco final
                int len = pre + body + tail;

                // decodificar lo justo de esta parte
                double step0 = s.rate;                          // golpes de la canción por golpe de la mezcla
                double srcSecs = (len / (double) SR) * step0 + 3;
                double startSec = s.down - pre / (double) SR * step0;
                double w0 = Math.max(0, startSec - 1);
                Dec.Pcm p = decodeRange(ctx, uris.get(s.song), w0, w0 + srcSecs + 2);
                float[] B = renderSeg(p, (startSec - w0) * p.sr, s.rate * p.sr / (double) SR, len,
                        last ? body - xf : -1, bf);
                p = null;

                // igualar el volumen de todas las partes
                normalizar(B, pre, pre + body);

                // entrada: el que entra va suave hasta el golpe
                if (first) {
                    fadeIn(B, 0, (int) bf);
                    mixDrum(B, drums[Synth.PLATILLO], 0, 0.55f);
                    mixDrum(B, drums[Synth.BOMBO], 0, 0.6f);
                } else if (prev.efecto == MEZCLA) {
                    entradaMezcla(B, pre);
                } else {
                    entrada(B, pre, prev.efecto, bf);
                }
                // golpe de llegada en el tiempo 1 de la parte nueva (solo en los cambios cortos)
                if (!first && prev.efecto != MEZCLA) {
                    mixDrum(B, drums[Synth.BOMBO], pre, 0.75f);
                    if (prev.efecto != ECO) mixDrum(B, drums[Synth.PLATILLO], pre, 0.6f);
                    if (prev.efecto == FRENO) mixDrum(B, drums[Synth.SCRATCH], Math.max(0, pre - (int) (bf / 2)), 0.45f);
                }

                // salida: los últimos 4 golpes llevan el efecto
                float[] spill = null;
                if (!last && s.efecto == MEZCLA) salidaMezcla(B, pre + body - xf, xf);
                else if (!last) spill = salida(B, pre + body - xf, xf, s.efecto, bf, drums);
                else finalEco(B, pre + body - xf, xf, len, bf, drums);

                // juntar con el pedazo que venía de la parte anterior
                if (carry != null) for (int k = 0; k < Math.min(carry.length, B.length); k++) B[k] += carry[k];

                int keep = last ? len : pre + body - xf;          // lo que se queda para el próximo cambio
                written += writeOut(w, B, 0, keep, limiter);
                if (!last) {
                    int tl = len - keep;                            // = los golpes del cambio
                    carry = new float[(tl + (spill != null ? spill.length / 2 : 0)) * 2];
                    System.arraycopy(B, keep * 2, carry, 0, tl * 2);
                    if (spill != null) for (int k = 0; k < spill.length; k++) carry[tl * 2 + k] += spill[k];
                } else carry = null;
            }
        } finally {
            pr.p("Guardando…");
            w.finish();
        }
        Resultado r = new Resultado();
        r.seg = written / (double) SR;
        r.partes = plan.size();
        r.canciones = n;
        r.bpm = master;
        return r;
    }

    // ------------------------------------------------------------ escoger partes

    static List<Seg> fuertes(float[] e, double segSec, int want, int song) {
        int nh = e.length;
        int win = (int) Math.round(segSec * 10);
        double[] pre = new double[nh + 1];
        for (int i = 0; i < nh; i++) pre[i + 1] = pre[i] + e[i];
        int lo = (int) (nh * 0.08) + 40, hi = nh - win - (int) (nh * 0.05) - 30;
        if (hi <= lo) { lo = Math.max(0, nh / 10); hi = Math.max(lo + 1, nh - win - 10); }
        // el pedazo también debe llegar fuerte desde el arranque (no un final que se apaga)
        double[] score = new double[Math.max(1, hi)];
        for (int s = lo; s < hi; s++) {
            double m = (pre[s + win] - pre[s]) / win;
            int a = Math.min(nh - 1, s + 40);
            double arr = (pre[a] - pre[s]) / Math.max(1, a - s);
            score[s] = m * 0.8 + arr * 0.2;
        }
        List<Seg> out = new ArrayList<>();
        boolean[] used = new boolean[Math.max(1, hi)];
        for (int k = 0; k < want; k++) {
            int best = -1;
            double bs = -1;
            for (int s = lo; s < hi; s++) if (!used[s] && score[s] > bs) { bs = score[s]; best = s; }
            if (best < 0) break;
            Seg g = new Seg();
            g.song = song;
            g.t = best / 10.0;
            out.add(g);
            int gap = (int) (win * 1.2);
            for (int s = Math.max(lo, best - gap); s < Math.min(hi, best + gap); s++) used[s] = true;
        }
        if (out.isEmpty()) { Seg g = new Seg(); g.song = song; g.t = Math.max(0, nh / 30.0); out.add(g); }
        out.sort((a, b) -> Double.compare(a.t, b.t));
        return out;
    }

    // ------------------------------------------------------------ sonido

    static Dec.Pcm decodeRange(Context ctx, Uri u, double s, double e) throws Exception {
        final Dec.Pcm p = new Dec.Pcm();
        Dec.Info in = Dec.info(ctx, u);
        int sr0 = in.sr > 0 ? in.sr : 44100;
        int cap = (int) ((e - s) * sr0) + sr0;
        p.d = new short[cap * 2];
        p.sr = sr0;
        final long sUs = (long) (s * 1e6), eUs = (long) (e * 1e6);
        try {
            Dec.stream(ctx, u, sUs, eUs, (buf, frames, ch, sr) -> {
                p.sr = sr;
                int room = p.d.length / 2 - p.frames;
                int take = Math.min(frames, room);
                for (int f = 0; f < take; f++) {
                    short l = buf[f * ch];
                    short r = ch > 1 ? buf[f * ch + 1] : l;
                    p.d[p.frames * 2] = l;
                    p.d[p.frames * 2 + 1] = r;
                    p.frames++;
                }
                if (take < frames) throw new Dec.Stop();
            });
        } catch (Dec.Stop ignored) {
        }
        return p;
    }

    /** Pasa un pedazo a la velocidad de la mezcla. brakeAt: desde ese cuadro se va frenando (-1 = no). */
    static float[] renderSeg(Dec.Pcm p, double pos0, double step, int len, int brakeAt, double bf) {
        float[] B = new float[len * 2];
        double pos = pos0;
        for (int o = 0; o < len; o++) {
            int i = (int) pos;
            if (i >= 0 && i + 1 < p.frames) {
                float t = (float) (pos - i);
                B[2 * o] = p.d[2 * i] + (p.d[2 * i + 2] - p.d[2 * i]) * t;
                B[2 * o + 1] = p.d[2 * i + 1] + (p.d[2 * i + 3] - p.d[2 * i + 1]) * t;
            }
            pos += step;
        }
        return B;
    }

    static void normalizar(float[] B, int a, int b) {
        double s = 0;
        int n = 0;
        for (int k = a; k < b; k += 4) {
            float l = B[2 * k], r = B[2 * k + 1];
            s += l * l + r * r;
            n += 2;
        }
        if (n == 0) return;
        double rms = Math.sqrt(s / n);
        if (rms < 1) return;
        float g = (float) Math.max(0.4, Math.min(2.5, 4600.0 / rms));   // v6: más bajito, con espacio para el cruce
        for (int k = 0; k < B.length; k++) B[k] *= g;
    }

    static void fadeIn(float[] B, int a, int n) {
        for (int k = 0; k < n && a + k < B.length / 2; k++) {
            float g = (float) Math.sin((k / (double) n) * Math.PI / 2);
            B[2 * (a + k)] *= g;
            B[2 * (a + k) + 1] *= g;
        }
    }

    /** El que entra: durante los 4 golpes antes de su tiempo 1. */
    static void entrada(float[] B, int pre, int efecto, double bf) {
        Fx.Biquad hp = new Fx.Biquad();
        hp.highPass(280, 0.7);
        for (int k = 0; k < pre; k++) {
            double x = k / (double) pre;
            float g;
            if (efecto == BARRIDO || efecto == REDOBLE) g = (float) Math.sin(x * Math.PI / 2) * 0.85f;
            else if (efecto == ECO) g = x < 0.75 ? 0f : (float) ((x - 0.75) / 0.25) * 0.8f;
            else g = x < 0.85 ? 0f : (float) ((x - 0.85) / 0.15) * 0.6f;   // FRENO: entra de golpe
            float l = hp.left(B[2 * k]), r = hp.right(B[2 * k + 1]);   // sin bajos hasta el golpe
            B[2 * k] = l * g;
            B[2 * k + 1] = r * g;
        }
    }

    /** El que sale: aplica el efecto en sus últimos 4 golpes. Devuelve la cola (eco) que sigue sonando. */
    static float[] salida(float[] B, int a, int n, int efecto, double bf, short[][] drums) {
        float[] spill = null;
        if (efecto == BARRIDO) {
            Fx.Biquad hp = new Fx.Biquad();
            Random rnd = new Random(7);
            Fx.Biquad nf = new Fx.Biquad();
            for (int k = 0; k < n; k++) {
                double x = k / (double) n;
                if (k % 64 == 0) hp.highPass(30 * Math.pow(70, x), 0.8);
                float g = (float) Math.cos(x * Math.PI / 2);
                int o = a + k;
                B[2 * o] = hp.left(B[2 * o]) * g;
                B[2 * o + 1] = hp.right(B[2 * o + 1]) * g;
                // subida de ruido (la "ola" del DJ)
                if (k % 64 == 0) nf.highPass(600 + 6000 * x, 0.9);
                float z = (float) ((rnd.nextFloat() * 2 - 1) * 2600 * x * x);
                B[2 * o] += nf.left(z);
                B[2 * o + 1] += nf.right(z);
            }
        } else if (efecto == REDOBLE) {
            Fx.Biquad lp = new Fx.Biquad();
            for (int k = 0; k < n; k++) {
                double x = k / (double) n;
                if (k % 64 == 0) lp.lowPass(16000 * Math.pow(0.03, x), 0.8);
                float g = (float) Math.cos(x * Math.PI / 2 * 0.9);
                int o = a + k;
                B[2 * o] = lp.left(B[2 * o]) * g;
                B[2 * o + 1] = lp.right(B[2 * o + 1]) * g;
            }
            // redoble que se acelera: negras, corcheas, semicorcheas
            double t = 0;
            while (t < 4 - 1e-6) {
                double v = 0.25 + 0.5 * (t / 4.0);
                mixDrum(B, drums[Synth.REDOBLANTE], a + (int) (t * bf), (float) v);
                double d = t < 2 ? 0.5 : (t < 3 ? 0.25 : 0.125);
                t += d;
            }
        } else if (efecto == ECO) {
            int dly = (int) Math.round(bf * 0.75);
            int cut = a + (int) (2 * bf);                    // a los 2 golpes se corta lo seco y queda el eco
            int tailLen = n + (int) (6 * bf);
            float[] wet = new float[(n + tailLen) * 2];
            float fb = 0.55f;
            for (int k = 0; k < n + tailLen; k++) {
                int o = a + k;
                float dl = 0, dr = 0;
                if (o < cut && o < B.length / 2) { dl = B[2 * o]; dr = B[2 * o + 1]; }
                float pl = k >= dly ? wet[2 * (k - dly)] : 0, prr = k >= dly ? wet[2 * (k - dly) + 1] : 0;
                wet[2 * k] = dl + prr * fb;                     // eco que rebota de lado a lado
                wet[2 * k + 1] = dr + pl * fb;
            }
            for (int k = 0; k < n; k++) {
                int o = a + k;
                float dry = o < cut ? 1f : 0f;
                float l = B[2 * o] * dry, r = B[2 * o + 1] * dry;
                B[2 * o] = l + (k >= dly ? (wet[2 * k] - (o < cut ? B[2 * o] : 0)) * 0.7f : 0);
                B[2 * o + 1] = r + (k >= dly ? (wet[2 * k + 1] - (o < cut ? B[2 * o + 1] : 0)) * 0.7f : 0);
            }
            spill = new float[tailLen * 2];
            for (int k = 0; k < tailLen; k++) {
                float g = 0.7f * (1f - k / (float) tailLen);
                spill[2 * k] = wet[2 * (n + k)] * g;
                spill[2 * k + 1] = wet[2 * (n + k) + 1] * g;
            }
        } else { // FRENO: los primeros 3 golpes normales, el último se frena como un tocadiscos
            int bk = (int) (3 * bf);
            int bl = n - bk;
            float[] src = new float[bl * 2];
            System.arraycopy(B, (a + bk) * 2, src, 0, bl * 2);
            double pos = 0;
            for (int k = 0; k < bl; k++) {
                double x = k / (double) bl;
                int i = (int) pos;
                float l = 0, r = 0;
                if (i + 1 < bl) {
                    float t = (float) (pos - i);
                    l = src[2 * i] + (src[2 * i + 2] - src[2 * i]) * t;
                    r = src[2 * i + 1] + (src[2 * i + 3] - src[2 * i + 1]) * t;
                }
                float g = (float) (1 - x * 0.6);
                B[2 * (a + bk + k)] = l * g;
                B[2 * (a + bk + k) + 1] = r * g;
                pos += Math.max(0, 1 - x * 1.05);
            }
        }
        return spill;
    }

    /** Cierre: eco que se va apagando y platillo. */
    static void finalEco(float[] B, int a, int n, int len, double bf, short[][] drums) {
        int dly = (int) Math.round(bf * 0.75);
        int cut = a + n;
        float[] wl = new float[len - a], wr = new float[len - a];
        for (int k = 0; k < len - a; k++) {
            int o = a + k;
            float dl = o < cut ? B[2 * o] : 0, dr = o < cut ? B[2 * o + 1] : 0;
            float pl = k >= dly ? wl[k - dly] : 0, pr = k >= dly ? wr[k - dly] : 0;
            wl[k] = dl + pr * 0.55f;
            wr[k] = dr + pl * 0.55f;
        }
        for (int k = 0; k < len - a; k++) {
            int o = a + k;
            double x = k / (double) (len - a);
            float g = (float) Math.max(0, 1 - x);
            float dry = o < cut ? (float) (1 - k / (double) n) : 0;
            B[2 * o] = (B[2 * o] * dry + (wl[k] - (o < cut ? B[2 * o] : 0)) * 0.7f) * g;
            B[2 * o + 1] = (B[2 * o + 1] * dry + (wr[k] - (o < cut ? B[2 * o + 1] : 0)) * 0.7f) * g;
        }
        mixDrum(B, drums[Synth.PLATILLO], cut, 0.6f);
        mixDrum(B, drums[Synth.BOMBO], cut, 0.7f);
    }

    static void mixDrum(float[] B, short[] d, int at, float vol) {
        int frames = B.length / 2;
        for (int k = 0; k < d.length; k++) {
            int o = at + k;
            if (o < 0) continue;
            if (o >= frames) break;
            float v = d[k] * vol;
            B[2 * o] += v;
            B[2 * o + 1] += v;
        }
    }

    /** Escribe con un limitador de verdad: baja el volumen justo antes del pico, sin rasgar el sonido. */
    static long writeOut(Aac w, float[] B, int a, int n, Lim L) {
        short[] buf = new short[4096 * 2];
        int bi = 0;
        final int BLK = 128;
        for (int k0 = a; k0 < a + n; k0 += BLK) {
            int k1 = Math.min(a + n, k0 + BLK);
            float peak = 1;
            for (int k = k0; k < k1; k++) peak = Math.max(peak, Math.max(Math.abs(B[2 * k]), Math.abs(B[2 * k + 1])));
            float target = Math.min(1f, L.techo / peak);
            float g0 = L.g, g1;
            if (target < L.g) g1 = target;                         // ataque: de una
            else g1 = L.g + (target - L.g) * 0.004f;               // suelta: despacito (~1 s)
            if (g1 < target && g1 < g0) g1 = target;
            for (int k = k0; k < k1; k++) {
                float t = (k - k0) / (float) (k1 - k0);
                float g = target < g0 ? target : g0 + (g1 - g0) * t;   // si hay pico, la ganancia ya está abajo desde el inicio del bloque
                buf[2 * bi] = clip(B[2 * k] * g);
                buf[2 * bi + 1] = clip(B[2 * k + 1] * g);
                if (++bi == 4096) { w.write(buf, 0, bi); bi = 0; }
            }
            L.g = g1;
        }
        if (bi > 0) w.write(buf, 0, bi);
        return n;
    }

    static final class Lim { float g = 1f; final float techo = 0.89f * 32767f; }

    static short clip(float v) {
        int s = Math.round(v);
        if (s > 32767) s = 32767; else if (s < -32768) s = -32768;
        return (short) s;
    }

    /** Cruce profesional, el que entra: sin bajos y subiendo la primera mitad; en el compás 3 le pasan los bajos. */
    static void entradaMezcla(float[] B, int pre) {
        Fx.Biquad hp = new Fx.Biquad();
        hp.highPass(220, 0.7);
        int half = pre / 2;
        for (int k = 0; k < pre; k++) {
            float l = B[2 * k], r = B[2 * k + 1];
            if (k < half) {
                double x = k / (double) half;
                float g = (float) Math.sin(x * Math.PI / 2) * 0.9f;
                l = hp.left(l) * g;
                r = hp.right(r) * g;
            } else {
                float g = 0.9f + 0.1f * (float) ((k - half) / (double) (pre - half));
                hp.left(l); hp.right(r);                           // el filtro sigue andando para no dar golpe
                l *= g; r *= g;
            }
            B[2 * k] = l;
            B[2 * k + 1] = r;
        }
    }

    /** Cruce profesional, el que sale: suena entero la primera mitad; luego suelta los bajos y se va apagando. */
    static void salidaMezcla(float[] B, int a, int n) {
        Fx.Biquad hp = new Fx.Biquad();
        int half = n / 2;
        for (int k = 0; k < n; k++) {
            int o = a + k;
            if (o >= B.length / 2) break;
            if (k < half) {
                float g = 1f - 0.1f * (k / (float) half);
                B[2 * o] *= g;
                B[2 * o + 1] *= g;
            } else {
                double x = (k - half) / (double) (n - half);
                if ((k - half) % 64 == 0) hp.highPass(200 + 500 * x, 0.7);
                float g = 0.9f * (float) Math.cos(x * Math.PI / 2);
                B[2 * o] = hp.left(B[2 * o]) * g;
                B[2 * o + 1] = hp.right(B[2 * o + 1]) * g;
            }
        }
    }

    /** Entre los golpes cercanos (±8, saltando de a 4 = compás), escoge donde la canción "entra con todo". */
    static double mejorEntrada(Dec.Pcm p, double w0, double d, double per) {
        int hop = Math.max(1, p.sr / 100);
        int nh = p.frames / hop;
        if (nh < 100) return d;
        float[] e = new float[nh];
        for (int h = 0; h < nh; h++) {
            long s = 0;
            int b = h * hop * 2;
            for (int k = 0; k < hop; k += 2) s += Math.abs(p.d[b + 2 * k] + p.d[b + 2 * k + 1]);
            e[h] = s;
        }
        double best = d, bs = -1e30;
        int w = (int) Math.round(per * 2 * 100);                  // 2 golpes antes y después
        for (int j = -8; j <= 8; j += 4) {
            double c = d + j * per;
            int h = (int) Math.round((c - w0) * 100);
            if (h - w < 0 || h + w >= nh) continue;
            double antes = 0, despues = 0;
            for (int q = h - w; q < h; q++) antes += e[q];
            for (int q = h; q < h + w; q++) despues += e[q];
            double sc = despues - antes + despues * 0.15 - Math.abs(j) * 0.02 * despues;
            if (sc > bs) { bs = sc; best = c; }
        }
        return best;
    }

    static short lim(float v) {
        float x = v / 32768f;
        float ax = Math.abs(x);
        if (ax > 0.85f) {
            float y = 0.85f + 0.15f * (float) Math.tanh((ax - 0.85f) / 0.15f);
            x = Math.signum(x) * y;
        }
        int s = Math.round(x * 32767f);
        if (s > 32767) s = 32767; else if (s < -32768) s = -32768;
        return (short) s;
    }

    private Gran() {}
}
