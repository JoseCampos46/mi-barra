package co.jose.djchepe;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Música libre y legal (Internet Archive): solo discos con licencia Creative Commons, dominio público
 * o de sellos libres (netlabels). No pide clave. Baja siempre la versión MP3 más liviana.
 */
public final class Libre {

    public interface Prog { void p(int porciento); }

    /** Disco encontrado: id, título, artista. */
    public static final class Disco { public String id, titulo, artista; }

    /** Canción de un disco: archivo, título, tamaño en bytes, duración. */
    public static final class Pista { public String archivo, titulo, dur; public long bytes; }

    static String leer(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(25000);
        c.setRequestProperty("User-Agent", "DJChepeGallego/6 (Android)");
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    static String uno(JSONObject o, String k) {
        Object v = o.opt(k);
        if (v instanceof JSONArray) return ((JSONArray) v).optString(0, "");
        return v == null ? "" : String.valueOf(v);
    }

    public static List<Disco> buscar(String que) throws Exception {
        String q = "(" + que + ") AND mediatype:(audio) AND (collection:(netlabels) OR licenseurl:(*creativecommons*) OR licenseurl:(*publicdomain*))";
        String url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(q, "UTF-8")
                + "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&sort%5B%5D=downloads+desc&rows=40&page=1&output=json";
        JSONArray docs = new JSONObject(leer(url)).getJSONObject("response").getJSONArray("docs");
        List<Disco> out = new ArrayList<>();
        for (int i = 0; i < docs.length(); i++) {
            JSONObject d = docs.getJSONObject(i);
            Disco x = new Disco();
            x.id = uno(d, "identifier");
            x.titulo = uno(d, "title");
            x.artista = uno(d, "creator");
            if (!x.id.isEmpty()) out.add(x);
        }
        return out;
    }

    /** Canciones del disco; de cada una deja solo el MP3 más liviano. */
    public static List<Pista> pistas(String id) throws Exception {
        JSONArray files = new JSONObject(leer("https://archive.org/metadata/" + URLEncoder.encode(id, "UTF-8"))).optJSONArray("files");
        Map<String, Pista> mejor = new HashMap<>();
        List<String> orden = new ArrayList<>();
        if (files != null) for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.getJSONObject(i);
            String name = f.optString("name", "");
            if (!name.toLowerCase().endsWith(".mp3")) continue;
            String key = name.replaceAll("(?i)(_64kb|_vbr|_128kb|_256kb|_320kb)?\\.mp3$", "");
            long size = 0;
            try { size = Long.parseLong(f.optString("size", "0")); } catch (Exception ignored) {}
            Pista p = mejor.get(key);
            if (p == null) { orden.add(key); }
            if (p == null || (size > 0 && size < p.bytes)) {
                Pista n = new Pista();
                n.archivo = name;
                String t = f.optString("title", "");
                n.titulo = t.isEmpty() ? key.replaceAll(".*/", "").replace('_', ' ') : t;
                n.bytes = size;
                n.dur = f.optString("length", "");
                mejor.put(key, n);
            }
        }
        List<Pista> out = new ArrayList<>();
        for (String k : orden) out.add(mejor.get(k));
        return out;
    }

    public static String url(String id, String archivo) throws Exception {
        StringBuilder b = new StringBuilder("https://archive.org/download/").append(URLEncoder.encode(id, "UTF-8").replace("+", "%20"));
        for (String part : archivo.split("/")) b.append('/').append(URLEncoder.encode(part, "UTF-8").replace("+", "%20"));
        return b.toString();
    }

    public static void bajar(String id, String archivo, File dst, Prog pr) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url(id, archivo)).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", "DJChepeGallego/6 (Android)");
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {                       // archive.org a veces manda a otro servidor
            String loc = c.getHeaderField("Location");
            c.disconnect();
            c = (HttpURLConnection) new URL(loc).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
        }
        long total = c.getContentLengthLong();
        try (InputStream in = c.getInputStream(); FileOutputStream os = new FileOutputStream(dst)) {
            byte[] buf = new byte[1 << 16];
            long got = 0;
            int n, last = -1;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                got += n;
                if (total > 0) {
                    int pc = (int) (got * 100 / total);
                    if (pc != last) { last = pc; pr.p(pc); }
                }
            }
        } finally {
            c.disconnect();
        }
    }

    private Libre() {}
}
