package co.jose.mibarra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Teclado Mi Barra: sugerencias arriba (aprende sus palabras), fila de signos a la vista,
 * números del mismo tamaño, tildes y signos dejando presionado, ◀ ▶ para mover el cursor
 * y 🎤 integrado (usa el dictado sin conexión del celular cuando está descargado).
 */
public class TecladoMiBarra extends InputMethodService {

    private final Handler h = new Handler(Looper.getMainLooper());
    private LinearLayout raiz, filas;
    private TextView[] sug = new TextView[3];
    private boolean mayus, bloqueoMayus, simbolos;
    private SpeechRecognizer sr;
    private boolean escuchando;

    // Diccionario: palabra → veces usada; y pares "palabra siguiente"
    private final Map<String, Integer> dic = new HashMap<>();
    private final Map<String, Map<String, Integer>> siguiente = new HashMap<>();
    private final Map<String, Integer> aprendidas = new HashMap<>();
    private String anterior = "";

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    static final String[] SIMBOLOS = {"@", "#", "$", "%", "*", "-", "+", "/", "(", ")"};
    static final String[] NUM = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    static final String[] NUM_ALT = {"!", "\"", "'", "¿", "?", "=", "&", "×", "÷", "°"};
    static final String[][] LETRAS = {
            {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"},
            {"a", "s", "d", "f", "g", "h", "j", "k", "l", "ñ"},
            {"z", "x", "c", "v", "b", "n", "m"}};
    static final Map<String, String> ALT = new HashMap<>();
    static {
        String[][] a = {{"q", "%"}, {"w", "\\"}, {"e", "é è ê ë €"}, {"r", "="}, {"t", "["}, {"y", "]"}, {"u", "ú ü ù"}, {"i", "í ì ï"},
                {"o", "ó ò ö º"}, {"p", "}"}, {"a", "á à ä ª @"}, {"s", "#"}, {"d", "$"}, {"f", "-"}, {"g", "&"}, {"h", "_"}, {"j", "+"},
                {"k", "("}, {"l", ")"}, {"ñ", "/"}, {"z", "*"}, {"x", "\""}, {"c", "' ç"}, {"v", ":"}, {"b", ";"}, {"n", "! ñ"}, {"m", "?"},
                {",", "; : …"}, {".", "… ? ! ¿ ¡"}};
        for (String[] x : a) ALT.put(x[0], x[1]);
        for (int i = 0; i < 10; i++) ALT.put(NUM[i], NUM_ALT[i]);
    }
    static final String[][] PAG_SIMBOLOS = {
            {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"},
            {"@", "#", "$", "%", "&", "-", "+", "(", ")", "/"},
            {"*", "\"", "'", ":", ";", "!", "?", "¿", "¡", "="},
            {"€", "°", "×", "÷", "½", "¼", "¾", "_", "~", "|"}};

    // ---------------- Diccionario ----------------

    /** "cancion" → "canción": la forma con tilde más usada de cada palabra. */
    private final Map<String, String> sinTilde = new HashMap<>();
    /** La última corrección automática, para deshacerla con ⌫. */
    private String corregidaDe, corregidaA;

    private static final String ABC = "abcdefghijklmnñopqrstuvwxyzáéíóúü";

    /** Corrector: si la palabra no existe, busca la más usada que se le parezca (una letra de diferencia o una tilde). */
    private String corregir(String palabra) {
        String w = palabra.toLowerCase(new Locale("es"));
        if (w.length() < 3 || dic.containsKey(w) || !w.matches("[\\p{L}]+")) return null;
        String mejor = sinTilde.get(SaludosActivity.sinTildes(w));
        if (mejor == null || mejor.equals(w)) {
            mejor = null;
            int peso = 4;
            List<String> cand = new ArrayList<>();
            for (int i = 0; i <= w.length(); i++) {
                if (i < w.length()) cand.add(w.substring(0, i) + w.substring(i + 1));                       // sobra una letra
                if (i < w.length() - 1) cand.add(w.substring(0, i) + w.charAt(i + 1) + w.charAt(i) + w.substring(i + 2)); // dos al revés
                for (int k = 0; k < ABC.length(); k++) {
                    char c = ABC.charAt(k);
                    if (i < w.length()) cand.add(w.substring(0, i) + c + w.substring(i + 1));               // una letra cambiada
                    cand.add(w.substring(0, i) + c + w.substring(i));                                       // falta una letra
                }
            }
            for (String c : cand) { int v = dic.getOrDefault(c, 0); if (v > peso) { peso = v; mejor = c; } }
        }
        if (mejor == null) return null;
        if (Character.isUpperCase(palabra.charAt(0))) mejor = Character.toUpperCase(mejor.charAt(0)) + mejor.substring(1);
        return mejor;
    }

    private File archivoAprendido() { return new File(getFilesDir(), "teclado_palabras.txt"); }

    private void cargarDiccionario() {
        if (!dic.isEmpty()) return;
        try (InputStream in = getAssets().open("palabras.txt")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            String[] ps = bo.toString("UTF-8").split("\\s+");
            // Versión 22: 30.000 palabras en orden de uso; las más usadas pesan más
            for (int i = 0; i < ps.length; i++) if (!ps[i].isEmpty()) dic.put(ps[i], Math.max(1, 60 - (int) (Math.log(i + 2) * 5.5)));
            for (Map.Entry<String, Integer> e : dic.entrySet()) {
                String k = SaludosActivity.sinTildes(e.getKey());
                String y = sinTilde.get(k);
                if (y == null || dic.getOrDefault(y, 0) < e.getValue()) sinTilde.put(k, e.getKey());
            }
        } catch (Exception ignored) {}
        try {
            for (String l : Files.readAllLines(archivoAprendido().toPath(), StandardCharsets.UTF_8)) {
                String[] p = l.split("\t");
                if (p.length == 2) { int v = Integer.parseInt(p[1]); aprendidas.put(p[0], v); dic.put(p[0], dic.getOrDefault(p[0], 0) + v); }
                else if (p.length == 3) siguiente.computeIfAbsent(p[0], k -> new HashMap<>()).put(p[1], Integer.parseInt(p[2]));
            }
        } catch (Exception ignored) {}
    }

    private long ultimaGuardada;

    private void aprender(String palabra) {
        String w = palabra.toLowerCase(new Locale("es")).replaceAll("[^\\p{L}0-9]", "");
        if (w.length() < 2) { anterior = ""; return; }
        dic.put(w, dic.getOrDefault(w, 0) + 3);
        aprendidas.put(w, aprendidas.getOrDefault(w, 0) + 3);
        if (!anterior.isEmpty()) {
            Map<String, Integer> m = siguiente.computeIfAbsent(anterior, k -> new HashMap<>());
            m.put(w, m.getOrDefault(w, 0) + 1);
        }
        anterior = w;
        if (System.currentTimeMillis() - ultimaGuardada > 15000) guardarDiccionario();
    }

    private void guardarDiccionario() {
        ultimaGuardada = System.currentTimeMillis();
        StringBuilder b = new StringBuilder();
        for (Map.Entry<String, Integer> e : aprendidas.entrySet()) b.append(e.getKey()).append('\t').append(e.getValue()).append('\n');
        for (Map.Entry<String, Map<String, Integer>> e : siguiente.entrySet())
            for (Map.Entry<String, Integer> f : e.getValue().entrySet())
                b.append(e.getKey()).append('\t').append(f.getKey()).append('\t').append(f.getValue()).append('\n');
        final byte[] datos = b.toString().getBytes(StandardCharsets.UTF_8);
        new Thread(() -> { try { Files.write(archivoAprendido().toPath(), datos); } catch (Exception ignored) {} }).start();
    }

    // ---------------- La vista ----------------

    @Override
    public View onCreateInputView() {
        cargarDiccionario();
        raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable fondo = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF1F2738, 0xFF161C2A});
        raiz.setBackground(fondo);
        raiz.setPadding(dp(3), 0, dp(3), dp(6));
        LinearLayout barra = new LinearLayout(this);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            TextView t = new TextView(this);
            t.setTextColor(Color.WHITE);
            t.setTextSize(18);
            t.setGravity(Gravity.CENTER);
            t.setSingleLine(true);
            if (i == 1) t.setTypeface(Typeface.DEFAULT_BOLD);
            final int k = i;
            t.setOnClickListener(v -> elegirSugerencia(k));
            sug[i] = t;
            barra.addView(t, new LinearLayout.LayoutParams(0, dp(42), 1f));
        }
        raiz.addView(barra);
        filas = new LinearLayout(this);
        filas.setOrientation(LinearLayout.VERTICAL);
        raiz.addView(filas);
        armar();
        return raiz;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        simbolos = false;
        int clase = info.inputType & InputType.TYPE_MASK_CLASS;
        anterior = "";
        armar();
        autoMayus();
        actualizarSugerencias();
        if (clase == InputType.TYPE_CLASS_NUMBER || clase == InputType.TYPE_CLASS_PHONE) { simbolos = true; armar(); }
    }

    @Override public void onFinishInputView(boolean f) {
        super.onFinishInputView(f);
        if (repActivo != null) { h.removeCallbacks(repActivo); repActivo = null; }
        pararVoz();
        guardarDiccionario();
    }

    /** La tecla que se está repitiendo (⌫ o flechas). Si el teclado se redibuja, se para. */
    private Runnable repActivo;

    private void armar() {
        if (filas == null) return;
        if (repActivo != null) { h.removeCallbacks(repActivo); repActivo = null; }
        filas.removeAllViews();
        if (simbolos) {
            for (String[] f : PAG_SIMBOLOS) fila(f, 1, null);
        } else {
            fila(SIMBOLOS, 0.8f, 0xFF2C3446);
            fila(NUM, 1, null);
            fila(LETRAS[0], 1, null);
            LinearLayout f2 = filaVacia();
            for (String s : LETRAS[1]) f2.addView(tecla(s), peso(1));
            LinearLayout f3 = filaVacia();
            f3.addView(especial(bloqueoMayus ? "⇪" : "⇧", this::shift, mayus), peso(1.4f));
            for (String s : LETRAS[2]) f3.addView(tecla(s), peso(1));
            f3.addView(repetible("⌫", this::borrar), peso(1.4f));
        }
        LinearLayout f4 = filaVacia();
        f4.addView(especial(simbolos ? "ABC" : "?123", () -> { simbolos = !simbolos; armar(); }, false), peso(1.2f));
        TextView mic = especial("🎤", this::voz, false);
        GradientDrawable gm = new GradientDrawable();
        gm.setColor(escuchando ? 0xFFFF5252 : 0xFFE53935);
        gm.setCornerRadius(dp(9));
        mic.setBackground(gm);
        f4.addView(mic, peso(1));
        f4.addView(tecla(","), peso(1));
        f4.addView(repetible("◀", () -> mover(KeyEvent.KEYCODE_DPAD_LEFT)), peso(1));
        f4.addView(espacio(), peso(3.2f));
        f4.addView(repetible("▶", () -> mover(KeyEvent.KEYCODE_DPAD_RIGHT)), peso(1));
        f4.addView(tecla("."), peso(1));
        TextView ent = especial("↵", this::enter, false);
        GradientDrawable ge = new GradientDrawable();
        ge.setColor(0xFF1565C0);
        ge.setCornerRadius(dp(9));
        ent.setBackground(ge);
        f4.addView(ent, peso(1.2f));
    }

    private LinearLayout.LayoutParams peso(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, w);
        p.setMargins(dp(2), dp(3), dp(2), dp(3));
        return p;
    }

    private LinearLayout filaVacia() { return filaVacia(dp(50)); }

    private LinearLayout filaVacia(int alto) {
        LinearLayout f = new LinearLayout(this);
        filas.addView(f, new LinearLayout.LayoutParams(-1, alto));
        return f;
    }

    private void fila(String[] teclas, float alto, Integer color) {
        LinearLayout f = filaVacia(Math.round(dp(50) * alto));
        for (String s : teclas) {
            TextView t = tecla(s);
            if (color != null) {
                GradientDrawable g = new GradientDrawable();
                g.setColor(color);
                g.setCornerRadius(dp(9));
                t.setBackground(g);
                t.setTextColor(0xFFFFD27A);
                t.setTextSize(18);
            }
            f.addView(t, peso(1));
        }
    }

    private GradientDrawable fondoTecla(int c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(dp(9));
        return g;
    }

    private TextView base(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        t.setBackground(fondoTecla(0xFF3A4356));
        return t;
    }

    private String visible(String s) { return mayus && s.length() == 1 && Character.isLetter(s.charAt(0)) ? s.toUpperCase(new Locale("es")) : s; }

    /** Tecla normal: un toque escribe; dejándola presionada salen los signos o las tildes. */
    private TextView tecla(String s) {
        FrameLayoutTecla t = new FrameLayoutTecla(this, visible(s), ALT.get(s));
        t.setOnTouchListener(new View.OnTouchListener() {
            boolean largo;
            final Runnable alLargo = () -> { largo = true; mostrarAlternos(t, s); };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        largo = false;
                        v.setBackground(fondoTecla(0xFF5B6886));
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                        if (ALT.containsKey(s)) h.postDelayed(alLargo, 380);
                        return true;
                    case MotionEvent.ACTION_UP:
                        h.removeCallbacks(alLargo);
                        v.setBackground(fondoTecla(0xFF3A4356));
                        if (!largo) escribir(visible(s));
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        h.removeCallbacks(alLargo);
                        v.setBackground(fondoTecla(0xFF3A4356));
                        return true;
                }
                return false;
            }
        });
        return t;
    }

    /** Tecla con su signo pequeñito arriba a la derecha. */
    static final class FrameLayoutTecla extends TextView {
        private final String alt;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        FrameLayoutTecla(android.content.Context c, String texto, String alternos) {
            super(c);
            alt = alternos == null ? null : alternos.split(" ")[0];
            setText(texto);
            setTextColor(Color.WHITE);
            setTextSize(22);
            setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF3A4356);
            g.setCornerRadius(9 * c.getResources().getDisplayMetrics().density);
            setBackground(g);
            p.setColor(0xAAFFFFFF);
            p.setTextSize(11 * c.getResources().getDisplayMetrics().scaledDensity);
            p.setTextAlign(android.graphics.Paint.Align.RIGHT);
        }
        @Override protected void onDraw(android.graphics.Canvas c) {
            super.onDraw(c);
            if (alt != null && !alt.equals(getText().toString())) c.drawText(alt, getWidth() - p.getTextSize() * 0.4f, p.getTextSize() * 1.05f, p);
        }
    }

    private PopupWindow pop;

    private void mostrarAlternos(View ancla, String s) {
        String[] ops = ALT.get(s).split(" ");
        if (ops.length == 1) { escribir(ops[0]); return; }
        LinearLayout l = new LinearLayout(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(12));
        l.setBackground(g);
        l.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (String o : ops) {
            String m = mayus ? o.toUpperCase(new Locale("es")) : o;
            TextView t = new TextView(this);
            t.setText(m);
            t.setTextSize(24);
            t.setTextColor(0xFF111111);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> { escribir(m); if (pop != null) pop.dismiss(); });
            l.addView(t, new LinearLayout.LayoutParams(dp(46), dp(52)));
        }
        pop = new PopupWindow(l, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        pop.setElevation(dp(8));
        pop.showAsDropDown(ancla, 0, -ancla.getHeight() - dp(60));
    }

    private TextView especial(String s, Runnable r, boolean activo) {
        TextView t = base(s);
        t.setTextSize(s.length() > 2 ? 15 : 21);
        t.setBackground(fondoTecla(activo ? 0xFF7986CB : 0xFF4B5670));
        t.setOnClickListener(v -> { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); r.run(); });
        return t;
    }

    /** Teclas que repiten mientras se mantienen: borrar y las flechas. */
    private TextView repetible(String s, Runnable r) {
        TextView t = base(s);
        t.setBackground(fondoTecla(0xFF4B5670));
        t.setOnTouchListener(new View.OnTouchListener() {
            int veces;
            final Runnable rep = new Runnable() { @Override public void run() { r.run(); veces++; h.postDelayed(this, veces > 12 ? 35 : 80); } };
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    veces = 0;
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    if (repActivo != null) h.removeCallbacks(repActivo);
                    repActivo = rep;
                    h.postDelayed(rep, 420);
                    r.run();
                    v.setBackground(fondoTecla(0xFF6B7896));
                } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    h.removeCallbacks(rep);
                    if (repActivo == rep) repActivo = null;
                    v.setBackground(fondoTecla(0xFF4B5670));
                }
                return true;
            }
        });
        return t;
    }

    /** Barra espaciadora: un toque pone espacio; deslizando el dedo mueve el cursor. */
    private TextView espacio() {
        TextView t = base("");
        t.setOnTouchListener(new View.OnTouchListener() {
            float x0; boolean movio;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: x0 = e.getX(); movio = false; v.setBackground(fondoTecla(0xFF5B6886)); return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getX() - x0;
                        if (Math.abs(dx) > dp(14)) {
                            movio = true;
                            mover(dx > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT);
                            x0 = e.getX();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        v.setBackground(fondoTecla(0xFF3A4356));
                        if (!movio) escribir(" ");
                        return true;
                }
                return false;
            }
        });
        return t;
    }

    // ---------------- Escribir ----------------

    private void escribir(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (" ".equals(s) || ".".equals(s) || ",".equals(s)) {
            String palabra = palabraActual();
            // Versión 22: revisión automática al terminar la palabra (⌫ enseguida la deja como estaba)
            corregidaDe = null;
            String arreglo = palabra.isEmpty() || palabraNueva(palabra) ? null : corregir(palabra);
            if (arreglo != null) {
                ic.deleteSurroundingText(palabra.length(), 0);
                ic.commitText(arreglo, 1);
                corregidaDe = palabra;
                corregidaA = arreglo;
                palabra = arreglo;
            }
            if (!palabra.isEmpty()) aprender(palabra);
            // ". " después de espacio doble
            CharSequence antes = ic.getTextBeforeCursor(2, 0);
            if (" ".equals(s) && antes != null && antes.length() == 2 && antes.charAt(1) == ' ' && Character.isLetterOrDigit(antes.charAt(0))) {
                ic.deleteSurroundingText(1, 0);
                ic.commitText(". ", 1);
            } else if ((".".equals(s) || ",".equals(s)) && antes != null && antes.length() > 0 && antes.charAt(antes.length() - 1) == ' ') {
                ic.deleteSurroundingText(1, 0);
                ic.commitText(s + " ", 1);
            } else ic.commitText(s, 1);
        } else ic.commitText(s, 1);
        if (mayus && !bloqueoMayus && s.length() == 1 && Character.isLetter(s.charAt(0))) { mayus = false; armar(); }
        autoMayus();
        actualizarSugerencias();
    }

    /** Si ya la escribió igualita antes, es una palabra suya: no se corrige. */
    private boolean palabraNueva(String p) { return aprendidas.getOrDefault(p.toLowerCase(new Locale("es")), 0) >= 6; }

    private void borrar() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (corregidaDe != null) {
            CharSequence a0 = ic.getTextBeforeCursor(corregidaA.length() + 2, 0);
            String t0 = a0 == null ? "" : a0.toString();
            for (String fin : new String[]{" ", ". ", ",", "."}) {
                if (t0.endsWith(corregidaA + fin)) {
                    ic.deleteSurroundingText(corregidaA.length() + fin.length(), 0);
                    ic.commitText(corregidaDe + fin, 1);
                    aprendidas.put(corregidaDe.toLowerCase(new Locale("es")), 6); // no la vuelve a corregir
                    dic.put(corregidaDe.toLowerCase(new Locale("es")), 6);
                    corregidaDe = null;
                    actualizarSugerencias();
                    return;
                }
            }
            corregidaDe = null;
        }
        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) ic.commitText("", 1);
        else {
            CharSequence a = ic.getTextBeforeCursor(2, 0);
            int n = a != null && a.length() == 2 && Character.isSurrogatePair(a.charAt(0), a.charAt(1)) ? 2 : 1;
            ic.deleteSurroundingText(n, 0);
        }
        autoMayus();
        actualizarSugerencias();
    }

    private void mover(int tecla) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, tecla));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, tecla));
        actualizarSugerencias();
    }

    private long ultimoShift;

    private void shift() {
        long ahora = System.currentTimeMillis();
        if (mayus && ahora - ultimoShift < 400) bloqueoMayus = true;
        else if (bloqueoMayus) { bloqueoMayus = false; mayus = false; }
        else mayus = !mayus;
        ultimoShift = ahora;
        armar();
    }

    private void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        String p = palabraActual();
        if (!p.isEmpty()) aprender(p);
        anterior = "";
        EditorInfo ei = getCurrentInputEditorInfo();
        int accion = ei == null ? 0 : ei.imeOptions & EditorInfo.IME_MASK_ACTION;
        boolean multilinea = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (!multilinea && accion != EditorInfo.IME_ACTION_NONE && accion != EditorInfo.IME_ACTION_UNSPECIFIED
                && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) ic.performEditorAction(accion);
        else { ic.commitText("\n", 1); autoMayus(); }
    }

    private void autoMayus() {
        if (bloqueoMayus) return;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null) return;
        int var = ei.inputType & InputType.TYPE_MASK_VARIATION;
        if ((ei.inputType & InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT
                || var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || var == InputType.TYPE_TEXT_VARIATION_URI
                || var == InputType.TYPE_TEXT_VARIATION_PASSWORD || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) {
            if (mayus) { mayus = false; armar(); }
            return;
        }
        CharSequence a = ic.getTextBeforeCursor(3, 0);
        String t = a == null ? "" : a.toString();
        boolean debe = t.trim().isEmpty() || t.endsWith(". ") || t.endsWith("? ") || t.endsWith("! ") || t.endsWith("\n") || t.endsWith("¿") || t.endsWith("¡");
        if (debe != mayus) { mayus = debe; armar(); }
    }

    // ---------------- Sugerencias ----------------

    private String palabraActual() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "";
        CharSequence a = ic.getTextBeforeCursor(40, 0);
        if (a == null) return "";
        String t = a.toString();
        int i = t.length();
        while (i > 0 && Character.isLetterOrDigit(t.charAt(i - 1))) i--;
        return t.substring(i);
    }

    private final String[] mostradas = new String[3];

    private void actualizarSugerencias() {
        if (sug[0] == null || escuchando) return;
        String p = palabraActual().toLowerCase(new Locale("es"));
        List<String> r = new ArrayList<>();
        if (p.isEmpty()) {
            Map<String, Integer> m = siguiente.get(anterior);
            if (m != null) {
                List<Map.Entry<String, Integer>> l = new ArrayList<>(m.entrySet());
                l.sort((x, y) -> y.getValue() - x.getValue());
                for (Map.Entry<String, Integer> e : l) { if (r.size() >= 3) break; r.add(e.getKey()); }
            }
            for (String x : new String[]{"de", "que", "la", "el", "y", "para"}) { if (r.size() >= 3) break; if (!r.contains(x)) r.add(x); }
        } else {
            String ps = SaludosActivity.sinTildes(p);
            List<Map.Entry<String, Integer>> l = new ArrayList<>();
            for (Map.Entry<String, Integer> e : dic.entrySet())
                if (e.getKey().length() > p.length() - 1 && SaludosActivity.sinTildes(e.getKey()).startsWith(ps)) l.add(e);
            l.sort((x, y) -> y.getValue() - x.getValue());
            for (Map.Entry<String, Integer> e : l) { if (r.size() >= 3) break; if (!e.getKey().equals(p)) r.add(e.getKey()); }
            if (r.size() < 3 && !r.contains(p)) r.add(0, p);
        }
        boolean cap = !palabraActual().isEmpty() && Character.isUpperCase(palabraActual().charAt(0));
        int[] orden = {1, 0, 2}; // la mejor va en el centro
        for (int i = 0; i < 3; i++) {
            String w = i < r.size() ? r.get(i) : "";
            if (cap && !w.isEmpty()) w = Character.toUpperCase(w.charAt(0)) + w.substring(1);
            mostradas[orden[i]] = w;
        }
        for (int i = 0; i < 3; i++) sug[i].setText(mostradas[i]);
    }

    private void elegirSugerencia(int k) {
        String w = mostradas[k];
        if (w == null || w.isEmpty()) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        String p = palabraActual();
        if (!p.isEmpty()) ic.deleteSurroundingText(p.length(), 0);
        ic.commitText(w + " ", 1);
        aprender(w);
        autoMayus();
        actualizarSugerencias();
    }

    // ---------------- Micrófono ----------------

    private void voz() {
        if (escuchando) { pararVoz(); armar(); actualizarSugerencias(); return; }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(this, TecladoAjustesActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }
        // Versión 16: si el español está descargado, escucha con el oído propio (sin internet, sin Google)
        // Versión 22: primero el dictado de Google (entiende mucho mejor); el oído propio solo si no hay otro
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            if (VozLocal.listo(this)) { vozLocal(); return; }
            sug[1].setText("Este celular no tiene dictado");
            return;
        }
        seguido = true;
        escucharGoogle();
    }

    /** Dictado seguido: escribe cada frase y vuelve a escuchar solo, hasta que toque 🎤 otra vez. */
    private boolean seguido;
    private int vaciosSeguidos;

    private void escucharGoogle() {
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle b) { sug[0].setText(""); sug[1].setText("🎤 Hable ahora…"); sug[2].setText(""); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float v) {}
            @Override public void onBufferReceived(byte[] b) {}
            @Override public void onEndOfSpeech() { sug[1].setText("✍ Escribiendo…"); }
            @Override public void onError(int e) {
                if (seguido && (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) && ++vaciosSeguidos < 3) {
                    if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} sr = null; }
                    escucharGoogle();
                    return;
                }
                escuchando = false;
                seguido = false;
                if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} sr = null; }
                armar();
                sug[1].setText(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "No le entendí. Toque 🎤 otra vez"
                        : e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ? "Sin internet: baje el español sin conexión (⚙)"
                        : "Toque 🎤 otra vez");
            }
            @Override public void onResults(Bundle b) {
                escuchando = false;
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) {
                        CharSequence a = ic.getTextBeforeCursor(60, 0);
                        String antes = a == null ? "" : a.toString();
                        String t = NotasActivity.signos(r.get(0), antes);
                        if (!antes.isEmpty() && !antes.endsWith(" ") && !antes.endsWith("\n")) t = " " + t;
                        ic.commitText(t + " ", 1);
                        for (String w : t.split("\\s+")) aprender(w);
                    }
                }
                vaciosSeguidos = 0;
                if (seguido) {
                    if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} sr = null; }
                    escucharGoogle();
                    return;
                }
                armar();
                autoMayus();
                actualizarSugerencias();
            }
            @Override public void onPartialResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) sug[1].setText("🎤 " + r.get(0));
            }
            @Override public void onEvent(int t, Bundle b) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
        boolean ya = escuchando;
        escuchando = true;
        if (!ya) armar();
        sr.startListening(i);
    }

    /** Dictado con el oído propio: escucha seguido; cada frase se escribe sola. Toque 🎤 para parar. */
    private void vozLocal() {
        escuchando = true;
        armar();
        sug[0].setText(""); sug[1].setText("🎤 Abriendo el oído…"); sug[2].setText("");
        VozLocal.escuchar(this, new VozLocal.Oido() {
            @Override public void parcial(String t) { if (escuchando) sug[1].setText("🎤 " + t); }
            @Override public void frase(String t) {
                if (!escuchando) return;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                CharSequence a = ic.getTextBeforeCursor(60, 0);
                String antes = a == null ? "" : a.toString();
                String x = NotasActivity.signos(t, antes);
                if (!antes.isEmpty() && !antes.endsWith(" ") && !antes.endsWith("\n")) x = " " + x;
                ic.commitText(x + " ", 1);
                for (String w : x.split("\\s+")) aprender(w);
                sug[1].setText("🎤 Siga hablando… (toque 🎤 para parar)");
            }
            @Override public void error(String txt) { escuchando = false; armar(); sug[1].setText(txt); }
            @Override public void terminado() { if (escuchando) { escuchando = false; armar(); actualizarSugerencias(); } }
        });
    }

    private void pararVoz() {
        VozLocal.parar();
        escuchando = false;
        seguido = false;
        vaciosSeguidos = 0;
        if (sr != null) { try { sr.stopListening(); sr.destroy(); } catch (Exception ignored) {} sr = null; }
    }

    @Override public void onDestroy() { pararVoz(); guardarDiccionario(); super.onDestroy(); }
}
