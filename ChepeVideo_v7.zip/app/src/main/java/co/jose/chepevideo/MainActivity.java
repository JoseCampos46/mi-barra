package co.jose.chepevideo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.provider.OpenableColumns;
import android.view.WindowManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SonicAudioProcessor;
import androidx.media3.effect.Crop;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.google.android.gms.tasks.Tasks;
import com.google.common.collect.ImmutableList;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    static final int TEAL_L = 0xFFE1F5EE, TEAL_D = 0xFF0F6E56, TEAL_T = 0xFF085041;
    static final int AMB_L = 0xFFFAEEDA, AMB_T = 0xFF633806, AMB_B = 0xFFBA7517;
    static final int REQ_VIDEO = 1, REQ_IMAGE = 2, REQ_LAYER = 3, REQ_BG_IMG = 4, REQ_BG_VID = 5,
            REQ_JOIN = 6, REQ_MUSIC = 7, REQ_MIC = 12, REQ_NOTIF = 13,
            REQ_SF_VIDEO = 14, REQ_SF_FOTO = 15;
    static final String[] TRANS = {"✂ Corte", "🌑 Desvanecer", "🔍 Zoom", "➡ Deslizar", "🌀 Giro"};
    static final String[] FORMATS = {"Como el primero", "Vertical", "Horizontal", "Cuadrado"};
    static final long TRANS_MS = 600;

    private ExoPlayer player;
    private PlayerView playerView;
    private OverlayView overlay;
    private TimelineView timeline;
    private CintaView cinta;
    private final java.util.ArrayDeque<List<Proj.Clip>> deshacer = new java.util.ArrayDeque<>();
    private volatile Bitmap fotoVideo;
    private boolean enLista;
    private long baseA, baseAt, baseOff;
    private boolean agarrando;
    private final java.util.Map<Proj.Music, ExoPlayer> sonPlayers = new java.util.HashMap<>();
    private ZoomFrame videoFrame;
    private long lastTapT;
    private LinearLayout topBar, ctxBox, ctxRow, thumbRow, timelineRow, panel, capasBox;
    private int capaSel = -1;
    private final List<View> barras = new ArrayList<>();
    private final List<TextView> durasCapa = new ArrayList<>();
    private HorizontalScrollView ctxScroll;
    private ScrollView gridScroll;
    private TextView titleView, statusView, openBtn, playBtn, muteBtn, undoBtn, tiempoView, saveBtn;
    private LinearLayout herrRow, playRow;
    private HorizontalScrollView herrScroll;
    private Mode pendingMode;
    private long insertAt = -1;
    private Uri ultimoUnido;
    private String ultimoNombre;
    private long ultimoTam;
    private android.media.MediaRecorder grabadora;
    private File vozFile;
    private long vozAt, vozT0;
    private GridLayout grid;
    private final ImageView[] thumbs = new ImageView[5];
    private final EnumMap<Mode, TextView> modeBtns = new EnumMap<>(Mode.class);
    private final Mode[] order = {Mode.OPEN, Mode.JOIN, Mode.CUT, Mode.SPEED, Mode.MUTE,
            Mode.PHOTO, Mode.SUBS, Mode.TEXT, Mode.IMAGE, Mode.CROP,
            Mode.BG, Mode.LAYER, Mode.MUSIC, Mode.AUDIO, Mode.EXPORT};

    private boolean landscape, menuVisible = true, exporting, previewBusy, subsBusy;
    private boolean photoCarta = true, bgGreen, layerGreen;
    private Mode mode = Mode.NONE;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private Compositor previewComp;
    private Seg imgSeg;
    private MediaMetadataRetriever thumbRet;
    private Uri thumbUri;
    private long lastThumbPos = -1;
    private Runnable pendingMic;

    private ExoPlayer musicPlayer;
    private boolean screenOn, askedNotif;
    private int savedVol = -1;
    private Runnable jobCleanup;
    private SharedPreferences prefs;

    private SpeechRecognizer micRec;
    private boolean micActive;
    private long micSegStart;

    // ------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("chepevideo", MODE_PRIVATE);
        player = new ExoPlayer.Builder(this).build();
        player.setSeekParameters(SeekParameters.EXACT);
        buildViews();
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                playBtn.setText(isPlaying ? "⏸" : "▶");
                if (mode == Mode.PHOTO) refreshCtx();
                overlay.invalidate();
            }
        });
        landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyLayout();
        setMode(Mode.NONE);
        handleIntent(getIntent());
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() { onTick(); ui.postDelayed(this, 40); }
    };

    @Override protected void onResume() { super.onResume(); ui.removeCallbacks(tick); ui.post(tick); }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
        if (micActive) finishMic();
        if (grabadora != null) pararVoz();
        player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        keepScreen(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        player.release();
        if (musicPlayer != null) musicPlayer.release();
        if (!exporting) TrabajoService.stop(this);
        final Compositor pc = previewComp;
        final MediaMetadataRetriever tr = thumbRet;
        final Seg sg = imgSeg;
        exec.execute(() -> {
            if (pc != null) pc.release();
            if (sg != null) sg.close();
            if (tr != null) try { tr.release(); } catch (Exception ignored) {}
        });
        exec.shutdown();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        landscape = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyLayout();
        refreshCtx();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        else if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        if (u != null) loadVideo(u);
    }

    // ------------------------------------------------------------ pantalla

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    private TextView chip(String label, boolean active, Runnable r) {
        TextView t = tv(label, 14, active ? Color.WHITE : TEAL_T, true);
        t.setBackground(round(active ? TEAL_D : TEAL_L, 18));
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView lab(String s) {
        TextView t = tv(s, 13, Color.BLACK, true);
        t.setBackground(round(Color.WHITE, 8));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private TextView small(String s, Runnable r) {
        TextView t = tv(s, 22, TEAL_T, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(TEAL_L, 10));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void add(View v) { ctxRow.addView(v); }

    private void buildViews() {
        playerView = (PlayerView) getLayoutInflater().inflate(R.layout.reproductor, null, false);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setShutterBackgroundColor(Color.BLACK);
        playerView.setPlayer(player);

        overlay = new OverlayView(this);
        overlay.onTap = this::onVideoTap;
        overlay.onScrub = (dx, dt, ancho) -> {
            if (cinta == null || fuenteCinta.total() <= 0 || ancho <= 0) return;
            player.pause();
            float vel = Math.abs(dx) / dt / getResources().getDisplayMetrics().density;
            float gan = vel < 0.08f ? 0.3f : vel < 0.25f ? 0.6f : 1f;
            // todo el ancho de la pantalla = todo el video
            cinta.moverPor((long) (dx * gan * fuenteCinta.total() / ancho));
        };
        overlay.onChanged = () -> { marks(); if (mode == Mode.CROP) refreshCtx(); };

        videoFrame = new ZoomFrame(this);
        videoFrame.gate = overlay::wantsPinch;
        videoFrame.box.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        videoFrame.box.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        titleView = tv("🎬 Chepe Video v7", 18, Color.BLACK, true);
        statusView = tv("", 12, TEAL_T, true);
        statusView.setBackground(round(TEAL_L, 8));
        statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
        statusView.setVisibility(View.GONE);
        openBtn = chip("📂 Abrir", false, () -> pick(REQ_VIDEO, "video/*"));
        saveBtn = chip("💾 Guardar", true, this::guardar);

        topBar = hbox();
        topBar.setPadding(dp(10), dp(6), dp(4), dp(6));

        ctxRow = hbox();
        ctxRow.setPadding(dp(6), dp(5), dp(6), dp(5));
        ctxScroll = new HorizontalScrollView(this);
        ctxScroll.setHorizontalScrollBarEnabled(false);
        ctxScroll.addView(ctxRow);

        thumbRow = hbox();
        thumbRow.setPadding(dp(6), 0, dp(6), dp(5));
        for (int i = 0; i < 5; i++) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(i == 2 ? TEAL_D : 0xFFB5D4F4, 4));
            int pd = dp(i == 2 ? 3 : 1);
            iv.setPadding(pd, pd, pd, pd);
            final int off = i - 2;
            iv.setOnClickListener(v -> step(off));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            lp.setMarginEnd(dp(4));
            thumbRow.addView(iv, lp);
            thumbs[i] = iv;
        }
        ctxBox = vbox();
        ctxBox.addView(ctxScroll);
        // Versión 4: las capas (un video por fila) sin tener que desplazarse de lado
        capasBox = vbox();
        capasBox.setPadding(dp(6), dp(4), dp(6), dp(4));
        capasBox.setVisibility(View.GONE);
        ctxBox.addView(capasBox, new LinearLayout.LayoutParams(-1, -2));
        ctxBox.addView(thumbRow);

        timeline = new TimelineView(this);
        timeline.listener = new TimelineView.Listener() {
            @Override public void onSeek(long ms) { player.seekTo(ms); }
            @Override public void onTrim(long s, long e) {
                Proj.trimStart = s; Proj.trimEnd = e;
                Proj.Clip c = capaAbierta();
                if (c != null) { c.a = s; c.b = e; refrescarBarras(); }
                if (mode == Mode.CUT) refreshCtx();
            }
            @Override public void onLock(boolean a, boolean b) {
                Proj.lockA = a; Proj.lockB = b;
                Proj.Clip c = capaAbierta();
                if (c != null) { c.lockA = a; c.lockB = b; }
            }
        };
        playBtn = small("▶", this::togglePlay);
        playBtn.setTextSize(24);
        // Versión 6: la cinta como en InShot (raya roja fija en el centro)
        cinta = new CintaView(this);
        cinta.fuente = fuenteCinta;
        cinta.oyente = oyenteCinta;
        // − y + mueven un cuadro; para acercar o alejar la cinta se usan dos dedos
        TextView minus = small("−", () -> step(-1));
        TextView plus = small("+", () -> step(1));
        // Versión 6.1: más grandes para atinarles con el dedo
        for (TextView bt : new TextView[]{minus, plus}) {
            bt.setTextSize(30);
            GradientDrawable g = round(TEAL_L, 10);
            g.setStroke(dp(2), TEAL_D);
            bt.setBackground(g);
            bt.setPadding(0, 0, 0, dp(3));
        }
        muteBtn = small("🔊", this::silenciar);
        muteBtn.setTextSize(15);
        View mas = new BotonMas();
        mas.setOnClickListener(v -> menuInsertar());
        timelineRow = hbox();
        timelineRow.setPadding(dp(3), dp(2), dp(3), dp(2));
        timelineRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(42), dp(42));
        ml.setMarginEnd(dp(3));
        timelineRow.addView(mas, ml);
        LinearLayout.LayoutParams ul = new LinearLayout.LayoutParams(dp(30), dp(42));
        ul.setMarginEnd(dp(2));
        timelineRow.addView(muteBtn, ul);
        LinearLayout.LayoutParams mn = new LinearLayout.LayoutParams(dp(46), dp(64));
        mn.setMarginEnd(dp(3));
        timelineRow.addView(minus, mn);
        timelineRow.addView(cinta, new LinearLayout.LayoutParams(0, cinta.altoTotal(4), 1f));
        LinearLayout.LayoutParams pn = new LinearLayout.LayoutParams(dp(46), dp(64));
        pn.setMarginStart(dp(3));
        timelineRow.addView(plus, pn);

        // debajo del video: ↶ deshacer · ▶ play
        undoBtn = small("↶", this::deshacerTodo);
        undoBtn.setTextSize(20);
        playRow = hbox();
        playRow.setGravity(Gravity.CENTER_VERTICAL);
        playRow.setPadding(dp(8), dp(2), dp(8), dp(2));
        playRow.addView(undoBtn, new LinearLayout.LayoutParams(dp(44), dp(38)));
        playRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        playRow.addView(playBtn, new LinearLayout.LayoutParams(dp(64), dp(40)));
        playRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        tiempoView = tv("", 12, TEAL_T, true);
        tiempoView.setGravity(Gravity.CENTER);
        playRow.addView(tiempoView, new LinearLayout.LayoutParams(dp(44), dp(38)));

        grid = new GridLayout(this);
        gridScroll = new ScrollView(this);
        // Versión 6: herramientas pequeñas en una sola fila encima de la cinta
        herrRow = hbox();
        herrRow.setPadding(dp(3), dp(3), dp(3), dp(3));
        herrScroll = new HorizontalScrollView(this);
        herrScroll.setHorizontalScrollBarEnabled(false);
        herrScroll.addView(herrRow);
        // Versión 6.3: la calidad queda guardada aquí; 💾 Guardar ya no pregunta
        calidadBtn = herrBtn("⚙", "" + ALTOS[calidadGuardada()]);
        calidadBtn.setOnClickListener(v -> menuCalidad());
        addModeBtn(Mode.MUSIC, "🎵", "Música");
        addModeBtn(Mode.TEXT, "🔤", "Texto");
        addTool("✂", "Dividir", this::dividirTodo);
        addTool("🗑", "Borrar", this::borrarTodo);
        addTool("⧉", "Duplicar", this::duplicarTodo);
        addModeBtn(Mode.SPEED, "🐢", "Velocidad");
        addModeBtn(Mode.ZOOM, "🔍", "Zoom");
        addTool("🎬", "TikTok", this::tiktokTodo);
        addModeBtn(Mode.SUBS, "💬", "Letrero");
        addModeBtn(Mode.LAYER, "👥", "Encima");
        addModeBtn(Mode.IMAGE, "🖼️", "Fotos");
        addTool("👤", "Sin fondo", this::menuSinFondo);
        addModeBtn(Mode.BG, "🌄", "Fondo");
        addModeBtn(Mode.CROP, "🔲", "Cuadro");
        addModeBtn(Mode.PHOTO, "📷", "Foto");
        addModeBtn(Mode.AUDIO, "🎧", "A M4A");
    }

    private TextView herrBtn(String icon, String label) {
        TextView t = tv(icon + "\n" + label, 10.5f, TEAL_T, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(2), dp(3), dp(2), dp(3));
        t.setBackground(round(TEAL_L, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(58), dp(48));
        lp.setMarginEnd(dp(4));
        herrRow.addView(t, lp);
        return t;
    }

    private void addTool(String icon, String label, Runnable r) {
        TextView t = herrBtn(icon, label);
        t.setOnClickListener(v -> r.run());
    }

    /** El botón rojo con una cruz gruesa: inserta video, foto, audio o texto en la raya roja. */
    private final class BotonMas extends View {
        final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        BotonMas() { super(MainActivity.this); }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            pp.setColor(0xFFE53935);
            cv.drawRoundRect(0, 0, w, h, dp(9), dp(9), pp);
            pp.setColor(Color.WHITE);
            float g = Math.min(w, h) * 0.17f, l = Math.min(w, h) * 0.30f, cx = w / 2f, cy = h / 2f;
            cv.drawRoundRect(cx - l, cy - g / 2f, cx + l, cy + g / 2f, g / 3f, g / 3f, pp);
            cv.drawRoundRect(cx - g / 2f, cy - l, cx + g / 2f, cy + l, g / 3f, g / 3f, pp);
        }
    }

    private void addModeBtn(final Mode m, String icon, String label) {
        TextView t = herrBtn(icon, label);
        t.setOnClickListener(v -> onModeClick(m));
        modeBtns.put(m, t);
    }

    /** Versión 4: todos los botones iguales y apagados; solo se enciende el que él toque. */
    private void styleBtn(Mode m, boolean active) {
        TextView t = modeBtns.get(m);
        if (t == null) return;
        if (active) {
            GradientDrawable g = round(TEAL_D, 10);
            g.setStroke(dp(3), 0xFFEF9F27);
            t.setBackground(g);
            t.setTextColor(Color.WHITE);
        } else {
            t.setBackground(round(TEAL_L, 10));
            t.setTextColor(TEAL_T);
        }
    }

    private static void detach(View v) {
        ViewParent p = v.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(v);
    }

    private void applyLayout() {
        if (panel != null) { panel.removeAllViews(); detach(panel); }
        gridScroll.removeAllViews();
        for (View v : new View[]{videoFrame, titleView, statusView, openBtn, saveBtn, ctxBox, timelineRow, grid, topBar, gridScroll, herrScroll, playRow}) detach(v);
        topBar.removeAllViews();
        if (!landscape) {
            // Versión 6, como InShot: video grande arriba, ▶ debajo, herramientas encima de la cinta
            topBar.addView(titleView);
            topBar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
            sl.setMarginEnd(dp(6));
            topBar.addView(statusView, sl);
            topBar.addView(openBtn);
            topBar.addView(saveBtn);
            LinearLayout root = vbox();
            root.setBackgroundColor(Color.WHITE);
            root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));
            root.addView(videoFrame, new LinearLayout.LayoutParams(-1, 0, 1f));
            root.addView(playRow, new LinearLayout.LayoutParams(-1, -2));
            root.addView(ctxBox, new LinearLayout.LayoutParams(-1, -2));
            root.addView(herrScroll, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.setMargins(0, 0, 0, dp(6));
            root.addView(timelineRow, tl);
            timelineRow.setBackgroundColor(Color.WHITE);
            timelineRow.setVisibility(View.VISIBLE);
            timeline.dark = false;
            panel = null;
            menuVisible = true;
            ui.removeCallbacks(autoHide);
            setContentView(root);
            pantallaLimpia();
        } else {
            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.BLACK);
            root.addView(videoFrame, new FrameLayout.LayoutParams(-1, -1));
            panel = vbox();
            panel.setBackgroundColor(0xEE04342C);
            panel.setPadding(dp(4), dp(4), dp(4), dp(4));
            topBar.addView(openBtn);
            topBar.addView(saveBtn);
            panel.addView(topBar);
            panel.addView(playRow);
            panel.addView(ctxBox);
            panel.addView(herrScroll);
            panel.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));
            root.addView(panel, new FrameLayout.LayoutParams(dp(250), -1, Gravity.END));
            FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            tl.rightMargin = dp(250);
            root.addView(timelineRow, tl);
            timelineRow.setBackgroundColor(0xCC000000);
            timeline.dark = true;
            FrameLayout.LayoutParams st = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
            st.setMargins(dp(8), dp(8), 0, 0);
            root.addView(statusView, st);
            setContentView(root);
            showMenu(true);
        }
    }

    /** Versión 7: pantalla limpia — sin video abierto solo se ve "Abrir"; las herramientas aparecen al abrir uno. */
    private void pantallaLimpia() {
        boolean vacio = Proj.uri == null && Proj.clips.isEmpty() && mode != Mode.JOIN;
        int vis = vacio ? View.GONE : View.VISIBLE;
        if (herrScroll != null) herrScroll.setVisibility(vis);
        if (playRow != null) playRow.setVisibility(vis);
        if (saveBtn != null) saveBtn.setVisibility(vis);
        if (openBtn != null) openBtn.setVisibility(vacio ? View.GONE : View.VISIBLE);
        if (!landscape && timelineRow != null) timelineRow.setVisibility(vis);
    }

    private final Runnable autoHide = () -> { if (landscape && !exporting && !micActive) showMenu(false); };

    private void showMenu(boolean v) {
        if (!landscape || panel == null) return;
        menuVisible = v;
        panel.setVisibility(v ? View.VISIBLE : View.GONE);
        timelineRow.setVisibility(v ? View.VISIBLE : View.GONE);
        ui.removeCallbacks(autoHide);
        if (v) ui.postDelayed(autoHide, 4000);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (landscape && menuVisible && ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            ui.removeCallbacks(autoHide);
            ui.postDelayed(autoHide, 4000);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void onVideoTap() {
        long now = android.os.SystemClock.uptimeMillis();
        boolean dbl = now - lastTapT < 350;
        lastTapT = dbl ? 0 : now;
        if (dbl && videoFrame.zoomed()) videoFrame.reset();
        if (landscape) showMenu(!menuVisible);
        else togglePlay();
    }

    private void status(String s) {
        if (s == null || s.isEmpty()) { statusView.setVisibility(View.GONE); return; }
        statusView.setText(s);
        statusView.setVisibility(View.VISIBLE);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static String fmt(long ms) { return TimelineView.fmt(ms); }

    private static String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }

    private static int even(int v) { v = Math.max(2, v); return v % 2 == 0 ? v : v - 1; }

    // ------------------------------------------------------------ herramientas

    private void onModeClick(Mode m) {
        if (m == Mode.OPEN) { pick(REQ_VIDEO, "video/*"); return; }
        if (m == Mode.EXPORT) { guardar(); return; }
        if (m == Mode.JOIN) { aCinta(); return; }
        if (Proj.uri == null && Proj.clips.isEmpty()) { toast("Primero abra un video 📂"); pick(REQ_VIDEO, "video/*"); return; }
        if (m == Mode.MUTE) { silenciar(); return; }
        // Versión 6: si hay pedazos en la cinta, primero quedan en un solo video y luego se abre la herramienta
        if (mode == Mode.JOIN) { prepararUnico(m); return; }
        setMode(m == mode ? Mode.NONE : m);
    }

    /** De la cinta de pedazos a un solo video, para las herramientas que trabajan sobre el video completo. */
    private void prepararUnico(Mode m) {
        if (Proj.clips.isEmpty()) { setMode(m); return; }
        if (Proj.clips.size() == 1 && Proj.clips.get(0).uri.equals(Proj.uri)) {
            Proj.Clip c = Proj.clips.get(0);
            Proj.trimStart = c.a; Proj.trimEnd = c.b;
            Proj.wm = c.wm; Proj.wmFuerza = c.wmFuerza; Proj.wmArriba = c.wmArriba;
            Proj.clips.clear();
            deshacer.clear();
            setMode(m == Mode.EXPORT ? Mode.NONE : m);
            syncTimeline();
            if (m == Mode.EXPORT) export(Math.max(0, calidad));
            return;
        }
        pendingMode = m;
        player.pause();
        toast("🎞 Primero junto los pedazos en un solo video…");
        doJoin();
    }

    /** Pasa el video abierto a la cinta de pedazos (para insertar, dividir, duplicar). */
    private void aCinta() {
        if (mode == Mode.JOIN) return;
        if (Proj.uri == null) { setMode(Mode.JOIN); return; }
        if (!Proj.texts.isEmpty() || !Proj.sonidos.isEmpty() || !Proj.images.isEmpty())
            toast("Los textos, fotos y sonidos vuelven a aparecer cuando use otra herramienta");
        long g = Math.max(0, player.getCurrentPosition() - Proj.trimStart);
        Proj.Clip c = new Proj.Clip(Proj.uri, Proj.name, Proj.durMs, Proj.w, Proj.h, Proj.joinTrans);
        c.thumb = fotoVideo;
        c.wm = Proj.wm; c.wmFuerza = Proj.wmFuerza; c.wmArriba = Proj.wmArriba;
        c.a = Proj.trimStart; c.b = Proj.trimEnd;
        deshacer.clear();
        Proj.clips.clear();
        Proj.clips.add(c);
        capaSel = -1;
        setMode(Mode.JOIN);
        cinta.posMs = g;
        armarLista(g);
    }

    /** El pedazo que está bajo la raya roja (o el escogido). */
    private int clipBajoRaya() {
        if (capaSel >= 0 && capaSel < Proj.clips.size()) return capaSel;
        long[] o = offs();
        long g = cinta.posMs;
        for (int i = 0; i < Proj.clips.size(); i++) if (g >= o[i] && g < o[i + 1]) return i;
        return Proj.clips.isEmpty() ? -1 : Proj.clips.size() - 1;
    }

    private void silenciar() {
        if (Proj.uri == null && Proj.clips.isEmpty()) return;
        Proj.mute = !Proj.mute;
        applyVolume();
        muteBtn.setText(Proj.mute ? "🔇" : "🔊");
        toast(Proj.mute ? "🔇 Video sin sonido" : "🔊 Video con sonido");
        refreshCtx();
    }

    private void deshacerTodo() {
        if (mode == Mode.JOIN) deshacerCinta();
        else toast("↶ Deshacer funciona en la cinta de pedazos");
    }

    private void dividirTodo() {
        if (Proj.uri == null && Proj.clips.isEmpty()) return;
        if (mode == Mode.JOIN) { dividirCinta(); return; }
        if (mode == Mode.MUSIC && Proj.selSon != null) { dividirSonido(); return; }
        dividirVideoSolo();
    }

    private void borrarTodo() {
        if (mode == Mode.JOIN) {
            int i = clipBajoRaya();
            if (i < 0) return;
            capaSel = i;
            borrarCinta();
            toast("🗑 Pedazo borrado (↶ para deshacer)");
            return;
        }
        if (cinta.selFila == 1 && Proj.selSon != null) { borrarSonido(); return; }
        if (cinta.selFila == 2 && Proj.selText != null) {
            Proj.texts.remove(Proj.selText);
            Proj.selText = null; cinta.selFila = -1; cinta.selIdx = -1;
            marks(); refreshCtx();
            return;
        }
        toast("Divida primero con ✂ y luego borre el pedazo que no quiere");
    }

    private void duplicarTodo() {
        if (Proj.uri == null && Proj.clips.isEmpty()) return;
        if (mode != Mode.JOIN) aCinta();
        int i = clipBajoRaya();
        if (i < 0) return;
        capaSel = i;
        duplicarCinta();
        toast("⧉ Pedazo duplicado");
    }

    private void marcaTodo() {
        if (Proj.uri == null && Proj.clips.isEmpty()) return;
        if (mode == Mode.JOIN) capaSel = clipBajoRaya();
        dialogoMarca();
    }

    private void tiktokTodo() {
        if (Proj.uri == null && Proj.clips.isEmpty()) return;
        if (mode == Mode.JOIN) capaSel = clipBajoRaya();
        quitarFinalTikTok();
    }

    /** ➕ rojo: meter algo en la raya roja. */
    private void menuInsertar() {
        String[] op = {"🎬 Video (en la cinta, en la raya roja)", "👥 Video encima (sin fondo)", "🖼 Foto encima",
                "🎵 Audio o música", "🎙 Grabar mi voz", "🔤 Texto"};
        new AlertDialog.Builder(this).setTitle("➕ Insertar en la raya roja").setItems(op, (d, w) -> {
            if (w == 0) {
                if (Proj.uri != null || !Proj.clips.isEmpty()) {
                    aCinta();
                    insertAt = cinta.posMs;
                }
                pickMulti();
                return;
            }
            if (Proj.uri == null && Proj.clips.isEmpty()) { toast("Primero abra un video 📂"); return; }
            Mode need = w == 1 ? Mode.LAYER : w == 2 ? Mode.IMAGE : w == 5 ? Mode.TEXT : Mode.MUSIC;
            final int ww = w;
            Runnable after = () -> {
                if (ww == 1) pick(REQ_LAYER, "video/*");
                else if (ww == 2) pick(REQ_IMAGE, "image/*");
                else if (ww == 3) pick(REQ_MUSIC, "audio/*");
                else if (ww == 4) grabarVoz();
                else editText(newText(""), true);
            };
            if (mode == Mode.JOIN) { accionPendiente = after; prepararUnico(need); }
            else { if (mode != need) setMode(need); after.run(); }
        }).show();
    }

    private Runnable accionPendiente;

    /** 💾 Guardar: siempre el MP4 más liviano sin perder calidad (720p). */
    // Versión 6.1: tamaños para escoger (720 arriba)
    // Versión 7: se agrega 240 (mínima) para comprimir al máximo
    static final int[] ALTOS = {720, 540, 480, 360, 240};
    static final int[] BITS = {1_500_000, 1_100_000, 800_000, 450_000, 250_000};
    static final String[] NOMBRES = {"720 · nítido (familia)", "540 · bueno", "480 · buena (recomendada)", "360 · liviana", "240 · mínima (la más liviana)"};
    private int calidad = -1;

    /** Versión 6.3: la calidad guardada (se escoge una vez en ⚙ Calidad y queda). */
    private int calidadGuardada() {
        int q = prefs.getInt("calidad", 2);
        return Math.max(0, Math.min(ALTOS.length - 1, q));
    }

    /** Versión 6.3: 💾 Guardar ya no pregunta nada: une todo lo de la cinta y guarda de una vez. */
    private void guardar() {
        if (Proj.uri == null && Proj.clips.isEmpty()) { toast("Primero abra un video 📂"); return; }
        if (exporting) { toast("Ya estoy guardando, espere"); return; }
        calidad = calidadGuardada();
        if (!Proj.clips.isEmpty()) prepararUnico(Mode.EXPORT);
        else export(calidad);
    }

    /** Versión 6.3: ⚙ Calidad — se escoge una vez y queda guardada para todos los videos. */
    private void menuCalidad() {
        int ult = calidadGuardada();
        long ms = (mode == Mode.JOIN || !Proj.clips.isEmpty()) ? totalCinta()
                : (long) ((Proj.trimEnd - Proj.trimStart) / Math.max(0.1f, Proj.speed));
        String[] op = new String[ALTOS.length];
        for (int i = 0; i < op.length; i++) {
            op[i] = NOMBRES[i];
            if (ms > 0) {
                double mb = ms / 1000.0 * (BITS[i] + 128_000) / 8.0 / 1_000_000.0;
                op[i] += "   ≈ " + String.format(Locale.US, "%.1f MB", mb);
            }
        }
        new AlertDialog.Builder(this).setTitle("⚙ Calidad para guardar")
                .setSingleChoiceItems(op, ult, (d, w) -> {
                    d.dismiss();
                    calidad = w;
                    prefs.edit().putInt("calidad", w).apply();
                    if (calidadBtn != null) calidadBtn.setText("⚙\n" + ALTOS[w]);
                    toast("Queda guardado: " + NOMBRES[w]);
                })
                .setNegativeButton("Cerrar", null).show();
    }

    private TextView calidadBtn;
    /** Versión 6.3: si la unión es el video final (sin adornos), ya quedó guardado. */
    private boolean unionEsFinal;

    private boolean sinAdornos() {
        return Proj.texts.isEmpty() && Proj.images.isEmpty() && Proj.sonidos.isEmpty() && Proj.subs.isEmpty()
                && !Proj.mute && Proj.speed == 1f && Proj.crop == null && Proj.layer == null && Proj.bg == null && Proj.zooms.isEmpty();
    }

    // ------------------------------------------------------------ Versión 6: 🎙 grabar mi voz encima del video

    private void grabarVoz() {
        if (Proj.uri == null) return;
        if (grabadora != null) { pararVoz(); return; }
        needMic(() -> {
            try {
                File dir = new File(getFilesDir(), "voces");
                dir.mkdirs();
                vozFile = new File(dir, "voz_" + stamp() + ".m4a");
                android.media.MediaRecorder r = Build.VERSION.SDK_INT >= 31 ? new android.media.MediaRecorder(this) : new android.media.MediaRecorder();
                r.setAudioSource(android.media.MediaRecorder.AudioSource.MIC);
                r.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);
                r.setAudioEncodingBitRate(96000);
                r.setAudioSamplingRate(44100);
                r.setOutputFile(vozFile.getAbsolutePath());
                r.prepare();
                vozAt = player.getCurrentPosition();
                if (vozAt >= Proj.trimEnd - 300) { vozAt = Proj.trimStart; player.seekTo(vozAt); }
                player.setVolume(0f);
                r.start();
                vozT0 = android.os.SystemClock.elapsedRealtime();
                grabadora = r;
                player.play();
                if (mode != Mode.MUSIC) setMode(Mode.MUSIC); else refreshCtx();
                status("🎙 Grabando… hable ahora");
            } catch (Exception e) {
                grabadora = null;
                toast("No se pudo grabar: " + e.getMessage());
            }
        });
    }

    private void pararVoz() {
        android.media.MediaRecorder r = grabadora;
        if (r == null) return;
        grabadora = null;
        long dur = android.os.SystemClock.elapsedRealtime() - vozT0;
        try { r.stop(); } catch (Exception ignored) { dur = 0; }
        try { r.release(); } catch (Exception ignored) {}
        player.pause();
        applyVolume();
        status(null);
        if (dur < 500 || vozFile == null || !vozFile.exists()) { toast("La grabación quedó muy corta"); refreshCtx(); return; }
        Proj.Music m = new Proj.Music(Uri.fromFile(vozFile), "Mi voz", dur);
        m.at = vozAt; m.a = 0; m.b = dur; m.vol = 1f;
        m.entra = false; m.sale = false;
        Proj.sonidos.add(m);
        Proj.selSon = m;
        cinta.selFila = 1; cinta.selIdx = Proj.sonidos.size() - 1;
        player.seekTo(vozAt);
        marks();
        refreshCtx();
        toast("🎙 Su voz quedó en la pista morada");
    }

    private void setMode(Mode m) {
        Mode prev = mode;
        if (prev == Mode.PHOTO && m != Mode.PHOTO) player.setPlaybackParameters(new PlaybackParameters(Proj.speed));
        if (prev == Mode.CROP && m != Mode.CROP && isFullCrop()) Proj.crop = null;
        mode = m;
        overlay.mode = m;
        // Versión 5: al entrar a la cinta de pedazos se ven seguidos; al salir vuelve el video abierto
        if (m == Mode.JOIN && prev != Mode.JOIN && !Proj.clips.isEmpty()) armarLista(0);
        if (m != Mode.JOIN && prev == Mode.JOIN) salirDeLista();
        if (m != Mode.JOIN && prev == Mode.JOIN || m == Mode.JOIN && prev != Mode.JOIN) {
            cinta.selFila = -1; cinta.selIdx = -1;
            cinta.setLayoutParams(new LinearLayout.LayoutParams(0, cinta.altoTotal(m == Mode.JOIN ? 1 : 4), 1f));
            // Versión 6: la cinta no se encoge sola
        }
        if (m == Mode.PHOTO) {
            player.pause();
            player.setPlaybackParameters(new PlaybackParameters(0.25f));
            lastThumbPos = -1;
        }
        if (m == Mode.CROP && Proj.crop == null) { Proj.crop = new RectF(0, 0, 1, 1); overlay.cropAspect = 0f; }
        for (Mode k : order) styleBtn(k, k == m);
        refreshCtx();
        overlay.invalidate();
    }

    private void refreshCtx() {
        ctxRow.removeAllViews();
        boolean capas = mode == Mode.JOIN;
        capasBox.setVisibility(capas ? View.VISIBLE : View.GONE);
        ctxScroll.setVisibility(capas ? View.GONE : View.VISIBLE);
        if (!capas) { capasBox.removeAllViews(); barras.clear(); durasCapa.clear(); }
        thumbRow.setVisibility(mode == Mode.PHOTO ? View.VISIBLE : View.GONE);
        pantallaLimpia();
        if (Proj.uri == null && mode != Mode.JOIN) {
            TextView grande = chip("📂  Abrir video", true, () -> pick(REQ_VIDEO, "video/*"));
            grande.setTextSize(22);
            grande.setPadding(dp(22), dp(14), dp(22), dp(14));
            add(grande);
            add(chip("🎞 Varios videos", false, this::pickMulti));
            final String last = prefs.getString("last", null);
            if (last != null) add(chip("↩ Abrir el último: " + shortName(prefs.getString("lastName", "video")), false,
                    () -> loadVideo(Uri.parse(last), false)));
            return;
        }
        switch (mode) {
            case NONE:
                add(lab(shortName(Proj.name) + " · " + Proj.w + " × " + Proj.h + " · " + fmt(Proj.durMs)));
                add(lab("Corra la cinta · ➕ inserta en la raya roja"));
                break;
            case JOIN:
                ctxJoin();
                break;
            case TEXT:
                ctxText();
                break;
            case MUSIC:
                ctxSonido();
                break;
            case ZOOM:
                ctxZoom();
                break;
            case AUDIO:
                add(chip("🗣 Voz · pequeño · ≈ " + audioMb(0), false, () -> exportAudio(0)));
                add(chip("🎵 Música · buena · ≈ " + audioMb(1), true, () -> exportAudio(1)));
                add(lab("Saca el sonido del pedazo " + fmt(Proj.trimStart) + " → " + fmt(Proj.trimEnd)));
                add(lab("Queda en Descargas/MiBarra/ChepeVideo/Audios"));
                break;
            case CUT:
                // Versión 5: el video se recorta con las agarraderas [ ] de la cinta gris
                add(chip("✂ Dividir aquí", false, this::dividirVideoSolo));
                add(chip("🎵 Quitar final TikTok", false, this::quitarFinalTikTok));
                add(chip("↺ Todo", false, () -> { Proj.trimStart = 0; Proj.trimEnd = Proj.durMs; Proj.lockA = false; Proj.lockB = false; syncTimeline(); refreshCtx(); }));
                add(lab("Toque la cinta gris y arrastre [ ] para recortar"));
                break;
            case SPEED:
                for (float s : new float[]{2f, 1f, 0.5f, 0.25f}) {
                    final float sp = s;
                    add(chip(speedName(s), Proj.speed == s, () -> {
                        Proj.speed = sp;
                        player.setPlaybackParameters(new PlaybackParameters(sp));
                        refreshCtx();
                    }));
                }
                add(lab("Así queda el video final"));
                break;
            case MUTE:
                add(chip(Proj.mute ? "🔇 Sin sonido" : "🔊 Con sonido", true, () -> {
                    Proj.mute = !Proj.mute;
                    applyVolume();
                    refreshCtx();
                }));
                add(lab("Toque para cambiar"));
                break;
            case PHOTO:
                add(chip("◀ Atrás 1", false, () -> step(-1)));
                add(chip(player.isPlaying() ? "⏸ 0.25x" : "▶ 0.25x", false, this::togglePlay));
                add(chip("Adelante 1 ▶", false, () -> step(1)));
                add(chip("📷 Tomar", true, this::takePhoto));
                add(chip(photoCarta ? "📄 Carta: Sí" : "📄 Carta: No", false, () -> { photoCarta = !photoCarta; refreshCtx(); }));
                break;
            case SUBS: {
                add(chip("en".equals(Proj.lang) ? "Video en: Inglés" : "Video en: Español", false, () -> {
                    Proj.lang = "en".equals(Proj.lang) ? "es" : "en";
                    refreshCtx();
                }));
                add(chip(micActive ? "⏹ Parar" : (subsBusy ? "⏳ Trabajando…" : "✨ Hacer letreros (Gemini)"), false, () -> {
                    if (micActive) finishMic(); else makeSubs();
                }));
                add(chip("🎤 Por micrófono", false, this::startMicSubs));
                add(chip("📱 Sin internet", false, this::makeSubsCelular));
                add(chip("🔑 Llave", false, () -> pedirLlave(false)));
                add(chip("✏️ Corregir", false, this::editSubs));
                String[] sm = {"👁 Ambos", "👁 Solo original", "🚫 Ocultos"};
                add(chip(sm[Proj.subsMode], false, () -> { Proj.subsMode = (Proj.subsMode + 1) % 3; refreshCtx(); }));
                add(lab(Proj.subs.size() + " letreros"));
                break;
            }
            case IMAGE: {
                final Proj.ImageLayer im = Proj.selImage;
                add(chip("🖼 Agregar foto", im == null, () -> pick(REQ_IMAGE, "image/*")));
                if (im != null) {
                    if (Proj.images.size() > 1) add(chip("▶ Siguiente foto (" + (Proj.images.indexOf(im) + 1) + "/" + Proj.images.size() + ")", false, () -> {
                        int k = (Proj.images.indexOf(im) + 1) % Proj.images.size();
                        Proj.selImage = Proj.images.get(k);
                        player.seekTo(Proj.selImage.startMs);
                        refreshCtx();
                    }));
                    add(chip(im.noBg ? "✂ Sin fondo: Sí" : "✂ Sin fondo: No", false, this::toggleImageBg));
                    if (Proj.layer != null) add(chip(Proj.fotoDelante ? "⇅ Foto delante" : "⇅ Video delante", false, () -> {
                        Proj.fotoDelante = !Proj.fotoDelante; overlay.invalidate(); invalidatePreview(); refreshCtx();
                    }));
                    add(chip("⏮ Desde aquí", false, () -> {
                        im.startMs = player.getCurrentPosition();
                        if (im.endMs <= im.startMs + 200) im.endMs = Math.min(Proj.durMs, im.startMs + 5000);
                        marks(); refreshCtx();
                    }));
                    add(chip("Hasta aquí ⏭", false, () -> {
                        im.endMs = Math.max(player.getCurrentPosition(), im.startMs + 200);
                        marks(); refreshCtx();
                    }));
                    add(lab(fmt(im.startMs) + " → " + fmt(im.endMs)));
                    add(chip("⏱ Todo el video", false, () -> { im.startMs = 0; im.endMs = Proj.durMs; marks(); refreshCtx(); }));
                    add(chip("🗑 Quitar", false, () -> {
                        Proj.images.remove(im);
                        Proj.selImage = Proj.images.isEmpty() ? null : Proj.images.get(Proj.images.size() - 1);
                        marks(); refreshCtx();
                    }));
                    add(lab("Mueva con un dedo · agrande con dos"));
                } else {
                    add(lab("La foto queda sin fondo: solo la persona"));
                }
                break;
            }
            case CROP: {
                String[] names = {"Todo", "Libre", "1:1", "9:16", "16:9", "4:5"};
                float[] asp = {-1f, 0f, 1f, 9f / 16f, 16f / 9f, 0.8f};
                boolean fullC = isFullCrop();
                for (int i = 0; i < names.length; i++) {
                    final float a = asp[i];
                    boolean act = a < 0 ? fullC : (!fullC && overlay.cropAspect == a);
                    add(chip(names[i], act, () -> setCrop(a)));
                }
                add(lab(cropInfo()));
                break;
            }
            case BG: {
                add(chip(bgGreen ? "🟩 Tela verde" : "🤖 Automático", false, () -> {
                    bgGreen = !bgGreen;
                    Proj.Background bg = Proj.bg;
                    if (bg != null) bg.green = bgGreen;
                    invalidatePreview(); refreshCtx();
                }));
                add(chip("🖼 Foto", false, () -> pick(REQ_BG_IMG, "image/*")));
                add(chip("🎨 Color", false, this::pickColor));
                add(chip("🎬 Video", false, () -> pick(REQ_BG_VID, "video/*")));
                if (Proj.bg != null) {
                    add(chip("🗑 Quitar", false, () -> { Proj.bg = null; invalidatePreview(); refreshCtx(); }));
                    add(lab("Pause el video para ver el fondo exacto"));
                } else {
                    add(lab("Escoja qué poner detrás de la persona"));
                }
                break;
            }
            case LAYER: {
                final Proj.VideoLayer L = Proj.layer;
                add(chip("🎬 Escoger video", L == null, () -> pick(REQ_LAYER, "video/*")));
                add(chip(layerGreen ? "🟩 Tela verde" : "🤖 Automático", false, () -> {
                    layerGreen = !layerGreen;
                    Proj.VideoLayer l2 = Proj.layer;
                    if (l2 != null) { l2.green = layerGreen; makeLayerStill(); }
                    invalidatePreview(); refreshCtx();
                }));
                if (L != null) {
                    add(chip("⏮ Empieza aquí", false, () -> {
                        L.startMs = player.getCurrentPosition();
                        marks(); invalidatePreview(); refreshCtx();
                    }));
                    add(lab(fmt(L.startMs) + " → " + fmt(L.startMs + L.durMs)));
                    add(chip("🗑 Quitar", false, () -> {
                        Proj.layer = null;
                        overlay.layerStill = null;
                        overlay.layerCut = null;
                        marks(); refreshCtx();
                    }));
                    add(chip(Proj.fotoDelante ? "⇅ Foto delante" : "⇅ Video delante", false, () -> {
                        Proj.fotoDelante = !Proj.fotoDelante; overlay.invalidate(); invalidatePreview(); refreshCtx();
                    }));
                    add(lab("Mueva la persona con el dedo"));
                }
                break;
            }
            case EXPORT:
                for (int q = 0; q < 3; q++) {
                    final int qq = q;
                    add(chip(qName(q) + " · ≈ " + estMb(q), false, () -> export(qq)));
                }
                add(lab("Se guarda en Descargas/MiBarra/ChepeVideo"));
                break;
        }
    }

    private static String speedName(float s) {
        if (s == 2f) return "⚡ 2x";
        if (s == 1f) return "Normal";
        if (s == 0.5f) return "🐢 0.5x";
        return "🐌 0.25x";
    }

    private static String qName(int q) {
        return q == 0 ? "💾 Liviano (WhatsApp)" : q == 1 ? "Buena" : "Máxima";
    }

    private String estMb(int q) {
        double secs = (Proj.trimEnd - Proj.trimStart) / 1000.0 / Math.max(0.1, Proj.speed);
        int vb = q == 0 ? 1_200_000 : q == 1 ? 2_500_000 : 6_000_000;
        double mb = secs * (vb + (Proj.mute ? 0 : 128_000)) / 8.0 / 1_000_000.0;
        return String.format(Locale.US, "%.1f MB", mb);
    }

    private void syncTimeline() {
        timeline.durMs = Proj.durMs;
        timeline.startMs = Proj.trimStart;
        timeline.endMs = Proj.trimEnd;
        timeline.lockA = Proj.lockA;
        timeline.lockB = Proj.lockB;
        timeline.invalidate();
    }

    private void marks() {
        cinta.invalidate();
        timeline.ranges.clear();
        Proj.VideoLayer L = Proj.layer;
        if (L != null) timeline.ranges.add(new long[]{L.startMs, L.startMs + L.durMs, 0xFFEF9F27});
        for (Proj.ImageLayer im : Proj.images) timeline.ranges.add(new long[]{im.startMs, im.endMs, 0xFFD4537E});
        for (Proj.TextLayer t : Proj.texts) timeline.ranges.add(new long[]{t.startMs, t.endMs, 0xFF7F77DD});
        timeline.invalidate();
    }

    private void togglePlay() {
        // Versión 6: ▶ solo reproduce (no abre carpetas)
        if (Proj.uri == null && Proj.clips.isEmpty()) { toast("Abra un video con 📂 Abrir"); return; }
        if (grabadora != null) { pararVoz(); return; }
        if (player.isPlaying()) { player.pause(); return; }
        if (mode == Mode.JOIN && enLista) {
            if (player.getPlaybackState() == Player.STATE_ENDED || cinta.posMs >= totalCinta() - 60) seekGlobal(0);
            player.play();
            return;
        }
        long p = player.getCurrentPosition();
        if (p >= Proj.trimEnd - 60 || p < Proj.trimStart || player.getPlaybackState() == Player.STATE_ENDED)
            player.seekTo(Proj.trimStart);
        player.play();
    }

    private void onTick() {
        keepScreen(exporting || subsBusy || micActive || (Proj.uri != null && player.isPlaying()));
        tiempoView.setText(mode == Mode.JOIN ? fmt(totalCinta()) : Proj.uri == null ? "" : fmt(Proj.trimEnd - Proj.trimStart));
        muteBtn.setText(Proj.mute ? "🔇" : "🔊");
        if (mode == Mode.JOIN && enLista) {
            // en la cinta de pedazos el tiempo es el de toda la cinta
            if (!agarrando) cinta.posMs = globalPos();
            cinta.invalidate();
            return;
        }
        if (Proj.uri == null) return;
        long pos = player.getCurrentPosition();
        boolean playing = player.isPlaying();
        if (playing && !micActive) {
            if (pos >= Proj.trimEnd) { player.pause(); player.seekTo(Proj.trimStart); pos = Proj.trimStart; playing = false; }
            else if (pos < Proj.trimStart - 150) player.seekTo(Proj.trimStart);
        }
        if (micActive && (pos >= Proj.trimEnd || player.getPlaybackState() == Player.STATE_ENDED)) finishMic();
        if (grabadora != null && (pos >= Proj.trimEnd - 80 || player.getPlaybackState() == Player.STATE_ENDED)) pararVoz();
        syncSonidos(pos, playing);
        mostrarZoom(pos, playing);
        timeline.setPos(pos);
        if (!agarrando && (playing || cinta.posMs != pos)) { cinta.posMs = pos; cinta.invalidate(); }
        overlay.posMs = pos;
        overlay.playing = playing;
        overlay.invalidate();
        if (!playing) {
            maybePreview(pos);
            if (mode == Mode.PHOTO && pos != lastThumbPos) { lastThumbPos = pos; loadThumbs(pos); }
        }
    }

    // ------------------------------------------------------------ vista previa en pausa

    private void invalidatePreview() {
        overlay.compositeTime = -1;
        overlay.layerCutTime = -1;
        overlay.invalidate();
    }

    private void maybePreview(final long pos) {
        if (previewBusy) return;
        final boolean needBg = Proj.bg != null && overlay.compositeTime != pos;
        Proj.VideoLayer L = Proj.layer;
        final boolean needLayer = L != null && pos >= L.startMs && pos < L.startMs + L.durMs && overlay.layerCutTime != pos;
        if (!needBg && !needLayer) return;
        previewBusy = true;
        if (previewComp == null) previewComp = new Compositor(this, false);
        final Compositor comp = previewComp;
        float sc = Math.min(1f, 640f / Math.max(1, Math.max(Proj.w, Proj.h)));
        final int pw = Math.max(2, Math.round(Proj.w * sc)), ph = Math.max(2, Math.round(Proj.h * sc));
        exec.execute(() -> {
            Bitmap bgB = null, lc = null;
            if (needBg) try { bgB = comp.composeBg(pw, ph, pos); } catch (Throwable ignored) {}
            if (needLayer) try { lc = comp.layerCut(pos, 480); } catch (Throwable ignored) {}
            final Bitmap fb = bgB, fl = lc;
            ui.post(() -> {
                previewBusy = false;
                if (needBg) { overlay.composite = fb; overlay.compositeTime = pos; }
                if (needLayer) { overlay.layerCut = fl; overlay.layerCutTime = pos; }
                overlay.invalidate();
            });
        });
    }

    // ------------------------------------------------------------ abrir archivos

    private void pick(int req, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType(type);
            try { startActivityForResult(Intent.createChooser(g, "Escoger"), req); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_JOIN) {
            if (res != RESULT_OK || data == null) return;
            List<Uri> us = new ArrayList<>();
            ClipData cd = data.getClipData();
            if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) { Uri x = cd.getItemAt(k).getUri(); if (x != null) us.add(x); }
            else if (data.getData() != null) us.add(data.getData());
            for (Uri x : us) try { getContentResolver().takePersistableUriPermission(x, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            addClips(us);
            return;
        }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        switch (req) {
            case REQ_VIDEO: loadVideo(u); break;
            case REQ_IMAGE: loadImageLayer(u); break;
            case REQ_LAYER: loadVideoLayer(u); break;
            case REQ_BG_IMG: loadBgImage(u); break;
            case REQ_BG_VID: loadBgVideo(u); break;
            case REQ_MUSIC: loadMusic(u); break;
            case REQ_SF_VIDEO: sinFondoVideo(u); break;
            case REQ_SF_FOTO: sinFondoFoto(u); break;
        }
    }

    private void loadVideo(final Uri u) { loadVideo(u, false); }

    private void loadVideo(final Uri u, final boolean keep) {
        status("Abriendo video…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            // Versión 5: una fotito del video para la cinta gris
            Bitmap fv = null;
            if (fi != null && fi.durMs > 0) {
                MediaMetadataRetriever rr = null;
                try { rr = Frames.open(this, u); if (rr != null) fv = Frames.grab(rr, Math.min(1000, fi.durMs / 2), 160, 160); }
                catch (Exception ignored) {}
                finally { if (rr != null) try { rr.release(); } catch (Exception ignored) {} }
            }
            final Bitmap ffv = fv;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                if (micActive) finishMic();
                fotoVideo = ffv;
                Proj.reset(u, fi, keep);
                Proj.name = nameOf(u);
                prefs.edit().putString("last", u.toString()).putString("lastName", Proj.name).apply();
                overlay.vw = fi.w;
                overlay.vh = fi.h;
                overlay.composite = null;
                overlay.layerCut = null;
                overlay.layerStill = null;
                invalidatePreview();
                player.setMediaItem(MediaItem.fromUri(u));
                player.prepare();
                applyVolume();
                player.setPlaybackParameters(new PlaybackParameters(1f));
                syncTimeline();
                marks();
                // Versión 6: el video abierto (o el que salió de unir) queda solo en la cinta
                Proj.clips.clear();
                deshacer.clear();
                capaSel = -1;
                if (!keep) cinta.post(cinta::ajustar);
                setMode(Mode.NONE);
                if (!keep) autoTikTok(u, fi.durMs);
                Mode pm = pendingMode;
                pendingMode = null;
                Runnable acc = accionPendiente;
                accionPendiente = null;
                if (pm == Mode.EXPORT) {
                    // Versión 6.3: un solo archivo. Si no hay adornos, la unión ya es el video final.
                    if (unionEsFinal && ultimoUnido != null) showSaved(ultimoUnido, ultimoNombre, ultimoTam, "video/mp4", "✅ Video listo", "");
                    else export(Math.max(0, calidad));
                    unionEsFinal = false;
                } else if (pm != null) {
                    setMode(pm);
                    if (acc != null) acc.run();
                } else toast("Video listo · " + fmt(fi.durMs));
            });
        });
    }

    private void loadImageLayer(final Uri u) {
        status("✂ Quitando el fondo de la foto…");
        final long pos = player.getCurrentPosition();
        exec.execute(() -> {
            Bitmap orig = Seg.load(this, u, 1600);
            Bitmap cut = null;
            String note = null;
            if (orig != null) {
                try {
                    if (Seg.hasTransparency(orig)) {
                        cut = Seg.trim(orig);
                    } else {
                        if (imgSeg == null) imgSeg = new Seg(false);
                        Bitmap c = Seg.trim(imgSeg.cutout(orig, false));
                        if (c != null && (long) c.getWidth() * c.getHeight() > (long) orig.getWidth() * orig.getHeight() / 50) cut = c;
                        else note = "No encontré una persona en la foto: queda con fondo";
                    }
                } catch (Exception e) {
                    note = "No se pudo quitar el fondo: queda con fondo";
                }
            }
            final Bitmap fo = orig, fc = cut;
            final String fn = note;
            ui.post(() -> {
                status(null);
                if (fo == null) { toast("No pude abrir la foto"); return; }
                long st = pos, en = Math.min(Proj.durMs, pos + 5000);
                if (en - st < 1000) { st = Math.max(0, Proj.durMs - 5000); en = Proj.durMs; }
                Proj.ImageLayer nl = new Proj.ImageLayer(fc != null ? fc : fo, fo, fc != null, st, en);
                Proj.images.add(nl);
                Proj.selImage = nl;
                if (mode != Mode.IMAGE) setMode(Mode.IMAGE);
                if (fn != null) toast(fn);
                marks();
                refreshCtx();
            });
        });
    }

    private void toggleImageBg() {
        final Proj.ImageLayer im = Proj.selImage;
        if (im == null) return;
        if (im.noBg) { im.bmp = im.original; im.noBg = false; refreshCtx(); return; }
        status("✂ Quitando el fondo…");
        exec.execute(() -> {
            Bitmap c = null;
            try {
                if (imgSeg == null) imgSeg = new Seg(false);
                c = Seg.trim(imgSeg.cutout(im.original, false));
            } catch (Exception ignored) {}
            final Bitmap fc = c;
            ui.post(() -> {
                status(null);
                if (fc != null) { im.bmp = fc; im.noBg = true; } else toast("No se pudo quitar el fondo");
                refreshCtx();
            });
        });
    }

    private Bitmap stillOf(Uri u, boolean green) {
        MediaMetadataRetriever r = null;
        try {
            r = Frames.open(this, u);
            Bitmap f = Frames.grab(r, 0, 480, 480);
            if (f == null) return null;
            if (imgSeg == null) imgSeg = new Seg(false);
            return imgSeg.cutout(f, green);
        } catch (Exception e) {
            return null;
        } finally {
            if (r != null) try { r.release(); } catch (Exception ignored) {}
        }
    }

    private void loadVideoLayer(final Uri u) {
        status("👥 Preparando el video de encima…");
        final long pos = player.getCurrentPosition();
        final boolean g = layerGreen;
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            // Versión 6: si es un video ya recortado (fondo verde), se borra el verde solo
            boolean g2 = g;
            if (inf != null) {
                MediaMetadataRetriever rr = null;
                try { rr = Frames.open(this, u); if (rr != null && SinFondo.esVerde(Frames.grab(rr, 300, 160, 160))) g2 = true; }
                catch (Exception ignored) {}
                finally { if (rr != null) try { rr.release(); } catch (Exception ignored) {} }
            }
            final boolean gg = g2;
            final Bitmap still = inf == null ? null : stillOf(u, gg);
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                long st = Math.max(0, Math.min(pos, Proj.durMs - 500));
                Proj.layer = new Proj.VideoLayer(u, fi.durMs, gg, st, (float) fi.h / fi.w);
                layerGreen = gg;
                if (mode != Mode.LAYER) setMode(Mode.LAYER);
                overlay.layerStill = still;
                invalidatePreview();
                marks();
                refreshCtx();
            });
        });
    }

    private void makeLayerStill() {
        final Proj.VideoLayer L = Proj.layer;
        if (L == null) return;
        exec.execute(() -> {
            final Bitmap s = stillOf(L.uri, L.green);
            ui.post(() -> { overlay.layerStill = s; overlay.invalidate(); });
        });
    }

    private void loadBgImage(final Uri u) {
        status("🌄 Cargando el fondo…");
        exec.execute(() -> {
            final Bitmap b = Seg.load(this, u, 1920);
            ui.post(() -> {
                status(null);
                if (b == null) { toast("No pude abrir la foto"); return; }
                Proj.bg = new Proj.Background(1, 0, b, null, bgGreen, 0);
                invalidatePreview();
                refreshCtx();
            });
        });
    }

    private void loadBgVideo(final Uri u) {
        status("🌄 Cargando el video de fondo…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0) { toast("No pude abrir ese video"); return; }
                Proj.bg = new Proj.Background(2, 0, null, u, bgGreen, fi.durMs);
                invalidatePreview();
                refreshCtx();
            });
        });
    }

    private void pickColor() {
        final String[] names = {"⬜ Blanco", "⬛ Negro", "🟩 Verde", "🟦 Azul", "🟥 Rojo", "🟨 Amarillo", "◻️ Gris", "🟫 Café"};
        final int[] cols = {Color.WHITE, Color.BLACK, 0xFF3B6D11, 0xFF185FA5, 0xFFA32D2D, 0xFFEF9F27, 0xFF888780, 0xFF633806};
        new AlertDialog.Builder(this).setTitle("Color de fondo").setItems(names, (d, i) -> {
            Proj.bg = new Proj.Background(0, cols[i], null, null, bgGreen, 0);
            invalidatePreview();
            refreshCtx();
        }).show();
    }

    // ------------------------------------------------------------ cuadro (recorte)

    private boolean isFullCrop() {
        RectF c = Proj.crop;
        return c == null || (c.left < 0.002f && c.top < 0.002f && c.right > 0.998f && c.bottom > 0.998f);
    }

    private void setCrop(float a) {
        if (a < 0f) {
            Proj.crop = new RectF(0, 0, 1, 1);
            overlay.cropAspect = 0f;
        } else {
            overlay.cropAspect = a;
            if (a > 0f) {
                float vw = Proj.w, vh = Proj.h;
                float w = vw, h = w / a;
                if (h > vh) { h = vh; w = h * a; }
                float nw = w / vw, nh = h / vh;
                Proj.crop = new RectF((1 - nw) / 2f, (1 - nh) / 2f, (1 + nw) / 2f, (1 + nh) / 2f);
            } else if (isFullCrop()) {
                Proj.crop = new RectF(0.1f, 0.1f, 0.9f, 0.9f);
            }
        }
        overlay.invalidate();
        refreshCtx();
    }

    private String cropInfo() {
        RectF c = Proj.crop;
        if (c == null) return "Video completo";
        return "Queda de " + Math.round(Proj.w * c.width()) + " × " + Math.round(Proj.h * c.height()) + " · arrastre las esquinas";
    }

    // ------------------------------------------------------------ foto cuadro a cuadro

    // ------------------------------------------------------------ Versión 6: ✂ Quitar fondo y guardar

    private void menuSinFondo() {
        new AlertDialog.Builder(this).setTitle("✂ Quitar fondo y guardar")
                .setItems(new String[]{"🎬 De un video (queda con fondo verde)", "🖼 De una foto (queda sin fondo, PNG)"}, (d, w) -> {
                    if (w == 0) pick(REQ_SF_VIDEO, "video/*"); else pick(REQ_SF_FOTO, "image/*");
                }).show();
    }

    private void sinFondoVideo(final Uri u) {
        status("✂ Revisando el video…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                float sc = Math.min(1f, 720f / Math.max(1, Math.min(fi.w, fi.h)));
                int W = even(Math.round(fi.w * sc)), H = even(Math.round(fi.h * sc));
                final SinFondo ov = new SinFondo(this, u, W, H);
                List<Effect> fx = new ArrayList<>();
                fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(ov)));
                fx.add(Presentation.createForWidthAndHeight(W, H, Presentation.LAYOUT_SCALE_TO_FIT));
                EditedMediaItem ed = new EditedMediaItem.Builder(MediaItem.fromUri(u))
                        .setEffects(new Effects(new ArrayList<>(), fx)).build();
                Composition comp = new Composition.Builder(ImmutableList.of(new EditedMediaItemSequence(ImmutableList.of(ed)))).build();
                final File out = new File(getCacheDir(), "chepe_sinfondo.mp4");
                toast("✂ Esto tarda un rato: va cuadro por cuadro");
                runJob(baseTransformer(2_500_000), comp, out, "✂ Quitando el fondo…", ov::release, f -> {
                    final String name = "SinFondo_" + stamp() + ".mp4";
                    toDownloads(f, "SinFondo", name, "video/mp4", (uu, nm, size) -> {
                        String mb = String.format(Locale.US, "%.1f MB", size / 1_000_000.0);
                        new AlertDialog.Builder(this).setTitle("✅ Video sin fondo listo")
                                .setMessage("Quedó en Descargas/MiBarra/ChepeVideo/SinFondo\n\n" + nm + "\nPesa " + mb
                                        + "\n\nEl fondo verde se borra solo cuando lo ponga 👥 Encima.")
                                .setPositiveButton(Proj.uri != null ? "👥 Ponerlo encima ya" : "OK", (d, w) -> {
                                    if (Proj.uri != null && uu != null) { layerGreen = true; loadVideoLayer(uu); }
                                })
                                .setNegativeButton("Después", null).show();
                    });
                });
            });
        });
    }

    private void sinFondoFoto(final Uri u) {
        status("✂ Quitando el fondo de la foto…");
        exec.execute(() -> {
            Uri saved = null;
            String err = null;
            try {
                Bitmap orig = Seg.load(this, u, 2000);
                if (orig == null) throw new Exception("No pude abrir la foto");
                if (imgSeg == null) imgSeg = new Seg(false);
                Bitmap cut = Seg.trim(imgSeg.cutout(orig, false));
                if (cut == null) throw new Exception("No encontré una persona en la foto");
                File tmp = new File(getCacheDir(), "sinfondo.png");
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp)) { cut.compress(Bitmap.CompressFormat.PNG, 100, fo); }
                saved = Store.saveFile(this, tmp, "SinFondo", "SinFondo_" + stamp() + ".png", "image/png");
            } catch (Exception e) { err = e.getMessage(); }
            final Uri fs = saved;
            final String fe = err;
            ui.post(() -> {
                status(null);
                if (fs == null) { toast(fe != null ? fe : "No se pudo guardar"); return; }
                new AlertDialog.Builder(this).setTitle("✅ Foto sin fondo lista")
                        .setMessage("Quedó en Descargas/MiBarra/ChepeVideo/SinFondo como PNG (sin fondo).")
                        .setPositiveButton(Proj.uri != null ? "🖼 Ponerla encima ya" : "OK", (d, w) -> {
                            if (Proj.uri != null) loadImageLayer(fs);
                        })
                        .setNegativeButton("Después", null).show();
            });
        });
    }

    private void step(int n) {
        player.pause();
        float fms = 1000f / Math.max(1f, Proj.fps);
        long t = player.getCurrentPosition() + Math.round(n * fms);
        player.seekTo(Math.max(0, Math.min(Proj.durMs, t)));
    }

    private void loadThumbs(final long pos) {
        final Uri u = Proj.uri;
        final float fms = 1000f / Math.max(1f, Proj.fps);
        exec.execute(() -> {
            try {
                if (thumbRet == null || !u.equals(thumbUri)) {
                    if (thumbRet != null) try { thumbRet.release(); } catch (Exception ignored) {}
                    thumbRet = Frames.open(this, u);
                    thumbUri = u;
                }
                final Bitmap[] bs = new Bitmap[5];
                for (int i = 0; i < 5; i++) bs[i] = Frames.grab(thumbRet, pos + Math.round((i - 2) * fms), 200, 200);
                ui.post(() -> { for (int i = 0; i < 5; i++) thumbs[i].setImageBitmap(bs[i]); });
            } catch (Exception ignored) {}
        });
    }

    private void takePhoto() {
        final long pos = player.getCurrentPosition();
        final Uri u = Proj.uri;
        final boolean carta = photoCarta;
        status("📷 Guardando foto…");
        exec.execute(() -> {
            String msg;
            MediaMetadataRetriever r = null;
            try {
                r = Frames.open(this, u);
                Bitmap b = Frames.argb(r.getFrameAtTime(pos * 1000L, MediaMetadataRetriever.OPTION_CLOSEST));
                if (b == null) throw new Exception("no salió el cuadro");
                String name = "foto_" + stamp();
                Store.saveJpg(this, b, "Fotos", name + ".jpg");
                if (carta) Store.saveJpg(this, Seg.carta(b), "Fotos", name + "_carta.jpg");
                msg = "📷 Foto guardada en Descargas/MiBarra/ChepeVideo/Fotos";
            } catch (Exception e) {
                msg = "No se pudo sacar la foto: " + e.getMessage();
            } finally {
                if (r != null) try { r.release(); } catch (Exception ignored) {}
            }
            final String m2 = msg;
            ui.post(() -> { status(null); toast(m2); });
        });
    }

    // ------------------------------------------------------------ letreros

    private String langTag() { return "en".equals(Proj.lang) ? "en-US" : "es-CO"; }

    private void needMic(Runnable r) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) r.run();
        else {
            pendingMic = r;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_MIC) return;
        Runnable r = pendingMic;
        pendingMic = null;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && r != null) r.run();
        else toast("Sin permiso del micrófono no se pueden hacer los letreros");
    }

    private void makeSubs() {
        if (subsBusy) { toast("Ya estoy haciendo los letreros"); return; }
        // Versión 4: los letreros los hace Gemini (oye el video, escribe y traduce); si no hay llave, se pide
        if (Letreros.llave(this).length() < 20) { pedirLlave(true); return; }
        subsGemini();
    }

    private void subsGemini() {
        final Uri u = Proj.uri;
        final long s0 = Proj.trimStart, s1 = Math.min(Proj.trimEnd, Proj.trimStart + 20 * 60_000L);
        final boolean en = "en".equals(Proj.lang);
        subsBusy = true;
        status("💬 Sacando el sonido…");
        refreshCtx();
        new Thread(() -> {
            String err = null;
            List<Proj.Sub> out = new ArrayList<>();
            try {
                short[] pcm = AudioPcm.decode16k(this, u, s0, s1);
                out = Letreros.hacer(this, pcm, s0, en, m -> ui.post(() -> status(m)));
                if (out.isEmpty()) err = "Gemini no escuchó voces en el video";
            } catch (java.net.UnknownHostException e) {
                err = "📶 No hay internet para hacer los letreros";
            } catch (Exception e) {
                err = "No se pudieron hacer los letreros: " + e.getMessage();
            }
            final String fe = err;
            final List<Proj.Sub> fo = out;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                if (fe == null) {
                    Proj.subs.clear();
                    Proj.subs.addAll(fo);
                    toast("💬 " + fo.size() + " letreros listos con Gemini");
                } else {
                    toast(fe);
                    if (fe.contains("llave")) pedirLlave(false);
                }
                overlay.invalidate();
                refreshCtx();
            });
        }).start();
    }

    /** Pide una sola vez la llave gratis de Gemini. */
    private void pedirLlave(final boolean luegoHacer) {
        LinearLayout l = vbox();
        l.setPadding(dp(18), dp(8), dp(18), 0);
        TextView ex = tv("Es la misma llave de Mi Barra (empieza por AQ. o por AIza).\n\n1. Toque «🌐 Página» y copie su llave con el ícono 📋.\n2. Vuelva y toque «📋 Pegar».\n3. Toque «Guardar».", 15, Color.BLACK, false);
        l.addView(ex);
        final android.widget.EditText e = new android.widget.EditText(this);
        e.setHint("Llave de Gemini");
        e.setSingleLine(true);
        e.setText(Letreros.llave(this));
        l.addView(e);
        LinearLayout f = hbox();
        TextView pag = chip("🌐 Página", false, () -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Letreros.PAGINA_LLAVE))); } catch (Exception ignored) {}
        });
        TextView peg = chip("📋 Pegar", false, () -> {
            try {
                android.content.ClipboardManager cm = getSystemService(android.content.ClipboardManager.class);
                if (cm != null && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0)
                    e.setText(Letreros.limpiar(String.valueOf(cm.getPrimaryClip().getItemAt(0).coerceToText(this))));
            } catch (Exception ignored) {}
        });
        f.addView(pag);
        f.addView(peg);
        l.addView(f);
        new AlertDialog.Builder(this).setTitle("🔑 Llave de Gemini").setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    Letreros.guardarLlave(this, e.getText().toString());
                    if (Letreros.llave(this).length() < 20) { toast("Esa llave está incompleta"); return; }
                    toast("🔑 Llave guardada");
                    if (luegoHacer) subsGemini();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** El camino viejo (reconocimiento del celular), queda por si no hay internet. */
    private void makeSubsCelular() {
        if (Build.VERSION.SDK_INT >= 33) needMic(this::subsFromFile);
        else askMicMode("En este celular los letreros se hacen así: el video suena en voz alta (yo subo el volumen solo) y el celular lo escucha. No hable mientras tanto. ¿Empezamos?");
    }

    private void askMicMode(String msg) {
        new AlertDialog.Builder(this).setTitle("🎤 Letreros por micrófono").setMessage(msg)
                .setPositiveButton("Empezar", (d, w) -> startMicSubs())
                .setNegativeButton("Cancelar", null).show();
    }

    private void subsFromFile() {
        final Uri u = Proj.uri;
        final long s0 = Proj.trimStart, s1 = Math.min(Proj.trimEnd, Proj.trimStart + 15 * 60_000L);
        final String lang = langTag(), src = Proj.lang;
        subsBusy = true;
        status("💬 Escuchando el video…");
        refreshCtx();
        new Thread(() -> {
            String err = null, note = null;
            List<Proj.Sub> out = new ArrayList<>();
            try {
                short[] pcm = AudioPcm.decode16k(this, u, s0, s1);
                List<int[]> segs = AudioPcm.segments(pcm);
                int fails = 0;
                for (int i = 0; i < segs.size(); i++) {
                    final int n = i + 1, tot = segs.size();
                    ui.post(() -> status("💬 Letreros " + n + " de " + tot + "…"));
                    int[] sg = segs.get(i);
                    String r = Recog.fromPcm(this, ui, pcm, sg[0], sg[1], lang);
                    if (r == null) {
                        fails++;
                        if (out.isEmpty() && fails >= 2) { err = "mic"; break; }
                        continue;
                    }
                    if (!r.trim().isEmpty())
                        out.add(new Proj.Sub(s0 + sg[0] * 1000L / 16000L, s0 + sg[1] * 1000L / 16000L, r.trim(), ""));
                }
                if (err == null && out.isEmpty()) err = segs.isEmpty() ? "No escuché voces en el video" : "mic";
                if (err == null) {
                    List<Proj.Sub> sp = splitSubs(out);
                    out.clear();
                    out.addAll(sp);
                    ui.post(() -> status("🌐 Traduciendo…"));
                    try { translate(out, src); } catch (Exception e) { note = "Letreros listos, pero sin traducción (revise el internet)"; }
                }
            } catch (Exception e) {
                err = "No se pudieron hacer los letreros: " + e.getMessage();
            }
            final String fe = err, fn = note;
            final List<Proj.Sub> fo = out;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                if (fe == null) {
                    Proj.subs.clear();
                    Proj.subs.addAll(fo);
                    toast(fn != null ? fn : "💬 " + fo.size() + " letreros listos");
                } else if ("mic".equals(fe)) {
                    askMicMode("Este celular no deja leer el sonido directo del archivo. Lo hacemos por micrófono: el video suena duro (yo subo el volumen solo) y el celular escucha. ¿Empezamos?");
                } else {
                    toast(fe);
                }
                refreshCtx();
            });
        }).start();
    }

    /** Traduce (se llama desde un hilo de trabajo). */
    private void translate(List<Proj.Sub> list, String src) throws Exception {
        if (list.isEmpty()) return;
        boolean en = "en".equals(src);
        TranslatorOptions o = new TranslatorOptions.Builder()
                .setSourceLanguage(en ? TranslateLanguage.ENGLISH : TranslateLanguage.SPANISH)
                .setTargetLanguage(en ? TranslateLanguage.SPANISH : TranslateLanguage.ENGLISH)
                .build();
        Translator t = Translation.getClient(o);
        try {
            Tasks.await(t.downloadModelIfNeeded(), 180, TimeUnit.SECONDS);
            for (Proj.Sub s : list) {
                if (s.text == null || s.text.trim().isEmpty()) continue;
                s.trans = Tasks.await(t.translate(s.text), 30, TimeUnit.SECONDS);
            }
        } finally {
            t.close();
        }
    }

    private void startMicSubs() {
        needMic(() -> {
            if (micActive) return;
            if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Este celular no tiene reconocimiento de voz"); return; }
            Proj.subs.clear();
            micActive = true;
            player.setVolume(1f);
            maxVolume();
            player.setPlaybackParameters(new PlaybackParameters(1f));
            player.seekTo(Proj.trimStart);
            player.play();
            micRec = SpeechRecognizer.createSpeechRecognizer(this);
            micRec.setRecognitionListener(micListener);
            micListen();
            status("🎤 Escuchando… no hable mientras tanto");
            if (mode != Mode.SUBS) setMode(Mode.SUBS); else refreshCtx();
        });
    }

    private void micListen() {
        if (!micActive || micRec == null) return;
        micSegStart = player.getCurrentPosition();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try { micRec.startListening(i); } catch (Exception e) { ui.postDelayed(this::micListen, 400); }
    }

    private final RecognitionListener micListener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle p) {}
        @Override public void onBeginningOfSpeech() { micSegStart = Math.max(Proj.trimStart, player.getCurrentPosition() - 300); }
        @Override public void onRmsChanged(float v) {}
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onError(int e) { if (micActive) ui.postDelayed(MainActivity.this::micListen, 250); }
        @Override public void onResults(Bundle b) {
            ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (l != null && !l.isEmpty() && l.get(0) != null && !l.get(0).trim().isEmpty()) {
                long end = player.getCurrentPosition();
                Proj.subs.add(new Proj.Sub(micSegStart, Math.max(end, micSegStart + 1200), l.get(0).trim(), ""));
                if (mode == Mode.SUBS) refreshCtx();
            }
            if (micActive) micListen();
        }
        @Override public void onPartialResults(Bundle b) {}
        @Override public void onEvent(int t, Bundle b) {}
    };

    private void finishMic() {
        if (!micActive) return;
        micActive = false;
        try { if (micRec != null) { micRec.cancel(); micRec.destroy(); } } catch (Exception ignored) {}
        micRec = null;
        player.pause();
        restoreVolume();
        applyVolume();
        player.setPlaybackParameters(new PlaybackParameters(mode == Mode.PHOTO ? 0.25f : Proj.speed));
        final List<Proj.Sub> list = splitSubs(new ArrayList<>(Proj.subs));
        Proj.subs.clear();
        Proj.subs.addAll(list);
        final String src = Proj.lang;
        if (list.isEmpty()) { status(null); toast("No escuché voces. Suba el volumen e intente otra vez"); refreshCtx(); return; }
        status("🌐 Traduciendo…");
        subsBusy = true;
        refreshCtx();
        new Thread(() -> {
            String note = null;
            try { translate(list, src); } catch (Exception e) { note = "Letreros listos, pero sin traducción (revise el internet)"; }
            final String fn = note;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                toast(fn != null ? fn : "💬 " + list.size() + " letreros listos");
                refreshCtx();
            });
        }).start();
    }

    private void editSubs() {
        final long pos = player.getCurrentPosition();
        final LinearLayout box = vbox();
        box.setPadding(dp(14), dp(6), dp(14), dp(6));
        final List<Object[]> rows = new ArrayList<>();
        TextView addB = chip("➕ Agregar letrero en " + fmt(pos), false, null);
        box.addView(addB);
        if (Proj.subs.isEmpty()) box.addView(tv("Todavía no hay letreros. Use ✨ Hacer letreros o agregue uno aquí.", 14, Color.BLACK, false));
        for (Proj.Sub s : Proj.subs) addSubRow(box, rows, s);
        addB.setOnClickListener(v -> addSubRow(box, rows, new Proj.Sub(pos, pos + 3000, "", "")));
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this).setTitle("✏️ Corregir letreros").setView(sv)
                .setPositiveButton("Guardar", (d, w) -> applySubRows(rows, false))
                .setNeutralButton("Guardar y traducir", (d, w) -> applySubRows(rows, true))
                .setNegativeButton("Cancelar", null).show();
    }

    private void addSubRow(LinearLayout box, List<Object[]> rows, Proj.Sub s) {
        TextView t = tv("⏱ " + fmt(s.startMs) + " – " + fmt(s.endMs), 13, TEAL_T, true);
        t.setPadding(0, dp(10), 0, 0);
        EditText e1 = new EditText(this);
        e1.setText(s.text);
        e1.setTextColor(Color.BLACK);
        e1.setTextSize(16);
        e1.setHint("Lo que se dice");
        EditText e2 = new EditText(this);
        e2.setText(s.trans);
        e2.setTextColor(AMB_T);
        e2.setTextSize(16);
        e2.setHint("Traducción");
        box.addView(t);
        box.addView(e1);
        box.addView(e2);
        rows.add(new Object[]{s, e1, e2});
    }

    private void applySubRows(List<Object[]> rows, boolean retranslate) {
        final List<Proj.Sub> list = new ArrayList<>();
        for (Object[] r : rows) {
            Proj.Sub s = (Proj.Sub) r[0];
            s.text = ((EditText) r[1]).getText().toString().trim();
            s.trans = ((EditText) r[2]).getText().toString().trim();
            if (!s.text.isEmpty() || !s.trans.isEmpty()) list.add(s);
        }
        Collections.sort(list, (a, b) -> Long.compare(a.startMs, b.startMs));
        Proj.subs.clear();
        Proj.subs.addAll(list);
        refreshCtx();
        if (!retranslate) return;
        final String src = Proj.lang;
        status("🌐 Traduciendo…");
        new Thread(() -> {
            String note = null;
            try { translate(list, src); } catch (Exception e) { note = "No se pudo traducir (revise el internet)"; }
            final String fn = note;
            ui.post(() -> { status(null); toast(fn != null ? fn : "Traducción lista"); refreshCtx(); });
        }).start();
    }

    // ------------------------------------------------------------ trabajos largos (guardar, unir, audio)

    private interface Done { void run(File out); }

    private void askNotif() {
        if (askedNotif || Build.VERSION.SDK_INT < 33) return;
        askedNotif = true;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            try { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF); } catch (Exception ignored) {}
    }

    private Transformer.Builder baseTransformer(int videoBitrate) {
        return new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(new DefaultEncoderFactory.Builder(this)
                        .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
                        .setEnableFallback(true)
                        .build());
    }

    /** Arranca un trabajo con el Transformer; muestra el avance y mantiene la app despierta. */
    private void runJob(Transformer.Builder b, Composition comp, final File out, final String what,
                        final Runnable cleanup, final Done done) {
        if (exporting) { toast("Ya estoy trabajando, espere que termine"); if (cleanup != null) cleanup.run(); return; }
        if (micActive) finishMic();
        player.pause();
        if (out.exists()) out.delete();
        final Transformer tr;
        try {
            tr = b.addListener(new Transformer.Listener() {
                @Override public void onCompleted(Composition c, ExportResult r) { jobEnd(out, null, done); }
                @Override public void onError(Composition c, ExportResult r, ExportException e) { jobEnd(out, e, done); }
            }).build();
        } catch (Exception e) {
            if (cleanup != null) cleanup.run();
            toast("No se pudo empezar: " + e.getMessage());
            return;
        }
        exporting = true;
        jobCleanup = cleanup;
        askNotif();
        TrabajoService.start(this, what);
        status(what + " 0 %");
        try {
            tr.start(comp, out.getAbsolutePath());
        } catch (Exception e) {
            jobEnd(out, e, done);
            return;
        }
        final ProgressHolder ph = new ProgressHolder();
        ui.post(new Runnable() {
            @Override public void run() {
                if (!exporting) return;
                try {
                    if (tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) status(what + " " + ph.progress + " %");
                } catch (Exception ignored) {}
                ui.postDelayed(this, 500);
            }
        });
    }

    private void jobEnd(final File out, Exception e, Done done) {
        if (!exporting) return;
        exporting = false;
        final Runnable c = jobCleanup;
        jobCleanup = null;
        if (c != null) new Thread(c).start();
        TrabajoService.stop(this);
        if (e != null) {
            pendingMode = null;
            accionPendiente = null;
            status(null);
            out.delete();
            String code = (e instanceof ExportException) ? ((ExportException) e).getErrorCodeName() : String.valueOf(e.getMessage());
            new AlertDialog.Builder(this).setTitle("No se pudo terminar")
                    .setMessage("Error: " + code + "\n\nMándeme un pantallazo de este letrero para arreglarlo.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        done.run(out);
    }

    /** Pasa el archivo terminado a Descargas/MiBarra/ChepeVideo/(sub) y luego llama a after. */
    private interface Saved { void run(Uri u, String name, long size); }

    private void toDownloads(final File out, final String sub, final String name, final String mime, final Saved after) {
        status("💾 Pasando a Descargas…");
        exec.execute(() -> {
            Uri saved = null;
            String err = null;
            try { saved = Store.saveFile(this, out, sub, name, mime); } catch (Exception ex) { err = ex.getMessage(); }
            final long size = out.length();
            out.delete();
            final Uri fs = saved;
            final String fe = err;
            ui.post(() -> {
                status(null);
                if (fs == null) { toast("No se pudo pasar a Descargas: " + fe); return; }
                after.run(fs, name, size);
            });
        });
    }

    // ------------------------------------------------------------ guardar MP4

    private long outDurMs() { return (long) ((Proj.trimEnd - Proj.trimStart) / Math.max(0.05f, Proj.speed)); }

    private EditedMediaItemSequence musicSeq(Proj.Music mu, long outMs) {
        boolean loop = mu.durMs > 0 && mu.durMs < outMs;
        MediaItem.Builder mb = new MediaItem.Builder().setUri(mu.uri);
        if (!loop) mb.setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder().setEndPositionMs(outMs).build());
        EditedMediaItem me = new EditedMediaItem.Builder(mb.build())
                .setRemoveVideo(true)
                .setEffects(new Effects(
                        ImmutableList.<AudioProcessor>of(new Gain(mu.vol, mu.soft ? 1500 : 0, mu.soft ? 2500 : 0, outMs, false)),
                        ImmutableList.<Effect>of()))
                .build();
        return new EditedMediaItemSequence(ImmutableList.of(me), loop);
    }

    private void export(int q) {
        if (exporting) { toast("Ya estoy guardando, espere"); return; }
        final Uri u = Proj.uri;
        if (u == null) return;
        RectF crop = isFullCrop() ? null : Proj.crop;
        int srcW = Proj.w, srcH = Proj.h;
        float cw = srcW * (crop != null ? crop.width() : 1f), ch = srcH * (crop != null ? crop.height() : 1f);
        // Versión 6: 💾 Guardar = el más liviano sin perder calidad (720p, 1.5 Mbps)
        int qq = Math.max(0, Math.min(ALTOS.length - 1, q));
        int target = ALTOS[qq];
        int bitrate = BITS[qq];
        float sc = Math.min(1f, target / Math.max(1f, Math.min(cw, ch)));
        int outW = even(Math.round(cw * sc)), outH = even(Math.round(ch * sc));
        // Versión 5: los sonidos de la pista morada
        final List<EditedMediaItemSequence> sons = secuenciasSonido();
        final boolean hayS = !sons.isEmpty();

        MediaItem item = new MediaItem.Builder().setUri(u)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(Proj.trimStart).setEndPositionMs(Proj.trimEnd).build())
                .build();
        List<Effect> fx = new ArrayList<>();
        // Versión 6.1: el zoom grabado va primero (los textos encima no se agrandan)
        if (!Proj.zooms.isEmpty()) fx.add(new ZoomFx(Proj.trimStart));
        boolean subsOn = !Proj.subs.isEmpty() && Proj.subsMode != 2;
        boolean dynamic = Proj.bg != null || Proj.layer != null;
        final ExportOverlay ov = (dynamic || !Proj.images.isEmpty() || !Proj.texts.isEmpty() || subsOn)
                ? new ExportOverlay(this, srcW, srcH, Proj.trimStart, dynamic) : null;
        if (ov != null) fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(ov)));
        if (crop != null) fx.add(new Crop(crop.left * 2f - 1f, crop.right * 2f - 1f, 1f - crop.bottom * 2f, 1f - crop.top * 2f));
        if (Proj.speed != 1f) fx.add(new SpeedChangeEffect(Proj.speed));
        fx.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT));
        List<AudioProcessor> ap = new ArrayList<>();
        if (Proj.speed != 1f && !(Proj.mute && !hayS)) {
            SonicAudioProcessor son = new SonicAudioProcessor();
            son.setSpeed(Proj.speed);
            ap.add(son);
        }
        if (Proj.mute && hayS) ap.add(new Gain(0f, 0, 0, 0, false));
        EditedMediaItem edited = new EditedMediaItem.Builder(item)
                .setRemoveAudio(Proj.mute && !hayS)
                .setEffects(new Effects(ap, fx))
                .build();
        List<EditedMediaItemSequence> seqs = new ArrayList<>();
        seqs.add(new EditedMediaItemSequence(ImmutableList.of(edited)));
        seqs.addAll(sons);
        Composition.Builder cb = new Composition.Builder(ImmutableList.copyOf(seqs));
        if (hayS) cb.experimentalSetForceAudioTrack(true);

        final File out = new File(getCacheDir(), "chepe_export.mp4");
        runJob(baseTransformer(bitrate), cb.build(), out, "💾 Guardando video…",
                ov == null ? null : ov::release,
                f -> {
                    final String name = "ChepeVideo_" + stamp() + ".mp4";
                    toDownloads(f, "", name, "video/mp4", (uu, nm, size) -> showSaved(uu, nm, size, "video/mp4", "✅ Video listo", ""));
                });
    }

    /** Versión 6.3: al terminar no pregunta nada (ni ver, ni compartir): queda guardado y avisa. */
    private void showSaved(final Uri u, String name, long size, final String mime, String title, String sub) {
        String mb = String.format(Locale.US, "%.1f MB", size / 1_000_000.0);
        String donde = "Descargas/MiBarra/ChepeVideo" + (sub.isEmpty() ? "" : "/" + sub);
        status(title + " · " + mb + " · " + donde);
        toast(title + "\n" + donde + "\n" + name + " · " + mb);
        ui.postDelayed(() -> { if (!exporting) status(null); }, 6000);
    }

    // ------------------------------------------------------------ video a audio M4A

    private String audioMb(int q) {
        double secs = outDurMs() / 1000.0;
        int kbps = q == 0 ? 48 : 96;
        return String.format(Locale.US, "%.1f MB", secs * kbps / 8.0 / 1000.0);
    }

    private void exportAudio(final int q) {
        final Uri u = Proj.uri;
        if (u == null) return;
        MediaItem item = new MediaItem.Builder().setUri(u)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(Proj.trimStart).setEndPositionMs(Proj.trimEnd).build())
                .build();
        List<AudioProcessor> ap = new ArrayList<>();
        if (q == 0) ap.add(new Gain(1f, 0, 0, 0, true));
        if (Proj.speed != 1f || q == 0) {
            SonicAudioProcessor son = new SonicAudioProcessor();
            if (Proj.speed != 1f) son.setSpeed(Proj.speed);
            if (q == 0) son.setOutputSampleRateHz(24000);
            ap.add(son);
        }
        EditedMediaItem edited = new EditedMediaItem.Builder(item)
                .setRemoveVideo(true)
                .setEffects(new Effects(ap, ImmutableList.<Effect>of()))
                .build();
        Composition comp = new Composition.Builder(ImmutableList.of(new EditedMediaItemSequence(ImmutableList.of(edited)))).build();
        Transformer.Builder b = new Transformer.Builder(this)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(new AudioRate(new DefaultEncoderFactory.Builder(this).setEnableFallback(true).build(),
                        q == 0 ? 48_000 : 96_000));
        final File out = new File(getCacheDir(), "chepe_audio.m4a");
        runJob(b, comp, out, "🎧 Sacando el audio…", null, f -> {
            String base = Proj.name == null || Proj.name.isEmpty() ? "audio" : Proj.name.replaceAll("\\.[^.]*$", "");
            base = base.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ _-]", "").trim();
            if (base.length() > 30) base = base.substring(0, 30);
            final String name = (base.isEmpty() ? "audio" : base) + "_" + stamp() + ".m4a";
            toDownloads(f, "Audios", name, "audio/mp4", (uu, nm, size) -> showSaved(uu, nm, size, "audio/mp4", "✅ Audio listo", "Audios"));
        });
    }

    // ------------------------------------------------------------ unir videos

    private void pickMulti() {
        // Versión 6.3: la galería de videos con casillas: se tocan varios (en el orden que se quieran) y se suben juntos
        try {
            Intent pg = new Intent(android.provider.MediaStore.ACTION_PICK_IMAGES);
            pg.setType("video/*");
            pg.putExtra(android.provider.MediaStore.EXTRA_PICK_IMAGES_MAX, 30);
            boolean hay = Build.VERSION.SDK_INT >= 33
                    || (Build.VERSION.SDK_INT >= 30 && android.os.ext.SdkExtensions.getExtensionVersion(Build.VERSION_CODES.R) >= 2);
            if (hay) {
                toast("Toque los videos en el orden que los quiere y luego \"Agregar\"");
                startActivityForResult(pg, REQ_JOIN);
                return;
            }
        } catch (Exception ignored) {}
        toast("Para escoger varios: deje el dedo en el primero y luego toque los demás");
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQ_JOIN); }
        catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType("video/*");
            g.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try { startActivityForResult(Intent.createChooser(g, "Escoger videos"), REQ_JOIN); } catch (Exception ignored) {}
        }
    }

    private void addClips(final List<Uri> us) {
        if (us.isEmpty()) return;
        status("🎞 Revisando " + us.size() + (us.size() == 1 ? " video…" : " videos…"));
        exec.execute(() -> {
            final List<Proj.Clip> got = new ArrayList<>();
            final int[] tiktoks = {0};
            int bad = 0;
            for (Uri x : us) {
                Frames.VInfo fi = null;
                try { fi = Frames.info(this, x); } catch (Exception ignored) {}
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { bad++; continue; }
                Proj.Clip c = new Proj.Clip(x, nameOf(x), fi.durMs, fi.w, fi.h, Proj.joinTrans);
                MediaMetadataRetriever r = null;
                try {
                    r = Frames.open(this, x);
                    c.thumb = Frames.grab(r, Math.min(800, fi.durMs / 2), 160, 160);
                } catch (Exception ignored) {
                } finally {
                    if (r != null) try { r.release(); } catch (Exception ignored) {}
                }
                // Versión 6: final de TikTok y marca, solos
                long fc = buscarFinalTikTok(x, fi.durMs);
                if (fc > 0) { c.b = Math.max(c.a + 300, fc - 120); tiktoks[0]++; }
                got.add(c);
            }
            final int fb = bad;
            ui.post(() -> {
                status(null);
                if (got.isEmpty()) { insertAt = -1; if (fb > 0) toast("No se pudo abrir ese video"); return; }
                // Versión 6: si no había nada abierto y es uno solo, se abre como video normal
                if (Proj.uri == null && Proj.clips.isEmpty() && got.size() == 1) { insertAt = -1; loadVideo(got.get(0).uri); return; }
                boolean primera = Proj.clips.isEmpty();
                if (!primera) guardarDeshacer();
                int idx = Proj.clips.size();
                // Versión 6.3: el video nuevo entra DESPUÉS del pedazo donde está la raya roja (sin partirlo)
                if (insertAt >= 0 && !primera) idx = indiceDespues(insertAt);
                insertAt = -1;
                Proj.clips.addAll(idx, got);
                long donde = offs()[idx];
                if (fb > 0) toast(fb == 1 ? "Un video no se pudo abrir" : fb + " videos no se pudieron abrir");
                if (tiktoks[0] > 0) toast("🎵 Quité el final de TikTok (" + tiktoks[0] + ")");
                if (mode != Mode.JOIN) setMode(Mode.JOIN); else refreshCtx();
                capaSel = idx; cinta.selFila = 0; cinta.selIdx = idx;
                cinta.posMs = donde;
                armarLista(donde);
                // la cinta NO se encoge al insertar; solo se ajusta la primera vez
                if (primera) cinta.post(cinta::ajustar);
            });
        });
    }

    /** Dónde entra lo insertado: si la raya roja está dentro de un pedazo, lo parte ahí. */
    /** Versión 6.3: el puesto justo después del pedazo que está bajo la raya roja. */
    private int indiceDespues(long g) {
        long[] o = offs();
        int n = Proj.clips.size();
        for (int i = 0; i < n; i++) if (g >= o[i] && g < o[i + 1]) return i + 1;
        return n;
    }

    private int indiceInsertar(long g) {
        long[] o = offs();
        int n = Proj.clips.size();
        for (int i = 0; i < n; i++) {
            if (g > o[i] + 200 && g < o[i + 1] - 200) {
                Proj.Clip c = Proj.clips.get(i), d = c.copia();
                long corte = c.a + (g - o[i]);
                c.b = corte;
                d.a = corte;
                Proj.clips.add(i + 1, d);
                return i + 1;
            }
            if (Math.abs(g - o[i]) <= 200) return i;
        }
        return n;
    }

    private long joinTotal() {
        long t = 0;
        for (Proj.Clip c : Proj.clips) t += c.dur();
        return t;
    }

    // ------------------------------------------------------------ Versión 5: la cinta (como InShot)

    private long[] offs() {
        int n = Proj.clips.size();
        long[] o = new long[n + 1];
        for (int i = 0; i < n; i++) o[i + 1] = o[i] + Proj.clips.get(i).dur();
        return o;
    }

    private long totalCinta() { long[] o = offs(); return o[o.length - 1]; }

    private final CintaView.Fuente fuenteCinta = new CintaView.Fuente() {
        @Override public int filas() { return mode == Mode.JOIN ? 1 : 4; }
        @Override public int cuantos(int f) {
            if (mode == Mode.JOIN) return Proj.clips.size();
            if (Proj.uri == null) return 0;
            if (f == 0) return 1;
            if (f == 1) return Proj.sonidos.size();
            if (f == 3) return Proj.zooms.size();
            return Proj.texts.size();
        }
        @Override public long ini(int f, int i) {
            try {
                if (mode == Mode.JOIN) return offs()[i];
                if (f == 0) return Proj.trimStart;
                if (f == 1) return Proj.sonidos.get(i).at;
                if (f == 3) return Proj.zooms.get(i).a;
                return Proj.texts.get(i).startMs;
            } catch (Exception e) { return 0; }
        }
        @Override public long fin(int f, int i) {
            try {
                if (mode == Mode.JOIN) return offs()[i + 1];
                if (f == 0) return Proj.trimEnd;
                if (f == 1) return Math.min(Proj.durMs, Proj.sonidos.get(i).finEn(Proj.trimEnd));
                if (f == 3) return Proj.zooms.get(i).b;
                return Proj.texts.get(i).endMs;
            } catch (Exception e) { return 0; }
        }
        @Override public String nombre(int f, int i) {
            try {
                if (mode == Mode.JOIN) return String.valueOf(i + 1);
                if (f == 0) return null;
                if (f == 1) { Proj.Music m = Proj.sonidos.get(i); return (m.delVideo ? "🎙 " : "🎵 ") + shortName(m.name); }
                if (f == 3) return "🔍 x" + String.format(Locale.US, "%.1f", Proj.zooms.get(i).s);
                return "T " + Proj.texts.get(i).text;
            } catch (Exception e) { return null; }
        }
        @Override public Bitmap foto(int f, int i) {
            try {
                if (mode == Mode.JOIN) return Proj.clips.get(i).thumb;
                return fotoVideo;
            } catch (Exception e) { return null; }
        }
        @Override public long total() { return mode == Mode.JOIN ? totalCinta() : Proj.durMs; }
    };

    private final CintaView.Oyente oyenteCinta = new CintaView.Oyente() {
        // Versión 6.3: dejar el dedo quieto en un video de la cinta y arrastrarlo a otro puesto
        @Override public boolean puedeReordenar() { return mode == Mode.JOIN && Proj.clips.size() > 1 && !exporting; }

        @Override public void onReordenar(int de, int a) {
            if (de < 0 || de >= Proj.clips.size()) return;
            guardarDeshacer();
            Proj.Clip c = Proj.clips.remove(de);
            a = Math.max(0, Math.min(Proj.clips.size(), a));
            Proj.clips.add(a, c);
            capaSel = a; cinta.selFila = 0; cinta.selIdx = a;
            long donde = offs()[a];
            cinta.posMs = donde;
            armarLista(donde);
            refreshCtx();
            toast("Video pasado al puesto " + (a + 1));
        }

        @Override public void onMover(long ms) {
            if (mode == Mode.JOIN) seekGlobal(ms); else if (Proj.uri != null) player.seekTo(ms);
        }

        @Override public void onEscoger(int f, int i) {
            if (mode == Mode.JOIN) { capaSel = i; refreshCtx(); return; }
            if (f == 1 && i >= 0 && i < Proj.sonidos.size()) {
                Proj.selSon = Proj.sonidos.get(i);
                if (mode != Mode.MUSIC) setMode(Mode.MUSIC); else refreshCtx();
            } else if (f == 2 && i >= 0 && i < Proj.texts.size()) {
                Proj.selText = Proj.texts.get(i);
                if (mode != Mode.TEXT) setMode(Mode.TEXT); else refreshCtx();
            } else if (f == 3 && i >= 0 && i < Proj.zooms.size()) {
                Proj.selZoom = Proj.zooms.get(i);
                if (mode != Mode.ZOOM) setMode(Mode.ZOOM); else refreshCtx();
            } else if (f == 0 && i == 0) {
                if (mode != Mode.CUT) setMode(Mode.CUT); else refreshCtx();
            } else refreshCtx();
            cinta.selFila = f; cinta.selIdx = i;
        }

        @Override public void onAgarradera(int f, int i, boolean inicio, long ms) {
            if (!agarrando) {
                agarrando = true;
                if (mode == Mode.JOIN && i >= 0 && i < Proj.clips.size()) {
                    guardarDeshacer();
                    baseA = Proj.clips.get(i).a;
                    baseOff = offs()[i];
                } else if (f == 1 && i >= 0 && i < Proj.sonidos.size()) {
                    baseA = Proj.sonidos.get(i).a;
                    baseAt = Proj.sonidos.get(i).at;
                }
            }
            if (mode == Mode.JOIN) {
                if (i < 0 || i >= Proj.clips.size()) return;
                Proj.Clip c = Proj.clips.get(i);
                if (inicio) c.a = Math.max(0, Math.min(c.b - 300, baseA + (ms - baseOff)));
                else c.b = Math.max(c.a + 300, Math.min(c.durMs, c.a + (ms - offs()[i])));
                cinta.posMs = inicio ? offs()[i] : offs()[i + 1];
                return;
            }
            if (f == 0) {
                if (inicio) Proj.trimStart = Math.max(0, Math.min(ms, Proj.trimEnd - 300));
                else Proj.trimEnd = Math.min(Proj.durMs, Math.max(ms, Proj.trimStart + 300));
                player.seekTo(inicio ? Proj.trimStart : Proj.trimEnd);
            } else if (f == 1 && i >= 0 && i < Proj.sonidos.size()) {
                Proj.Music m = Proj.sonidos.get(i);
                if (inicio) {
                    long d = (long) ((ms - baseAt) * m.speed);
                    long na = Math.max(0, Math.min(m.b - 300, baseA + d));
                    m.at = baseAt + (long) ((na - baseA) / m.speed);
                    m.a = na;
                } else {
                    long len = Math.max(300, ms - m.at);
                    m.b = Math.min(m.durMs, m.fuenteEn(len));
                }
                player.seekTo(inicio ? m.at : Math.min(Proj.durMs, m.at + m.largo()));
            } else if (f == 3 && i >= 0 && i < Proj.zooms.size()) {
                Proj.Zoom z = Proj.zooms.get(i);
                if (inicio) z.a = Math.max(0, Math.min(ms, z.b - 300));
                else z.b = Math.min(Proj.durMs, Math.max(ms, z.a + 300));
                player.seekTo(inicio ? z.a : z.b);
            } else if (f == 2 && i >= 0 && i < Proj.texts.size()) {
                Proj.TextLayer t = Proj.texts.get(i);
                if (inicio) t.startMs = Math.max(0, Math.min(ms, t.endMs - 300));
                else t.endMs = Math.min(Proj.durMs, Math.max(ms, t.startMs + 300));
                player.seekTo(inicio ? t.startMs : t.endMs);
            }
        }

        @Override public void onSoltar() {
            if (agarrando && mode == Mode.JOIN) armarLista(cinta.posMs);
            agarrando = false;
            marks();
            refreshCtx();
        }
    };

    /** La lista de pedazos en el reproductor, para verlos seguidos como quedarían. */
    private void armarLista(long globalMs) {
        List<MediaItem> l = new ArrayList<>();
        for (Proj.Clip c : Proj.clips)
            l.add(new MediaItem.Builder().setUri(c.uri).setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.a).setEndPositionMs(c.b).build()).build());
        if (l.isEmpty()) return;
        enLista = true;
        player.setMediaItems(l);
        player.prepare();
        player.setVolume(Proj.mute ? 0f : 1f);
        player.setPlaybackParameters(new PlaybackParameters(1f));
        seekGlobal(globalMs);
        cinta.invalidate();
    }

    private void seekGlobal(long ms) {
        if (!enLista) return;
        long[] o = offs();
        int n = Proj.clips.size();
        if (n == 0) return;
        int i = 0;
        while (i < n - 1 && ms >= o[i + 1]) i++;
        long local = Math.max(0, Math.min(Proj.clips.get(i).dur() - 1, ms - o[i]));
        try { player.seekTo(i, local); } catch (Exception ignored) {}
    }

    private long globalPos() {
        long[] o = offs();
        int i = player.getCurrentMediaItemIndex();
        if (i < 0 || i >= o.length - 1) return 0;
        return o[i] + Math.max(0, player.getCurrentPosition());
    }

    /** Al salir de la cinta, el reproductor vuelve al video abierto. */
    private void salirDeLista() {
        if (!enLista) return;
        enLista = false;
        if (Proj.uri != null) {
            player.setMediaItem(MediaItem.fromUri(Proj.uri));
            player.prepare();
            applyVolume();
            player.setPlaybackParameters(new PlaybackParameters(Proj.speed));
            player.seekTo(Proj.trimStart);
        }
    }

    private void guardarDeshacer() {
        List<Proj.Clip> l = new ArrayList<>();
        for (Proj.Clip c : Proj.clips) l.add(c.copia());
        deshacer.push(l);
        while (deshacer.size() > 30) deshacer.removeLast();
    }

    private void deshacerCinta() {
        if (deshacer.isEmpty()) { toast("No hay nada que deshacer"); return; }
        long g = cinta.posMs;
        Proj.clips.clear();
        Proj.clips.addAll(deshacer.pop());
        capaSel = Math.min(capaSel, Proj.clips.size() - 1);
        cinta.selFila = capaSel >= 0 ? 0 : -1; cinta.selIdx = capaSel;
        armarLista(Math.min(g, totalCinta()));
        refreshCtx();
        toast("↶ Deshecho");
    }

    /** ✂ Parte el pedazo justo en la raya roja. */
    private void dividirCinta() {
        long g = cinta.posMs;
        long[] o = offs();
        int n = Proj.clips.size();
        for (int i = 0; i < n; i++) {
            if (g > o[i] + 200 && g < o[i + 1] - 200) {
                guardarDeshacer();
                Proj.Clip c = Proj.clips.get(i), d = c.copia();
                long corte = c.a + (g - o[i]);
                c.b = corte;
                d.a = corte;
                Proj.clips.add(i + 1, d);
                capaSel = i + 1;
                cinta.selFila = 0; cinta.selIdx = i + 1;
                armarLista(g);
                refreshCtx();
                toast("✂ Dividido. Toque el pedazo que no quiera y 🗑 Borrar");
                return;
            }
        }
        toast("Ponga la raya roja dentro de un pedazo (no en la punta)");
    }

    private Proj.Clip clipSel() { return capaSel >= 0 && capaSel < Proj.clips.size() ? Proj.clips.get(capaSel) : null; }

    private void borrarCinta() {
        if (clipSel() == null) { toast("Toque primero el pedazo que va a borrar"); return; }
        guardarDeshacer();
        long g = offs()[capaSel];
        Proj.clips.remove(capaSel);
        capaSel = -1; cinta.selFila = -1; cinta.selIdx = -1;
        if (Proj.clips.isEmpty()) { enLista = false; refreshCtx(); return; }
        armarLista(Math.min(g, totalCinta() - 1));
        refreshCtx();
    }

    private void duplicarCinta() {
        Proj.Clip c = clipSel();
        if (c == null) { toast("Toque primero el pedazo"); return; }
        guardarDeshacer();
        Proj.clips.add(capaSel + 1, c.copia());
        armarLista(cinta.posMs);
        refreshCtx();
    }

    private void moverCinta(int dir) {
        Proj.Clip c = clipSel();
        int j = capaSel + dir;
        if (c == null || j < 0 || j >= Proj.clips.size()) return;
        guardarDeshacer();
        Collections.swap(Proj.clips, capaSel, j);
        capaSel = j; cinta.selFila = 0; cinta.selIdx = j;
        armarLista(offs()[j]);
        refreshCtx();
    }

    /** En el video solo: ✂ Dividir lo parte en dos pedazos y pasa a la cinta de pedazos. */
    private void dividirVideoSolo() {
        if (Proj.uri == null) return;
        long g = player.getCurrentPosition();
        if (g <= Proj.trimStart + 200 || g >= Proj.trimEnd - 200) { toast("Ponga la raya roja dentro del video"); return; }
        Proj.Clip c = new Proj.Clip(Proj.uri, Proj.name, Proj.durMs, Proj.w, Proj.h, Proj.joinTrans);
        c.thumb = fotoVideo;
        c.wm = Proj.wm; c.wmFuerza = Proj.wmFuerza; c.wmArriba = Proj.wmArriba;
        Proj.Clip d = c.copia();
        c.a = Proj.trimStart; c.b = g;
        d.a = g; d.b = Proj.trimEnd;
        deshacer.clear();
        Proj.clips.clear();
        Proj.clips.add(c);
        Proj.clips.add(d);
        capaSel = 1;
        setMode(Mode.JOIN);
        cinta.selFila = 0; cinta.selIdx = 1;
        armarLista(g - Proj.trimStart);
        toast("✂ Dividido en 2 pedazos. Toque el que no quiera y 🗑 Borrar");
    }

    // ------------------------------------------------------------ Versión 5: pista morada (sonidos)

    /** 🎙 Saca el sonido del video a la pista morada (y el video queda sin sonido propio). */
    private void extraerAudio() {
        if (Proj.uri == null) return;
        for (Proj.Music m : Proj.sonidos) if (m.delVideo) { toast("El sonido del video ya está en la pista morada"); return; }
        Proj.Music m = new Proj.Music(Proj.uri, "Sonido del video", Proj.durMs);
        m.delVideo = true;
        m.a = Proj.trimStart; m.b = Proj.trimEnd; m.at = Proj.trimStart;
        m.entra = false; m.sale = false;
        Proj.sonidos.add(m);
        Proj.selSon = m;
        Proj.mute = true;
        applyVolume();
        refreshCtx();
        toast("🎙 El sonido quedó en la pista morada: recórtelo con [ ] o divídalo");
    }

    private void dividirSonido() {
        Proj.Music m = Proj.selSon;
        if (m == null) return;
        long g = player.getCurrentPosition();
        if (g <= m.at + 200 || g >= m.at + m.largo() - 200) { toast("Ponga la raya roja dentro del sonido"); return; }
        Proj.Music d = m.copia();
        long corte = m.fuenteEn(g - m.at);
        m.b = corte; m.sale = false;
        d.a = corte; d.at = g; d.entra = false;
        Proj.sonidos.add(Proj.sonidos.indexOf(m) + 1, d);
        Proj.selSon = d;
        refreshCtx();
        toast("✂ Sonido dividido");
    }

    private void borrarSonido() {
        Proj.Music m = Proj.selSon;
        if (m == null) return;
        Proj.sonidos.remove(m);
        ExoPlayer ep = sonPlayers.remove(m);
        if (ep != null) ep.release();
        boolean quedaVideo = false;
        for (Proj.Music x : Proj.sonidos) if (x.delVideo) quedaVideo = true;
        if (m.delVideo && !quedaVideo) { Proj.mute = false; applyVolume(); }
        Proj.selSon = Proj.sonidos.isEmpty() ? null : Proj.sonidos.get(Proj.sonidos.size() - 1);
        cinta.selFila = -1; cinta.selIdx = -1;
        refreshCtx();
    }

    // ------------------------------------------------------------ Versión 6.1: 🔍 zoom grabado

    private void ctxZoom() {
        final Proj.Zoom z = Proj.selZoom != null && Proj.zooms.contains(Proj.selZoom) ? Proj.selZoom : null;
        add(chip("⏮ Desde aquí", z == null, () -> {
            float[] st = zoomActual();
            if (st == null) { toast("Pause y agrande con dos dedos lo que quiere ver"); return; }
            long a = player.getCurrentPosition();
            Proj.Zoom nz = new Proj.Zoom(a, Math.min(Proj.trimEnd, a + 3000), st[0], st[1], st[2]);
            Proj.zooms.add(nz);
            Proj.selZoom = nz;
            marks(); refreshCtx();
            toast("🔍 Zoom puesto 3 s · corra la raya roja y toque Hasta aquí");
        }));
        if (z != null) {
            add(chip("Hasta aquí ⏭", false, () -> {
                z.b = Math.max(z.a + 300, player.getCurrentPosition());
                marks(); refreshCtx();
            }));
            add(chip("🔄 Usar este zoom", false, () -> {
                float[] st = zoomActual();
                if (st == null) { toast("Agrande con dos dedos primero"); return; }
                z.s = st[0]; z.cx = st[1]; z.cy = st[2];
                refreshCtx();
            }));
            add(lab(fmt(z.a) + " → " + fmt(z.b)));
            add(chip("🗑 Quitar zoom", false, () -> {
                Proj.zooms.remove(z);
                Proj.selZoom = null;
                videoFrame.reset();
                marks(); refreshCtx();
            }));
        } else {
            add(lab("Pause · agrande con dos dedos · toque Desde aquí"));
        }
    }

    /** El zoom que hay ahora en la pantalla grande, pasado al video: {cuánto, cx, cy} o null. */
    private float[] zoomActual() {
        if (!videoFrame.zoomed()) return null;
        RectF vr = overlay.videoRect();
        if (vr.width() < 2 || vr.height() < 2) return null;
        float cx = (videoFrame.centroX() - vr.left) / vr.width();
        float cy = (videoFrame.centroY() - vr.top) / vr.height();
        // el zoom de la pantalla es el mismo que queda en el video
        float s = videoFrame.zoom();
        if (s < 1.05f) return null;
        return new float[]{Math.min(8f, s), Math.max(0f, Math.min(1f, cx)), Math.max(0f, Math.min(1f, cy))};
    }

    private boolean zoomMostrado;

    /** Al reproducir (o pausado fuera de 🔍), la pantalla grande muestra el zoom grabado. */
    private void mostrarZoom(long pos, boolean playing) {
        if (Proj.zooms.isEmpty()) { if (zoomMostrado) { videoFrame.reset(); zoomMostrado = false; } return; }
        if (videoFrame.pellizcando()) return;
        if (!playing && mode == Mode.ZOOM) return; // él está escogiendo el zoom
        float[] z = Proj.zoomEn(pos);
        if (z == null) { if (zoomMostrado) { videoFrame.reset(); zoomMostrado = false; } return; }
        RectF vr = overlay.videoRect();
        videoFrame.mostrar(z[0], vr.left + z[1] * vr.width(), vr.top + z[2] * vr.height());
        zoomMostrado = true;
    }

    private void ctxSonido() {
        add(chip("🎵 Insertar audio", false, () -> pick(REQ_MUSIC, "audio/*")));
        add(chip(grabadora != null ? "⏹ Parar grabación" : "🎙 Grabar mi voz", grabadora != null, this::grabarVoz));
        add(chip("🔓 Soltar audio del video", false, this::extraerAudio));
        add(chip(Proj.mute ? "🔊 Devolver sonido del video" : "🔇 Quitar sonido del video", false, () -> {
            Proj.mute = !Proj.mute; applyVolume(); refreshCtx();
        }));
        final Proj.Music m = Proj.selSon;
        if (m == null || !Proj.sonidos.contains(m)) { add(lab("Toque un sonido de la pista morada para recortarlo")); return; }
        add(lab((m.delVideo ? "🎙 " : "🎵 ") + shortName(m.name)));
        add(chip("✂ Dividir", false, this::dividirSonido));
        add(chip("🗑 Borrar", false, this::borrarSonido));
        add(chip("−", false, () -> { m.vol = Math.max(0f, Math.round(m.vol * 10f - 1f) / 10f); refreshCtx(); }));
        add(lab("Volumen " + Math.round(m.vol * 100) + " %"));
        add(chip("+", false, () -> { m.vol = Math.min(2f, Math.round(m.vol * 10f + 1f) / 10f); refreshCtx(); }));
        // Versión 6.1: velocidad y tono
        add(lab("  Velocidad:"));
        for (float v : new float[]{0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f}) {
            final float vv = v;
            add(chip(v == 1f ? "Normal" : (v == 0.5f ? "0.5x" : v == 0.75f ? "0.75x" : v == 1.25f ? "1.25x" : v == 1.5f ? "1.5x" : "2x"),
                    m.speed == v, () -> { m.speed = vv; marks(); refreshCtx(); }));
        }
        add(lab("  Tono:"));
        String[] tn = {"Muy grave", "Grave", "Normal", "Agudo", "Muy agudo"};
        float[] tv = {0.7f, 0.85f, 1f, 1.2f, 1.45f};
        for (int i = 0; i < tn.length; i++) {
            final float t2 = tv[i];
            add(chip(tn[i], m.tono == t2, () -> { m.tono = t2; refreshCtx(); }));
        }
        add(chip(m.entra ? "◢ Entra suave ✔" : "◢ Entra suave", m.entra, () -> { m.entra = !m.entra; refreshCtx(); }));
        add(chip(m.sale ? "◣ Sale suave ✔" : "◣ Sale suave", m.sale, () -> { m.sale = !m.sale; refreshCtx(); }));
        if (!m.delVideo) add(chip(m.repetir ? "🔁 Repetir ✔" : "🔁 Repetir", m.repetir, () -> { m.repetir = !m.repetir; refreshCtx(); }));
        add(chip("⏮ Empieza aquí", false, () -> { m.at = player.getCurrentPosition(); refreshCtx(); }));
    }

    /** La vista previa de la pista morada: cada sonido suena en su sitio. */
    private void syncSonidos(long pos, boolean playing) {
        for (java.util.Iterator<java.util.Map.Entry<Proj.Music, ExoPlayer>> it = sonPlayers.entrySet().iterator(); it.hasNext(); ) {
            java.util.Map.Entry<Proj.Music, ExoPlayer> en = it.next();
            if (!Proj.sonidos.contains(en.getKey())) { en.getValue().release(); it.remove(); }
        }
        for (Proj.Music m : Proj.sonidos) {
            ExoPlayer ep = sonPlayers.get(m);
            boolean dentro = playing && !micActive && !exporting && pos >= m.at && pos < m.finEn(Proj.trimEnd);
            if (!dentro) { if (ep != null && ep.getPlayWhenReady()) ep.pause(); continue; }
            if (ep == null) {
                ep = new ExoPlayer.Builder(this).build();
                ep.setMediaItem(MediaItem.fromUri(m.uri));
                ep.prepare();
                sonPlayers.put(m, ep);
            }
            long want = m.fuenteEn((pos - m.at) % m.largo());
            ep.setVolume(Math.min(1f, m.vol));
            PlaybackParameters pp = ep.getPlaybackParameters();
            if (pp.speed != m.speed || pp.pitch != m.tono) ep.setPlaybackParameters(new PlaybackParameters(m.speed, m.tono));
            if (!ep.getPlayWhenReady()) { ep.seekTo(want); ep.play(); }
            else if (ep.getPlaybackState() == Player.STATE_READY && Math.abs(ep.getCurrentPosition() - want) > 600) ep.seekTo(want);
        }
    }

    /** Los sonidos de la pista morada para guardar el video (cada uno en su sitio). */
    private List<EditedMediaItemSequence> secuenciasSonido() {
        List<EditedMediaItemSequence> out = new ArrayList<>();
        float sp = Math.max(0.05f, Proj.speed);
        long finOut = outDurMs();
        for (Proj.Music m : Proj.sonidos) {
            long ini = Math.max(m.at, Proj.trimStart);
            long fin = Math.min(m.finEn(Proj.trimEnd), Proj.trimEnd);
            if (fin - ini < 200) continue;
            long saltoFuente = ini - m.at;          // lo que se recortó al principio por el recorte del video
            long retraso = (long) ((ini - Proj.trimStart) / sp);
            long largoTotal = fin - ini;
            List<EditedMediaItem> items = new ArrayList<>();
            long puesto = 0;
            boolean primero = true;
            while (puesto < largoTotal && items.size() < 200) {
                long desde = m.fuenteEn((saltoFuente + puesto) % m.largo());
                long cuanto = Math.min((long) ((m.b - desde) / m.speed), largoTotal - puesto);
                if (cuanto < 50) break;
                boolean ultimo = puesto + cuanto >= largoTotal - 50;
                List<AudioProcessor> ap = new ArrayList<>();
                // Versión 6.1: velocidad y tono del sonido
                if (m.speed != 1f || m.tono != 1f) {
                    SonicAudioProcessor son = new SonicAudioProcessor();
                    son.setSpeed(m.speed);
                    son.setPitch(m.tono);
                    ap.add(son);
                }
                ap.add(new Gain(m.vol, primero && m.entra ? 800 : 0, ultimo && m.sale ? 1500 : 0, cuanto, false));
                if (primero && retraso > 0) ap.add(new Retraso(retraso));
                MediaItem mi = new MediaItem.Builder().setUri(m.uri).setClippingConfiguration(
                        new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(desde).setEndPositionMs(Math.min(m.b, desde + (long) (cuanto * m.speed))).build()).build();
                items.add(new EditedMediaItem.Builder(mi).setRemoveVideo(true)
                        .setEffects(new Effects(ImmutableList.copyOf(ap), ImmutableList.<Effect>of())).build());
                puesto += cuanto;
                primero = false;
                if (!m.repetir) break;
            }
            if (!items.isEmpty()) out.add(new EditedMediaItemSequence(ImmutableList.copyOf(items)));
        }
        return out;
    }

    // ------------------------------------------------------------ Versión 4: capas (unir con líneas azul y roja)

    /** La capa que está abierta en el reproductor (si está en Unir). */
    private Proj.Clip capaAbierta() {
        if (mode != Mode.JOIN || capaSel < 0 || capaSel >= Proj.clips.size()) return null;
        return Proj.clips.get(capaSel);
    }

    private void refrescarBarras() {
        for (int i = 0; i < barras.size() && i < Proj.clips.size(); i++) {
            barras.get(i).invalidate();
            if (i < durasCapa.size()) durasCapa.get(i).setText("Queda\n" + fmt(Proj.clips.get(i).dur()));
        }
    }

    private void irA(long ms) {
        player.seekTo(ms);
        timeline.verEn(ms);
    }

    /** Abre la capa en el reproductor con sus líneas, candados y marca. */
    private void abrirCapa(final int idx) {
        if (idx < 0 || idx >= Proj.clips.size()) return;
        final Proj.Clip c = Proj.clips.get(idx);
        capaSel = idx;
        status("Abriendo capa " + (idx + 1) + "…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, c.uri); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0) { toast("No pude abrir ese video"); return; }
                Proj.reset(c.uri, fi, true);
                Proj.name = c.name;
                Proj.trimStart = c.a; Proj.trimEnd = Math.min(c.b, fi.durMs);
                Proj.lockA = c.lockA; Proj.lockB = c.lockB;
                Proj.wm = c.wm; Proj.wmFuerza = c.wmFuerza; Proj.wmArriba = c.wmArriba;
                overlay.vw = fi.w; overlay.vh = fi.h;
                overlay.composite = null; overlay.layerCut = null; overlay.layerStill = null;
                invalidatePreview();
                player.setMediaItem(MediaItem.fromUri(c.uri));
                player.prepare();
                applyVolume();
                player.setPlaybackParameters(new PlaybackParameters(1f));
                player.seekTo(c.a);
                syncTimeline();
                marks();
                timeline.verEn(c.a);
                refreshCtx();
            });
        });
    }

    private void moverCapa(int idx, int dir) {
        int j = idx + dir;
        if (idx < 0 || j < 0 || j >= Proj.clips.size()) return;
        List<Proj.Clip> l = new ArrayList<>(Proj.clips);
        Collections.swap(l, idx, j);
        Proj.clips.clear();
        Proj.clips.addAll(l);
        if (capaSel == idx) capaSel = j; else if (capaSel == j) capaSel = idx;
        refreshCtx();
    }

    private TextView botonCapa(String t, int fondo, int letra, Runnable r) {
        TextView b = tv(t, 13, letra, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(fondo, 10));
        b.setPadding(dp(2), dp(8), dp(2), dp(8));
        b.setOnClickListener(v -> r.run());
        return b;
    }

    private void filaBotones(LinearLayout dentro, TextView... bs) {
        LinearLayout f = hbox();
        for (TextView b : bs) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            f.addView(b, lp);
        }
        dentro.addView(f, new LinearLayout.LayoutParams(-1, -2));
    }

    /** Rayita de la capa: gris el video completo, oscuro lo que se quita, y las dos líneas. */
    private final class BarraMini extends View {
        final Proj.Clip c;
        final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        BarraMini(Proj.Clip c) { super(MainActivity.this); this.c = c; }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            pp.setColor(0xFF90A4AE);
            cv.drawRoundRect(0, h * 0.25f, w, h * 0.75f, dp(3), dp(3), pp);
            float xa = c.durMs > 0 ? w * c.a / c.durMs : 0, xb = c.durMs > 0 ? w * c.b / c.durMs : w;
            pp.setColor(0xAA000000);
            cv.drawRect(0, h * 0.25f, xa, h * 0.75f, pp);
            cv.drawRect(xb, h * 0.25f, w, h * 0.75f, pp);
            pp.setColor(0xFF2979FF);
            cv.drawRect(Math.max(0, xa - dp(2)), 0, Math.max(dp(3), xa + dp(1.5f)), h, pp);
            pp.setColor(0xFFFF1744);
            cv.drawRect(Math.min(w - dp(3), xb - dp(1.5f)), 0, Math.min(w, xb + dp(2)), h, pp);
        }
    }

    /** Versión 5: los botones de la cinta de pedazos, quietos en tres filas (sin desplazarse de lado). */
    private void ctxJoin() {
        capasBox.removeAllViews();
        barras.clear();
        durasCapa.clear();
        final boolean hay = clipSel() != null;
        // Versión 6: Dividir, Borrar, Duplicar, Marca y TikTok están en la fila de herramientas
        filaBotones(capasBox,
                botonCapa("⬅ Mover", 0xFF37474F, Color.WHITE, () -> { if (hay) moverCinta(-1); else toast("Toque primero el pedazo"); }),
                botonCapa("Mover ➡", 0xFF37474F, Color.WHITE, () -> { if (hay) moverCinta(1); else toast("Toque primero el pedazo"); }),
                botonCapa("✨ " + TRANS[Proj.joinTrans], AMB_L, AMB_T, () ->
                        new AlertDialog.Builder(this).setTitle("Paso entre pedazos").setItems(TRANS, (d, w) -> {
                            Proj.joinTrans = w;
                            for (Proj.Clip c : Proj.clips) c.trans = w;
                            refreshCtx();
                        }).show()));
        TextView ay = tv(Proj.clips.isEmpty() ? "Toque el ➕ rojo y escoja los videos"
                : hay ? "Pedazo " + (capaSel + 1) + " de " + Proj.clips.size() + ": arrastre [ ] para recortar"
                : Proj.clips.size() + " pedazos · corra la cinta con el dedo · toque un pedazo", 11.5f, Color.BLACK, true);
        ay.setPadding(dp(4), dp(2), dp(4), 0);
        capasBox.addView(ay);
    }

    /** ▒ Suavizar la marca de TikTok: prender o apagar, cuánta fuerza y dónde empieza. */
    private void dialogoMarca() {
        LinearLayout l = vbox();
        l.setPadding(dp(18), dp(8), dp(18), 0);
        final android.widget.CheckBox on = new android.widget.CheckBox(this);
        on.setText("Suavizar la marca de TikTok");
        on.setTextSize(16);
        on.setChecked(true);
        final Proj.Clip cc = capaAbierta();
        final boolean wm0 = cc != null ? cc.wmArriba : Proj.wmArriba;
        final float f0 = cc != null ? cc.wmFuerza : Proj.wmFuerza;
        l.addView(on);
        TextView tf = tv("Fuerza: poco ⟶ mucho", 14, Color.BLACK, true);
        tf.setPadding(0, dp(10), 0, 0);
        l.addView(tf);
        final android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(100);
        sb.setProgress(Math.round(f0 * 100));
        l.addView(sb);
        final android.widget.CheckBox ar = new android.widget.CheckBox(this);
        ar.setText("La marca empieza ARRIBA (y a la mitad pasa abajo)");
        ar.setTextSize(15);
        ar.setChecked(wm0);
        l.addView(ar);
        final android.widget.CheckBox todas = new android.widget.CheckBox(this);
        todas.setText("Lo mismo para todas las capas");
        todas.setTextSize(15);
        if (mode == Mode.JOIN && Proj.clips.size() > 1) l.addView(todas);
        new AlertDialog.Builder(this).setTitle("▒ Suavizar marca").setView(l)
                .setPositiveButton("Listo", (d, w) -> {
                    boolean nw = on.isChecked();
                    float nf = Math.max(0.1f, sb.getProgress() / 100f);
                    boolean na = ar.isChecked();
                    if (cc != null) { cc.wm = nw; cc.wmFuerza = nf; cc.wmArriba = na; }
                    else { Proj.wm = nw; Proj.wmFuerza = nf; Proj.wmArriba = na; }
                    if (todas.isChecked()) for (Proj.Clip x : Proj.clips) { x.wm = nw; x.wmFuerza = nf; x.wmArriba = na; }
                    invalidatePreview();
                    overlay.invalidate();
                    refreshCtx();
                })
                .setNeutralButton("Quitar", (d, w) -> {
                    if (cc != null) cc.wm = false; else Proj.wm = false;
                    overlay.invalidate();
                    refreshCtx();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** 🎵 Busca al final la pantalla oscura con el logo de TikTok y recorta justo antes. */
    private void quitarFinalTikTok() {
        final Proj.Clip cc = mode == Mode.JOIN ? clipSel() : null;
        final Uri u = cc != null ? cc.uri : Proj.uri;
        final long dur = cc != null ? cc.durMs : Proj.durMs;
        if (u == null || dur <= 0) return;
        status("🎵 Buscando el final de TikTok…");
        exec.execute(() -> {
            long corte = buscarFinalTikTok(u, dur);
            final long fc = corte;
            ui.post(() -> {
                status(null);
                if (fc <= 0) { toast("No encontré el final de TikTok en este video. Recórtelo con la agarradera ]"); return; }
                if (cc != null) {
                    guardarDeshacer();
                    cc.b = Math.max(cc.a + 300, Math.min(cc.b, fc - 120));
                    armarLista(offs()[Proj.clips.indexOf(cc) + 1] - 1500);
                    refreshCtx();
                    toast("🎵 Final de TikTok quitado de este pedazo");
                    return;
                }
                long fin = Math.max(Proj.trimStart + 300, fc - 120);
                Proj.trimEnd = fin;
                syncTimeline();
                player.seekTo(Math.max(Proj.trimStart, fin - 1500));
                refreshCtx();
                toast("🎵 Final de TikTok quitado: el video termina en " + fmt(fin));
            });
        });
    }

    /** Versión 6: al abrir, si es de TikTok, quita el final y suaviza la marca sin que lo pida. */
    private void autoTikTok(final Uri u, final long dur) {
        exec.execute(() -> {
            final long fc = buscarFinalTikTok(u, dur);
            if (fc <= 0) return;
            ui.post(() -> {
                if (!u.equals(Proj.uri)) return;
                Proj.trimEnd = Math.max(Proj.trimStart + 300, Math.min(Proj.trimEnd, fc - 120));
                syncTimeline(); marks(); invalidatePreview(); overlay.invalidate(); refreshCtx();
                toast("🎵 Es de TikTok: quité el final (" + fmt(dur - Proj.trimEnd) + ")");
            });
        });
    }

    /** Versión 6: busca en los últimos 9 s la pantalla final de TikTok. Devuelve dónde empieza o -1. */
    private long buscarFinalTikTok(Uri u, long dur) {
        long corte = -1;
        MediaMetadataRetriever r = null;
        try {
            r = Frames.open(this, u);
            if (r == null) return -1;
            long t = dur - 150;
            long limite = Math.max(0, dur - 9000);
            boolean viOscuro = false;
            int fallos = 0;
            while (t > limite) {
                Bitmap b = Frames.grab(r, t, 96, 96);
                if (b == null) { t -= 250; continue; }
                if (esFinalTikTok(b)) { viOscuro = true; corte = t; fallos = 0; }
                else if (viOscuro && ++fallos >= 2) break;
                t -= 250;
            }
            if (!viOscuro || dur - corte < 800) corte = -1;
        } catch (Exception ignored) {
            corte = -1;
        } finally {
            if (r != null) try { r.release(); } catch (Exception ignored) {}
        }
        return corte;
    }

    /** La pantalla final de TikTok: casi toda oscura (o casi toda de un solo color) con un logo pequeño. */
    private static boolean esFinalTikTok(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight(), oscuros = 0, total = 0;
        long sr = 0, sg = 0, sb = 0;
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        for (int c : px) {
            int r = (c >> 16) & 255, g = (c >> 8) & 255, bb = c & 255;
            sr += r; sg += g; sb += bb;
            if (r + g + bb < 160) oscuros++;
            total++;
        }
        if (total == 0) return false;
        // parejo: casi todos los puntos cerca del color promedio
        int mr = (int) (sr / total), mg = (int) (sg / total), mb = (int) (sb / total), parejos = 0;
        for (int c : px) {
            int r = (c >> 16) & 255, g = (c >> 8) & 255, bb = c & 255;
            if (Math.abs(r - mr) + Math.abs(g - mg) + Math.abs(bb - mb) < 60) parejos++;
        }
        return oscuros * 100 / total > 66 || (parejos * 100 / total > 75 && mr + mg + mb < 260);
    }

    private void clipMenu(final int idx) {
        if (idx < 0 || idx >= Proj.clips.size()) return;
        final Proj.Clip c = Proj.clips.get(idx);
        final boolean last = idx == Proj.clips.size() - 1;
        List<String> items = new ArrayList<>();
        items.add("◀ Pasar antes");
        items.add("Pasar después ▶");
        items.add(last ? "✨ (es el último: no lleva transición)" : "✨ Transición después: " + TRANS[c.trans]);
        items.add("▶ Ver este video");
        items.add("🗑 Quitar de la lista");
        new AlertDialog.Builder(this).setTitle("Video " + (idx + 1) + " · " + shortName(c.name))
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    List<Proj.Clip> l = new ArrayList<>(Proj.clips);
                    if (w == 0 && idx > 0) { Collections.swap(l, idx, idx - 1); }
                    else if (w == 1 && idx < l.size() - 1) { Collections.swap(l, idx, idx + 1); }
                    else if (w == 2 && !last) {
                        new AlertDialog.Builder(this).setTitle("Transición después del video " + (idx + 1))
                                .setItems(TRANS, (d2, w2) -> { c.trans = w2; refreshCtx(); }).show();
                        return;
                    } else if (w == 3) {
                        Intent v = new Intent(Intent.ACTION_VIEW);
                        v.setDataAndType(c.uri, "video/*");
                        v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { startActivity(v); } catch (Exception ignored) { toast("No hay con qué ver el video"); }
                        return;
                    } else if (w == 4) { l.remove(idx); }
                    Proj.clips.clear();
                    Proj.clips.addAll(l);
                    refreshCtx();
                }).show();
    }

    private int[] joinSize(Proj.Clip first, int alto) {
        float k = alto / 720f;
        switch (Proj.joinFormat) {
            case 1: return new int[]{even(Math.round(720 * k)), even(Math.round(1280 * k))};
            case 2: return new int[]{even(Math.round(1280 * k)), even(Math.round(720 * k))};
            case 3: return new int[]{even(Math.round(720 * k)), even(Math.round(720 * k))};
        }
        int fw = first.w > 0 ? first.w : 720, fh = first.h > 0 ? first.h : 1280;
        float sc = Math.min(1f, (float) alto / Math.max(1, Math.min(fw, fh)));
        return new int[]{even(Math.round(fw * sc)), even(Math.round(fh * sc))};
    }

    private void doJoin() {
        final List<Proj.Clip> cl = new ArrayList<>(Proj.clips);
        if (cl.isEmpty()) { toast("Agregue videos con ➕"); return; }
        // Versión 6.3: si es para guardar y no hay adornos, se une de una vez con la calidad escogida
        final boolean finalDirecto = pendingMode == Mode.EXPORT && sinAdornos();
        final int q = finalDirecto ? calidadGuardada() : 0;
        int[] wh = joinSize(cl.get(0), ALTOS[q]);
        int W = wh[0], H = wh[1];
        ImmutableList.Builder<EditedMediaItem> items = ImmutableList.builder();
        int n = cl.size();
        for (int i = 0; i < n; i++) {
            Proj.Clip c = cl.get(i);
            int inT = i > 0 ? cl.get(i - 1).trans : (Proj.joinSoft ? 1 : 0);
            int outT = i < n - 1 ? c.trans : (Proj.joinSoft ? 1 : 0);
            // Versión 4: cada capa solo entre su línea azul (a) y su línea roja (b)
            long dur = c.dur();
            long tt = Math.min(TRANS_MS, dur / 3);
            List<Effect> fx = new ArrayList<>();
            if (false) fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(
                    new Marca.Overlay(c.w, c.h, c.a, c.durMs, c.wmFuerza, c.wmArriba))));
            fx.add(Presentation.createForWidthAndHeight(W, H, Presentation.LAYOUT_SCALE_TO_FIT));
            if (TransMotion.moves(inT) || TransMotion.moves(outT))
                fx.add(new TransMotion(inT, outT, dur, tt, (float) W / H));
            boolean fi = inT == 1 || inT == 2, fo = outT == 1 || outT == 2;
            if (fi || fo) fx.add(new TransFade(fi, fo, dur, tt));
            MediaItem.Builder mb = new MediaItem.Builder().setUri(c.uri);
            if (c.a > 0 || c.b < c.durMs)
                mb.setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.a).setEndPositionMs(c.b).build());
            items.add(new EditedMediaItem.Builder(mb.build())
                    .setEffects(new Effects(ImmutableList.<AudioProcessor>of(), fx))
                    .build());
        }
        Composition comp = new Composition.Builder(ImmutableList.of(new EditedMediaItemSequence(items.build())))
                .experimentalSetForceAudioTrack(true)
                .build();
        // Versión 6.3: la unión de trabajo va a la memoria interna (no deja un archivo extra en Descargas)
        File[] viejos = getCacheDir().listFiles((dd, nn) -> nn.startsWith("union_") && nn.endsWith(".mp4"));
        if (viejos != null) for (File v : viejos) if (Proj.uri == null || !Uri.fromFile(v).equals(Proj.uri)) v.delete();
        final File out = new File(getCacheDir(), "union_" + stamp() + ".mp4");
        runJob(baseTransformer(finalDirecto ? BITS[q] : 2_000_000), comp, out,
                finalDirecto ? "💾 Guardando video…" : "🎞 Juntando los pedazos…", null, f -> {
            if (finalDirecto) {
                // el video final: un solo archivo en Descargas/MiBarra/ChepeVideo
                final String name = "ChepeVideo_" + stamp() + ".mp4";
                toDownloads(f, "", name, "video/mp4", (uu, nm, size) -> {
                    ultimoUnido = uu; ultimoNombre = nm; ultimoTam = size;
                    unionEsFinal = true;
                    loadVideo(uu, true);
                });
            } else {
                // para seguir trabajando (textos, fotos, música…) o para guardar con adornos
                ultimoUnido = null;
                unionEsFinal = false;
                loadVideo(Uri.fromFile(f), true);
            }
        });
    }

    // ------------------------------------------------------------ textos

    private Proj.TextLayer newText(String txt) {
        long pos = player.getCurrentPosition();
        long st = pos, en = Math.min(Proj.durMs, pos + 4000);
        if (en - st < 1000) { st = Math.max(0, Proj.durMs - 4000); en = Proj.durMs; }
        Proj.TextLayer t = new Proj.TextLayer(txt, st, en);
        t.style = 5; // Versión 5: de entrada con borde y sombra
        return t;
    }

    private void ctxText() {
        final Proj.TextLayer t = Proj.selText;
        add(chip("➕ Escribir texto", t == null, () -> editText(newText(""), true)));
        add(chip("🎂 Cumpleaños", false, () -> {
            Proj.TextLayer x = newText("¡Feliz cumpleaños!");
            x.style = 3; x.anim = 5; x.size = 0.11f; x.cy = 0.18f;
            editText(x, true);
        }));
        add(chip("📢 Publicidad", false, () -> {
            Proj.TextLayer x = newText("¡Oferta especial!");
            x.style = 2; x.anim = 2; x.size = 0.08f; x.cy = 0.8f;
            editText(x, true);
        }));
        if (t == null) { add(lab("Escriba lo que quiera encima del video")); return; }
        if (Proj.texts.size() > 1) add(chip("▶ Siguiente texto (" + (Proj.texts.indexOf(t) + 1) + "/" + Proj.texts.size() + ")", false, () -> {
            int k = (Proj.texts.indexOf(t) + 1) % Proj.texts.size();
            Proj.selText = Proj.texts.get(k);
            player.seekTo(Proj.selText.startMs);
            refreshCtx();
        }));
        add(chip("✏️ Cambiar", false, () -> editText(t, false)));
        add(chip("⏮ Desde aquí", false, () -> {
            t.startMs = player.getCurrentPosition();
            if (t.endMs <= t.startMs + 300) t.endMs = Math.min(Proj.durMs, t.startMs + 4000);
            marks(); refreshCtx();
        }));
        add(chip("Hasta aquí ⏭", false, () -> {
            t.endMs = Math.max(player.getCurrentPosition(), t.startMs + 300);
            marks(); refreshCtx();
        }));
        add(lab(fmt(t.startMs) + " → " + fmt(t.endMs)));
        add(chip("⏱ Todo el video", false, () -> { t.startMs = 0; t.endMs = Proj.durMs; marks(); refreshCtx(); }));
        add(chip("🗑 Quitar", false, () -> {
            Proj.texts.remove(t);
            Proj.selText = Proj.texts.isEmpty() ? null : Proj.texts.get(Proj.texts.size() - 1);
            marks(); refreshCtx();
        }));
        add(lab("Mueva con un dedo · agrande con dos"));
    }

    /** Fila de opciones donde se escoge una sola. */
    private HorizontalScrollView choices(String[] labels, int[] colors, int selected, IntConsumer onPick) {
        final LinearLayout row = hbox();
        row.setPadding(0, dp(4), 0, dp(4));
        final List<TextView> all = new ArrayList<>();
        final int[] sel = {selected};
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            TextView t = tv(labels[i], 14, TEAL_T, true);
            t.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMarginEnd(dp(6));
            t.setLayoutParams(lp);
            all.add(t);
            row.addView(t);
        }
        final Runnable paint = () -> {
            for (int i = 0; i < all.size(); i++) {
                TextView t = all.get(i);
                boolean on = i == sel[0];
                if (colors != null) {
                    GradientDrawable g = round(colors[i], 18);
                    g.setStroke(dp(on ? 4 : 1), on ? 0xFFEF9F27 : 0xFF888780);
                    t.setBackground(g);
                    int c = colors[i];
                    boolean darkC = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 < 140;
                    t.setTextColor(darkC ? Color.WHITE : Color.BLACK);
                } else {
                    t.setBackground(round(on ? TEAL_D : TEAL_L, 18));
                    t.setTextColor(on ? Color.WHITE : TEAL_T);
                }
            }
        };
        for (int i = 0; i < all.size(); i++) {
            final int k = i;
            all.get(i).setOnClickListener(v -> { sel[0] = k; paint.run(); onPick.accept(k); });
        }
        paint.run();
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    private static int indexOf(int[] a, int v) {
        for (int i = 0; i < a.length; i++) if (a[i] == v) return i;
        return 0;
    }

    private void editText(final Proj.TextLayer t, final boolean isNew) {
        player.pause();
        final LinearLayout box = vbox();
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        final EditText et = new EditText(this);
        et.setText(t.text);
        et.setHint("Escriba aquí el texto");
        et.setTextColor(Color.BLACK);
        et.setTextSize(19);
        et.setMinLines(2);
        et.setSelection(et.getText().length());
        box.addView(et);
        final int[] v = {t.style, t.color, t.anim};
        box.addView(tv("Estilo", 13, TEAL_T, true));
        box.addView(choices(TextPainter.STYLES, null, v[0], k -> v[0] = k));
        box.addView(tv("Color", 13, TEAL_T, true));
        box.addView(choices(TextPainter.COLOR_NAMES, TextPainter.COLORS, indexOf(TextPainter.COLORS, v[1]), k -> v[1] = TextPainter.COLORS[k]));
        box.addView(tv("Movimiento al aparecer", 13, TEAL_T, true));
        box.addView(choices(TextPainter.ANIMS, null, v[2], k -> v[2] = k));
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(isNew ? "🔤 Texto nuevo" : "✏️ Cambiar texto").setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    String txt = et.getText().toString().trim();
                    if (txt.isEmpty()) { toast("El texto quedó vacío"); return; }
                    t.text = txt;
                    t.style = v[0];
                    t.color = v[1];
                    t.anim = v[2];
                    if (isNew) Proj.texts.add(t);
                    Proj.selText = t;
                    if (mode != Mode.TEXT) setMode(Mode.TEXT);
                    player.seekTo(t.startMs);
                    marks();
                    refreshCtx();
                    overlay.invalidate();
                })
                .setNegativeButton("Cancelar", null);
        if (!isNew) b.setNeutralButton("🗑 Quitar", (d, w) -> {
            Proj.texts.remove(t);
            Proj.selText = Proj.texts.isEmpty() ? null : Proj.texts.get(Proj.texts.size() - 1);
            marks();
            refreshCtx();
        });
        b.show();
    }

    // ------------------------------------------------------------ música

    private void ctxMusic() {
        final Proj.Music mu = Proj.music;
        add(chip(mu == null ? "🎵 Escoger música" : "🎵 Cambiar música", mu == null, () -> pick(REQ_MUSIC, "audio/*")));
        if (mu == null) { add(lab("Búsquela en la carpeta que quiera")); return; }
        add(lab("🎶 " + shortName(mu.name) + " · " + fmt(mu.durMs)));
        add(chip("−", false, () -> { mu.vol = Math.max(0f, Math.round(mu.vol * 10f - 1f) / 10f); refreshCtx(); }));
        add(lab("Música " + Math.round(mu.vol * 100) + " %"));
        add(chip("+", false, () -> { mu.vol = Math.min(1f, Math.round(mu.vol * 10f + 1f) / 10f); refreshCtx(); }));
        add(chip("−", false, () -> { mu.videoVol = Math.max(0f, Math.round(mu.videoVol * 10f - 1f) / 10f); applyVolume(); refreshCtx(); }));
        add(lab("Voz del video " + Math.round(mu.videoVol * 100) + " %"));
        add(chip("+", false, () -> { mu.videoVol = Math.min(1f, Math.round(mu.videoVol * 10f + 1f) / 10f); applyVolume(); refreshCtx(); }));
        add(chip(mu.soft ? "🌅 Entra y sale suave: Sí" : "🌅 Entra y sale suave: No", false, () -> { mu.soft = !mu.soft; refreshCtx(); }));
        add(chip("🗑 Quitar", false, () -> {
            Proj.music = null;
            if (musicPlayer != null) musicPlayer.stop();
            applyVolume();
            refreshCtx();
        }));
    }

    private void loadMusic(final Uri u) {
        status("🎵 Cargando la música…");
        exec.execute(() -> {
            long d = 0;
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, u);
                d = Frames.parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            } catch (Exception ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) {}
            }
            final long fd = d;
            final String nm = nameOf(u);
            ui.post(() -> {
                status(null);
                if (fd <= 0) { toast("No pude abrir esa música"); return; }
                // Versión 5: la música entra a la pista morada desde donde está la raya roja
                Proj.Music mu = new Proj.Music(u, nm, fd);
                long aqui = player.getCurrentPosition();
                mu.at = (aqui >= Proj.trimStart && aqui < Proj.trimEnd - 500) ? aqui : Proj.trimStart;
                mu.vol = Proj.mute ? 1f : 0.6f;
                Proj.sonidos.add(mu);
                Proj.selSon = mu;
                if (mode != Mode.MUSIC) setMode(Mode.MUSIC); else refreshCtx();
                toast("🎵 Música en la pista morada: recórtela con [ ] o muévala con «⏮ Empieza aquí»");
            });
        });
    }

    private void syncMusic(long pos, boolean playing) {
        ExoPlayer mp = musicPlayer;
        if (mp == null) return;
        Proj.Music mu = Proj.music;
        if (mu == null || !playing || micActive || exporting) {
            if (mp.getPlayWhenReady()) mp.pause();
            return;
        }
        mp.setVolume(mu.vol);
        long want = (long) ((pos - Proj.trimStart) / Math.max(0.05f, Proj.speed));
        if (want < 0) want = 0;
        if (mu.durMs > 0) want %= mu.durMs;
        if (!mp.getPlayWhenReady()) {
            mp.seekTo(want);
            mp.play();
        } else if (mp.getPlaybackState() == Player.STATE_READY && Math.abs(mp.getCurrentPosition() - want) > 700) {
            mp.seekTo(want);
        }
    }

    private void applyVolume() {
        if (micActive) return;
        player.setVolume(Proj.mute ? 0f : 1f);
    }

    // ------------------------------------------------------------ utilidades

    private void keepScreen(boolean on) {
        if (on == screenOn) return;
        screenOn = on;
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** Para los letreros por micrófono: el video suena a todo volumen y después se deja como estaba. */
    private void maxVolume() {
        try {
            AudioManager am = getSystemService(AudioManager.class);
            if (am == null) return;
            if (savedVol < 0) savedVol = am.getStreamVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
        } catch (Exception ignored) {}
    }

    private void restoreVolume() {
        if (savedVol < 0) return;
        try {
            AudioManager am = getSystemService(AudioManager.class);
            if (am != null) am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVol, 0);
        } catch (Exception ignored) {}
        savedVol = -1;
    }

    /** Parte los letreros largos en pedazos cortos (máximo 7 palabras) repartiendo el tiempo, para que vayan al ritmo. */
    private static List<Proj.Sub> splitSubs(List<Proj.Sub> in) {
        List<Proj.Sub> out = new ArrayList<>();
        for (Proj.Sub s : in) {
            String txt = s.text == null ? "" : s.text.trim();
            String[] w = txt.isEmpty() ? new String[0] : txt.split("\\s+");
            if (w.length <= 8) { out.add(s); continue; }
            int parts = (w.length + 6) / 7;
            int per = (w.length + parts - 1) / parts;
            int totalChars = txt.length();
            long span = Math.max(1, s.endMs - s.startMs);
            long t = s.startMs;
            int used = 0;
            for (int p = 0; p < parts; p++) {
                int a = p * per, b = Math.min(w.length, a + per);
                if (a >= b) break;
                StringBuilder sb = new StringBuilder();
                for (int k = a; k < b; k++) { if (sb.length() > 0) sb.append(' '); sb.append(w[k]); }
                used += sb.length() + 1;
                long end = p == parts - 1 || b == w.length ? s.endMs : s.startMs + span * Math.min(used, totalChars) / Math.max(1, totalChars);
                out.add(new Proj.Sub(t, Math.max(end, t + 600), sb.toString(), ""));
                t = end;
            }
        }
        return out;
    }

    private String nameOf(Uri u) {
        if (u == null) return "";
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String n = c.getString(0);
                    if (n != null) return n;
                }
            } catch (Exception ignored) {}
        }
        String n = u.getLastPathSegment();
        return n == null ? "" : n;
    }

    private static String shortName(String n) {
        if (n == null) return "";
        return n.length() > 26 ? n.substring(0, 23) + "…" : n;
    }
}
