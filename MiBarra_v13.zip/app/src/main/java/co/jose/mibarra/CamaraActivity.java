package co.jose.mibarra;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

/** Abre la cámara normal del celular y guarda la foto o el video en Descargas/MiBarra/Fotos o Videos. */
public class CamaraActivity extends Activity {
    private Uri destino;
    private boolean video;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        video = getIntent().getBooleanExtra("video", false);
        if (b != null && b.getString("destino") != null) { destino = Uri.parse(b.getString("destino")); return; }
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(video ? new String[]{android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO}
                    : new String[]{android.Manifest.permission.CAMERA}, 2);
            return;
        }
        lanzar();
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] res) {
        super.onRequestPermissionsResult(r, p, res);
        if (res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) lanzar();
        else { Toast.makeText(this, "Sin permiso de cámara no puedo tomar fotos", Toast.LENGTH_LONG).show(); finish(); }
    }

    private void lanzar() {
        destino = Util.crearEnDescargas(this, (video ? "Video_" : "Foto_") + Util.fecha() + (video ? ".mp4" : ".jpg"),
                video ? "video/mp4" : "image/jpeg");
        Intent i = new Intent(video ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, destino)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(i, 1);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "No pude abrir la cámara del celular", Toast.LENGTH_LONG).show();
            borrar();
            finish();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        if (destino != null) o.putString("destino", destino.toString());
    }

    @Override
    protected void onActivityResult(int pedido, int resultado, Intent d) {
        super.onActivityResult(pedido, resultado, d);
        if (resultado == RESULT_OK && destino != null) {
            Util.terminar(this, destino);
            Toast.makeText(this, (video ? "🎥 Video" : "📷 Foto") + " guardado en Descargas/MiBarra/" + (video ? "Videos" : "Fotos"),
                    Toast.LENGTH_LONG).show();
        } else {
            borrar();
        }
        finish();
    }

    private void borrar() {
        try { if (destino != null) getContentResolver().delete(destino, null, null); } catch (Exception ignored) {}
    }
}
