package co.jose.mibarra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/**
 * Temporizador de cocina que sigue contando con la pantalla apagada.
 * Al terminar: dice "se acabó el tiempo" y suena la canción escogida, la radio o la alarma del celular.
 * También sirve para oír la radio (un enlace de transmisión).
 */
public class RelojService extends Service {
    static final String INICIAR = "co.jose.mibarra.RELOJ_INICIAR", PARAR = "co.jose.mibarra.RELOJ_PARAR",
            RADIO = "co.jose.mibarra.RELOJ_RADIO";
    static volatile long fin;          // cuándo termina (0 = no hay)
    static volatile boolean sonando, radio;
    static volatile String nombre = "";

    private final Handler h = new Handler(Looper.getMainLooper());
    private MediaPlayer mp;
    private TextToSpeech voz;
    private PowerManager.WakeLock wl;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String a = i == null ? PARAR : i.getAction();
        if (PARAR.equals(a)) { parar(); return START_NOT_STICKY; }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("reloj", "Reloj de cocina", NotificationManager.IMPORTANCE_HIGH));
        if (voz == null) voz = new TextToSpeech(this, s -> { if (s == TextToSpeech.SUCCESS) voz.setLanguage(new Locale("es", "CO")); });
        if (INICIAR.equals(a)) {
            soltarSonido();
            radio = false;
            fin = System.currentTimeMillis() + i.getLongExtra("ms", 60000);
            nombre = i.getStringExtra("nombre") == null ? "" : i.getStringExtra("nombre");
            startForeground(41, aviso(false), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            if (wl == null) {
                wl = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MiBarra:reloj");
                wl.setReferenceCounted(false);
            }
            wl.acquire(Math.max(60000, fin - System.currentTimeMillis() + 10 * 60000));
            h.removeCallbacks(tic);
            h.post(tic);
        } else if (RADIO.equals(a)) {
            soltarSonido();
            fin = 0;
            radio = true;
            nombre = "📻 Radio";
            startForeground(41, aviso(true), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            tocar(Uri.parse(i.getStringExtra("url")), false);
        }
        return START_NOT_STICKY;
    }

    private final Runnable tic = new Runnable() {
        @Override public void run() {
            if (fin == 0) return;
            long falta = fin - System.currentTimeMillis();
            if (falta <= 0) { sonar(); return; }
            h.postDelayed(this, Math.min(1000, falta));
        }
    };

    private void sonar() {
        fin = 0;
        sonando = true;
        getSystemService(NotificationManager.class).notify(41, aviso(true));
        try { voz.speak("Se acabó el tiempo" + (nombre.isEmpty() ? "" : " de " + nombre), TextToSpeech.QUEUE_FLUSH, null, "r"); } catch (Exception ignored) {}
        android.content.SharedPreferences p = getSharedPreferences("barra", MODE_PRIVATE);
        String cancion = p.getString("relojCancion", ""), url = p.getString("relojRadio", "");
        int cual = p.getInt("relojSonido", 0); // 0 alarma del celular, 1 canción, 2 radio
        Uri u = cual == 1 && !cancion.isEmpty() ? Uri.parse(cancion) : cual == 2 && !url.isEmpty() ? Uri.parse(url)
                : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        final Uri fu = u;
        h.postDelayed(() -> tocar(fu, cual != 2), 1800);
        // Si nadie la apaga, se calla sola a los 10 minutos
        h.postDelayed(this::parar, 10 * 60000);
    }

    private void tocar(Uri u, boolean repetir) {
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(radio ? AudioAttributes.USAGE_MEDIA : AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setDataSource(this, u);
            mp.setLooping(repetir);
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.setOnErrorListener((m, w, e) -> {
                if (!radio) tocarAlarma();
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) {
            if (!radio) tocarAlarma();
        }
    }

    private void tocarAlarma() {
        soltarSonido();
        try {
            mp = MediaPlayer.create(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            if (mp != null) { mp.setLooping(true); mp.start(); }
        } catch (Exception ignored) {}
    }

    private Notification aviso(boolean ahora) {
        PendingIntent abrir = PendingIntent.getActivity(this, 0, new Intent(this, RelojActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent parar = PendingIntent.getService(this, 1, new Intent(this, RelojService.class).setAction(PARAR),
                PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, "reloj")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(abrir)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, radio ? "⏹ Apagar radio" : sonando ? "⏹ Apagar" : "✖ Cancelar", parar).build());
        if (radio) b.setContentTitle("📻 Radio sonando").setContentText("Toque Apagar para quitarla");
        else if (sonando || ahora) b.setContentTitle("⏰ ¡Se acabó el tiempo!" + (nombre.isEmpty() ? "" : " · " + nombre))
                .setContentText("Toque Apagar").setFullScreenIntent(abrir, true).setCategory(Notification.CATEGORY_ALARM);
        else b.setContentTitle("⏳ Temporizador" + (nombre.isEmpty() ? "" : " · " + nombre))
                .setUsesChronometer(true).setChronometerCountDown(true).setWhen(fin).setShowWhen(true)
                .setContentText("Sigue contando aunque apague la pantalla");
        return b.build();
    }

    private void soltarSonido() {
        if (mp != null) { try { mp.stop(); } catch (Exception ignored) {} try { mp.release(); } catch (Exception ignored) {} mp = null; }
    }

    private void parar() {
        h.removeCallbacksAndMessages(null);
        soltarSonido();
        fin = 0;
        sonando = false;
        radio = false;
        if (wl != null && wl.isHeld()) wl.release();
        if (voz != null) { voz.shutdown(); voz = null; }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public void onDestroy() { soltarSonido(); if (wl != null && wl.isHeld()) wl.release(); super.onDestroy(); }
}
