package co.jose.mibarra;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Reloj de cocina: cronómetro que habla, temporizador con canción o radio, alarma y radio. */
public class RelojActivity extends Base {

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private LinearLayout cuerpo;
    private Button[] pest = new Button[3];
    private int pestana;
    private TextView grande;
    private TextToSpeech voz;

    // Cronómetro (sigue vivo mientras la app esté abierta)
    private static long cInicio, cAcum;
    private static boolean cCorriendo;
    private static final List<Long> vueltas = new ArrayList<>();
    private static long ultimoMinutoDicho;

    private static final int CANCION = 51;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("barra", MODE_PRIVATE);
        voz = new TextToSpeech(this, s -> { if (s == TextToSpeech.SUCCESS) voz.setLanguage(new Locale("es", "CO")); });
        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(0xFF101418);
        LinearLayout fila = horizontal();
        String[] n = {"⏱ Cronómetro", "⏳ Temporizador", "⏰ Alarma · 📻"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            pest[i] = boton(n[i], 0xFF263238);
            pest[i].setTextSize(14);
            pest[i].setOnClickListener(v -> mostrar(k));
            fila.addView(pest[i], peso(1));
        }
        raiz.addView(fila, ancho(52));
        cuerpo = vertical();
        cuerpo.setPadding(dp(14), dp(10), dp(14), dp(14));
        ScrollView sv = new ScrollView(this);
        sv.addView(cuerpo);
        raiz.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(raiz);
        mostrar(RelojService.fin > 0 || RelojService.sonando ? 1 : prefs.getInt("relojPest", 0));
    }

    @Override protected void onResume() { super.onResume(); h.post(tic); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tic); }
    @Override protected void onDestroy() { if (voz != null) voz.shutdown(); super.onDestroy(); }

    private final Runnable tic = new Runnable() {
        @Override public void run() { refrescar(); h.postDelayed(this, 200); }
    };

    private void mostrar(int k) {
        pestana = k;
        prefs.edit().putInt("relojPest", k).apply();
        for (int i = 0; i < 3; i++) pest[i].setBackgroundColor(i == k ? 0xFF1565C0 : 0xFF263238);
        cuerpo.removeAllViews();
        grande = new TextView(this);
        grande.setTextSize(64);
        grande.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        grande.setTextColor(Color.WHITE);
        grande.setGravity(Gravity.CENTER);
        grande.setPadding(0, dp(10), 0, dp(10));
        cuerpo.addView(grande);
        if (k == 0) cronometro();
        else if (k == 1) temporizador();
        else alarma();
        refrescar();
    }

    private static String hms(long ms, boolean decimas) {
        long s = ms / 1000;
        String t = s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                : String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
        return decimas ? t + "," + (ms % 1000) / 100 : t;
    }

    private long cTiempo() { return cAcum + (cCorriendo ? System.currentTimeMillis() - cInicio : 0); }

    private void refrescar() {
        if (grande == null) return;
        if (pestana == 0) {
            long t = cTiempo();
            grande.setText(hms(t, true));
            int cada = prefs.getInt("cronoVoz", 5);
            if (cCorriendo && cada > 0) {
                long min = t / 60000;
                if (min > 0 && min % cada == 0 && min != ultimoMinutoDicho) {
                    ultimoMinutoDicho = min;
                    decir("Van " + (min == 1 ? "un minuto" : min + " minutos"));
                }
            }
        } else if (pestana == 1) {
            if (RelojService.sonando) grande.setText("⏰ ¡YA!");
            else if (RelojService.fin > 0) grande.setText(hms(Math.max(0, RelojService.fin - System.currentTimeMillis() + 999), false));
            else grande.setText("00:00");
        } else {
            grande.setText(new java.text.SimpleDateFormat("hh:mm a", new Locale("es", "CO")).format(new java.util.Date()));
        }
    }

    private void decir(String s) { try { voz.speak(s, TextToSpeech.QUEUE_FLUSH, null, "c"); } catch (Exception ignored) {} }

    // ---------------- Cronómetro ----------------

    private void cronometro() {
        LinearLayout f = horizontal();
        Button ir = boton(cCorriendo ? "⏸ Pausa" : "▶ Empezar", cCorriendo ? 0xFFF57C00 : 0xFF2E7D32);
        ir.setTextSize(20);
        ir.setOnClickListener(v -> {
            if (cCorriendo) { cAcum += System.currentTimeMillis() - cInicio; cCorriendo = false; }
            else { cInicio = System.currentTimeMillis(); cCorriendo = true; }
            mostrar(0);
        });
        Button vu = boton("🏁 Vuelta", 0xFF455A64);
        vu.setOnClickListener(v -> { if (cCorriendo) { vueltas.add(0, cTiempo()); mostrar(0); } });
        Button re = boton("↺ Cero", 0xFF6D4C41);
        re.setOnClickListener(v -> { cCorriendo = false; cAcum = 0; vueltas.clear(); ultimoMinutoDicho = 0; mostrar(0); });
        f.addView(ir, peso(1.4f));
        f.addView(vu, peso(1));
        f.addView(re, peso(1));
        cuerpo.addView(f, ancho(64));
        TextView t = texto("🗣 Que me diga el tiempo en voz alta:");
        cuerpo.addView(t);
        LinearLayout op = horizontal();
        int[] cada = {0, 1, 5, 10, 15};
        String[] nom = {"No", "Cada 1 min", "Cada 5", "Cada 10", "Cada 15"};
        for (int i = 0; i < cada.length; i++) {
            final int c = cada[i];
            Button bt = boton(nom[i], prefs.getInt("cronoVoz", 5) == c ? 0xFF1565C0 : 0xFF37474F);
            bt.setTextSize(12);
            bt.setOnClickListener(v -> { prefs.edit().putInt("cronoVoz", c).apply(); mostrar(0); });
            op.addView(bt, peso(1));
        }
        cuerpo.addView(op, ancho(48));
        for (int i = 0; i < vueltas.size(); i++) {
            long dif = vueltas.get(i) - (i + 1 < vueltas.size() ? vueltas.get(i + 1) : 0);
            cuerpo.addView(texto("Vuelta " + (vueltas.size() - i) + ":  " + hms(vueltas.get(i), true) + "   (+" + hms(dif, true) + ")"));
        }
    }

    // ---------------- Temporizador ----------------

    private void temporizador() {
        if (RelojService.fin > 0 || RelojService.sonando) {
            if (!RelojService.nombre.isEmpty()) cuerpo.addView(texto("Para: " + RelojService.nombre));
            Button p = boton(RelojService.sonando ? "⏹  APAGAR LA ALARMA" : "✖  Cancelar el temporizador", 0xFFC62828);
            p.setTextSize(20);
            p.setOnClickListener(v -> { startService(new Intent(this, RelojService.class).setAction(RelojService.PARAR)); h.postDelayed(() -> mostrar(1), 300); });
            cuerpo.addView(p, ancho(70));
            cuerpo.addView(texto("Puede apagar la pantalla: sigue contando y le avisa con voz y sonido."));
            return;
        }
        EditText para = campoTexto("¿Para qué? (arroz, frijoles, horno…) — opcional", prefs.getString("relojNombre", ""));
        cuerpo.addView(para);
        cuerpo.addView(texto("Toque los minutos:"));
        int[] mins = {1, 3, 5, 10, 15, 20, 30, 45, 60};
        LinearLayout f = null;
        for (int i = 0; i < mins.length; i++) {
            if (i % 3 == 0) { f = horizontal(); cuerpo.addView(f, ancho(58)); }
            final int m = mins[i];
            Button bt = boton(m + " min", 0xFF2E7D32);
            bt.setTextSize(18);
            bt.setOnClickListener(v -> arrancar(m * 60000L, para.getText().toString().trim()));
            f.addView(bt, peso(1));
        }
        LinearLayout otro = horizontal();
        EditText mm = campoTexto("Otros minutos", "");
        mm.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        otro.addView(mm, peso(1));
        Button go = boton("▶", 0xFF2E7D32);
        go.setOnClickListener(v -> {
            double x = Util.cantidad(mm.getText().toString());
            if (x <= 0) { aviso("Escriba los minutos"); return; }
            arrancar((long) (x * 60000), para.getText().toString().trim());
        });
        otro.addView(go, new LinearLayout.LayoutParams(dp(70), dp(54)));
        cuerpo.addView(otro);
        sonido();
    }

    private void arrancar(long ms, String nombre) {
        prefs.edit().putString("relojNombre", nombre).apply();
        startForegroundService(new Intent(this, RelojService.class).setAction(RelojService.INICIAR)
                .putExtra("ms", ms).putExtra("nombre", nombre));
        decir("Listo, " + (ms >= 60000 ? (ms / 60000) + (ms / 60000 == 1 ? " minuto" : " minutos") : (ms / 1000) + " segundos"));
        h.postDelayed(() -> mostrar(1), 300);
    }

    /** Qué suena al terminar: alarma del celular, una canción suya o la radio. */
    private void sonido() {
        cuerpo.addView(texto("\nAl terminar suena:"));
        int cual = prefs.getInt("relojSonido", 0);
        String[] n = {"🔔 Alarma", "🎵 Canción", "📻 Radio"};
        LinearLayout f = horizontal();
        for (int i = 0; i < 3; i++) {
            final int k = i;
            Button bt = boton(n[i], i == cual ? 0xFF1565C0 : 0xFF37474F);
            bt.setOnClickListener(v -> {
                if (k == 1) {
                    Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE);
                    try { startActivityForResult(it, CANCION); } catch (Exception e) { aviso("No encontré canciones"); }
                    return;
                }
                if (k == 2 && prefs.getString("relojRadio", "").isEmpty()) { pedirRadio(() -> { prefs.edit().putInt("relojSonido", 2).apply(); mostrar(1); }); return; }
                prefs.edit().putInt("relojSonido", k).apply();
                mostrar(1);
            });
            f.addView(bt, peso(1));
        }
        cuerpo.addView(f, ancho(50));
        if (cual == 1) cuerpo.addView(texto("Canción: " + prefs.getString("relojCancionNombre", "(escoja una)")));
        if (cual == 2) cuerpo.addView(texto("Radio: " + prefs.getString("relojRadio", "")));
    }

    @Override
    protected void onActivityResult(int r, int res, Intent d) {
        super.onActivityResult(r, res, d);
        if (r == CANCION && res == RESULT_OK && d != null && d.getData() != null) {
            Uri u = d.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            String nom = u.getLastPathSegment();
            try (android.database.Cursor c = getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (ix >= 0) nom = c.getString(ix);
                }
            } catch (Exception ignored) {}
            prefs.edit().putString("relojCancion", u.toString()).putString("relojCancionNombre", nom).putInt("relojSonido", 1).apply();
            mostrar(1);
        }
    }

    private void pedirRadio(Runnable listo) {
        EditText e = campoTexto("https://…  (enlace de la emisora)", prefs.getString("relojRadio", ""));
        new AlertDialog.Builder(this).setTitle("📻 Enlace de la emisora")
                .setMessage("Pegue el enlace de transmisión de la emisora (lo da la página de la emisora; suele terminar en .mp3, .aac o /stream).")
                .setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String u = e.getText().toString().trim();
                    if (!u.startsWith("http")) { aviso("El enlace debe empezar por http"); return; }
                    prefs.edit().putString("relojRadio", u).apply();
                    listo.run();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Alarma y radio ----------------

    private void alarma() {
        Button al = boton("⏰  Poner una alarma (hora fija)", 0xFF6A1B9A);
        al.setTextSize(18);
        al.setOnClickListener(v -> {
            java.util.Calendar c = java.util.Calendar.getInstance();
            new TimePickerDialog(this, (tp, hh, mm) -> {
                EditText msg = campoTexto("¿Para qué? (opcional)", "");
                new AlertDialog.Builder(this).setTitle(String.format(Locale.US, "Alarma a las %02d:%02d", hh, mm)).setView(msg)
                        .setPositiveButton("Poner", (d, w) -> {
                            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                                    .putExtra(AlarmClock.EXTRA_HOUR, hh).putExtra(AlarmClock.EXTRA_MINUTES, mm)
                                    .putExtra(AlarmClock.EXTRA_MESSAGE, msg.getText().toString().trim().isEmpty() ? "Mi Barra" : msg.getText().toString().trim())
                                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                            try { startActivity(i); aviso(String.format(Locale.US, "⏰ Alarma puesta a las %02d:%02d en el reloj del celular", hh, mm)); }
                            catch (Exception e) { aviso("Este celular no deja poner alarmas desde otra app"); }
                        }).setNegativeButton("Cancelar", null).show();
            }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), false).show();
        });
        cuerpo.addView(al, ancho(64));
        cuerpo.addView(texto("La alarma queda guardada en el reloj del celular, con su sonido; suena aunque Mi Barra esté cerrada."));
        Button ver = boton("📋  Ver mis alarmas", 0xFF455A64);
        ver.setOnClickListener(v -> { try { startActivity(new Intent(AlarmClock.ACTION_SHOW_ALARMS)); } catch (Exception e) { aviso("No se pudo abrir el reloj"); } });
        cuerpo.addView(ver, ancho(50));

        cuerpo.addView(texto("\n📻 Radio"));
        boolean suena = RelojService.radio;
        Button ra = boton(suena ? "⏹  Apagar la radio" : "▶  Oír la radio", suena ? 0xFFC62828 : 0xFF2E7D32);
        ra.setTextSize(18);
        ra.setOnClickListener(v -> {
            if (RelojService.radio) { startService(new Intent(this, RelojService.class).setAction(RelojService.PARAR)); h.postDelayed(() -> mostrar(2), 300); return; }
            Runnable tocar = () -> {
                startForegroundService(new Intent(this, RelojService.class).setAction(RelojService.RADIO).putExtra("url", prefs.getString("relojRadio", "")));
                aviso("📻 Conectando con la emisora…");
                h.postDelayed(() -> mostrar(2), 400);
            };
            if (prefs.getString("relojRadio", "").isEmpty()) pedirRadio(tocar); else tocar.run();
        });
        cuerpo.addView(ra, ancho(60));
        Button cam = boton("✎  Cambiar la emisora", 0xFF455A64);
        cam.setOnClickListener(v -> pedirRadio(() -> mostrar(2)));
        cuerpo.addView(cam, ancho(48));
        String r = prefs.getString("relojRadio", "");
        if (!r.isEmpty()) cuerpo.addView(texto("Emisora: " + r));
    }

    private TextView texto(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFCFD8DC);
        t.setTextSize(16);
        t.setPadding(dp(2), dp(8), dp(2), dp(4));
        return t;
    }
}
