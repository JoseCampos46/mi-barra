package co.jose.miinventor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * La hoja del boceto 2D. Dos dedos siempre acercan y corren la hoja.
 * Con «Ver» un dedo corre la hoja y tocar escoge; con las herramientas de dibujo el dedo pone los puntos
 * (se ve la línea mientras corre el dedo y el punto queda donde lo suelta).
 */
public class VistaBoceto extends View {

    public static final int VER = 0, LINEA = 1, RECT = 2, CIRCULO = 3, ARCO = 4, TEXTO = 5, COTA = 6, MOVER = 7;
    public static final String[] AYUDA = {
            "Un dedo corre la hoja, dos dedos acercan. Toque líneas para escogerlas (hasta 2) y luego 🔗 Amarrar.",
            "Línea: suelte el dedo en cada punto. Para terminar toque ✓ o cierre en el primer punto.",
            "Rectángulo: suelte en una esquina y luego en la esquina contraria.",
            "Círculo: suelte en el centro y luego en el borde.",
            "Arco: suelte en el centro, luego en el inicio y luego en el final.",
            "Texto: suelte el dedo donde va el texto.",
            "Cota: toque una línea o un círculo; o toque dos puntos para la distancia entre ellos.",
            "Mover: arrastre un punto; el dibujo se acomoda respetando medidas y amarres."};

    public interface Oyente {
        void antes();                                        // guardar para deshacer
        void cambio();                                       // ya cambió algo
        void pedirCota(Boceto.Restr nueva);                  // escribir el valor de una cota nueva
        void pedirDistancia(int p1, int p2);                 // escoger horizontal, vertical o alineada
        void editarCota(Boceto.Restr r);
        void pedirTexto(double x, double y);
        void seleccion();
        void aviso(String s);
    }

    public Boceto b = new Boceto();
    public Medidas medidas;
    public Oyente oyente;
    public int modo = VER;
    public final List<Integer> sel = new ArrayList<>();      // entidades escogidas
    public int selPunto = -1;

    private double esc = 0.1;          // píxeles por mm
    private float offX, offY;          // dónde queda el (0,0) en la pantalla
    private boolean listo;

    // lo que se va dibujando
    private final List<Integer> clic = new ArrayList<>();    // puntos ya puestos con la herramienta
    private double fx = Double.NaN, fy;                      // dónde está el dedo (mm)
    private int cotaP1 = -1;

    private final Paint pLin = new Paint(Paint.ANTI_ALIAS_FLAG), pPto = new Paint(Paint.ANTI_ALIAS_FLAG),
            pCota = new Paint(Paint.ANTI_ALIAS_FLAG), pTxt = new Paint(Paint.ANTI_ALIAS_FLAG), pRej = new Paint(),
            pGlifo = new Paint(Paint.ANTI_ALIAS_FLAG), pFondo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Object[]> zonasCota = new ArrayList<>();   // {RectF, Restr} para tocar el número de una cota

    public VistaBoceto(Context c) {
        super(c);
        pLin.setStyle(Paint.Style.STROKE);
        pLin.setStrokeCap(Paint.Cap.ROUND);
        pCota.setStyle(Paint.Style.STROKE);
        pRej.setStrokeWidth(1);
        pGlifo.setFakeBoldText(true);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    // ---------------- Pantalla ↔ mm ----------------

    private float sx(double x) { return (float) (offX + x * esc); }
    private float sy(double y) { return (float) (offY - y * esc); }
    private double mx(float x) { return (x - offX) / esc; }
    private double my(float y) { return (offY - y) / esc; }

    public void encuadrar() {
        if (getWidth() == 0) return;
        double[] c = b.caja();
        double w = Math.max(500, c[2] - c[0]), h = Math.max(500, c[3] - c[1]);
        esc = Math.min(getWidth() * 0.78 / w, getHeight() * 0.70 / h);
        offX = (float) (getWidth() / 2.0 - (c[0] + c[2]) / 2 * esc);
        offY = (float) (getHeight() / 2.0 + (c[1] + c[3]) / 2 * esc);
        listo = true;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!listo || ow == 0) encuadrar();
    }

    public void ponerModo(int m) {
        modo = m;
        clic.clear();
        cotaP1 = -1;
        fx = Double.NaN;
        if (m != VER) { sel.clear(); selPunto = -1; }
        invalidate();
    }

    /** Termina la línea que se venía dibujando. */
    public void terminar() {
        clic.clear();
        cotaP1 = -1;
        fx = Double.NaN;
        invalidate();
    }

    // ---------------- Imán a puntos ----------------

    private int puntoCerca(float x, float y, float radio) {
        int mejor = -1;
        float d = radio;
        for (Boceto.Punto p : b.puntos.values()) {
            float dd = (float) Math.hypot(sx(p.x) - x, sy(p.y) - y);
            if (dd < d) { d = dd; mejor = p.id; }
        }
        return mejor;
    }

    /** Distancia en pantalla del dedo a una entidad. */
    private float distA(Boceto.Ent e, float x, float y) {
        Boceto.Punto a = b.puntos.get(e.a);
        if (a == null) return Float.MAX_VALUE;
        switch (e.tipo) {
            case Boceto.LINEA: {
                Boceto.Punto q = b.puntos.get(e.b);
                if (q == null) return Float.MAX_VALUE;
                float ax = sx(a.x), ay = sy(a.y), bx = sx(q.x), by = sy(q.y);
                float vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy;
                float t = l2 < 1 ? 0 : Math.max(0, Math.min(1, ((x - ax) * vx + (y - ay) * vy) / l2));
                return (float) Math.hypot(x - (ax + vx * t), y - (ay + vy * t));
            }
            case Boceto.CIRCULO: case Boceto.ARCO:
                return (float) Math.abs(Math.hypot(x - sx(a.x), y - sy(a.y)) - e.r * esc);
            case Boceto.TEXTO:
                return (float) Math.hypot(x - sx(a.x), y - sy(a.y));
        }
        return Float.MAX_VALUE;
    }

    private Boceto.Ent entCerca(float x, float y) {
        Boceto.Ent mejor = null;
        float d = dp(26);
        for (Boceto.Ent e : b.ents) {
            float dd = distA(e, x, y);
            if (dd < d) { d = dd; mejor = e; }
        }
        return mejor;
    }

    /** Pone un punto: si cae cerca de uno que ya existe, usa ese (quedan pegados). Si no, redondea a 10 mm. */
    private int ponerPunto(float x, float y) {
        int k = puntoCerca(x, y, dp(22));
        if (k >= 0) return k;
        double gx = Math.round(mx(x) / 10) * 10.0, gy = Math.round(my(y) / 10) * 10.0;
        return b.punto(gx, gy).id;
    }

    /** Línea nueva: si quedó casi horizontal o casi vertical, se amarra así (como Inventor). */
    private void lineaNueva(int a, int c) {
        if (a == c) return;
        Boceto.Punto p = b.puntos.get(a), q = b.puntos.get(c);
        Boceto.Ent e = b.linea(p, q);
        double ang = Math.toDegrees(Math.atan2(q.y - p.y, q.x - p.x));
        double m = Math.abs(((ang % 180) + 180) % 180);
        if (m < 4 || m > 176) { q.y = p.y; b.restriccion(Boceto.HORIZ, e.id, -1, -1, -1, null); }
        else if (Math.abs(m - 90) < 4) { q.x = p.x; b.restriccion(Boceto.VERT, e.id, -1, -1, -1, null); }
    }

    // ---------------- Dedos ----------------

    private float x0, y0, ax, ay, d0, mx0, my0, ox0, oy0;
    private double esc0;
    private boolean dos, movio;
    private int arrastre = -1;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = ax = e.getX(); y0 = ay = e.getY();
                dos = false; movio = false;
                arrastre = -1;
                if (modo == MOVER) {
                    arrastre = puntoCerca(x0, y0, dp(30));
                    if (arrastre >= 0 && oyente != null) oyente.antes();
                }
                if (dibujando()) { fx = mx(x0); fy = my(y0); invalidate(); }
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dos = true;
                    fx = Double.NaN;
                    d0 = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    esc0 = esc; ox0 = offX; oy0 = offY;
                    mx0 = (e.getX(0) + e.getX(1)) / 2; my0 = (e.getY(0) + e.getY(1)) / 2;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dos && e.getPointerCount() >= 2) {
                    float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    float cx = (e.getX(0) + e.getX(1)) / 2, cy = (e.getY(0) + e.getY(1)) / 2;
                    double f = d0 > 0 ? d / d0 : 1;
                    double nuevo = Math.max(0.002, Math.min(50, esc0 * f));
                    f = nuevo / esc0;
                    esc = nuevo;
                    // el punto que estaba entre los dedos sigue entre los dedos
                    offX = (float) (cx - (mx0 - ox0) * f);
                    offY = (float) (cy - (my0 - oy0) * f);
                    invalidate();
                    return true;
                }
                if (dos) return true;
                if (Math.hypot(e.getX() - x0, e.getY() - y0) > dp(8)) movio = true;
                if (modo == MOVER && arrastre >= 0) {
                    Boceto.Punto p = b.puntos.get(arrastre);
                    if (p != null) {
                        int k = puntoCerca(e.getX(), e.getY(), dp(16));
                        p.x = Math.round(mx(e.getX()) / 5) * 5.0;
                        p.y = Math.round(my(e.getY()) / 5) * 5.0;
                        if (k >= 0 && k != arrastre) { Boceto.Punto q = b.puntos.get(k); p.x = q.x; p.y = q.y; }
                        b.resolver(medidas, arrastre);
                        invalidate();
                    }
                } else if (dibujando()) {
                    fx = mx(e.getX()); fy = my(e.getY());
                    invalidate();
                } else if (movio) {
                    offX += e.getX() - ax;
                    offY += e.getY() - ay;
                    invalidate();
                }
                ax = e.getX(); ay = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
                if (dos) return true;
                if (modo == MOVER && arrastre >= 0) {
                    b.resolver(medidas, -1);
                    arrastre = -1;
                    if (oyente != null) oyente.cambio();
                    invalidate();
                    return true;
                }
                if (dibujando()) { soltar(e.getX(), e.getY()); return true; }
                if (!movio) tocar(e.getX(), e.getY());
                return true;
        }
        return true;
    }

    private boolean dibujando() { return modo >= LINEA && modo <= COTA; }

    /** El dedo se soltó con una herramienta de dibujo. */
    private void soltar(float x, float y) {
        fx = Double.NaN;
        switch (modo) {
            case LINEA: {
                if (oyente != null) oyente.antes();
                int k = ponerPunto(x, y);
                if (!clic.isEmpty()) {
                    int ult = clic.get(clic.size() - 1);
                    if (k == ult) { invalidate(); return; }
                    lineaNueva(ult, k);
                    if (k == clic.get(0)) { clic.clear(); listoCambio(); return; }   // cerró la figura
                }
                clic.add(k);
                listoCambio();
                return;
            }
            case RECT: {
                if (clic.isEmpty()) { clic.add(-1); fx = mx(x); fy = my(y); clicX = fx; clicY = fy; invalidate(); return; }
                if (oyente != null) oyente.antes();
                double x1 = Math.round(Math.min(clicX, mx(x)) / 10) * 10.0, x2 = Math.round(Math.max(clicX, mx(x)) / 10) * 10.0;
                double y1 = Math.round(Math.min(clicY, my(y)) / 10) * 10.0, y2 = Math.round(Math.max(clicY, my(y)) / 10) * 10.0;
                clic.clear();
                if (x2 - x1 < 1 || y2 - y1 < 1) { invalidate(); return; }
                Boceto.Punto a = b.punto(x1, y1), q = b.punto(x2, y1), c = b.punto(x2, y2), d = b.punto(x1, y2);
                Boceto.Ent ab = b.linea(a, q), bc = b.linea(q, c), cd = b.linea(c, d), da = b.linea(d, a);
                b.restriccion(Boceto.HORIZ, ab.id, -1, -1, -1, null);
                b.restriccion(Boceto.HORIZ, cd.id, -1, -1, -1, null);
                b.restriccion(Boceto.VERT, bc.id, -1, -1, -1, null);
                b.restriccion(Boceto.VERT, da.id, -1, -1, -1, null);
                listoCambio();
                return;
            }
            case CIRCULO: {
                if (clic.isEmpty()) { if (oyente != null) oyente.antes(); clic.add(ponerPunto(x, y)); invalidate(); return; }
                Boceto.Punto c = b.puntos.get(clic.get(0));
                clic.clear();
                double r = Math.round(Math.hypot(mx(x) - c.x, my(y) - c.y) / 5) * 5.0;
                if (r < 1) { b.limpiarPuntos(); invalidate(); return; }
                Boceto.Ent e = b.ent(Boceto.CIRCULO);
                e.a = c.id; e.r = r;
                listoCambio();
                return;
            }
            case ARCO: {
                if (clic.isEmpty()) { if (oyente != null) oyente.antes(); clic.add(ponerPunto(x, y)); invalidate(); return; }
                if (clic.size() == 1) { clic.add(ponerPunto(x, y)); invalidate(); return; }
                Boceto.Punto c = b.puntos.get(clic.get(0)), p1 = b.puntos.get(clic.get(1));
                double r = Math.hypot(p1.x - c.x, p1.y - c.y);
                double an = Math.atan2(my(y) - c.y, mx(x) - c.x);
                int k = puntoCerca(x, y, dp(22));
                Boceto.Punto p2 = k >= 0 ? b.puntos.get(k) : b.punto(c.x + r * Math.cos(an), c.y + r * Math.sin(an));
                clic.clear();
                if (r < 1 || p2.id == p1.id) { b.limpiarPuntos(); invalidate(); return; }
                Boceto.Ent e = b.ent(Boceto.ARCO);
                e.a = c.id; e.b = p1.id; e.c = p2.id; e.r = r;
                b.resolver(medidas, -1);
                listoCambio();
                return;
            }
            case TEXTO:
                if (oyente != null) oyente.pedirTexto(Math.round(mx(x) / 10) * 10.0, Math.round(my(y) / 10) * 10.0);
                return;
            case COTA: {
                int k = puntoCerca(x, y, dp(20));
                if (k >= 0) {
                    if (cotaP1 < 0) { cotaP1 = k; invalidate(); if (oyente != null) oyente.aviso("Ahora toque el otro punto"); return; }
                    if (k != cotaP1) { int p1 = cotaP1; cotaP1 = -1; invalidate(); if (oyente != null) oyente.pedirDistancia(p1, k); return; }
                }
                cotaP1 = -1;
                Boceto.Ent e = entCerca(x, y);
                if (e == null) { invalidate(); return; }
                Boceto.Restr r = new Boceto.Restr();
                r.e1 = e.id;
                if (e.tipo == Boceto.LINEA) r.tipo = Boceto.C_LARGO;
                else if (e.tipo == Boceto.CIRCULO) r.tipo = Boceto.C_DIAM;
                else if (e.tipo == Boceto.ARCO) r.tipo = Boceto.C_RADIO;
                else { invalidate(); return; }
                invalidate();
                if (oyente != null) oyente.pedirCota(r);
                return;
            }
        }
    }

    private double clicX, clicY;

    private void listoCambio() {
        invalidate();
        if (oyente != null) oyente.cambio();
    }

    /** Tocar con «Ver»: el número de una cota se edita; una línea o círculo se escoge. */
    private void tocar(float x, float y) {
        for (Object[] z : zonasCota) {
            RectF r = (RectF) z[0];
            if (r.contains(x, y) || (Math.abs(r.centerX() - x) < r.width() / 2 + dp(10) && Math.abs(r.centerY() - y) < r.height() / 2 + dp(10))) {
                if (oyente != null) oyente.editarCota((Boceto.Restr) z[1]);
                return;
            }
        }
        if (modo == MOVER) return;
        int k = puntoCerca(x, y, dp(14));
        Boceto.Ent e = entCerca(x, y);
        if (e == null && k < 0) { sel.clear(); selPunto = -1; }
        else if (e != null && (k < 0 || distA(e, x, y) < dp(6))) {
            Integer id = e.id;
            if (sel.contains(id)) sel.remove(id);
            else { if (sel.size() >= 2) sel.remove(0); sel.add(id); }
            selPunto = -1;
        } else { selPunto = k; sel.clear(); }
        invalidate();
        if (oyente != null) oyente.seleccion();
    }

    // ---------------- Dibujo ----------------

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(Color.WHITE);
        rejilla(c);
        zonasCota.clear();
        pintar(c, false);
        // lo que se está dibujando
        pLin.setColor(0xFFFF6F00);
        pLin.setStrokeWidth(dp(2));
        pLin.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(6), dp(4)}, 0));
        if (!Double.isNaN(fx)) {
            if (modo == LINEA && !clic.isEmpty()) {
                Boceto.Punto p = b.puntos.get(clic.get(clic.size() - 1));
                if (p != null) {
                    c.drawLine(sx(p.x), sy(p.y), sx(fx), sy(fy), pLin);
                    letrero(c, Formula.n(Math.hypot(fx - p.x, fy - p.y)) + " mm", sx(fx) + dp(12), sy(fy) - dp(30));
                }
            } else if (modo == RECT && !clic.isEmpty()) {
                c.drawRect(Math.min(sx(clicX), sx(fx)), Math.min(sy(clicY), sy(fy)), Math.max(sx(clicX), sx(fx)), Math.max(sy(clicY), sy(fy)), pLin);
                letrero(c, Formula.n(Math.abs(fx - clicX)) + " × " + Formula.n(Math.abs(fy - clicY)), sx(fx) + dp(12), sy(fy) - dp(30));
            } else if ((modo == CIRCULO || modo == ARCO) && !clic.isEmpty()) {
                Boceto.Punto p = b.puntos.get(clic.get(0));
                if (p != null) {
                    float r = (float) (Math.hypot(fx - p.x, fy - p.y) * esc);
                    if (modo == CIRCULO || clic.size() == 1) c.drawCircle(sx(p.x), sy(p.y), r, pLin);
                    c.drawLine(sx(p.x), sy(p.y), sx(fx), sy(fy), pLin);
                }
            }
            // la cruz donde va el dedo (corrida arriba para que el dedo no la tape)
            pPto.setColor(0xFFFF6F00);
            c.drawCircle(sx(fx), sy(fy), dp(4), pPto);
        }
        pLin.setPathEffect(null);
        if (cotaP1 >= 0) {
            Boceto.Punto p = b.puntos.get(cotaP1);
            if (p != null) { pPto.setColor(0xFFFF6F00); c.drawCircle(sx(p.x), sy(p.y), dp(8), pPto); }
        }
        for (Integer k : clic) {
            Boceto.Punto p = k == null || k < 0 ? null : b.puntos.get(k);
            if (p != null) { pPto.setColor(0xFFFF6F00); c.drawCircle(sx(p.x), sy(p.y), dp(5), pPto); }
        }
        // la ayuda de la herramienta
        pTxt.setTextSize(dp(12.5f));
        pTxt.setColor(0xFF37474F);
        pTxt.setFakeBoldText(false);
        dibujarTextoLargo(c, AYUDA[modo], dp(8), dp(16), getWidth() - dp(16));
    }

    private void letrero(Canvas c, String s, float x, float y) {
        pTxt.setTextSize(dp(13));
        pTxt.setFakeBoldText(true);
        float w = pTxt.measureText(s);
        pFondo.setColor(0xEEFFF3E0);
        c.drawRoundRect(x - dp(4), y - dp(15), x + w + dp(4), y + dp(5), dp(4), dp(4), pFondo);
        pTxt.setColor(0xFFE65100);
        c.drawText(s, x, y, pTxt);
    }

    private void dibujarTextoLargo(Canvas c, String s, float x, float y, float ancho) {
        String[] pal = s.split(" ");
        StringBuilder ln = new StringBuilder();
        for (String p : pal) {
            if (pTxt.measureText(ln + " " + p) > ancho && ln.length() > 0) { c.drawText(ln.toString(), x, y, pTxt); y += dp(15); ln.setLength(0); }
            if (ln.length() > 0) ln.append(' ');
            ln.append(p);
        }
        if (ln.length() > 0) c.drawText(ln.toString(), x, y, pTxt);
    }

    private void rejilla(Canvas c) {
        double paso = 10;
        while (paso * esc < dp(14)) paso *= 10;
        double x0m = mx(0), x1m = mx(getWidth()), y0m = my(getHeight()), y1m = my(0);
        for (int pase = 0; pase < 2; pase++) {
            double p = pase == 0 ? paso : paso * 10;
            pRej.setColor(pase == 0 ? 0xFFF1F3F5 : 0xFFDDE3E8);
            for (double x = Math.floor(x0m / p) * p; x <= x1m; x += p) c.drawLine(sx(x), 0, sx(x), getHeight(), pRej);
            for (double y = Math.floor(y0m / p) * p; y <= y1m; y += p) c.drawLine(0, sy(y), getWidth(), sy(y), pRej);
        }
        pRej.setColor(0xFFB0BEC5);
        c.drawLine(sx(0), 0, sx(0), getHeight(), pRej);
        c.drawLine(0, sy(0), getWidth(), sy(0), pRej);
    }

    /**
     * Dibuja el boceto. impreso = true: todo negro nítido (para el PDF), sin puntos ni marcas de amarre.
     */
    public void pintar(Canvas c, boolean impreso) {
        float grueso = impreso ? 1.6f : dp(2.2f);
        // entidades
        for (Boceto.Ent e : b.ents) {
            boolean escogida = !impreso && sel.contains(e.id);
            pLin.setColor(escogida ? 0xFFFF8F00 : Color.BLACK);
            pLin.setStrokeWidth(escogida ? grueso * 1.8f : grueso);
            Boceto.Punto a = b.puntos.get(e.a);
            if (a == null) continue;
            switch (e.tipo) {
                case Boceto.LINEA: {
                    Boceto.Punto q = b.puntos.get(e.b);
                    if (q != null) c.drawLine(sx(a.x), sy(a.y), sx(q.x), sy(q.y), pLin);
                    break;
                }
                case Boceto.CIRCULO:
                    c.drawCircle(sx(a.x), sy(a.y), (float) (e.r * esc), pLin);
                    break;
                case Boceto.ARCO: {
                    Boceto.Punto p1 = b.puntos.get(e.b), p2 = b.puntos.get(e.c);
                    if (p1 == null || p2 == null) break;
                    float r = (float) (e.r * esc);
                    double a1 = Math.toDegrees(Math.atan2(-(p1.y - a.y), p1.x - a.x));
                    double a2 = Math.toDegrees(Math.atan2(-(p2.y - a.y), p2.x - a.x));
                    // en la pantalla el eje Y va al revés: el arco va del inicio al final en contra del reloj (en mm)
                    double barrido = a1 - a2;
                    while (barrido <= 0) barrido += 360;
                    c.drawArc(new RectF(sx(a.x) - r, sy(a.y) - r, sx(a.x) + r, sy(a.y) + r), (float) a1, (float) -barrido, false, pLin);
                    break;
                }
                case Boceto.TEXTO: {
                    pTxt.setColor(escogida ? 0xFFFF8F00 : Color.BLACK);
                    pTxt.setFakeBoldText(false);
                    pTxt.setTextSize((float) Math.max(impreso ? 6 : dp(9), (e.r <= 0 ? 150 : e.r) * esc));
                    c.drawText(e.texto, sx(a.x), sy(a.y), pTxt);
                    break;
                }
            }
        }
        // cotas
        for (Boceto.Restr r : b.restr) if (r.esCota()) cota(c, r, impreso);
        if (impreso) return;
        // marcas de amarre
        pGlifo.setTextSize(dp(11));
        for (Boceto.Restr r : b.restr) {
            if (r.esCota()) continue;
            String g = r.tipo == Boceto.HORIZ ? "═" : r.tipo == Boceto.VERT ? "║" : r.tipo == Boceto.PERP ? "⊥" : r.tipo == Boceto.PARAL ? "∥"
                    : r.tipo == Boceto.IGUAL ? "=" : r.tipo == Boceto.FIJO ? "📌" : "";
            for (int en : new int[]{r.e1, r.e2}) {
                Boceto.Ent e = b.entPorId(en);
                if (e == null) continue;
                float[] m = medio(e);
                pFondo.setColor(0xDDE8F5E9);
                float w = pGlifo.measureText(g);
                float yy = m[1] - dp(7);
                c.drawRoundRect(m[0] + dp(5), yy - dp(11), m[0] + dp(9) + w, yy + dp(3), dp(3), dp(3), pFondo);
                pGlifo.setColor(0xFF2E7D32);
                c.drawText(g, m[0] + dp(7), yy, pGlifo);
            }
            if (r.tipo == Boceto.FIJO) {
                Boceto.Punto p = b.puntos.get(r.p1);
                if (p != null) { pGlifo.setColor(0xFF2E7D32); c.drawText("📌", sx(p.x) + dp(4), sy(p.y) - dp(4), pGlifo); }
            }
        }
        // puntos
        for (Boceto.Punto p : b.puntos.values()) {
            pPto.setColor(p.id == selPunto ? 0xFFFF8F00 : 0xFF1565C0);
            c.drawCircle(sx(p.x), sy(p.y), dp(p.id == selPunto ? 6 : 3.2f), pPto);
        }
    }

    private float[] medio(Boceto.Ent e) {
        Boceto.Punto a = b.puntos.get(e.a);
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto q = b.puntos.get(e.b);
            return new float[]{(sx(a.x) + sx(q.x)) / 2, (sy(a.y) + sy(q.y)) / 2};
        }
        if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) return new float[]{sx(a.x), (float) (sy(a.y) - e.r * esc)};
        return new float[]{sx(a.x), sy(a.y)};
    }

    /** Texto de una cota: el número, y si es fórmula también el nombre (ancho = 4000). */
    public String textoCota(Boceto.Restr r) {
        double v = b.medir(r);
        String num = r.tipo == Boceto.C_ANG ? Formula.n(v) + "°" : (r.tipo == Boceto.C_DIAM ? "Ø" : r.tipo == Boceto.C_RADIO ? "R" : "") + Formula.n(v);
        if (r.error != null) return "⚠ " + r.formula;
        boolean formula = Formula.numero(r.formula) == null && !r.formula.trim().isEmpty();
        return formula ? r.formula.trim() + " = " + num : num;
    }

    private void cota(Canvas c, Boceto.Restr r, boolean impreso) {
        int col = impreso ? Color.BLACK : r.error != null ? 0xFFD32F2F : 0xFF0D47A1;
        pCota.setColor(col);
        pCota.setStrokeWidth(impreso ? 0.8f : dp(1.1f));
        pTxt.setColor(col);
        pTxt.setFakeBoldText(true);
        pTxt.setTextSize(impreso ? 8.5f : dp(12.5f));
        float sep = impreso ? 14 : dp(26);
        String t = textoCota(r);
        float ax1, ay1, ax2, ay2;   // los dos extremos medidos (pantalla)
        switch (r.tipo) {
            case Boceto.C_LARGO: case Boceto.C_DIST: case Boceto.C_HORIZ: case Boceto.C_VERT: {
                Boceto.Punto p, q;
                if (r.tipo == Boceto.C_LARGO) {
                    Boceto.Ent e = b.entPorId(r.e1);
                    if (e == null) return;
                    p = b.puntos.get(e.a); q = b.puntos.get(e.b);
                } else { p = b.puntos.get(r.p1); q = b.puntos.get(r.p2); }
                if (p == null || q == null) return;
                ax1 = sx(p.x); ay1 = sy(p.y); ax2 = sx(q.x); ay2 = sy(q.y);
                float dx, dy;   // hacia dónde se corre la línea de cota
                float l1x, l1y, l2x, l2y;
                if (r.tipo == Boceto.C_HORIZ) {
                    float top = Math.min(ay1, ay2) - sep;
                    l1x = ax1; l1y = top; l2x = ax2; l2y = top;
                } else if (r.tipo == Boceto.C_VERT) {
                    float der = Math.max(ax1, ax2) + sep;
                    l1x = der; l1y = ay1; l2x = der; l2y = ay2;
                } else {
                    float vx = ax2 - ax1, vy = ay2 - ay1, l = (float) Math.hypot(vx, vy);
                    if (l < 1) return;
                    dx = -vy / l; dy = vx / l;
                    if (dy > 0 || (Math.abs(dy) < 0.01f && dx < 0)) { dx = -dx; dy = -dy; }   // la cota va arriba o a la derecha
                    l1x = ax1 + dx * sep; l1y = ay1 + dy * sep; l2x = ax2 + dx * sep; l2y = ay2 + dy * sep;
                }
                c.drawLine(ax1, ay1, l1x, l1y, pCota);
                c.drawLine(ax2, ay2, l2x, l2y, pCota);
                c.drawLine(l1x, l1y, l2x, l2y, pCota);
                flecha(c, l1x, l1y, l2x, l2y, impreso);
                flecha(c, l2x, l2y, l1x, l1y, impreso);
                textoEnLinea(c, t, l1x, l1y, l2x, l2y, r, impreso);
                break;
            }
            case Boceto.C_RADIO: case Boceto.C_DIAM: {
                Boceto.Ent e = b.entPorId(r.e1);
                if (e == null) return;
                Boceto.Punto ce = b.puntos.get(e.a);
                if (ce == null) return;
                float cx = sx(ce.x), cy = sy(ce.y), rr = (float) (e.r * esc);
                float ux = 0.7071f, uy = -0.7071f;
                float ex = cx + ux * rr, ey = cy + uy * rr;
                if (r.tipo == Boceto.C_DIAM) c.drawLine(cx - ux * rr, cy - uy * rr, ex, ey, pCota);
                else c.drawLine(cx, cy, ex, ey, pCota);
                flecha(c, cx, cy, ex, ey, impreso);
                float tx = ex + ux * sep * 0.6f, ty = ey + uy * sep * 0.6f;
                c.drawLine(ex, ey, tx, ty, pCota);
                c.drawLine(tx, ty, tx + pTxt.measureText(t) + dp(4), ty, pCota);
                c.drawText(t, tx + dp(2), ty - dp(3), pTxt);
                zona(t, tx + dp(2), ty - dp(3), r, impreso);
                break;
            }
            case Boceto.C_ANG: {
                Boceto.Ent a = b.entPorId(r.e1), q = b.entPorId(r.e2);
                if (a == null || q == null) return;
                float[] m1 = medio(a), m2 = medio(q);
                float tx = (m1[0] + m2[0]) / 2, ty = (m1[1] + m2[1]) / 2;
                pCota.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(3), dp(3)}, 0));
                c.drawLine(m1[0], m1[1], tx, ty, pCota);
                c.drawLine(m2[0], m2[1], tx, ty, pCota);
                pCota.setPathEffect(null);
                String s = "∠ " + t;
                c.drawText(s, tx - pTxt.measureText(s) / 2, ty - dp(4), pTxt);
                zona(s, tx - pTxt.measureText(s) / 2, ty - dp(4), r, impreso);
                break;
            }
        }
    }

    private void flecha(Canvas c, float x1, float y1, float x2, float y2, boolean impreso) {
        float vx = x2 - x1, vy = y2 - y1, l = (float) Math.hypot(vx, vy);
        if (l < 1) return;
        vx /= l; vy /= l;
        float L = impreso ? 5 : dp(8), A = impreso ? 1.8f : dp(3);
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x1 + vx * L - vy * A, y1 + vy * L + vx * A);
        p.lineTo(x1 + vx * L + vy * A, y1 + vy * L - vx * A);
        p.close();
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setColor(pCota.getColor());
        c.drawPath(p, f);
    }

    private void textoEnLinea(Canvas c, String t, float x1, float y1, float x2, float y2, Boceto.Restr r, boolean impreso) {
        float mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
        double ang = Math.toDegrees(Math.atan2(y2 - y1, x2 - x1));
        if (ang > 90) ang -= 180;
        if (ang < -90) ang += 180;
        float w = pTxt.measureText(t);
        c.save();
        c.rotate((float) ang, mx, my);
        if (!impreso) {
            pFondo.setColor(0xF2FFFFFF);
            c.drawRect(mx - w / 2 - dp(2), my - dp(16), mx + w / 2 + dp(2), my - dp(2), pFondo);
        }
        c.drawText(t, mx - w / 2, my - (impreso ? 2 : dp(4)), pTxt);
        c.restore();
        if (!impreso) zonasCota.add(new Object[]{new RectF(mx - w / 2 - dp(6), my - dp(22), mx + w / 2 + dp(6), my + dp(6)), r});
    }

    private void zona(String t, float x, float y, Boceto.Restr r, boolean impreso) {
        if (impreso) return;
        zonasCota.add(new Object[]{new RectF(x - dp(4), y - dp(18), x + pTxt.measureText(t) + dp(4), y + dp(6)), r});
    }

    /** Para el PDF: prepara la escala y dibuja en negro dentro de un rectángulo (puntos del papel). */
    public void imprimir(Canvas c, float izq, float arriba, float ancho, float alto) {
        double viejaEsc = esc;
        float vx = offX, vy = offY;
        double[] k = b.caja();
        double w = Math.max(100, k[2] - k[0]), h = Math.max(100, k[3] - k[1]);
        esc = Math.min((ancho - 60) / w, (alto - 60) / h);
        offX = (float) (izq + ancho / 2 - (k[0] + k[2]) / 2 * esc);
        offY = (float) (arriba + alto / 2 + (k[1] + k[3]) / 2 * esc);
        pintar(c, true);
        escalaImpresa = esc;
        esc = viejaEsc; offX = vx; offY = vy;
    }

    /** Escala del último PDF (puntos de papel por mm) para escribir «Escala 1:…». */
    public double escalaImpresa;
}
