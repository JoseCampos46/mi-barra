package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * El mini Excel de medidas: filas con nombre y fórmula. Lo usan el boceto 2D y las piezas 3D.
 * Además trae valores de solo leer: T1, T2… (largo de cada pieza), total (suma de largos) y piezas (cuántas hay).
 */
public final class Medidas {

    public static class Fila {
        public String nombre = "";
        public String formula = "";
        public Fila() {}
        public Fila(String n, String f) { nombre = n; formula = f; }
    }

    public final List<Fila> filas = new ArrayList<>();
    /** Valores de solo leer que pone la app (largos de las piezas, total…). */
    public final Map<String, Double> fijos = new LinkedHashMap<>();

    private final Map<String, Double> valores = new HashMap<>();
    private final Map<String, String> errores = new HashMap<>();

    public Fila buscar(String nombre) {
        String p = Formula.plano(nombre);
        for (Fila f : filas) if (Formula.plano(f.nombre).equals(p)) return f;
        return null;
    }

    /** Calcula todas las filas (en el orden que haga falta) y guarda valores y errores. */
    public void calcular() {
        valores.clear();
        errores.clear();
        for (Fila f : filas) valor(Formula.plano(f.nombre), new HashSet<>());
    }

    private Double valor(String p, Set<String> camino) {
        if (valores.containsKey(p)) return valores.get(p);
        if (errores.containsKey(p)) return null;
        Fila f = null;
        for (Fila x : filas) if (Formula.plano(x.nombre).equals(p)) { f = x; break; }
        if (f == null) {
            for (Map.Entry<String, Double> e : fijos.entrySet()) if (Formula.plano(e.getKey()).equals(p)) return e.getValue();
            return null;
        }
        if (!camino.add(p)) { errores.put(p, "se usa a sí misma (círculo)"); return null; }
        try {
            double r = Formula.calcular(f.formula, k -> {
                Double x = valor(k, camino);
                if (x == null && errores.containsKey(k)) throw new Formula.Error("«" + k + "» tiene error");
                return x;
            });
            valores.put(p, r);
            return r;
        } catch (Formula.Error e) {
            errores.putIfAbsent(p, e.getMessage());
            return null;
        } finally {
            camino.remove(p);
        }
    }

    public Double valorDe(String nombre) { return valores.get(Formula.plano(nombre)); }
    public String errorDe(String nombre) { return errores.get(Formula.plano(nombre)); }

    /** Calcula una fórmula suelta (de una cota o de una pieza) usando la tablita. */
    public double evaluar(String formula) {
        Double n = Formula.numero(formula);
        if (n != null) return n;
        return Formula.calcular(formula, k -> {
            Double x = valores.get(k);
            if (x != null) return x;
            for (Map.Entry<String, Double> e : fijos.entrySet()) if (Formula.plano(e.getKey()).equals(k)) return e.getValue();
            return null;
        });
    }

    /** Un nombre válido: letras, números y _, que empiece con letra, que no choque con T1, total… */
    public static String nombreValido(String n) {
        if (n == null) return null;
        String t = n.trim().replace(' ', '_');
        if (t.isEmpty() || !Character.isLetter(t.charAt(0))) return null;
        for (char c : t.toCharArray()) if (!Character.isLetterOrDigit(c) && c != '_') return null;
        String p = Formula.plano(t);
        if (p.matches("t\\d+") || p.equals("total") || p.equals("piezas") || p.equals("pi")) return null;
        return t;
    }

    public JSONArray json() throws Exception {
        JSONArray a = new JSONArray();
        for (Fila f : filas) a.put(new JSONArray().put(f.nombre).put(f.formula));
        return a;
    }

    public void deJson(JSONArray a) {
        filas.clear();
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONArray x = a.optJSONArray(i);
            if (x != null) filas.add(new Fila(x.optString(0), x.optString(1)));
            else {
                JSONObject o = a.optJSONObject(i);
                if (o != null) filas.add(new Fila(o.optString("n"), o.optString("f")));
            }
        }
    }
}
