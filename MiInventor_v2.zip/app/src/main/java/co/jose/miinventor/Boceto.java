package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * El boceto 2D paramétrico (en mm): puntos, líneas, círculos, arcos y textos, amarrados con restricciones y cotas.
 * Cuando cambia una medida, el solucionador mueve los puntos lo menos posible para que todo se cumpla.
 */
public final class Boceto {

    // ---------------- Las piezas del dibujo ----------------

    public static final int LINEA = 0, CIRCULO = 1, ARCO = 2, TEXTO = 3;

    public static class Punto {
        public int id;
        public double x, y;
        public boolean fijo;
        Punto(int id, double x, double y) { this.id = id; this.x = x; this.y = y; }
    }

    public static class Ent {
        public int id, tipo;
        public int a = -1, b = -1, c = -1;   // línea: a-b · círculo: centro a · arco: centro a, inicio b, fin c · texto: punto a
        public double r;                     // radio (círculo y arco) o altura de la letra (texto)
        public String texto = "";
    }

    // ---------------- Restricciones y cotas ----------------

    public static final int HORIZ = 0, VERT = 1, PERP = 2, PARAL = 3, IGUAL = 4, FIJO = 5,
            C_LARGO = 10, C_HORIZ = 11, C_VERT = 12, C_DIST = 13, C_RADIO = 14, C_DIAM = 15, C_ANG = 16;

    public static final String[] NOMBRES = new String[17];
    static {
        NOMBRES[HORIZ] = "Horizontal"; NOMBRES[VERT] = "Vertical"; NOMBRES[PERP] = "Perpendicular (90°)";
        NOMBRES[PARAL] = "Paralela"; NOMBRES[IGUAL] = "Igual medida"; NOMBRES[FIJO] = "Punto fijo";
        NOMBRES[C_LARGO] = "Cota de largo"; NOMBRES[C_HORIZ] = "Cota horizontal"; NOMBRES[C_VERT] = "Cota vertical";
        NOMBRES[C_DIST] = "Cota alineada"; NOMBRES[C_RADIO] = "Cota de radio"; NOMBRES[C_DIAM] = "Cota de diámetro";
        NOMBRES[C_ANG] = "Cota de ángulo";
    }

    public static class Restr {
        public int tipo;
        public int e1 = -1, e2 = -1, p1 = -1, p2 = -1;
        public String formula = "";    // solo las cotas: el valor o la fórmula de la tablita
        public double off = Double.NaN; // dónde se dibuja la cota (mm, hacia un lado)
        public String error;            // si la fórmula tiene error
        public boolean esCota() { return tipo >= 10; }
    }

    public final Map<Integer, Punto> puntos = new LinkedHashMap<>();
    public final List<Ent> ents = new ArrayList<>();
    public final List<Restr> restr = new ArrayList<>();
    private int sigId = 1;

    public int nuevoId() { return sigId++; }

    public Punto punto(double x, double y) {
        Punto p = new Punto(nuevoId(), x, y);
        puntos.put(p.id, p);
        return p;
    }

    public Ent ent(int tipo) {
        Ent e = new Ent();
        e.id = nuevoId();
        e.tipo = tipo;
        ents.add(e);
        return e;
    }

    public Ent entPorId(int id) {
        for (Ent e : ents) if (e.id == id) return e;
        return null;
    }

    public Ent linea(Punto a, Punto b) {
        Ent e = ent(LINEA);
        e.a = a.id; e.b = b.id;
        return e;
    }

    public Restr restriccion(int tipo, int e1, int e2, int p1, int p2, String formula) {
        Restr r = new Restr();
        r.tipo = tipo; r.e1 = e1; r.e2 = e2; r.p1 = p1; r.p2 = p2;
        r.formula = formula == null ? "" : formula;
        restr.add(r);
        return r;
    }

    public boolean vacio() { return ents.isEmpty(); }

    /** Borra una entidad, sus restricciones y los puntos que queden sueltos. */
    public void borrar(Ent e) {
        ents.remove(e);
        restr.removeIf(r -> r.e1 == e.id || r.e2 == e.id);
        limpiarPuntos();
    }

    public void limpiarPuntos() {
        java.util.Set<Integer> usados = new java.util.HashSet<>();
        for (Ent e : ents) { usados.add(e.a); usados.add(e.b); usados.add(e.c); }
        puntos.keySet().removeIf(k -> !usados.contains(k));
        restr.removeIf(r -> (r.p1 >= 0 && !puntos.containsKey(r.p1)) || (r.p2 >= 0 && !puntos.containsKey(r.p2)));
    }

    // ---------------- Medidas que se ven ----------------

    public double largo(Ent e) {
        Punto a = puntos.get(e.a), b = puntos.get(e.b);
        return Math.hypot(b.x - a.x, b.y - a.y);
    }

    /** Valor actual de una cota (lo que mide hoy el dibujo). */
    public double medir(Restr r) {
        switch (r.tipo) {
            case C_LARGO: { Ent e = entPorId(r.e1); return e == null ? 0 : largo(e); }
            case C_HORIZ: { Punto a = puntos.get(r.p1), b = puntos.get(r.p2); return Math.abs(b.x - a.x); }
            case C_VERT: { Punto a = puntos.get(r.p1), b = puntos.get(r.p2); return Math.abs(b.y - a.y); }
            case C_DIST: { Punto a = puntos.get(r.p1), b = puntos.get(r.p2); return Math.hypot(b.x - a.x, b.y - a.y); }
            case C_RADIO: { Ent e = entPorId(r.e1); return e == null ? 0 : e.r; }
            case C_DIAM: { Ent e = entPorId(r.e1); return e == null ? 0 : 2 * e.r; }
            case C_ANG: { Ent a = entPorId(r.e1), b = entPorId(r.e2); return a == null || b == null ? 0 : Math.abs(Math.toDegrees(angulo(a, b, null))); }
        }
        return 0;
    }

    /** Ángulo con signo entre dos líneas (radianes), leyendo los puntos de X si viene. */
    private double angulo(Ent a, Ent b, double[] X) {
        double[] u = vec(a, X), v = vec(b, X);
        return Math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]);
    }

    // ---------------- El solucionador ----------------

    private Map<Integer, Integer> idx;   // punto → posición de su x en X (-1 si está fijo)
    private Map<Integer, Integer> idxR;  // círculo/arco → posición de su radio en X
    private int arrastrado = -1;

    private double px(int id, double[] X) { Integer k = idx.get(id); Punto p = puntos.get(id); return k == null || k < 0 ? p.x : X[k]; }
    private double py(int id, double[] X) { Integer k = idx.get(id); Punto p = puntos.get(id); return k == null || k < 0 ? p.y : X[k + 1]; }
    private double rr(Ent e, double[] X) { Integer k = idxR.get(e.id); return k == null ? e.r : X[k]; }

    private double[] vec(Ent e, double[] X) {
        if (X == null) { Punto a = puntos.get(e.a), b = puntos.get(e.b); return new double[]{b.x - a.x, b.y - a.y}; }
        return new double[]{px(e.b, X) - px(e.a, X), py(e.b, X) - py(e.a, X)};
    }

    private interface Res { double f(double[] X); }

    private static class Ecu {
        Res f;
        int[] vars;
        Restr de;
    }

    private void varsPunto(List<Integer> l, int id) { Integer k = idx.get(id); if (k != null && k >= 0) { l.add(k); l.add(k + 1); } }

    private int[] lista(List<Integer> l) { int[] r = new int[l.size()]; for (int i = 0; i < r.length; i++) r[i] = l.get(i); return r; }

    private Ecu ecu(Restr de, Res f, int[] pts, int[] ents) {
        Ecu q = new Ecu();
        q.f = f;
        q.de = de;
        List<Integer> l = new ArrayList<>();
        for (int p : pts) varsPunto(l, p);
        for (int e : ents) { Integer k = idxR.get(e); if (k != null) l.add(k); }
        q.vars = lista(l);
        return q;
    }

    /** Arma las ecuaciones. Las cotas toman su valor de la tablita de medidas. */
    private List<Ecu> ecuaciones(Medidas m) {
        List<Ecu> eq = new ArrayList<>();
        for (Ent e : ents) {
            if (e.tipo != ARCO) continue;
            final Ent a = e;
            eq.add(ecu(null, X -> Math.hypot(px(a.b, X) - px(a.a, X), py(a.b, X) - py(a.a, X)) - rr(a, X), new int[]{a.a, a.b}, new int[]{a.id}));
            eq.add(ecu(null, X -> Math.hypot(px(a.c, X) - px(a.a, X), py(a.c, X) - py(a.a, X)) - rr(a, X), new int[]{a.a, a.c}, new int[]{a.id}));
        }
        for (Restr r : restr) {
            r.error = null;
            double val = 0;
            if (r.esCota()) {
                try {
                    Double num = Formula.numero(r.formula);
                    val = m != null ? m.evaluar(r.formula) : num != null ? num : Double.NaN;
                } catch (Exception ex) {
                    r.error = ex.getMessage() == null ? "error" : ex.getMessage();
                    continue;
                }
                if (Double.isNaN(val)) { r.error = "error"; continue; }
                if (val < 0 && r.tipo != C_ANG) { r.error = "medida negativa"; continue; }
            }
            final double v = val;
            final Restr rf = r;
            Ent e1 = entPorId(r.e1), e2 = entPorId(r.e2);
            switch (r.tipo) {
                case HORIZ:
                    if (e1 == null) break;
                    { final Ent a = e1; eq.add(ecu(r, X -> py(a.b, X) - py(a.a, X), new int[]{a.a, a.b}, new int[0])); }
                    break;
                case VERT:
                    if (e1 == null) break;
                    { final Ent a = e1; eq.add(ecu(r, X -> px(a.b, X) - px(a.a, X), new int[]{a.a, a.b}, new int[0])); }
                    break;
                case PERP: case PARAL:
                    if (e1 == null || e2 == null) break;
                    {
                        final Ent a = e1, b = e2;
                        final boolean perp = r.tipo == PERP;
                        eq.add(ecu(r, X -> {
                            double[] u = vec(a, X), w = vec(b, X);
                            double lu = Math.hypot(u[0], u[1]), lw = Math.hypot(w[0], w[1]);
                            if (lu < 1e-9 || lw < 1e-9) return 0;
                            double k = perp ? (u[0] * w[0] + u[1] * w[1]) : (u[0] * w[1] - u[1] * w[0]);
                            return k / (lu * lw) * (lu + lw) / 2;
                        }, new int[]{a.a, a.b, b.a, b.b}, new int[0]));
                    }
                    break;
                case IGUAL:
                    if (e1 == null || e2 == null) break;
                    {
                        final Ent a = e1, b = e2;
                        if (a.tipo == LINEA && b.tipo == LINEA)
                            eq.add(ecu(r, X -> { double[] u = vec(a, X), w = vec(b, X); return Math.hypot(u[0], u[1]) - Math.hypot(w[0], w[1]); },
                                    new int[]{a.a, a.b, b.a, b.b}, new int[0]));
                        else if (a.tipo != LINEA && b.tipo != LINEA && a.tipo != TEXTO && b.tipo != TEXTO)
                            eq.add(ecu(r, X -> rr(a, X) - rr(b, X), new int[0], new int[]{a.id, b.id}));
                    }
                    break;
                case C_LARGO:
                    if (e1 == null) break;
                    { final Ent a = e1; eq.add(ecu(r, X -> { double[] u = vec(a, X); return Math.hypot(u[0], u[1]) - v; }, new int[]{a.a, a.b}, new int[0])); }
                    break;
                case C_HORIZ: case C_VERT: {
                    final int p1 = r.p1, p2 = r.p2;
                    final boolean hz = r.tipo == C_HORIZ;
                    Punto a = puntos.get(p1), b = puntos.get(p2);
                    if (a == null || b == null) break;
                    double actual = hz ? b.x - a.x : b.y - a.y;
                    final double s = actual < 0 ? -1 : 1;   // se respeta para qué lado está
                    eq.add(ecu(r, X -> s * (hz ? px(p2, X) - px(p1, X) : py(p2, X) - py(p1, X)) - v, new int[]{p1, p2}, new int[0]));
                    break;
                }
                case C_DIST: {
                    final int p1 = r.p1, p2 = r.p2;
                    if (!puntos.containsKey(p1) || !puntos.containsKey(p2)) break;
                    eq.add(ecu(r, X -> Math.hypot(px(p2, X) - px(p1, X), py(p2, X) - py(p1, X)) - v, new int[]{p1, p2}, new int[0]));
                    break;
                }
                case C_RADIO: case C_DIAM:
                    if (e1 == null) break;
                    { final Ent a = e1; final double rad = r.tipo == C_DIAM ? v / 2 : v; eq.add(ecu(r, X -> rr(a, X) - rad, new int[0], new int[]{a.id})); }
                    break;
                case C_ANG:
                    if (e1 == null || e2 == null) break;
                    {
                        final Ent a = e1, b = e2;
                        double act = angulo(a, b, null);
                        final double objetivo = Math.toRadians(v) * (act < 0 ? -1 : 1);
                        eq.add(ecu(r, X -> {
                            double d = angulo(a, b, X) - objetivo;
                            while (d > Math.PI) d -= 2 * Math.PI;
                            while (d < -Math.PI) d += 2 * Math.PI;
                            double[] u = vec(a, X), w = vec(b, X);
                            return d * (Math.hypot(u[0], u[1]) + Math.hypot(w[0], w[1])) / 2;
                        }, new int[]{a.a, a.b, b.a, b.b}, new int[0]));
                    }
                    break;
            }
        }
        return eq;
    }

    /** Qué tan lejos quedó de cumplirse todo (mm). */
    public double ultimoError;

    /**
     * Mueve los puntos para que se cumplan todas las restricciones.
     * fijoTemporal: un punto que el dedo está arrastrando (se queda donde está el dedo).
     * Devuelve true si todo cuadró.
     */
    public boolean resolver(Medidas m, int fijoTemporal) {
        arrastrado = fijoTemporal;
        idx = new HashMap<>();
        idxR = new HashMap<>();
        java.util.Set<Integer> fijos = new java.util.HashSet<>();
        for (Restr r : restr) if (r.tipo == FIJO && r.p1 >= 0) fijos.add(r.p1);
        int n = 0;
        for (Punto p : puntos.values()) {
            if (p.fijo || fijos.contains(p.id) || p.id == arrastrado) { idx.put(p.id, -1); continue; }
            idx.put(p.id, n);
            n += 2;
        }
        for (Ent e : ents) if (e.tipo == CIRCULO || e.tipo == ARCO) { idxR.put(e.id, n); n++; }
        double[] X = new double[n];
        for (Punto p : puntos.values()) { Integer k = idx.get(p.id); if (k >= 0) { X[k] = p.x; X[k + 1] = p.y; } }
        for (Ent e : ents) { Integer k = idxR.get(e.id); if (k != null) X[k] = e.r; }
        List<Ecu> eq = ecuaciones(m);
        if (eq.isEmpty() || n == 0) { ultimoError = 0; return true; }

        double lambda = 1e-3;
        double err = error(eq, X);
        for (int it = 0; it < 80 && err > 1e-8; it++) {
            int M = eq.size();
            double[] res = new double[M];
            for (int i = 0; i < M; i++) res[i] = eq.get(i).f.f(X);
            // J^T J y J^T r, con derivadas numéricas solo de las variables de cada ecuación
            double[][] A = new double[n][n];
            double[] g = new double[n];
            for (int i = 0; i < M; i++) {
                Ecu q = eq.get(i);
                int[] vs = q.vars;
                double[] d = new double[vs.length];
                for (int k = 0; k < vs.length; k++) {
                    double old = X[vs[k]];
                    double h = 1e-6 * Math.max(1, Math.abs(old));
                    X[vs[k]] = old + h;
                    double f1 = q.f.f(X);
                    X[vs[k]] = old - h;
                    double f0 = q.f.f(X);
                    X[vs[k]] = old;
                    d[k] = (f1 - f0) / (2 * h);
                }
                for (int a = 0; a < vs.length; a++) {
                    g[vs[a]] += d[a] * res[i];
                    for (int b = 0; b < vs.length; b++) A[vs[a]][vs[b]] += d[a] * d[b];
                }
            }
            boolean mejoro = false;
            for (int tries = 0; tries < 8; tries++) {
                double[][] B = new double[n][];
                for (int i = 0; i < n; i++) B[i] = A[i].clone();
                for (int i = 0; i < n; i++) B[i][i] += lambda * (A[i][i] + 1e-6) + 1e-9;
                double[] paso = resolverLineal(B, g);
                if (paso == null) { lambda *= 10; continue; }
                double[] Y = X.clone();
                for (int i = 0; i < n; i++) Y[i] -= paso[i];
                double e2 = error(eq, Y);
                if (e2 < err) { X = Y; err = e2; lambda = Math.max(1e-9, lambda / 4); mejoro = true; break; }
                lambda *= 6;
            }
            if (!mejoro) break;
        }
        // devolver los resultados
        for (Punto p : puntos.values()) { Integer k = idx.get(p.id); if (k >= 0) { p.x = X[k]; p.y = X[k + 1]; } }
        for (Ent e : ents) { Integer k = idxR.get(e.id); if (k != null) e.r = Math.abs(X[k]); }
        double peor = 0;
        for (Ecu q : eq) peor = Math.max(peor, Math.abs(q.f.f(X)));
        ultimoError = peor;
        arrastrado = -1;
        return peor < 0.05;
    }

    private static double error(List<Ecu> eq, double[] X) {
        double s = 0;
        for (Ecu q : eq) { double v = q.f.f(X); s += v * v; }
        return s;
    }

    /** Gauss con pivote. */
    private static double[] resolverLineal(double[][] A, double[] b) {
        int n = b.length;
        double[] x = b.clone();
        for (int c = 0; c < n; c++) {
            int p = c;
            for (int r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
            if (Math.abs(A[p][c]) < 1e-14) return null;
            double[] t = A[c]; A[c] = A[p]; A[p] = t;
            double tb = x[c]; x[c] = x[p]; x[p] = tb;
            for (int r = c + 1; r < n; r++) {
                double f = A[r][c] / A[c][c];
                if (f == 0) continue;
                for (int k = c; k < n; k++) A[r][k] -= f * A[c][k];
                x[r] -= f * x[c];
            }
        }
        for (int c = n - 1; c >= 0; c--) {
            double s = x[c];
            for (int k = c + 1; k < n; k++) s -= A[c][k] * x[k];
            x[c] = s / A[c][c];
        }
        return x;
    }

    // ---------------- Copia (para deshacer) y archivo liviano ----------------

    private static double r1(double v) { return Math.round(v * 10) / 10.0; }

    public JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        JSONArray p = new JSONArray();
        for (Punto q : puntos.values()) {
            JSONArray x = new JSONArray().put(q.id).put(r1(q.x)).put(r1(q.y));
            if (q.fijo) x.put(1);
            p.put(x);
        }
        o.put("p", p);
        JSONArray e = new JSONArray();
        for (Ent q : ents) {
            JSONArray x = new JSONArray().put(q.id).put(q.tipo).put(q.a).put(q.b).put(q.c).put(r1(q.r));
            if (q.tipo == TEXTO) x.put(q.texto);
            e.put(x);
        }
        o.put("e", e);
        JSONArray r = new JSONArray();
        for (Restr q : restr) {
            JSONArray x = new JSONArray().put(q.tipo).put(q.e1).put(q.e2).put(q.p1).put(q.p2);
            if (q.esCota()) { x.put(q.formula); x.put(Double.isNaN(q.off) ? 0 : r1(q.off)); }
            r.put(x);
        }
        o.put("r", r);
        o.put("n", sigId);
        return o;
    }

    public static Boceto deJson(JSONObject o) {
        Boceto b = new Boceto();
        if (o == null) return b;
        JSONArray p = o.optJSONArray("p");
        if (p != null) for (int i = 0; i < p.length(); i++) {
            JSONArray x = p.optJSONArray(i);
            Punto q = new Punto(x.optInt(0), x.optDouble(1), x.optDouble(2));
            q.fijo = x.optInt(3, 0) == 1;
            b.puntos.put(q.id, q);
        }
        JSONArray e = o.optJSONArray("e");
        if (e != null) for (int i = 0; i < e.length(); i++) {
            JSONArray x = e.optJSONArray(i);
            Ent q = new Ent();
            q.id = x.optInt(0); q.tipo = x.optInt(1); q.a = x.optInt(2); q.b = x.optInt(3); q.c = x.optInt(4);
            q.r = x.optDouble(5, 0); q.texto = x.optString(6, "");
            b.ents.add(q);
        }
        JSONArray r = o.optJSONArray("r");
        if (r != null) for (int i = 0; i < r.length(); i++) {
            JSONArray x = r.optJSONArray(i);
            Restr q = new Restr();
            q.tipo = x.optInt(0); q.e1 = x.optInt(1); q.e2 = x.optInt(2); q.p1 = x.optInt(3); q.p2 = x.optInt(4);
            q.formula = x.optString(5, "");
            q.off = x.optDouble(6, 0);
            if (q.off == 0) q.off = Double.NaN;
            b.restr.add(q);
        }
        int maxId = 0;
        for (Integer k : b.puntos.keySet()) maxId = Math.max(maxId, k);
        for (Ent q : b.ents) maxId = Math.max(maxId, q.id);
        b.sigId = Math.max(o.optInt("n", 1), maxId + 1);
        return b;
    }

    public Boceto copia() {
        try { return deJson(json()); } catch (Exception e) { return new Boceto(); }
    }

    /** Las esquinas de todo el dibujo (mm): {minX, minY, maxX, maxY}. */
    public double[] caja() {
        double[] c = {Double.MAX_VALUE, Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE};
        for (Punto p : puntos.values()) { c[0] = Math.min(c[0], p.x); c[1] = Math.min(c[1], p.y); c[2] = Math.max(c[2], p.x); c[3] = Math.max(c[3], p.y); }
        for (Ent e : ents) if (e.tipo == CIRCULO || e.tipo == ARCO) {
            Punto q = puntos.get(e.a);
            if (q == null) continue;
            c[0] = Math.min(c[0], q.x - e.r); c[1] = Math.min(c[1], q.y - e.r); c[2] = Math.max(c[2], q.x + e.r); c[3] = Math.max(c[3], q.y + e.r);
        }
        if (c[0] > c[2]) return new double[]{0, 0, 3000, 2000};
        return c;
    }
}
