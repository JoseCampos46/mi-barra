package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Un tubo, ángulo o platina, con su largo de corte, hacia dónde va, a qué pieza se une y sus huecos. */
public class Pieza {

    public static final String[] TIPOS = {"Tubo cuadrado", "Tubo rectangular", "Tubo redondo", "Ángulo", "Platina"};
    public static final String[] DIRS = {"→ A lo ancho (X)", "↗ Hacia el fondo (Y)", "↑ Para arriba (Z)",
            "← A lo ancho, al revés (−X)", "↙ Hacia el frente (−Y)", "↓ Para abajo (−Z)"};
    public static final String[] CARAS = {"Arriba", "Abajo", "Lado", "Otro lado"};
    public static final String[] HUECOS = {"Redondo", "Cuadrado", "Ranura"};

    private static final float P = 25.4f;

    /** Medidas comunes: nombre, ancho, alto, espesor (mm). */
    public static final Object[][][] MEDIDAS = {
            {{"3/4\"", .75f * P, .75f * P, 1.2f}, {"1\"", P, P, 1.2f}, {"1 1/4\"", 1.25f * P, 1.25f * P, 1.2f},
                    {"1 1/2\"", 1.5f * P, 1.5f * P, 1.5f}, {"2\"", 2 * P, 2 * P, 1.5f}, {"2 1/2\"", 2.5f * P, 2.5f * P, 2f},
                    {"3\"", 3 * P, 3 * P, 2f}, {"4\"", 4 * P, 4 * P, 2.5f}},
            {{"1\" x 2\"", P, 2 * P, 1.2f}, {"1\" x 3\"", P, 3 * P, 1.5f}, {"1 1/2\" x 3\"", 1.5f * P, 3 * P, 1.5f},
                    {"2\" x 3\"", 2 * P, 3 * P, 1.5f}, {"2\" x 4\"", 2 * P, 4 * P, 2f}, {"3\" x 1 1/2\"", 3 * P, 1.5f * P, 1.5f}},
            {{"1/2\"", .5f * P, .5f * P, 1.2f}, {"3/4\"", .75f * P, .75f * P, 1.2f}, {"1\"", P, P, 1.2f},
                    {"1 1/4\"", 1.25f * P, 1.25f * P, 1.5f}, {"1 1/2\"", 1.5f * P, 1.5f * P, 1.5f}, {"2\"", 2 * P, 2 * P, 2f}},
            {{"1\" x 1/8\"", P, P, P / 8}, {"1 1/4\" x 1/8\"", 1.25f * P, 1.25f * P, P / 8}, {"1 1/2\" x 1/8\"", 1.5f * P, 1.5f * P, P / 8},
                    {"1 1/2\" x 3/16\"", 1.5f * P, 1.5f * P, 3 * P / 16}, {"2\" x 3/16\"", 2 * P, 2 * P, 3 * P / 16}, {"2\" x 1/4\"", 2 * P, 2 * P, P / 4}},
            {{"1\" x 1/8\"", P, P / 8, P / 8}, {"1 1/2\" x 1/8\"", 1.5f * P, P / 8, P / 8}, {"1 1/2\" x 3/16\"", 1.5f * P, 3 * P / 16, 3 * P / 16},
                    {"2\" x 3/16\"", 2 * P, 3 * P / 16, 3 * P / 16}, {"2\" x 1/4\"", 2 * P, P / 4, P / 4}, {"3\" x 1/4\"", 3 * P, P / 4, P / 4}}};

    public static class Hueco {
        public int tipo;      // 0 redondo, 1 cuadrado, 2 ranura
        public float d1 = 10; // diámetro, lado o largo de la ranura
        public float d2 = 8;  // ancho de la ranura
        public float pos = 50; // a cuántos mm del inicio de la pieza
        public int cara;

        public String texto() {
            String m = tipo == 0 ? "Ø" + n(d1) : tipo == 1 ? n(d1) + "x" + n(d1) : "ranura " + n(d1) + "x" + n(d2);
            return "hueco " + m + " a " + n(pos) + " mm (" + CARAS[cara].toLowerCase() + ")";
        }
    }

    public int id;
    public int tipo;
    public String medida = "2\"";
    public float a = 50.8f, b = 50.8f, t = 1.5f;
    public String calibre = "Cal 18";
    public float largo = 1000;
    public int dir;
    public float incl;
    public int padre = -1;    // -1: en el punto 0
    public int punto = 1;     // 0 inicio del padre, 1 fin del padre, 2 a una medida
    public float aMm;
    public float sep;
    public float cx, cy, cz;  // corrimiento
    public float corteIni, corteFin; // grados (0 = recto)
    public int giro;          // giro de la sección: 0, 1, 2, 3 (× 90°)
    public final List<Hueco> huecos = new ArrayList<>();
    /** Versión 2: fórmulas de la tablita para largo, sep, aMm, cx, cy, cz (si no hay, el número queda fijo). */
    public final Map<String, String> f = new java.util.HashMap<>();

    public static final String[] CAMPOS = {"largo", "sep", "aMm", "cx", "cy", "cz"};

    public float campo(String k) {
        switch (k) {
            case "largo": return largo; case "sep": return sep; case "aMm": return aMm;
            case "cx": return cx; case "cy": return cy; default: return cz;
        }
    }

    public void ponerCampo(String k, float v) {
        switch (k) {
            case "largo": largo = v; break; case "sep": sep = v; break; case "aMm": aMm = v; break;
            case "cx": cx = v; break; case "cy": cy = v; break; default: cz = v;
        }
    }

    /** Recalcula los campos que tienen fórmula. Devuelve el primer error (o null). */
    public String aplicarFormulas(Medidas m) {
        String err = null;
        for (String k : CAMPOS) {
            String fo = f.get(k);
            if (fo == null || fo.trim().isEmpty()) continue;
            try {
                float v = (float) m.evaluar(fo);
                if (k.equals("largo") && v <= 0) throw new Formula.Error("el largo da " + Formula.n(v));
                ponerCampo(k, v);
            } catch (Exception e) {
                if (err == null) err = nombre() + " (" + k + "): " + e.getMessage();
            }
        }
        return err;
    }

    // ---------------- Versión 2: girar 90° (la pieza y todo lo que tiene pegado) ----------------

    /** eje 0: alrededor de Z (en el piso) · 1: alrededor de X · 2: alrededor de Y. */
    public static int girarDir(int dir, int eje) {
        int[][] ciclo = {{0, 1, 3, 4}, {1, 2, 4, 5}, {2, 0, 5, 3}};
        int[] c = ciclo[eje];
        for (int i = 0; i < 4; i++) if (c[i] == dir) return c[(i + 1) % 4];
        return dir;
    }

    public static float[] girarVec(float[] v, int eje) {
        if (eje == 0) return new float[]{-v[1], v[0], v[2]};
        if (eje == 1) return new float[]{v[0], -v[2], v[1]};
        return new float[]{v[2], v[1], -v[0]};
    }

    public String nombre() { return "T" + id; }

    /** Cómo se pide en la ferretería: así se agrupan en la lista de corte. */
    public String referencia() {
        String r = TIPOS[tipo] + " " + medida;
        if (tipo <= 2 && calibre != null && !calibre.trim().isEmpty()) r += " " + calibre.trim();
        return r;
    }

    public static String n(float v) {
        if (Math.abs(v - Math.round(v)) < 0.05f) return String.valueOf(Math.round(v));
        return String.format(java.util.Locale.US, "%.1f", v);
    }

    // ---------------- Geometría ----------------

    public float[] direccion() {
        float[][] base = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {-1, 0, 0}, {0, -1, 0}, {0, 0, -1}};
        float[] h = base[Math.max(0, Math.min(5, dir))];
        double r = Math.toRadians(incl);
        float c = (float) Math.cos(r), s = (float) Math.sin(r);
        if (dir == 2 || dir == 5) return new float[]{s, 0, h[2] * c};      // vertical que se inclina hacia X
        return new float[]{h[0] * c, h[1] * c, s};                        // horizontal que se inclina para arriba
    }

    /** Dónde arranca la pieza (mm), siguiendo la cadena de piezas a las que va unida. */
    public float[] inicio(Map<Integer, Pieza> todas, int profundidad) {
        float[] d = direccion();
        float[] base = {0, 0, 0};
        Pieza pp = padre >= 0 ? todas.get(padre) : null;
        if (pp != null && profundidad < 60 && pp != this) {
            float[] ps = pp.inicio(todas, profundidad + 1);
            float[] pd = pp.direccion();
            float cuanto = punto == 0 ? 0 : punto == 1 ? pp.largo : aMm;
            base = new float[]{ps[0] + pd[0] * cuanto, ps[1] + pd[1] * cuanto, ps[2] + pd[2] * cuanto};
        }
        return new float[]{base[0] + d[0] * sep + cx, base[1] + d[1] * sep + cy, base[2] + d[2] * sep + cz};
    }

    // ---------------- Guardar ----------------

    public JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("tipo", tipo); o.put("medida", medida);
        o.put("a", a); o.put("b", b); o.put("t", t); o.put("calibre", calibre);
        o.put("largo", largo); o.put("dir", dir); o.put("incl", incl);
        o.put("padre", padre); o.put("punto", punto); o.put("aMm", aMm); o.put("sep", sep);
        o.put("cx", cx); o.put("cy", cy); o.put("cz", cz);
        o.put("corteIni", corteIni); o.put("corteFin", corteFin); o.put("giro", giro);
        JSONArray hs = new JSONArray();
        for (Hueco h : huecos) {
            JSONObject x = new JSONObject();
            x.put("tipo", h.tipo); x.put("d1", h.d1); x.put("d2", h.d2); x.put("pos", h.pos); x.put("cara", h.cara);
            hs.put(x);
        }
        o.put("huecos", hs);
        if (!f.isEmpty()) o.put("f", new JSONObject(f));
        return o;
    }

    public static Pieza deJson(JSONObject o) {
        Pieza p = new Pieza();
        p.id = o.optInt("id"); p.tipo = o.optInt("tipo"); p.medida = o.optString("medida", "");
        p.a = (float) o.optDouble("a", 50); p.b = (float) o.optDouble("b", 50); p.t = (float) o.optDouble("t", 1.5);
        p.calibre = o.optString("calibre", ""); p.largo = (float) o.optDouble("largo", 1000);
        p.dir = o.optInt("dir"); p.incl = (float) o.optDouble("incl", 0);
        p.padre = o.optInt("padre", -1); p.punto = o.optInt("punto", 1);
        p.aMm = (float) o.optDouble("aMm", 0); p.sep = (float) o.optDouble("sep", 0);
        p.cx = (float) o.optDouble("cx", 0); p.cy = (float) o.optDouble("cy", 0); p.cz = (float) o.optDouble("cz", 0);
        p.corteIni = (float) o.optDouble("corteIni", 0); p.corteFin = (float) o.optDouble("corteFin", 0);
        p.giro = o.optInt("giro");
        JSONArray hs = o.optJSONArray("huecos");
        if (hs != null) for (int i = 0; i < hs.length(); i++) {
            JSONObject x = hs.optJSONObject(i);
            if (x == null) continue;
            Hueco h = new Hueco();
            h.tipo = x.optInt("tipo"); h.d1 = (float) x.optDouble("d1", 10); h.d2 = (float) x.optDouble("d2", 8);
            h.pos = (float) x.optDouble("pos", 50); h.cara = x.optInt("cara");
            p.huecos.add(h);
        }
        JSONObject fo = o.optJSONObject("f");
        if (fo != null) for (java.util.Iterator<String> it = fo.keys(); it.hasNext(); ) { String k = it.next(); p.f.put(k, fo.optString(k)); }
        return p;
    }

    public Pieza copia(int nuevoId) {
        try {
            Pieza p = deJson(json());
            p.id = nuevoId;
            return p;
        } catch (Exception e) { return null; }
    }
}
