package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Mi Inventor 2: boceto 2D paramétrico (en mm), estructuras 3D en tubo, ángulo y platina,
 * y un mini Excel de medidas que manda en los dos. Lista de corte para comprar barras de 6 m.
 */
public class InventorActivity extends Activity {

    private static final String ULTIMO = "_ultimo";
    private static final float BARRA = 6000f, DISCO = 3f;   // barra de 6 m y lo que se come el disco al cortar
    private static final int ABRIR_ARCHIVO = 41;
    private static final int FONDO = 0xFF151A26;

    private final List<Pieza> piezas = new ArrayList<>();
    private final Medidas medidas = new Medidas();
    private Vista3D vista;
    private VistaBoceto boceto;
    private LinearLayout lista, listaMedidas;
    private FrameLayout contenedor;
    private View panel2D, panel3D, panelMedidas;
    private final TextView[] pestanas = new TextView[3];
    private final List<TextView> botonesModo2D = new ArrayList<>(), botonesModo3D = new ArrayList<>();
    private String nombreProyecto = "Sin nombre";
    private int escogida = -1;
    private int pestana = 0;

    // deshacer / rehacer: copias livianas del proyecto
    private final List<String> atras = new ArrayList<>(), adelante = new ArrayList<>();

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(FONDO);
        getWindow().setNavigationBarColor(FONDO);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(FONDO);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));

        // pestañas de arriba
        LinearLayout tabs = new LinearLayout(this);
        String[] nt = {"✏ 2D", "🧊 3D", "📊 Medidas"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            pestanas[i] = boton(nt[i], 0xFF37474F, () -> mostrar(k));
            pestanas[i].setTextSize(14);
            tabs.addView(pestanas[i], peso());
        }
        tabs.addView(boton("📋 Corte", 0xFF43A047, this::listaCorte), peso());
        tabs.addView(boton("📂", 0xFF6D4C41, this::menuProyecto), new LinearLayout.LayoutParams(dp(48), -1));
        raiz.addView(tabs, new LinearLayout.LayoutParams(-1, dp(44)));

        contenedor = new FrameLayout(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1f);
        cp.topMargin = dp(4);
        raiz.addView(contenedor, cp);
        panel2D = armar2D();
        panel3D = armar3D();
        panelMedidas = armarMedidas();
        contenedor.addView(panel2D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panel3D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panelMedidas, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);

        abrir(ULTIMO, true);
        pestana = getPreferences(MODE_PRIVATE).getInt("pestana", 0);
        mostrar(pestana);
        recalcular();
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardar(ULTIMO, true);
        getPreferences(MODE_PRIVATE).edit().putInt("pestana", pestana).apply();
    }

    @Override
    public void onBackPressed() {
        if (pestana == 0 && boceto.modo != VistaBoceto.VER) { modo2D(VistaBoceto.VER); return; }
        super.onBackPressed();
    }

    private void mostrar(int k) {
        pestana = k;
        panel2D.setVisibility(k == 0 ? View.VISIBLE : View.GONE);
        panel3D.setVisibility(k == 1 ? View.VISIBLE : View.GONE);
        panelMedidas.setVisibility(k == 2 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) colorear(pestanas[i], i == k ? 0xFF1E88E5 : 0xFF37474F);
        if (k == 2) pintarMedidas();
    }

    // ---------------- Ayudas ----------------

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        colorear(t, color);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void colorear(TextView t, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
    }

    private LinearLayout fila(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, peso());
        return l;
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private Pieza porId(int id) {
        for (Pieza p : piezas) if (p.id == id) return p;
        return null;
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    private int nuevoId() {
        int m = 0;
        for (Pieza p : piezas) m = Math.max(m, p.id);
        return m + 1;
    }

    // ---------------- Deshacer ----------------

    /** Guarda una copia antes de cambiar algo. */
    private void antes() {
        try {
            atras.add(proyecto().toString());
            if (atras.size() > 60) atras.remove(0);
            adelante.clear();
        } catch (Exception ignored) {}
    }

    private void deshacer() {
        if (atras.isEmpty()) { aviso("No hay nada para deshacer"); return; }
        try {
            adelante.add(proyecto().toString());
            cargar(new JSONObject(atras.remove(atras.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo deshacer"); }
    }

    private void rehacer() {
        if (adelante.isEmpty()) { aviso("No hay nada para rehacer"); return; }
        try {
            atras.add(proyecto().toString());
            cargar(new JSONObject(adelante.remove(adelante.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo rehacer"); }
    }

    /** Volver a la copia que se acaba de guardar (cuando algo no cuadró). */
    private void revertir() {
        if (atras.isEmpty()) return;
        try { cargar(new JSONObject(atras.remove(atras.size() - 1))); } catch (Exception ignored) {}
    }

    // ---------------- Todo se recalcula desde la tablita ----------------

    private void fijos() {
        medidas.fijos.clear();
        float total = 0;
        for (Pieza p : piezas) { medidas.fijos.put("T" + p.id, (double) p.largo); total += p.largo; }
        medidas.fijos.put("total", (double) total);
        medidas.fijos.put("piezas", (double) piezas.size());
    }

    /** Tablita → piezas 3D → boceto 2D. Devuelve true si el boceto cuadró. */
    private boolean recalcular() {
        fijos();
        medidas.calcular();
        String err = null;
        for (Pieza p : piezas) { String e = p.aplicarFormulas(medidas); if (err == null) err = e; }
        fijos();
        medidas.calcular();
        boolean ok = boceto.b.resolver(medidas, -1);
        boceto.invalidate();
        vista.escogida = escogida;
        vista.invalidate();
        pintarLista();
        if (pestana == 2) pintarMedidas();
        if (err != null) aviso("⚠ " + err);
        return ok;
    }

    // =====================================================================
    //                              BOCETO 2D
    // =====================================================================

    private View armar2D() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        boceto = new VistaBoceto(this);
        boceto.medidas = medidas;
        boceto.oyente = new VistaBoceto.Oyente() {
            @Override public void antes() { InventorActivity.this.antes(); }
            @Override public void cambio() { boceto.b.resolver(medidas, -1); boceto.invalidate(); }
            @Override public void pedirCota(Boceto.Restr nueva) { InventorActivity.this.pedirCota(nueva, null); }
            @Override public void pedirDistancia(int p1, int p2) { InventorActivity.this.pedirDistancia(p1, p2); }
            @Override public void editarCota(Boceto.Restr r) { InventorActivity.this.editarCota(r); }
            @Override public void pedirTexto(double x, double y) { InventorActivity.this.pedirTexto(x, y); }
            @Override public void seleccion() { }
            @Override public void aviso(String s) { InventorActivity.this.aviso(s); }
        };
        l.addView(boceto, new LinearLayout.LayoutParams(-1, 0, 1f));

        String[][] dib = {{"✋\nVer", "" + VistaBoceto.VER}, {"╱\nLínea", "" + VistaBoceto.LINEA}, {"▭\nRectáng.", "" + VistaBoceto.RECT},
                {"◯\nCírculo", "" + VistaBoceto.CIRCULO}, {"◠\nArco", "" + VistaBoceto.ARCO}, {"A\nTexto", "" + VistaBoceto.TEXTO}};
        LinearLayout f1 = new LinearLayout(this);
        for (String[] d : dib) {
            final int m = Integer.parseInt(d[1]);
            TextView t = boton(d[0], 0xFF37474F, () -> modo2D(m));
            t.setTag(m);
            botonesModo2D.add(t);
            f1.addView(t, peso());
        }
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(-1, dp(48));
        p1.topMargin = dp(4);
        l.addView(f1, p1);

        LinearLayout f2 = new LinearLayout(this);
        TextView tCota = boton("📏\nCota", 0xFF37474F, () -> modo2D(VistaBoceto.COTA));
        tCota.setTag(VistaBoceto.COTA);
        botonesModo2D.add(tCota);
        TextView tMover = boton("✥\nMover", 0xFF37474F, () -> modo2D(VistaBoceto.MOVER));
        tMover.setTag(VistaBoceto.MOVER);
        botonesModo2D.add(tMover);
        f2.addView(tCota, peso());
        f2.addView(boton("🔗\nAmarrar", 0xFF00897B, this::amarrar2D), peso());
        f2.addView(tMover, peso());
        f2.addView(boton("🗑\nBorrar", 0xFFC62828, this::borrar2D), peso());
        f2.addView(boton("↶\nAtrás", 0xFF5E35B1, this::deshacer), peso());
        f2.addView(boton("↷\nAdelante", 0xFF5E35B1, this::rehacer), peso());
        f2.addView(boton("✓\nListo", 0xFF2E7D32, () -> { boceto.terminar(); modo2D(VistaBoceto.VER); }), peso());
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(48));
        p2.topMargin = dp(4);
        l.addView(f2, p2);

        LinearLayout f3 = new LinearLayout(this);
        f3.addView(boton("⛶ Ver todo", 0xFF455A64, boceto::encuadrar), peso());
        f3.addView(boton("📄 PDF carta", 0xFF6D4C41, this::pdf2D), peso());
        f3.addView(boton("🧹 Hoja nueva", 0xFF455A64, () -> new AlertDialog.Builder(this).setMessage("¿Borrar todo el boceto 2D? (se puede deshacer con ↶)")
                .setPositiveButton("Borrar", (d, w) -> { antes(); boceto.b = new Boceto(); boceto.sel.clear(); boceto.invalidate(); })
                .setNegativeButton("Cancelar", null).show()), peso());
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(-1, dp(38));
        p3.topMargin = dp(4);
        l.addView(f3, p3);
        modo2D(VistaBoceto.VER);
        return l;
    }

    private void modo2D(int m) {
        boceto.ponerModo(m);
        for (TextView t : botonesModo2D) colorear(t, ((Integer) t.getTag()) == m ? 0xFFFF8F00 : 0xFF37474F);
    }

    private EditText campoTexto(String valor, String pista) {
        EditText e = new EditText(this);
        e.setText(valor);
        e.setHint(pista);
        e.setTextSize(18);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setSelection(e.getText().length());
        return e;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(0xFF90A4AE);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    /** Escribir el valor de una cota nueva: un número (mm) o una fórmula de la tablita; y si quiere, ponerle nombre. */
    private void pedirCota(Boceto.Restr nueva, String sugerido) {
        Boceto bb = boceto.b;
        double actual = bb.medir(nueva);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Medida en mm, o fórmula (ej. ancho - 2*tubo)"));
        EditText val = campoTexto(sugerido != null ? sugerido : Formula.n(actual), "");
        l.addView(val);
        l.addView(etiqueta("Nombre para la tablita (opcional, ej. ancho)"));
        EditText nom = campoTexto("", "sin nombre");
        l.addView(nom);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[nueva.tipo]).setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String v = val.getText().toString().trim();
                    if (v.isEmpty()) return;
                    String n = nom.getText().toString().trim();
                    antes();
                    if (!n.isEmpty()) {
                        String ok = Medidas.nombreValido(n);
                        if (ok == null) { aviso("Ese nombre no sirve: use letras y números, sin espacios"); atras.remove(atras.size() - 1); return; }
                        Medidas.Fila f = medidas.buscar(ok);
                        if (f == null) { f = new Medidas.Fila(ok, v); medidas.filas.add(f); } else f.formula = v;
                        nueva.formula = ok;
                    } else nueva.formula = v;
                    bb.restr.add(nueva);
                    if (!recalcular() || nueva.error != null) {
                        String por = nueva.error != null ? nueva.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se puso: " + por);
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirDistancia(int p1, int p2) {
        new AlertDialog.Builder(this).setTitle("📏 Distancia entre los dos puntos")
                .setItems(new String[]{"↔ Horizontal", "↕ Vertical", "⤢ Alineada (en línea recta)"}, (d, w) -> {
                    Boceto.Restr r = new Boceto.Restr();
                    r.tipo = w == 0 ? Boceto.C_HORIZ : w == 1 ? Boceto.C_VERT : Boceto.C_DIST;
                    r.p1 = p1; r.p2 = p2;
                    pedirCota(r, null);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void editarCota(Boceto.Restr r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Hoy mide " + boceto.textoCota(r) + (r.error != null ? "\n⚠ " + r.error : "")));
        l.addView(etiqueta("Nuevo valor (mm) o fórmula"));
        EditText val = campoTexto(r.formula, "");
        l.addView(val);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[r.tipo]).setView(l)
                .setPositiveButton("Cambiar", (d, w) -> {
                    String v = val.getText().toString().trim();
                    if (v.isEmpty() || v.equals(r.formula)) return;
                    antes();
                    int i = boceto.b.restr.indexOf(r);
                    // si la cota es solo el nombre de una fila, se cambia la fila (así se mueve todo lo que la usa)
                    Medidas.Fila f = medidas.buscar(r.formula);
                    if (f != null && Formula.numero(v) != null) f.formula = v; else r.formula = v;
                    boolean ok = recalcular();
                    Boceto.Restr rr = i >= 0 && i < boceto.b.restr.size() ? boceto.b.restr.get(i) : r;
                    if (!ok || rr.error != null) {
                        String por = rr.error != null ? rr.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se cambió: " + por);
                    }
                })
                .setNeutralButton("🗑 Quitar cota", (d, w) -> { antes(); boceto.b.restr.remove(r); recalcular(); })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirTexto(double x, double y) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        EditText t = campoTexto("", "Ej. COCINA");
        l.addView(t);
        l.addView(etiqueta("Alto de la letra (mm)"));
        EditText al = campoTexto("150", "");
        al.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(al);
        new AlertDialog.Builder(this).setTitle("A Texto").setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String s = t.getText().toString().trim();
                    if (s.isEmpty()) return;
                    antes();
                    Boceto.Punto p = boceto.b.punto(x, y);
                    Boceto.Ent e = boceto.b.ent(Boceto.TEXTO);
                    e.a = p.id;
                    e.texto = s;
                    Double h = Formula.numero(al.getText().toString());
                    e.r = h == null || h <= 0 ? 150 : h;
                    boceto.invalidate();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🔗 Amarrar: según lo escogido, las restricciones que sirven. */
    private void amarrar2D() {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null) s.add(e); }
        List<String> nom = new ArrayList<>();
        List<Runnable> acc = new ArrayList<>();
        if (boceto.selPunto >= 0) {
            boolean fijo = false;
            for (Boceto.Restr r : bb.restr) if (r.tipo == Boceto.FIJO && r.p1 == boceto.selPunto) fijo = true;
            final int p = boceto.selPunto;
            if (!fijo) { nom.add("📌 Dejar este punto fijo"); acc.add(() -> poner(Boceto.FIJO, -1, -1, p, -1)); }
            else { nom.add("🔓 Soltar este punto"); acc.add(() -> { antes(); bb.restr.removeIf(r -> r.tipo == Boceto.FIJO && r.p1 == p); recalcular(); }); }
        }
        if (s.size() == 1 && s.get(0).tipo == Boceto.LINEA) {
            final int e = s.get(0).id;
            nom.add("═ Horizontal"); acc.add(() -> poner(Boceto.HORIZ, e, -1, -1, -1));
            nom.add("║ Vertical"); acc.add(() -> poner(Boceto.VERT, e, -1, -1, -1));
            nom.add("📏 Cota de largo"); acc.add(() -> { Boceto.Restr r = new Boceto.Restr(); r.tipo = Boceto.C_LARGO; r.e1 = e; pedirCota(r, null); });
        }
        if (s.size() == 1 && (s.get(0).tipo == Boceto.CIRCULO || s.get(0).tipo == Boceto.ARCO)) {
            final int e = s.get(0).id;
            nom.add("📏 Cota de diámetro"); acc.add(() -> { Boceto.Restr r = new Boceto.Restr(); r.tipo = Boceto.C_DIAM; r.e1 = e; pedirCota(r, null); });
            nom.add("📏 Cota de radio"); acc.add(() -> { Boceto.Restr r = new Boceto.Restr(); r.tipo = Boceto.C_RADIO; r.e1 = e; pedirCota(r, null); });
        }
        if (s.size() == 2) {
            Boceto.Ent a = s.get(0), c = s.get(1);
            if (a.tipo == Boceto.LINEA && c.tipo == Boceto.LINEA) {
                nom.add("⊥ Perpendicular (90°)"); acc.add(() -> poner(Boceto.PERP, a.id, c.id, -1, -1));
                nom.add("∥ Paralelas"); acc.add(() -> poner(Boceto.PARAL, a.id, c.id, -1, -1));
                nom.add("= Igual largo"); acc.add(() -> poner(Boceto.IGUAL, a.id, c.id, -1, -1));
                nom.add("∠ Cota de ángulo"); acc.add(() -> { Boceto.Restr r = new Boceto.Restr(); r.tipo = Boceto.C_ANG; r.e1 = a.id; r.e2 = c.id; pedirCota(r, null); });
            } else if (a.tipo != Boceto.LINEA && c.tipo != Boceto.LINEA && a.tipo != Boceto.TEXTO && c.tipo != Boceto.TEXTO) {
                nom.add("= Igual radio"); acc.add(() -> poner(Boceto.IGUAL, a.id, c.id, -1, -1));
            }
        }
        // ver y quitar los amarres de lo escogido
        List<Boceto.Restr> suyas = new ArrayList<>();
        for (Boceto.Restr r : bb.restr) {
            boolean es = false;
            for (Boceto.Ent e : s) if (r.e1 == e.id || r.e2 == e.id) es = true;
            if (boceto.selPunto >= 0 && (r.p1 == boceto.selPunto || r.p2 == boceto.selPunto)) es = true;
            if (es) suyas.add(r);
        }
        for (Boceto.Restr r : suyas) {
            nom.add("🗑 Quitar: " + Boceto.NOMBRES[r.tipo] + (r.esCota() ? " (" + boceto.textoCota(r) + ")" : ""));
            acc.add(() -> { antes(); bb.restr.remove(r); recalcular(); });
        }
        if (nom.isEmpty()) {
            aviso("Primero, con ✋ Ver, toque una o dos líneas (o un punto) para amarrarlas");
            return;
        }
        new AlertDialog.Builder(this).setTitle("🔗 Amarrar").setItems(nom.toArray(new String[0]), (d, w) -> acc.get(w).run())
                .setNegativeButton("Cerrar", null).show();
    }

    private void poner(int tipo, int e1, int e2, int p1, int p2) {
        antes();
        boceto.b.restriccion(tipo, e1, e2, p1, p2, null);
        if (!recalcular()) {
            revertir();
            recalcular();
            aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)");
        }
    }

    private void borrar2D() {
        Boceto bb = boceto.b;
        if (boceto.sel.isEmpty() && boceto.selPunto < 0) { aviso("Con ✋ Ver toque lo que quiere borrar"); return; }
        antes();
        for (Integer id : new ArrayList<>(boceto.sel)) { Boceto.Ent e = bb.entPorId(id); if (e != null) bb.borrar(e); }
        if (boceto.selPunto >= 0) {
            int p = boceto.selPunto;
            for (Boceto.Ent e : new ArrayList<>(bb.ents)) if (e.a == p || e.b == p || e.c == p) bb.borrar(e);
            bb.puntos.remove(p);
            bb.limpiarPuntos();
        }
        boceto.sel.clear();
        boceto.selPunto = -1;
        recalcular();
    }

    /** El boceto en PDF tamaño carta, todo en negro nítido, con su escala. */
    private void pdf2D() {
        if (boceto.b.vacio()) { aviso("El boceto está vacío"); return; }
        try {
            PdfDocument doc = new PdfDocument();
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create());
            Canvas c = pg.getCanvas();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTextSize(13);
            p.setFakeBoldText(true);
            c.drawText("MI INVENTOR · " + nombreProyecto, 40, 45, p);
            p.setFakeBoldText(false);
            p.setTextSize(9.5f);
            boceto.imprimir(c, 36, 60, 540, 640);
            double esc = boceto.escalaImpresa;   // puntos de papel por mm
            long e = Math.max(1, Math.round(1 / (esc / 72.0 * 25.4)));
            c.drawText("Medidas en milímetros · Escala aprox. 1:" + e + " · " + new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "CO")).format(new Date()), 40, 735, p);
            // las medidas con nombre de la tablita, abajo
            StringBuilder sb = new StringBuilder();
            for (Medidas.Fila f : medidas.filas) {
                Double v = medidas.valorDe(f.nombre);
                if (sb.length() > 0) sb.append("   ");
                sb.append(f.nombre).append(" = ").append(v == null ? "⚠" : Formula.n(v));
            }
            if (sb.length() > 0) c.drawText(sb.length() > 110 ? sb.substring(0, 110) + "…" : sb.toString(), 40, 752, p);
            Paint marco = new Paint();
            marco.setStyle(Paint.Style.STROKE);
            marco.setColor(Color.BLACK);
            marco.setStrokeWidth(1);
            c.drawRect(30, 55, 582, 720, marco);
            doc.finishPage(pg);
            guardarPdf(doc, "MiInventor_Plano_");
        } catch (Exception ex) {
            aviso("No se pudo hacer el PDF");
        }
    }

    private void guardarPdf(PdfDocument doc, String prefijo) throws Exception {
        ContentValues cv = new ContentValues();
        String nom = prefijo + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".pdf";
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        try (OutputStream o = getContentResolver().openOutputStream(u)) { doc.writeTo(o); }
        doc.close();
        aviso("✔ PDF guardado en Descargas/MiBarra/MiInventor");
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception ignored) {}
    }

    // =====================================================================
    //                              MEDIDAS (mini Excel)
    // =====================================================================

    private View armarMedidas() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView ay = new TextView(this);
        ay.setText("Cada medida tiene nombre y fórmula. Las cotas del 2D y las piezas del 3D pueden usar estos nombres: "
                + "cambia un número y se rehace todo. Funciones: redondear( ), arriba( ), abajo( ), min( ; ), max( ; ), si(cond; sí; no).");
        ay.setTextColor(0xFFB0BEC5);
        ay.setTextSize(13);
        ay.setPadding(dp(6), dp(4), dp(6), dp(6));
        l.addView(ay);
        ScrollView sv = new ScrollView(this);
        listaMedidas = new LinearLayout(this);
        listaMedidas.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listaMedidas);
        l.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout acc = fila(
                boton("➕ Agregar medida", 0xFF00897B, () -> editarFila(null)),
                boton("💬 WhatsApp", 0xFF25A244, () -> compartirTexto(textoMedidas())),
                boton("↶ Atrás", 0xFF5E35B1, this::deshacer));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(46));
        ap.topMargin = dp(4);
        l.addView(acc, ap);
        return l;
    }

    private void pintarMedidas() {
        listaMedidas.removeAllViews();
        if (medidas.filas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay medidas. Toque ➕ Agregar medida, o en el 2D ponga una cota y escríbale un nombre.\n\n"
                    + "Ejemplo:\n  ancho = 4000\n  tubo = 40\n  travesano = ancho - 2*tubo\n  tubos_6m = arriba(total / 6000)");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            listaMedidas.addView(t);
        }
        int n = 1;
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            String err = medidas.errorDe(f.nombre);
            boolean soloNumero = Formula.numero(f.formula) != null;
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(err != null ? 0xFF4A1C1C : 0xFF1E2A3A);
            g.setCornerRadius(dp(8));
            r.setBackground(g);
            TextView num = new TextView(this);
            num.setText(String.valueOf(n++));
            num.setTextColor(0xFF78909C);
            num.setTextSize(12);
            r.addView(num, new LinearLayout.LayoutParams(dp(22), -2));
            TextView t = new TextView(this);
            t.setText(f.nombre + (soloNumero ? "" : "\n= " + f.formula));
            t.setTextColor(Color.WHITE);
            t.setTextSize(15);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView val = new TextView(this);
            val.setText(err != null ? "⚠ " + err : Formula.n(v == null ? 0 : v));
            val.setTextColor(err != null ? 0xFFFF8A80 : 0xFFFFD54A);
            val.setTextSize(err != null ? 12 : 17);
            val.setTypeface(Typeface.DEFAULT_BOLD);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(err != null ? dp(150) : -2, -2));
            r.setOnClickListener(x -> editarFila(f));
            r.setOnLongClickListener(x -> {
                new AlertDialog.Builder(this).setMessage("¿Borrar la medida «" + f.nombre + "»? Lo que la use quedará con error.")
                        .setPositiveButton("Borrar", (d, w) -> { antes(); medidas.filas.remove(f); recalcular(); })
                        .setNegativeButton("Cancelar", null).show();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            listaMedidas.addView(r, lp);
        }
        // los valores que pone la app
        TextView sub = new TextView(this);
        StringBuilder s = new StringBuilder("Valores de la app (solo leer):\n");
        for (Map.Entry<String, Double> e : medidas.fijos.entrySet()) s.append(e.getKey()).append(" = ").append(Formula.n(e.getValue())).append("   ");
        sub.setText(s.toString().trim());
        sub.setTextColor(0xFF90A4AE);
        sub.setTextSize(13);
        sub.setPadding(dp(8), dp(12), dp(8), dp(8));
        listaMedidas.addView(sub);
    }

    private void editarFila(Medidas.Fila f) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Nombre (sin espacios, ej. ancho)"));
        EditText nom = campoTexto(f == null ? "" : f.nombre, "ancho");
        l.addView(nom);
        l.addView(etiqueta("Valor o fórmula (ej. 4000  ·  ancho - 2*tubo)"));
        EditText fo = campoTexto(f == null ? "" : f.formula, "4000");
        l.addView(fo);
        new AlertDialog.Builder(this).setTitle(f == null ? "➕ Medida nueva" : "✏ " + f.nombre).setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = Medidas.nombreValido(nom.getText().toString());
                    String v = fo.getText().toString().trim();
                    if (n == null) { aviso("El nombre debe empezar con letra, sin espacios ni signos (y no puede ser T1, total…)"); return; }
                    if (v.isEmpty()) { aviso("Escriba el valor o la fórmula"); return; }
                    Medidas.Fila otra = medidas.buscar(n);
                    if (otra != null && otra != f) { aviso("Ya hay una medida «" + n + "»"); return; }
                    antes();
                    String viejo = f == null ? null : f.nombre;
                    Medidas.Fila x = f == null ? new Medidas.Fila() : f;
                    x.nombre = n;
                    x.formula = v;
                    if (f == null) medidas.filas.add(x);
                    // si cambió el nombre, se cambia también donde se usaba
                    if (viejo != null && !Formula.plano(viejo).equals(Formula.plano(n))) renombrar(viejo, n);
                    if (!recalcular()) {
                        revertir();
                        recalcular();
                        aviso("⚠ Con ese valor el dibujo no cuadra: no se cambió");
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Cambia un nombre dentro de todas las fórmulas. */
    private void renombrar(String viejo, String nuevo) {
        String re = "(?i)(?<![\\p{L}\\p{N}_])" + java.util.regex.Pattern.quote(viejo) + "(?![\\p{L}\\p{N}_])";
        for (Medidas.Fila f : medidas.filas) f.formula = f.formula.replaceAll(re, nuevo);
        for (Boceto.Restr r : boceto.b.restr) r.formula = r.formula.replaceAll(re, nuevo);
        for (Pieza p : piezas) for (Map.Entry<String, String> e : p.f.entrySet()) e.setValue(e.getValue().replaceAll(re, nuevo));
    }

    private String textoMedidas() {
        StringBuilder s = new StringBuilder("MI INVENTOR · MEDIDAS · ").append(nombreProyecto).append("\n\n");
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            s.append(f.nombre).append(" = ");
            if (Formula.numero(f.formula) == null) s.append(f.formula).append(" = ");
            s.append(v == null ? "⚠ error" : Formula.n(v)).append(" mm\n");
        }
        return s.toString();
    }

    // =====================================================================
    //                              3D
    // =====================================================================

    private boolean movioPieza;

    private View armar3D() {
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        vista = new Vista3D(this);
        vista.piezas = piezas;
        vista.alEscoger = id -> { escogida = id; pintarLista(); };
        vista.alMover = new Vista3D.AlMover() {
            @Override public void mover(int id, float dx, float dy, float dz) {
                Pieza p = porId(id);
                if (p == null) return;
                if (!movioPieza) { antes(); movioPieza = true; }
                p.cx += dx; p.cy += dy; p.cz += dz;
                p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                vista.invalidate();
            }
            @Override public void soltar() { movioPieza = false; pintarLista(); }
        };
        raiz.addView(vista, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        LinearLayout vistas = new LinearLayout(this);
        vistas.addView(boton("🧊 3D", 0xFF37474F, () -> vista.vista(-35, 25)), peso());
        vistas.addView(boton("Frente", 0xFF37474F, () -> vista.vista(0, 0)), peso());
        vistas.addView(boton("Lado", 0xFF37474F, () -> vista.vista(-90, 0)), peso());
        vistas.addView(boton("Arriba", 0xFF37474F, () -> vista.vista(0, 89)), peso());
        vistas.addView(boton("⛶ Todo", 0xFF37474F, () -> vista.encuadrar()), peso());
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(36));
        vp.topMargin = dp(4);
        raiz.addView(vistas, vp);

        // Versión 2: qué hace un dedo
        LinearLayout modos = new LinearLayout(this);
        String[][] md = {{"✋ Correr vista", "" + Vista3D.CORRER}, {"🔄 Girar", "" + Vista3D.GIRAR}, {"✥ Mover pieza", "" + Vista3D.MOVER}};
        for (String[] m : md) {
            final int k = Integer.parseInt(m[1]);
            TextView t = boton(m[0], 0xFF37474F, () -> modo3D(k));
            t.setTag(k);
            botonesModo3D.add(t);
            modos.addView(t, peso());
        }
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(36));
        mp.topMargin = dp(4);
        raiz.addView(modos, mp);

        LinearLayout acciones = new LinearLayout(this);
        acciones.addView(boton("➕\nPieza", 0xFF00897B, () -> editar(null)), peso());
        acciones.addView(boton("✏\nEditar", 0xFF1E88E5, () -> { Pieza p = porId(escogida); if (p == null) aviso("Toque primero una pieza"); else editar(p); }), peso());
        acciones.addView(boton("⧉\nCopiar", 0xFF5E35B1, this::copiarEscogida), peso());
        acciones.addView(boton("⟳\nRotar", 0xFF6A1B9A, this::rotar), peso());
        acciones.addView(boton("🔗\nAmarrar", 0xFF00897B, this::amarrar3D), peso());
        acciones.addView(boton("↶\nAtrás", 0xFF455A64, this::deshacer), peso());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(50));
        ap.topMargin = dp(4);
        raiz.addView(acciones, ap);

        ScrollView sv = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        sv.addView(lista);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 0.7f);
        lp.topMargin = dp(4);
        raiz.addView(sv, lp);
        modo3D(Vista3D.CORRER);
        return raiz;
    }

    private void modo3D(int m) {
        vista.modo = m;
        for (TextView t : botonesModo3D) colorear(t, ((Integer) t.getTag()) == m ? 0xFFFF8F00 : 0xFF37474F);
        if (m == Vista3D.MOVER) aviso("Arrastre la pieza con el dedo (se mueve de 5 en 5 mm)");
    }

    private String resumen(Pieza p) {
        StringBuilder s = new StringBuilder();
        s.append(p.nombre()).append(" · ").append(p.referencia()).append("\n")
                .append(Pieza.n(p.largo)).append(" mm");
        if (p.f.containsKey("largo")) s.append(" (= ").append(p.f.get("largo")).append(")");
        s.append(" · ").append(Pieza.DIRS[p.dir].substring(0, 1));
        if (Math.abs(p.incl) > 0.01f) s.append(" inclinado ").append(Pieza.n(p.incl)).append("°");
        Pieza pp = porId(p.padre);
        if (pp != null) {
            s.append(" · unido a ").append(pp.nombre()).append(p.punto == 0 ? " (inicio)" : p.punto == 1 ? " (final)" : " (a " + Pieza.n(p.aMm) + " mm)");
            if (Math.abs(p.sep) > 0.01f) s.append(" · separ. ").append(Pieza.n(p.sep)).append(" mm");
        }
        if (!p.huecos.isEmpty()) s.append(" · ").append(p.huecos.size()).append(p.huecos.size() == 1 ? " hueco" : " huecos");
        return s.toString();
    }

    private void pintarLista() {
        if (lista == null) return;
        lista.removeAllViews();
        if (piezas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Toque ➕ Pieza para empezar.\n\nCada pieza arranca en el punto 0 o pegada a otra pieza (al inicio, al final o a una medida), "
                    + "y puede quedar separada los milímetros que usted diga.\n\nUn dedo corre la vista (o gira con 🔄, o arrastra la pieza con ✥), dos dedos acercan. "
                    + "En el largo puede escribir una fórmula de la tablita, por ejemplo: ancho - 2*tubo.");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            lista.addView(t);
            return;
        }
        for (Pieza p : piezas) {
            TextView t = new TextView(this);
            t.setText(resumen(p));
            t.setTextColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            t.setTextSize(14);
            t.setPadding(dp(10), dp(7), dp(8), dp(7));
            GradientDrawable g = new GradientDrawable();
            g.setColor(p.id == escogida ? 0xFFFFB300 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34);
            g.setCornerRadius(dp(8));
            t.setBackground(g);
            t.setOnClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); });
            t.setOnLongClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); opcionesPieza(p); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            lista.addView(t, lp);
        }
    }

    private void opcionesPieza(Pieza p) {
        new AlertDialog.Builder(this).setTitle(p.nombre())
                .setItems(new String[]{"✏ Editar", "⧉ Copiar (queda pegada al final de esta)", "⟳ Rotar", "🔗 Amarrar a otra pieza", "🗑 Eliminar"}, (d, w) -> {
                    if (w == 0) editar(p);
                    else if (w == 1) copiarEscogida();
                    else if (w == 2) rotar();
                    else if (w == 3) amarrar3D();
                    else eliminar(p);
                }).show();
    }

    private void copiarEscogida() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        antes();
        Pieza c = p.copia(nuevoId());
        if (c == null) return;
        c.padre = p.id;
        c.punto = 1;
        c.sep = 0;
        c.cx = c.cy = c.cz = 0;
        c.f.remove("sep"); c.f.remove("cx"); c.f.remove("cy"); c.f.remove("cz"); c.f.remove("aMm");
        piezas.add(c);
        escogida = c.id;
        vista.encuadrar();
        recalcular();
        aviso("Copia " + c.nombre() + " pegada al final de " + p.nombre());
    }

    /** Las piezas que cuelgan de esta (para no amarrar en círculo y para rotar todo junto). */
    private Set<Integer> descendientes(int id) {
        Set<Integer> r = new HashSet<>();
        boolean cambio = true;
        r.add(id);
        while (cambio) {
            cambio = false;
            for (Pieza p : piezas) if (!r.contains(p.id) && r.contains(p.padre)) { r.add(p.id); cambio = true; }
        }
        return r;
    }

    /** Al eliminar o soltar, lo que estaba unido se queda en su puesto. */
    private void soltarEnSuPuesto(Pieza h) {
        Map<Integer, Pieza> m = mapa();
        float[] ini = h.inicio(m, 0), dir = h.direccion();
        h.padre = -1;
        h.cx = ini[0] - dir[0] * h.sep;
        h.cy = ini[1] - dir[1] * h.sep;
        h.cz = ini[2] - dir[2] * h.sep;
        h.f.remove("cx"); h.f.remove("cy"); h.f.remove("cz");
    }

    private void eliminar(Pieza p) {
        new AlertDialog.Builder(this).setMessage("¿Eliminar " + p.nombre() + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    antes();
                    for (Pieza h : piezas) if (h.padre == p.id) soltarEnSuPuesto(h);
                    piezas.remove(p);
                    escogida = -1;
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** ⟳ Rotar 90°: la pieza y todo lo que tiene pegado giran juntos. */
    private void rotar() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        new AlertDialog.Builder(this).setTitle("⟳ Rotar " + p.nombre() + " (y lo que tiene pegado)")
                .setItems(new String[]{"↻ 90° en el piso (alrededor de Z)", "↻ 90° parándola (alrededor de X)", "↻ 90° de lado (alrededor de Y)",
                        "↕ Cambiar la inclinación…", "🔁 Girar la sección 90° (ángulo o platina)"}, (d, w) -> {
                    if (w == 3) { inclinacion(p); return; }
                    antes();
                    if (w == 4) { p.giro = (p.giro + 1) & 3; recalcular(); return; }
                    for (Integer id : descendientes(p.id)) {
                        Pieza x = porId(id);
                        if (x == null) continue;
                        x.dir = Pieza.girarDir(x.dir, w);
                        if (x != p) {
                            float[] v = Pieza.girarVec(new float[]{x.cx, x.cy, x.cz}, w);
                            x.cx = v[0]; x.cy = v[1]; x.cz = v[2];
                        }
                    }
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cerrar", null).show();
    }

    private void inclinacion(Pieza p) {
        EditText e = campoTexto(Pieza.n(p.incl), "grados");
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        new AlertDialog.Builder(this).setTitle("Inclinación de " + p.nombre() + " (0 = derecho)").setView(e)
                .setPositiveButton("Listo", (d, w) -> {
                    Double v = Formula.numero(e.getText().toString());
                    if (v == null) return;
                    antes();
                    p.incl = v.floatValue();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🔗 Amarrar la pieza escogida a otra (o soltarla dejándola en su puesto). */
    private void amarrar3D() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere amarrar"); return; }
        Set<Integer> no = descendientes(p.id);
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (!no.contains(x.id)) posibles.add(x);
        List<String> nom = new ArrayList<>();
        if (p.padre >= 0) nom.add("🔓 Soltarla (se queda donde está)");
        for (Pieza x : posibles) nom.add("🔗 A " + x.nombre() + " · " + x.referencia());
        if (nom.isEmpty()) { aviso("No hay otra pieza para amarrarla"); return; }
        final int corre = p.padre >= 0 ? 1 : 0;
        new AlertDialog.Builder(this).setTitle("🔗 Amarrar " + p.nombre()).setItems(nom.toArray(new String[0]), (d, w) -> {
            if (corre == 1 && w == 0) { antes(); soltarEnSuPuesto(p); recalcular(); return; }
            Pieza padre = posibles.get(w - corre);
            LinearLayout l = new LinearLayout(this);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setPadding(dp(18), dp(4), dp(18), 0);
            Spinner sp = lista(l, "En qué punto de " + padre.nombre(), new String[]{"Al inicio", "Al final", "A una medida del inicio"}, 1);
            l.addView(etiqueta("Medida desde el inicio (mm o fórmula), si escogió «a una medida»"));
            EditText am = campoTexto("0", "");
            l.addView(am);
            l.addView(etiqueta("Separación (mm o fórmula): luz entre las dos piezas"));
            EditText se = campoTexto("0", "");
            l.addView(se);
            new AlertDialog.Builder(this).setTitle("🔗 " + p.nombre() + " → " + padre.nombre()).setView(l)
                    .setPositiveButton("Amarrar", (d2, w2) -> {
                        antes();
                        p.padre = padre.id;
                        p.punto = sp.getSelectedItemPosition();
                        p.cx = p.cy = p.cz = 0;
                        p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                        leerCampo(p, "aMm", am.getText().toString());
                        leerCampo(p, "sep", se.getText().toString());
                        vista.encuadrar();
                        recalcular();
                    }).setNegativeButton("Cancelar", null).show();
        }).setNegativeButton("Cerrar", null).show();
    }

    /** Un campo de la pieza: número fijo o fórmula de la tablita. */
    private void leerCampo(Pieza p, String k, String texto) {
        String t = texto == null ? "" : texto.trim();
        if (t.isEmpty()) return;
        Double n = Formula.numero(t);
        if (n != null) { p.ponerCampo(k, n.floatValue()); p.f.remove(k); return; }
        fijos();
        medidas.calcular();
        try {
            double v = medidas.evaluar(t);
            p.ponerCampo(k, (float) v);
            p.f.put(k, t);
        } catch (Exception e) {
            aviso("⚠ " + p.nombre() + ": la fórmula «" + t + "» no sirve: " + e.getMessage());
        }
    }

    // ---------------- Formulario de una pieza ----------------

    private EditText numero(LinearLayout l, String etiqueta, float valor, boolean signo) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        e.setText(Pieza.n(valor));
        e.setTextSize(17);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | (signo ? InputType.TYPE_NUMBER_FLAG_SIGNED : 0));
        l.addView(e);
        return e;
    }

    /** Casilla que acepta número o fórmula (el teclado normal, para poder escribir nombres). */
    private EditText numeroOFormula(LinearLayout l, String etiqueta, Pieza p, String k) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        String f = p.f.get(k);
        e.setText(f != null ? f : Pieza.n(p.campo(k)));
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        l.addView(e);
        return e;
    }

    private EditText[] filaNumeros(LinearLayout l, String[] etiquetas, float[] valores, boolean signo) {
        LinearLayout fila = new LinearLayout(this);
        EditText[] r = new EditText[etiquetas.length];
        for (int i = 0; i < etiquetas.length; i++) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            r[i] = numero(c, etiquetas[i], valores[i], signo);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.setMargins(0, 0, dp(6), 0);
            fila.addView(c, p);
        }
        l.addView(fila);
        return r;
    }

    private Spinner lista(LinearLayout l, String etiqueta, String[] items, int sel) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(Math.max(0, Math.min(items.length - 1, sel)));
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
        return s;
    }

    private static float leer(EditText e, float porDefecto) {
        try { return Float.parseFloat(e.getText().toString().trim().replace(',', '.')); } catch (Exception x) { return porDefecto; }
    }

    private static String[] nombresMedidas(int tipo) {
        Object[][] m = Pieza.MEDIDAS[tipo];
        String[] r = new String[m.length + 1];
        for (int i = 0; i < m.length; i++) r[i] = (String) m[i][0];
        r[m.length] = "Otra medida (escríbala abajo)";
        return r;
    }

    private void titulo(LinearLayout l, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(2));
        l.addView(t);
    }

    private void editar(Pieza original) {
        final boolean nueva = original == null;
        final Pieza p;
        if (nueva) {
            p = new Pieza();
            p.id = nuevoId();
            Pieza ult = piezas.isEmpty() ? null : piezas.get(piezas.size() - 1);
            if (ult != null) {   // por comodidad: la nueva sale igual a la anterior y pegada a su final
                p.tipo = ult.tipo; p.medida = ult.medida; p.a = ult.a; p.b = ult.b; p.t = ult.t; p.calibre = ult.calibre;
                p.padre = ult.id; p.punto = 1;
            }
        } else p = original;

        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), dp(10));
        sv.addView(l);

        titulo(l, "1. El perfil");
        Spinner sTipo = lista(l, "Perfil", Pieza.TIPOS, p.tipo);
        int iMed = Arrays.asList(nombresMedidas(p.tipo)).indexOf(p.medida);
        Spinner sMed = lista(l, "Medida", nombresMedidas(p.tipo), iMed < 0 ? Pieza.MEDIDAS[p.tipo].length : iMed);
        EditText[] dims = filaNumeros(l, new String[]{"Ancho mm", "Alto mm", "Espesor mm"}, new float[]{p.a, p.b, p.t}, false);
        TextView tc = new TextView(this);
        tc.setText("Calibre (para pedirlo en la ferretería)");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setPadding(0, dp(8), 0, 0);
        l.addView(tc);
        EditText eCal = new EditText(this);
        eCal.setText(p.calibre);
        l.addView(eCal);
        final int[] tipoAntes = {p.tipo};
        sTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                if (pos == tipoAntes[0]) return;
                tipoAntes[0] = pos;
                sMed.setAdapter(new ArrayAdapter<>(InventorActivity.this, android.R.layout.simple_spinner_dropdown_item, nombresMedidas(pos)));
                sMed.setSelection(Math.min(2, Pieza.MEDIDAS[pos].length - 1));
                eCal.setText(pos <= 2 ? "Cal 18" : "");
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });
        sMed.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                Object[][] m = Pieza.MEDIDAS[sTipo.getSelectedItemPosition()];
                if (pos >= m.length) return;
                dims[0].setText(Pieza.n((Float) m[pos][1]));
                dims[1].setText(Pieza.n((Float) m[pos][2]));
                dims[2].setText(Pieza.n((Float) m[pos][3]));
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });

        titulo(l, "2. Largo y hacia dónde va");
        EditText eLargo = numeroOFormula(l, "Largo de corte (mm o fórmula, ej. ancho - 2*tubo)", p, "largo");
        Spinner sDir = lista(l, "Dirección", Pieza.DIRS, p.dir);
        EditText eIncl = numero(l, "Inclinación (grados, 0 = derecho)", p.incl, true);
        Spinner sGiro = lista(l, "Girar la sección (para ángulo o platina)", new String[]{"0°", "90°", "180°", "270°"}, p.giro);

        titulo(l, "3. Dónde se une");
        Set<Integer> no = nueva ? new HashSet<>() : descendientes(p.id);
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (x != p && !no.contains(x.id)) posibles.add(x);
        String[] nomPadres = new String[posibles.size() + 1];
        nomPadres[0] = "En el punto 0 (suelta)";
        int selPadre = 0;
        for (int i = 0; i < posibles.size(); i++) {
            nomPadres[i + 1] = posibles.get(i).nombre() + " · " + posibles.get(i).referencia();
            if (posibles.get(i).id == p.padre) selPadre = i + 1;
        }
        Spinner sPadre = lista(l, "Va pegada a", nomPadres, selPadre);
        Spinner sPunto = lista(l, "En qué punto de esa pieza", new String[]{"Al inicio", "Al final", "A una medida del inicio"}, p.punto);
        EditText eAmm = numeroOFormula(l, "Medida desde el inicio (mm o fórmula), si escogió «a una medida»", p, "aMm");
        EditText eSep = numeroOFormula(l, "Separación (mm o fórmula) — luz entre las dos piezas", p, "sep");
        EditText eCx = numeroOFormula(l, "Correr X (mm o fórmula)", p, "cx");
        EditText eCy = numeroOFormula(l, "Correr Y (mm o fórmula)", p, "cy");
        EditText eCz = numeroOFormula(l, "Correr Z (mm o fórmula)", p, "cz");

        titulo(l, "4. Cortes de las puntas");
        EditText[] cortes = filaNumeros(l, new String[]{"Inicio (°)", "Final (°)"}, new float[]{p.corteIni, p.corteFin}, true);

        titulo(l, "5. Huecos y ranuras");
        LinearLayout cajaHuecos = new LinearLayout(this);
        cajaHuecos.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHuecos);
        List<Object[]> filasHueco = new ArrayList<>();
        for (Pieza.Hueco h : p.huecos) agregarFilaHueco(cajaHuecos, filasHueco, h);
        TextView masH = boton("➕ Agregar hueco", 0xFF37474F, () -> agregarFilaHueco(cajaHuecos, filasHueco, new Pieza.Hueco()));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(44));
        mp.topMargin = dp(6);
        l.addView(masH, mp);

        new AlertDialog.Builder(this).setTitle(nueva ? "➕ Pieza nueva " + p.nombre() : "✏ " + p.nombre()).setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    antes();
                    p.tipo = sTipo.getSelectedItemPosition();
                    int im = sMed.getSelectedItemPosition();
                    p.a = Math.max(1, leer(dims[0], p.a));
                    p.b = Math.max(1, leer(dims[1], p.b));
                    p.t = Math.max(0.3f, leer(dims[2], p.t));
                    p.medida = im < Pieza.MEDIDAS[p.tipo].length ? (String) Pieza.MEDIDAS[p.tipo][im][0]
                            : Pieza.n(p.a) + "x" + Pieza.n(p.b) + " mm";
                    p.calibre = eCal.getText().toString();
                    leerCampo(p, "largo", eLargo.getText().toString());
                    if (p.largo <= 0) p.largo = 1000;
                    p.dir = sDir.getSelectedItemPosition();
                    p.incl = leer(eIncl, 0);
                    p.giro = sGiro.getSelectedItemPosition();
                    int ip = sPadre.getSelectedItemPosition();
                    p.padre = ip == 0 ? -1 : posibles.get(ip - 1).id;
                    p.punto = sPunto.getSelectedItemPosition();
                    leerCampo(p, "aMm", eAmm.getText().toString());
                    leerCampo(p, "sep", eSep.getText().toString());
                    leerCampo(p, "cx", eCx.getText().toString());
                    leerCampo(p, "cy", eCy.getText().toString());
                    leerCampo(p, "cz", eCz.getText().toString());
                    p.corteIni = leer(cortes[0], 0); p.corteFin = leer(cortes[1], 0);
                    p.huecos.clear();
                    for (Object[] f : filasHueco) {
                        Pieza.Hueco h = new Pieza.Hueco();
                        h.tipo = ((Spinner) f[0]).getSelectedItemPosition();
                        h.d1 = Math.max(1, leer((EditText) f[1], 10));
                        h.d2 = Math.max(1, leer((EditText) f[2], 8));
                        h.pos = leer((EditText) f[3], 50);
                        h.cara = ((Spinner) f[4]).getSelectedItemPosition();
                        p.huecos.add(h);
                    }
                    if (nueva) piezas.add(p);
                    escogida = p.id;
                    vista.encuadrar();
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Una fila de hueco: tipo, medidas, posición y cara. */
    private void agregarFilaHueco(LinearLayout caja, List<Object[]> filas, Pieza.Hueco h) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(8), dp(4), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        f.setBackground(g);
        Spinner sT = lista(f, "Hueco " + (filas.size() + 1), Pieza.HUECOS, h.tipo);
        EditText[] m = filaNumeros(f, new String[]{"Ø / lado / largo", "Ancho ranura", "A mm del inicio"}, new float[]{h.d1, h.d2, h.pos}, false);
        Spinner sC = lista(f, "En qué cara", Pieza.CARAS, h.cara);
        Object[] reg = {sT, m[0], m[1], m[2], sC, f};
        TextView quitar = boton("✕ Quitar este hueco", 0xFFC62828, () -> { caja.removeView(f); filas.remove(reg); });
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, dp(38));
        qp.topMargin = dp(6);
        f.addView(quitar, qp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        caja.addView(f, lp);
        filas.add(reg);
    }

    // ---------------- Lista de corte ----------------

    private String textoCorte() {
        Map<String, List<Pieza>> grupos = new LinkedHashMap<>();
        for (Pieza p : piezas) {
            List<Pieza> g = grupos.get(p.referencia());
            if (g == null) { g = new ArrayList<>(); grupos.put(p.referencia(), g); }
            g.add(p);
        }
        StringBuilder s = new StringBuilder();
        s.append("MI INVENTOR - LISTA DE CORTE\n");
        s.append("Proyecto: ").append(nombreProyecto).append("\n");
        s.append(new SimpleDateFormat("dd/MM/yyyy h:mm a", new Locale("es", "CO")).format(new Date())).append("\n");
        s.append("Barras de 6 m · se descuentan 3 mm por cada corte\n");
        int totalBarras = 0;
        for (Map.Entry<String, List<Pieza>> en : grupos.entrySet()) {
            s.append("\n========================================\n");
            s.append(en.getKey().toUpperCase(new Locale("es", "CO"))).append("\n");
            s.append("========================================\n");
            float metros = 0;
            List<Float> largos = new ArrayList<>();
            List<String> largas = new ArrayList<>();
            int extra = 0;
            for (Pieza p : en.getValue()) {
                metros += p.largo;
                s.append(String.format(Locale.US, "%-4s %6s mm", p.nombre(), Pieza.n(p.largo)));
                if (Math.abs(p.corteIni) > 0.01f || Math.abs(p.corteFin) > 0.01f)
                    s.append("  cortes ").append(Pieza.n(p.corteIni)).append("° / ").append(Pieza.n(p.corteFin)).append("°");
                else s.append("  cortes rectos (90°)");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(h.texto()).append("\n");
                if (p.largo > BARRA) { largas.add(p.nombre() + " (" + Pieza.n(p.largo) + " mm)"); extra += (int) Math.ceil(p.largo / BARRA); }
                else largos.add(p.largo);
            }
            // acomodar los cortes en barras: primero los más largos
            largos.sort((x, y) -> Float.compare(y, x));
            List<List<Float>> barras = new ArrayList<>();
            List<Float> libre = new ArrayList<>();
            for (float L : largos) {
                int k = -1;
                for (int i = 0; i < barras.size(); i++) if (libre.get(i) >= L + (barras.get(i).isEmpty() ? 0 : DISCO)) { k = i; break; }
                if (k < 0) { barras.add(new ArrayList<>()); libre.add(BARRA); k = barras.size() - 1; }
                libre.set(k, libre.get(k) - L - (barras.get(k).isEmpty() ? 0 : DISCO));
                barras.get(k).add(L);
            }
            s.append("\nMetros lineales: ").append(String.format(Locale.US, "%.2f", metros / 1000f)).append(" m\n");
            for (int i = 0; i < barras.size(); i++) {
                s.append("Barra ").append(i + 1).append(": ");
                List<Float> b = barras.get(i);
                for (int j = 0; j < b.size(); j++) s.append(j == 0 ? "" : " + ").append(Pieza.n(b.get(j)));
                s.append("  (sobran ").append(Pieza.n(Math.max(0, libre.get(i)))).append(" mm)\n");
            }
            if (!largas.isEmpty()) s.append("Más largas que 6 m (van empatadas): ").append(String.join(", ", largas)).append("\n");
            int comprar = barras.size() + extra;
            totalBarras += comprar;
            s.append(">> COMPRAR: ").append(comprar).append(comprar == 1 ? " barra de 6 m\n" : " barras de 6 m\n");
        }
        s.append("\n----------------------------------------\n");
        s.append("TOTAL: ").append(totalBarras).append(" barras de 6 m\n");
        return s.toString();
    }

    private void listaCorte() {
        if (piezas.isEmpty()) { aviso("Todavía no hay piezas en el 3D"); return; }
        String txt = textoCorte();
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(Color.WHITE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("📋 Lista de corte").setView(sv)
                .setPositiveButton("📄 PDF carta", (d, w) -> pdf(txt))
                .setNeutralButton("📲 WhatsApp", (d, w) -> compartirTexto(txt))
                .setNegativeButton("Cerrar", null).show();
    }

    private void compartirTexto(String txt) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) { try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {} }
    }

    /** La lista en PDF tamaño carta, letras negras nítidas. */
    private void pdf(String txt) {
        try {
            PdfDocument doc = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(10.5f);
            String[] lineas = txt.split("\n");
            float alto = 14, arriba = 50, abajo = 792 - 45;
            int num = 1, i = 0;
            while (i < lineas.length) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                float y = arriba;
                while (i < lineas.length && y < abajo) {
                    String ln = lineas[i++];
                    p.setFakeBoldText(ln.startsWith(">>") || ln.startsWith("TOTAL") || ln.startsWith("MI INVENTOR") || (i > 1 && ln.equals(ln.toUpperCase()) && !ln.startsWith("=")));
                    c.drawText(ln, 45, y, p);
                    y += alto;
                }
                p.setFakeBoldText(false);
                c.drawText("Página " + num, 520, 775, p);
                doc.finishPage(pg);
                num++;
            }
            guardarPdf(doc, "MiInventor_Corte_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Proyectos (archivos livianos) ----------------

    private File carpeta() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private JSONObject proyecto() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 2);
        o.put("nombre", nombreProyecto);
        JSONArray a = new JSONArray();
        for (Pieza p : piezas) a.put(p.json());
        o.put("piezas", a);
        o.put("medidas", medidas.json());
        o.put("boceto", boceto.b.json());
        return o;
    }

    private void cargar(JSONObject o) throws Exception {
        JSONArray a = o.optJSONArray("piezas");
        piezas.clear();
        if (a != null) for (int i = 0; i < a.length(); i++) piezas.add(Pieza.deJson(a.getJSONObject(i)));
        medidas.deJson(o.optJSONArray("medidas"));
        boceto.b = Boceto.deJson(o.optJSONObject("boceto"));
        boceto.sel.clear();
        boceto.selPunto = -1;
        nombreProyecto = o.optString("nombre", nombreProyecto);
        if (porId(escogida) == null) escogida = -1;
    }

    private void menuProyecto() {
        new AlertDialog.Builder(this).setTitle("📂 Proyecto: " + nombreProyecto)
                .setItems(new String[]{"💾 Guardar con nombre", "📂 Abrir uno guardado", "📤 Enviar el proyecto (archivo liviano)",
                        "📥 Abrir un archivo recibido", "📄 Empezar uno nuevo (vacío)"}, (d, w) -> {
                    if (w == 0) pedirNombre();
                    else if (w == 1) listaProyectos();
                    else if (w == 2) enviarProyecto();
                    else if (w == 3) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_ARCHIVO); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else new AlertDialog.Builder(this).setMessage("¿Empezar vacío? Lo que no haya guardado con nombre se pierde (se puede deshacer con ↶).")
                                .setPositiveButton("Empezar", (d2, w2) -> {
                                    antes();
                                    piezas.clear(); medidas.filas.clear(); boceto.b = new Boceto();
                                    escogida = -1; nombreProyecto = "Sin nombre";
                                    vista.encuadrar(); boceto.encuadrar(); recalcular();
                                })
                                .setNegativeButton("Cancelar", null).show();
                }).show();
    }

    /** El proyecto es solo números y fórmulas: unos pocos KB. Se guarda en Descargas/MiBarra/MiInventor y se manda. */
    private void enviarProyecto() {
        try {
            byte[] datos = proyecto().toString().getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + ".miv.json";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            aviso("✔ Archivo de " + Math.max(1, datos.length / 1024) + " KB en Descargas/MiBarra/MiInventor");
            Intent i = new Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_STREAM, u)
                    .putExtra(Intent.EXTRA_TEXT, "Proyecto de Mi Inventor: " + nombreProyecto).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Enviar el proyecto"));
        } catch (Exception e) {
            aviso("No se pudo preparar el archivo");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != ABRIR_ARCHIVO || res != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            byte[] b = new byte[8192];
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONObject o = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            antes();
            cargar(o);
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            aviso("Ese archivo no es un proyecto de Mi Inventor");
        }
    }

    private void pedirNombre() {
        EditText e = new EditText(this);
        e.setText("Sin nombre".equals(nombreProyecto) ? "" : nombreProyecto);
        e.setHint("Por ejemplo: escalera 55-21");
        new AlertDialog.Builder(this).setTitle("Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty() || n.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    nombreProyecto = n;
                    guardar(n, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void guardar(String nombre, boolean callado) {
        try {
            try (FileWriter w = new FileWriter(new File(carpeta(), nombre + ".json"))) { w.write(proyecto().toString()); }
            if (!callado) aviso("✔ Guardado «" + nombre + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo guardar");
        }
    }

    private void abrir(String nombre, boolean callado) {
        try {
            File f = new File(carpeta(), nombre + ".json");
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            cargar(o);
            escogida = -1;
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            if (!callado) aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo abrir");
        }
    }

    private void listaProyectos() {
        File[] fs = carpeta().listFiles(x -> x.getName().endsWith(".json") && !x.getName().startsWith("_"));
        if (fs == null || fs.length == 0) { aviso("Todavía no hay proyectos guardados con nombre"); return; }
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] nom = new String[fs.length];
        for (int i = 0; i < fs.length; i++) nom[i] = fs[i].getName().replace(".json", "") + "  (" + Math.max(1, fs[i].length() / 1024) + " KB)";
        new AlertDialog.Builder(this).setTitle("📂 Proyectos").setItems(nom, (d, w) -> {
            String n = fs[w].getName().replace(".json", "");
            new AlertDialog.Builder(this).setTitle(n).setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                if (w2 == 0) { antes(); abrir(n, false); }
                else new AlertDialog.Builder(this).setMessage("¿Borrar «" + n + "» para siempre?")
                        .setPositiveButton("Borrar", (d3, w3) -> { fs[w].delete(); aviso("Borrado"); })
                        .setNegativeButton("Cancelar", null).show();
            }).show();
        }).show();
    }
}
