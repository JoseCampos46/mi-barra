package co.jose.miinventor;

import java.util.Locale;
import java.util.Map;

/**
 * Calcula fórmulas como en Excel: ancho - 2*tubo, (a+b)/2, redondear(x), arriba(x/6000), si(ancho>3000; 5; 4).
 * Nombres de medidas sin tildes ni espacios importantes (se aceptan con tildes y con _).
 * Funciones: redondear, arriba, abajo, min, max, si, raiz, abs, sen, cos, tan (en grados), pi.
 */
public final class Formula {

    public static class Error extends RuntimeException {
        public Error(String m) { super(m); }
    }

    /** Busca el valor de un nombre (devuelve null si no existe). */
    public interface Valores { Double valor(String nombre); }

    private final String s;
    private int i;
    private final Valores v;

    private Formula(String s, Valores v) { this.s = s; this.v = v; }

    public static double calcular(String texto, Valores v) {
        if (texto == null) throw new Error("vacía");
        String t = texto.trim().replace(',', '.').replace('×', '*').replace('÷', '/').replace('−', '-');
        if (t.startsWith("=")) t = t.substring(1);
        if (t.isEmpty()) throw new Error("vacía");
        Formula f = new Formula(t, v);
        double r = f.comparacion();
        f.espacios();
        if (f.i < f.s.length()) throw new Error("sobra «" + f.s.substring(f.i) + "»");
        if (Double.isNaN(r) || Double.isInfinite(r)) throw new Error("no da un número");
        return r;
    }

    /** Si el texto es solo un número, lo devuelve; si no, null. */
    public static Double numero(String t) {
        if (t == null) return null;
        try { return Double.parseDouble(t.trim().replace(',', '.')); } catch (Exception e) { return null; }
    }

    /** ¿El texto usa este nombre? (para saber qué depende de qué) */
    public static boolean usa(String formula, String nombre) {
        if (formula == null || nombre == null || nombre.isEmpty()) return false;
        String f = plano(formula), n = plano(nombre);
        int k = 0;
        while ((k = f.indexOf(n, k)) >= 0) {
            boolean antes = k == 0 || !letra(f.charAt(k - 1));
            int fin = k + n.length();
            boolean despues = fin >= f.length() || !letra(f.charAt(fin));
            if (antes && despues) return true;
            k = fin;
        }
        return false;
    }

    public static String plano(String x) {
        return java.text.Normalizer.normalize(x.toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").trim().replace(' ', '_');
    }

    private static boolean letra(char c) { return Character.isLetterOrDigit(c) || c == '_'; }

    // ---------------- El calculador ----------------

    private void espacios() { while (i < s.length() && s.charAt(i) == ' ') i++; }

    private boolean ve(String x) {
        espacios();
        if (s.startsWith(x, i)) { i += x.length(); return true; }
        return false;
    }

    private double comparacion() {
        double a = suma();
        espacios();
        if (ve(">=")) return a >= suma() ? 1 : 0;
        if (ve("<=")) return a <= suma() ? 1 : 0;
        if (ve("<>")) return Math.abs(a - suma()) > 1e-9 ? 1 : 0;
        if (ve(">")) return a > suma() ? 1 : 0;
        if (ve("<")) return a < suma() ? 1 : 0;
        if (ve("=")) return Math.abs(a - suma()) <= 1e-9 ? 1 : 0;
        return a;
    }

    private double suma() {
        double a = producto();
        while (true) {
            if (ve("+")) a += producto();
            else if (ve("-")) a -= producto();
            else return a;
        }
    }

    private double producto() {
        double a = potencia();
        while (true) {
            if (ve("*")) a *= potencia();
            else if (ve("/")) {
                double b = potencia();
                if (Math.abs(b) < 1e-12) throw new Error("división por cero");
                a /= b;
            } else return a;
        }
    }

    private double potencia() {
        double a = unario();
        if (ve("^")) return Math.pow(a, potencia());
        return a;
    }

    private double unario() {
        if (ve("-")) return -unario();
        if (ve("+")) return unario();
        return atomo();
    }

    private double atomo() {
        espacios();
        if (i >= s.length()) throw new Error("falta un número");
        char c = s.charAt(i);
        if (c == '(') {
            i++;
            double r = comparacion();
            if (!ve(")")) throw new Error("falta cerrar el paréntesis");
            return r;
        }
        if (Character.isDigit(c) || c == '.') {
            int ini = i;
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) i++;
            try { return Double.parseDouble(s.substring(ini, i)); } catch (Exception e) { throw new Error("número mal escrito"); }
        }
        if (Character.isLetter(c) || c == '_') {
            int ini = i;
            while (i < s.length() && letra(s.charAt(i))) i++;
            String nom = s.substring(ini, i);
            espacios();
            if (i < s.length() && s.charAt(i) == '(') {
                i++;
                return funcion(plano(nom));
            }
            String p = plano(nom);
            if (p.equals("pi")) return Math.PI;
            Double val = v == null ? null : v.valor(p);
            if (val == null) throw new Error("no existe «" + nom + "»");
            return val;
        }
        throw new Error("no entiendo «" + c + "»");
    }

    private double[] argumentos() {
        java.util.List<Double> a = new java.util.ArrayList<>();
        espacios();
        if (ve(")")) return new double[0];
        while (true) {
            a.add(comparacion());
            if (ve(";")) continue;
            if (ve(")")) break;
            throw new Error("separe con ; y cierre el paréntesis");
        }
        double[] r = new double[a.size()];
        for (int k = 0; k < r.length; k++) r[k] = a.get(k);
        return r;
    }

    private double funcion(String f) {
        double[] a = argumentos();
        switch (f) {
            case "redondear": case "redondeo": case "red":
                if (a.length == 2) { double m = Math.pow(10, a[1]); return Math.round(a[0] * m) / m; }
                pide(a, 1, f); return Math.round(a[0]);
            case "arriba": case "redondear_arriba": case "redondear.mas": case "techo":
                if (a.length == 2 && a[1] != 0) return Math.ceil(a[0] / a[1] - 1e-9) * a[1];
                pide(a, 1, f); return Math.ceil(a[0] - 1e-9);
            case "abajo": case "redondear_abajo": case "entero": case "piso":
                if (a.length == 2 && a[1] != 0) return Math.floor(a[0] / a[1] + 1e-9) * a[1];
                pide(a, 1, f); return Math.floor(a[0] + 1e-9);
            case "min": { if (a.length == 0) throw new Error("min() vacío"); double m = a[0]; for (double x : a) m = Math.min(m, x); return m; }
            case "max": { if (a.length == 0) throw new Error("max() vacío"); double m = a[0]; for (double x : a) m = Math.max(m, x); return m; }
            case "si": pide(a, 3, f); return a[0] != 0 ? a[1] : a[2];
            case "raiz": pide(a, 1, f); if (a[0] < 0) throw new Error("raíz de negativo"); return Math.sqrt(a[0]);
            case "abs": pide(a, 1, f); return Math.abs(a[0]);
            case "sen": case "seno": pide(a, 1, f); return Math.sin(Math.toRadians(a[0]));
            case "cos": case "coseno": pide(a, 1, f); return Math.cos(Math.toRadians(a[0]));
            case "tan": pide(a, 1, f); return Math.tan(Math.toRadians(a[0]));
            case "atan": pide(a, 1, f); return Math.toDegrees(Math.atan(a[0]));
            case "suma": { double t = 0; for (double x : a) t += x; return t; }
            default: throw new Error("no conozco la función «" + f + "»");
        }
    }

    private static void pide(double[] a, int n, String f) {
        if (a.length != n) throw new Error(f + "() lleva " + n + (n == 1 ? " valor" : " valores separados por ;"));
    }

    /** Para mostrar: 3920 → "3920", 950.5 → "950.5". */
    public static String n(double x) {
        if (Math.abs(x - Math.round(x)) < 0.05) return String.valueOf(Math.round(x));
        return String.format(Locale.US, "%.1f", x);
    }

    /** Para los valores guardados en un mapa sencillo. */
    public static Valores de(Map<String, Double> m) { return k -> m.get(k); }
}
