package co.jose.miinventor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Dibujo en 3D (vista sin perspectiva, como los planos). Versión 2: un dedo corre la vista (o gira con 🔄,
 * o arrastra la pieza con ✋ Mover), dos dedos acercan y corren.
 * Tocar una pieza la escoge.
 */
public class Vista3D extends View {

    public interface AlEscoger { void escogida(int id); }
    /** Versión 2: el dedo arrastró la pieza escogida (mm en X, Y, Z). */
    public interface AlMover { void mover(int id, float dx, float dy, float dz); void soltar(); }

    /** Versión 2: 0 = un dedo corre la vista · 1 = un dedo gira (orbitar) · 2 = un dedo arrastra la pieza. */
    public static final int CORRER = 0, GIRAR = 1, MOVER = 2;
    public int modo = CORRER;
    public AlMover alMover;
    private float acX, acY, acZ;   // lo arrastrado que falta pasar (se pasa de 5 en 5 mm)

    public List<Pieza> piezas = new ArrayList<>();
    public int escogida = -1;
    public AlEscoger alEscoger;

    private float giro = -35, elev = 25;   // grados
    private float zoom = 1, panX, panY;
    private float escalaBase = 0.1f;
    private final float[] centro = {0, 0, 0};

    private final Paint pCara = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBorde = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTxt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pEje = new Paint(Paint.ANTI_ALIAS_FLAG);

    public Vista3D(Context c) {
        super(c);
        pBorde.setStyle(Paint.Style.STROKE);
        pBorde.setStrokeWidth(dp(0.8f));
        pBorde.setColor(0x66000000);
        pTxt.setTextSize(dp(12));
        pTxt.setFakeBoldText(true);
        pEje.setStrokeWidth(dp(2));
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    public void vista(float g, float e) { giro = g; elev = e; encuadrar(); }

    /** Pone todo el trabajo dentro de la pantalla. */
    public void encuadrar() {
        zoom = 1; panX = 0; panY = 0;
        float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, mx = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        Map<Integer, Pieza> mapa = mapa();
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] e = {s[0] + d[0] * p.largo, s[1] + d[1] * p.largo, s[2] + d[2] * p.largo};
            for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], Math.min(s[k], e[k])); mx[k] = Math.max(mx[k], Math.max(s[k], e[k])); }
        }
        if (piezas.isEmpty()) { mn = new float[]{0, 0, 0}; mx = new float[]{1000, 1000, 1000}; }
        for (int k = 0; k < 3; k++) centro[k] = (mn[k] + mx[k]) / 2f;
        float tam = Math.max(300, Math.max(mx[0] - mn[0], Math.max(mx[1] - mn[1], mx[2] - mn[2])));
        float lado = Math.min(getWidth(), getHeight());
        if (lado <= 0) lado = dp(300);
        escalaBase = lado * 0.62f / (tam * 1.15f);
        invalidate();
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        encuadrar();
    }

    // ---------------- Proyección ----------------

    private float cg, sg, ce, se, esc;

    private void prepararCamara() {
        double g = Math.toRadians(giro), e = Math.toRadians(elev);
        cg = (float) Math.cos(g); sg = (float) Math.sin(g);
        ce = (float) Math.cos(e); se = (float) Math.sin(e);
        esc = escalaBase * zoom;
    }

    /** Devuelve {x pantalla, y pantalla, profundidad}. */
    private float[] proyectar(float x, float y, float z) {
        x -= centro[0]; y -= centro[1]; z -= centro[2];
        float x1 = x * cg - y * sg;
        float y1 = x * sg + y * cg;
        float arriba = z * ce + y1 * se;
        float prof = y1 * ce - z * se;
        return new float[]{getWidth() / 2f + panX + x1 * esc, getHeight() / 2f + panY - arriba * esc, prof};
    }

    /** Qué tan de frente se ve una cara (para darle luz). */
    private float deFrente(float[] n) {
        float y1 = n[0] * sg + n[1] * cg;
        return y1 * ce - n[2] * se;   // negativo: mira hacia uno
    }

    private static class Cara {
        float[] xs, ys;
        float prof;
        int color;
        boolean borde = true;
    }

    private static float[] suma(float[] a, float[] b, float k) { return new float[]{a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k}; }

    private static float[] cruz(float[] a, float[] b) {
        return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static float[] unir(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return l < 1e-6 ? new float[]{0, 0, 1} : new float[]{v[0] / l, v[1] / l, v[2] / l};
    }

    /** Los ejes de la sección: s (ancho) y u (alto), perpendiculares a la pieza. */
    static float[][] ejes(Pieza p) {
        float[] d = p.direccion();
        float[] u;
        if (Math.abs(d[2]) < 0.95f) u = unir(new float[]{-d[0] * d[2], -d[1] * d[2], 1 - d[2] * d[2]});
        else u = unir(new float[]{-d[0] * d[1], 1 - d[1] * d[1], -d[2] * d[1]});
        float[] s = unir(cruz(d, u));
        for (int k = 0; k < (p.giro & 3); k++) { float[] ns = u; u = new float[]{-s[0], -s[1], -s[2]}; s = ns; }
        return new float[][]{d, s, u};
    }

    /** La forma de la sección, como uno o dos polígonos en (s, u). */
    static List<float[][]> seccion(Pieza p) {
        List<float[][]> r = new ArrayList<>();
        float a = p.a, b = p.b, t = Math.max(1, p.t);
        switch (p.tipo) {
            case 2: {
                int n = 12;
                float[][] pol = new float[n][2];
                for (int i = 0; i < n; i++) { double an = 2 * Math.PI * i / n; pol[i][0] = (float) Math.cos(an) * a / 2; pol[i][1] = (float) Math.sin(an) * a / 2; }
                r.add(pol);
                break;
            }
            case 3:
                r.add(rect(-a / 2, -b / 2, a / 2, -b / 2 + t));
                r.add(rect(-a / 2, -b / 2 + t, -a / 2 + t, b / 2));
                break;
            case 4:
                r.add(rect(-a / 2, -t / 2, a / 2, t / 2));
                break;
            default:
                r.add(rect(-a / 2, -b / 2, a / 2, b / 2));
        }
        return r;
    }

    private static float[][] rect(float s0, float u0, float s1, float u1) {
        return new float[][]{{s0, u0}, {s1, u0}, {s1, u1}, {s0, u1}};
    }

    // ---------------- Dibujo ----------------

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D1018);
        prepararCamara();
        Map<Integer, Pieza> mapa = mapa();
        List<Cara> caras = new ArrayList<>();
        for (Pieza p : piezas) armarCaras(p, mapa, caras);
        Collections.sort(caras, (x, y) -> Float.compare(y.prof, x.prof));
        Path path = new Path();
        for (Cara k : caras) {
            path.reset();
            path.moveTo(k.xs[0], k.ys[0]);
            for (int i = 1; i < k.xs.length; i++) path.lineTo(k.xs[i], k.ys[i]);
            path.close();
            pCara.setColor(k.color);
            c.drawPath(path, pCara);
            if (k.borde) c.drawPath(path, pBorde);
        }
        // nombres de las piezas
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] m = proyectar(s[0] + d[0] * p.largo / 2, s[1] + d[1] * p.largo / 2, s[2] + d[2] * p.largo / 2);
            String nom = p.nombre();
            float w = pTxt.measureText(nom);
            pCara.setColor(p.id == escogida ? 0xEEFFB300 : 0xCC263238);
            c.drawRoundRect(m[0] - w / 2 - dp(4), m[1] - dp(18), m[0] + w / 2 + dp(4), m[1] - dp(2), dp(4), dp(4), pCara);
            pTxt.setColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            c.drawText(nom, m[0] - w / 2, m[1] - dp(6), pTxt);
        }
        dibujarEjes(c);
    }

    private void armarCaras(Pieza p, Map<Integer, Pieza> mapa, List<Cara> caras) {
        float[][] e = ejes(p);
        float[] d = e[0], s = e[1], u = e[2];
        float[] ini = p.inicio(mapa, 0);
        float[] fin = suma(ini, d, p.largo);
        int base = p.id == escogida ? 0xFFFFB300 : p.tipo == 3 ? 0xFFEF9F27 : p.tipo == 4 ? 0xFF90A4AE : 0xFF5DCAA5;
        for (float[][] pol : seccion(p)) {
            int n = pol.length;
            float[][] a3 = new float[n][], b3 = new float[n][];
            for (int i = 0; i < n; i++) {
                float[] off = {s[0] * pol[i][0] + u[0] * pol[i][1], s[1] * pol[i][0] + u[1] * pol[i][1], s[2] * pol[i][0] + u[2] * pol[i][1]};
                a3[i] = suma(ini, off, 1);
                b3[i] = suma(fin, off, 1);
            }
            // costados
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float ms = (pol[i][0] + pol[j][0]) / 2, mu = (pol[i][1] + pol[j][1]) / 2;
                float[] nrm = unir(new float[]{s[0] * ms + u[0] * mu, s[1] * ms + u[1] * mu, s[2] * ms + u[2] * mu});
                agregar(caras, new float[][]{a3[i], a3[j], b3[j], b3[i]}, nrm, base, n <= 4);
            }
            // tapas
            agregar(caras, b3, d, base, true);
            float[][] inv = new float[n][];
            for (int i = 0; i < n; i++) inv[i] = a3[n - 1 - i];
            agregar(caras, inv, new float[]{-d[0], -d[1], -d[2]}, base, true);
        }
        // huecos: un parche oscuro sobre la cara
        float mitadA = p.tipo == 4 ? p.t / 2 : p.b / 2, mitadS = p.a / 2;
        for (Pieza.Hueco h : p.huecos) {
            float[] cara, nrm;
            float sobre;
            float[] lado1;
            switch (h.cara) {
                case 1: nrm = new float[]{-u[0], -u[1], -u[2]}; sobre = mitadA; lado1 = s; break;
                case 2: nrm = s; sobre = mitadS; lado1 = u; break;
                case 3: nrm = new float[]{-s[0], -s[1], -s[2]}; sobre = mitadS; lado1 = u; break;
                default: nrm = u; sobre = mitadA; lado1 = s;
            }
            if (p.tipo == 2) sobre = p.a / 2;
            float[] cen = suma(suma(ini, d, h.pos), nrm, sobre + 0.6f);
            float largoH = h.tipo == 2 ? h.d1 : h.d1, anchoH = h.tipo == 2 ? h.d2 : h.d1;
            int lados = h.tipo == 0 ? 10 : 4;
            float[][] pts = new float[lados][];
            for (int i = 0; i < lados; i++) {
                float ca, cb;
                if (h.tipo == 0) { double an = 2 * Math.PI * i / lados; ca = (float) Math.cos(an) * h.d1 / 2; cb = (float) Math.sin(an) * h.d1 / 2; }
                else { ca = (i == 0 || i == 3 ? -1 : 1) * largoH / 2; cb = (i < 2 ? -1 : 1) * anchoH / 2; }
                pts[i] = suma(suma(cen, d, ca), lado1, cb);
            }
            cara = null;
            Cara k = hacer(pts, nrm, 0xFF101010);
            if (k != null) { k.prof -= 1; k.borde = false; caras.add(k); }
        }
    }

    private void agregar(List<Cara> caras, float[][] pts, float[] nrm, int base, boolean borde) {
        float f = deFrente(nrm);
        if (f > 0.02f) return;   // no se ve: mira para el otro lado
        float luz = 0.45f + 0.55f * Math.min(1f, -f);
        int col = Color.rgb(Math.round(Color.red(base) * luz), Math.round(Color.green(base) * luz), Math.round(Color.blue(base) * luz));
        Cara k = hacer(pts, nrm, col);
        if (k != null) { k.borde = borde; caras.add(k); }
    }

    private Cara hacer(float[][] pts, float[] nrm, int col) {
        if (deFrente(nrm) > 0.02f) return null;
        Cara k = new Cara();
        k.xs = new float[pts.length];
        k.ys = new float[pts.length];
        float pr = 0;
        for (int i = 0; i < pts.length; i++) {
            float[] q = proyectar(pts[i][0], pts[i][1], pts[i][2]);
            k.xs[i] = q[0];
            k.ys[i] = q[1];
            pr += q[2];
        }
        k.prof = pr / pts.length;
        k.color = col;
        return k;
    }

    /** Las flechitas X (rojo), Y (verde), Z (azul) en la esquina. */
    private void dibujarEjes(Canvas c) {
        float ox = dp(34), oy = getHeight() - dp(34), L = dp(24);
        float[][] ejes = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int[] col = {0xFFEF5350, 0xFF66BB6A, 0xFF42A5F5};
        String[] nom = {"X", "Y", "Z"};
        for (int i = 0; i < 3; i++) {
            float x1 = ejes[i][0] * cg - ejes[i][1] * sg;
            float y1 = ejes[i][0] * sg + ejes[i][1] * cg;
            float arriba = ejes[i][2] * ce + y1 * se;
            pEje.setColor(col[i]);
            c.drawLine(ox, oy, ox + x1 * L, oy - arriba * L, pEje);
            pTxt.setColor(col[i]);
            c.drawText(nom[i], ox + x1 * (L + dp(6)) - dp(4), oy - arriba * (L + dp(6)) + dp(4), pTxt);
        }
    }

    // ---------------- Dedos ----------------

    private float x0, y0, ax, ay, d0, z0, px0, py0, mx0, my0;
    private boolean dos, movio;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = ax = e.getX(); y0 = ay = e.getY();
                dos = false; movio = false;
                acX = acY = acZ = 0;
                if (modo == MOVER) {
                    // se arrastra la pieza que está bajo el dedo (o la escogida)
                    int id = buscar(x0, y0);
                    if (id >= 0 && id != escogida) { escogida = id; invalidate(); if (alEscoger != null) alEscoger.escogida(id); }
                }
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dos = true;
                    d0 = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    z0 = zoom; px0 = panX; py0 = panY;
                    mx0 = (e.getX(0) + e.getX(1)) / 2; my0 = (e.getY(0) + e.getY(1)) / 2;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dos && e.getPointerCount() >= 2) {
                    float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    if (d0 > 0) zoom = Math.max(0.2f, Math.min(25f, z0 * d / d0));
                    panX = px0 + (e.getX(0) + e.getX(1)) / 2 - mx0;
                    panY = py0 + (e.getY(0) + e.getY(1)) / 2 - my0;
                    invalidate();
                    return true;
                }
                if (dos) return true;
                float dx = e.getX() - ax, dy = e.getY() - ay;
                if (Math.hypot(e.getX() - x0, e.getY() - y0) > dp(8)) movio = true;
                if (movio) {
                    if (modo == GIRAR) {
                        giro -= dx * 0.4f;
                        elev = Math.max(-89, Math.min(89, elev + dy * 0.4f));
                    } else if (modo == MOVER && escogida >= 0 && alMover != null) {
                        // de pantalla a mm: derecha de la pantalla y arriba de la pantalla
                        prepararCamara();
                        float kx = dx / esc, ky = -dy / esc;
                        acX += cg * kx + sg * se * ky;
                        acY += -sg * kx + cg * se * ky;
                        acZ += ce * ky;
                        float px = Math.round(acX / 5) * 5f, py = Math.round(acY / 5) * 5f, pz = Math.round(acZ / 5) * 5f;
                        if (px != 0 || py != 0 || pz != 0) { alMover.mover(escogida, px, py, pz); acX -= px; acY -= py; acZ -= pz; }
                    } else {
                        panX += dx;
                        panY += dy;
                    }
                    invalidate();
                }
                ax = e.getX(); ay = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
                if (!dos && !movio) tocar(e.getX(), e.getY());
                if (modo == MOVER && movio && alMover != null) alMover.soltar();
                return true;
        }
        return true;
    }

    /** Escoge la pieza más cercana al dedo. */
    private void tocar(float x, float y) {
        int mejor = buscar(x, y);
        escogida = mejor;
        invalidate();
        if (alEscoger != null) alEscoger.escogida(mejor);
    }

    /** La pieza más cercana al dedo (-1 si ninguna). */
    private int buscar(float x, float y) {
        prepararCamara();
        Map<Integer, Pieza> mapa = mapa();
        int mejor = -1;
        float dist = dp(36);
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] a = proyectar(s[0], s[1], s[2]);
            float[] b = proyectar(s[0] + d[0] * p.largo, s[1] + d[1] * p.largo, s[2] + d[2] * p.largo);
            float vx = b[0] - a[0], vy = b[1] - a[1];
            float l2 = vx * vx + vy * vy;
            float tt = l2 < 1 ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * vx + (y - a[1]) * vy) / l2));
            float dd = (float) Math.hypot(x - (a[0] + vx * tt), y - (a[1] + vy * tt));
            if (dd < dist) { dist = dd; mejor = p.id; }
        }
        return mejor;
    }
}
