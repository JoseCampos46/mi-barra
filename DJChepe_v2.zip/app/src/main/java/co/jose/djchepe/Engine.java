package co.jose.djchepe;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * El DJ en vivo con DOS platos que suenan de verdad al mismo tiempo.
 * El deslizador A–B (crossfader) decide cuánto suena cada uno.
 * Mezcla automática: cuando la canción va terminando, arranca la otra empatada en el golpe y pasa el deslizador solo.
 * Juguetes: frenar y soltar, devolver, repetir, tartamudeo, scratch, eco, salón grande, avión, filtro y bajos/medios/agudos.
 */
public final class Engine implements Runnable {

    public static final int SR = 44100;

    public static final class Deck {
        public final short[] d;
        public final int frames, sr;
        public final String name;
        public final float bpm;
        public final double firstBeat, lead, end;
        public final float[] wave; // picos cada 100 ms
        volatile double pos;
        volatile double rate = 1, rateTarget = 1;
        volatile boolean on;
        int delay;

        public Deck(String n, Dec.Pcm p) {
            name = n;
            d = p.d;
            frames = p.frames;
            sr = p.sr;
            double[] a = Beat.analyze(p.d, p.frames, p.sr);
            bpm = (float) a[0];
            firstBeat = a[1];
            lead = a[2];
            end = a[3];
            int bin = Math.max(1, sr / 10);
            int nb = Math.max(1, frames / bin);
            wave = new float[nb];
            for (int b = 0; b < nb; b++) {
                int m = 0;
                int s0 = b * bin * 2, s1 = Math.min(frames * 2, s0 + bin * 2);
                for (int k = s0; k < s1; k += 4) m = Math.max(m, Math.abs(d[k]));
                wave[b] = m / 32768f;
            }
        }

        public double lenSec() { return (double) frames / sr; }
        public double posSec() { return pos / sr; }
        public boolean isOn() { return on; }
        public double rate() { return rate; }
    }

    private final Object lock = new Object();
    private volatile boolean running = true, playing = false;
    private volatile Deck d0, d1;
    private final ConcurrentLinkedQueue<Runnable> jobs = new ConcurrentLinkedQueue<>();

    // deslizador A–B
    private volatile float xf = 0f;
    private int animDelay, animPos, animLen;
    private float animFrom, animTo;
    private boolean animating;
    private int fadeOutSlot = -1;
    public volatile float xfSec = 6f;
    public volatile boolean auto = true;

    // juguetes del plato que más suena
    private volatile boolean brakeHeld;
    private double bfac = 1;
    private int backLeft, backTotal;
    private volatile int loopBeats;
    private int loopSlot = -1;
    private double loopStart, loopLen;
    private int stutterLeft, stutterSlot = -1;
    private double stutterStart, stutterBeat;
    private int scratchLeft, scratchTotal, echoLeft;
    private final float[] dl = new float[SR * 2], dr = new float[SR * 2];
    private int di = 0, delayLen = SR / 2;

    // sonido general
    private final Fx.Biquad eqLo = new Fx.Biquad(), eqMid = new Fx.Biquad(), eqHi = new Fx.Biquad(), filt = new Fx.Biquad();
    private volatile float vLo, vMid, vHi, vFilt;
    private volatile int fxVersion = 1;
    private int fxSeen = 0;
    private final Fx.Reverb reverb = new Fx.Reverb();
    private final Fx.Flanger flanger = new Fx.Flanger();
    private volatile boolean reverbOn, flangerOn;
    private float revMix = 0f, flMix = 0f;

    // voz
    private volatile short[] voice;
    private int voicePos = -1;
    private volatile boolean voiceReq;
    private float duck = 1f;

    private final short[][] padData;
    private final ConcurrentLinkedQueue<Integer> padQueue = new ConcurrentLinkedQueue<>();
    private final ArrayList<int[]> padsOn = new ArrayList<>();
    private volatile Recorder rec;
    private final Thread th;

    public Engine(short[][] pads) {
        padData = pads;
        th = new Thread(this, "dj");
        th.setPriority(Thread.MAX_PRIORITY);
        th.start();
    }

    // ---------------- lo que la pantalla puede preguntar

    public Deck deck(int i) { return i == 0 ? d0 : d1; }
    private void setDeck(int i, Deck d) { if (i == 0) d0 = d; else d1 = d; }
    public float xf() { return xf; }
    /** El plato que más se oye. */
    public int main() { return xf < 0.5f ? 0 : 1; }
    public boolean isMixing() { return animating; }
    public boolean isPlaying() { return playing; }
    public boolean isRecording() { return rec != null; }
    public boolean hasVoice() { return voice != null; }
    public int loopBeats() { return loopBeats; }
    public boolean reverbOn() { return reverbOn; }
    public boolean flangerOn() { return flangerOn; }
    public float gain(int i) {
        double a = xf * Math.PI / 2;
        return (float) (i == 0 ? Math.cos(a) : Math.sin(a));
    }

    /** Plato libre para cargar la siguiente canción, o -1 si los dos están ocupados. */
    public int idleSlot() {
        if (animating) return -1;
        int m = main(), o = 1 - m;
        if (deck(m) == null) return m;
        Deck od = deck(o);
        if (od == null) return o;
        return -1;
    }

    // ---------------- órdenes desde la pantalla

    public void setVoice(short[] v) { voice = v; }
    public void play() { synchronized (lock) { playing = true; lock.notifyAll(); } }
    public void pause() { playing = false; }
    public void sonar() { voiceReq = true; if (!playing) play(); }

    /** Pone una canción en el plato (start = que arranque de una vez). */
    public void load(final int slot, final Deck d, final boolean start) {
        jobs.add(() -> {
            if (animating) return;
            d.pos = (start ? d.lead : d.firstBeat) * d.sr;
            d.rate = 1;
            d.rateTarget = 1;
            d.on = start;
            d.delay = 0;
            setDeck(slot, d);
            if (start) { xf = slot == 0 ? 0f : 1f; }
        });
    }

    /** Arranca o para un plato (tocando su disco). */
    public void toggleDeck(final int slot) {
        jobs.add(() -> {
            Deck d = deck(slot);
            if (d == null) return;
            d.on = !d.on;
            d.delay = 0;
            if (d.on && d.pos >= d.frames - 2) d.pos = d.lead * d.sr;
        });
        if (!playing) play();
    }

    public void setXf(final float v) {
        jobs.add(() -> { animating = false; fadeOutSlot = -1; xf = Math.max(0f, Math.min(1f, v)); });
    }

    public void mixNow() { jobs.add(this::startMix); if (!playing) play(); }

    public void brake(boolean down) { brakeHeld = down; }

    public void backspin() { jobs.add(() -> { backTotal = backLeft = (int) (SR * 0.75); }); }

    public void scratch() { jobs.add(() -> { scratchTotal = scratchLeft = (int) (SR * 0.9); }); }

    /** Repetir: 0 (apagado), 1, 2 o 4 golpes. */
    public void setLoop(final int beats) {
        loopBeats = beats;
        jobs.add(() -> {
            if (beats <= 0) { loopSlot = -1; return; }
            int m = main();
            Deck d = deck(m);
            if (d == null) { loopSlot = -1; return; }
            loopSlot = m;
            loopStart = d.pos;
            loopLen = beats * 60.0 / Math.max(60, d.bpm) * d.sr;
        });
    }

    public void stutter() {
        jobs.add(() -> {
            int m = main();
            Deck d = deck(m);
            if (d == null) return;
            stutterSlot = m;
            stutterStart = d.pos;
            stutterBeat = 60.0 / Math.max(60, d.bpm) * d.sr;
            stutterLeft = (int) (SR * 2.4);
        });
    }

    public void echo() {
        jobs.add(() -> {
            echoLeft = SR * 3;
            Deck c = deck(main());
            double beat = c != null ? 60.0 / (c.bpm * c.rate) : 0.5;
            delayLen = Math.max(2000, Math.min(SR * 2 - 1, (int) (SR * beat * 0.75)));
            di %= delayLen;
        });
    }

    public void setReverb(boolean on) { reverbOn = on; }
    public void setFlanger(boolean on) { flangerOn = on; }

    /** band 0 bajos, 1 medios, 2 agudos; v de -1 (quita) a 1 (sube). */
    public void setEq(int band, float v) {
        if (band == 0) vLo = v; else if (band == 1) vMid = v; else vHi = v;
        fxVersion++;
    }

    /** -1 quita bajos … 0 normal … 1 quita agudos. */
    public void setFilter(float v) { vFilt = v; fxVersion++; }

    public void pad(int i) {
        if (i == Synth.SCRATCH && deck(main()) != null && playing) { scratch(); return; }
        padQueue.add(i);
        if (!playing) play();
    }

    public void startRec(File f) throws Exception {
        if (rec != null) return;
        Recorder r = new Recorder(f);
        rec = r;
        r.start();
    }

    public File stopRec() {
        Recorder r = rec;
        rec = null;
        if (r == null) return null;
        r.stopAndWait();
        return r.file;
    }

    public void release() {
        running = false;
        synchronized (lock) { lock.notifyAll(); }
        stopRec();
    }

    // ---------------- motor

    @Override
    public void run() {
        int n = 1024;
        int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack at = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(Math.max(min, n * 4 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        short[] out = new short[n * 2];
        boolean trackPlaying = false;
        while (running) {
            if (!playing) {
                if (trackPlaying) { at.pause(); at.flush(); trackPlaying = false; }
                synchronized (lock) {
                    while (!playing && running) {
                        try { lock.wait(); } catch (InterruptedException ignored) {}
                    }
                }
                if (!running) break;
            }
            if (!trackPlaying) { at.play(); trackPlaying = true; }
            try {
                render(out, n);
            } catch (Throwable t) {
                java.util.Arrays.fill(out, (short) 0);
            }
            at.write(out, 0, n * 2);
            Recorder r = rec;
            if (r != null) r.feed(out.clone());
        }
        try { at.stop(); } catch (Exception ignored) {}
        at.release();
    }

    private float rl, rr;

    private void read(Deck d, double r, int slot) {
        double p = d.pos;
        int i = (int) p;
        if (i < 0) { i = 0; p = 0; }
        if (i + 1 >= d.frames) { rl = 0; rr = 0; d.pos = d.frames; return; }
        float t = (float) (p - i);
        int b = i * 2;
        rl = (d.d[b] + (d.d[b + 2] - d.d[b]) * t) / 32768f;
        rr = (d.d[b + 1] + (d.d[b + 3] - d.d[b + 1]) * t) / 32768f;
        double np = Math.max(0, p + r * d.sr / SR);
        if (slot == loopSlot && r > 0 && np >= loopStart + loopLen) np -= loopLen;
        if (slot == stutterSlot && stutterLeft > 0 && r > 0) {
            int el = (int) (SR * 2.4) - stutterLeft;
            double seg = stutterBeat / (1 << Math.min(3, el / (int) (SR * 0.6)));
            if (np >= stutterStart + seg) np = stutterStart;
        }
        d.pos = np;
    }

    private static double closeRatio(double r) {
        double best = r;
        for (double c : new double[]{r, r * 2, r / 2})
            if (Math.abs(c - 1) < Math.abs(best - 1)) best = c;
        return best;
    }

    /** Arranca el otro plato empatado en el golpe y pasa el deslizador solo. */
    private void startMix() {
        if (animating) return;
        int m = main(), o = 1 - m;
        Deck a = deck(m), b = deck(o);
        if (b == null) return;
        if (a == null || !a.on) {
            if (!b.on) { b.on = true; b.delay = 0; b.pos = b.lead * b.sr; }
            beginAnim(o, 0, SR / 3);
            return;
        }
        if (b.on) {
            // los dos ya suenan (usted arrancó el otro a mano): solo pasa el deslizador
            beginAnim(o, 0, Math.max(SR / 4, (int) (xfSec * SR)));
            return;
        }
        double ratio = closeRatio(a.bpm * a.rate / b.bpm);
        b.rate = (ratio > 0.92 && ratio < 1.08) ? ratio : 1.0;
        b.rateTarget = b.rate;
        double period = 60.0 / a.bpm;
        double t = a.posSec();
        double k = Math.ceil((t - a.firstBeat) / period + 0.001);
        double nextBeat = a.firstBeat + k * period;
        double delay = (nextBeat - t) / Math.max(0.05, a.rate);
        if (delay < 0.05) delay += period / Math.max(0.05, a.rate);
        b.pos = b.firstBeat * b.sr;
        b.delay = (int) (delay * SR);
        b.on = true;
        beginAnim(o, b.delay, Math.max(SR / 4, (int) (xfSec * SR)));
    }

    private void beginAnim(int toSlot, int delay, int len) {
        animFrom = xf;
        animTo = toSlot == 0 ? 0f : 1f;
        animDelay = delay;
        animPos = 0;
        animLen = Math.max(1, len);
        animating = true;
        fadeOutSlot = 1 - toSlot;
    }

    private void endAnim() {
        animating = false;
        xf = animTo;
        int s = fadeOutSlot;
        fadeOutSlot = -1;
        if (s >= 0) {
            Deck old = deck(s);
            if (old != null) old.on = false;
            setDeck(s, null); // libera la memoria; la pantalla carga la siguiente ahí
            if (loopSlot == s) { loopSlot = -1; loopBeats = 0; }
        }
        Deck c = deck(main());
        if (c != null) c.rateTarget = 1;
    }

    private void updateFx() {
        if (fxSeen == fxVersion) return;
        fxSeen = fxVersion;
        eqLo.lowShelf(180, vLo < 0 ? vLo * 26 : vLo * 6);
        eqMid.peak(1000, 0.8, vMid < 0 ? vMid * 20 : vMid * 6);
        eqHi.highShelf(5000, vHi < 0 ? vHi * 26 : vHi * 6);
        float f = vFilt;
        if (Math.abs(f) < 0.04f) filt.off();
        else if (f < 0) filt.highPass(20 * Math.pow(100, -f), 0.85);
        else filt.lowPass(20000 * Math.pow(0.012, f), 0.85);
    }

    private void render(short[] out, int n) {
        Runnable j;
        while ((j = jobs.poll()) != null) j.run();
        updateFx();
        int m = main(), o = 1 - m;
        Deck A = deck(m), B = deck(o);
        // mezcla automática cuando la canción que más suena va terminando
        if (auto && !animating && A != null && A.on && B != null && !B.on) {
            double remain = (A.end - A.posSec()) / Math.max(0.05, A.rate);
            if (remain <= xfSec + 0.6) startMix();
        }
        // si la que suena se acabó y no hay otra, se apaga
        if (!animating && A != null && A.on && A.pos >= A.frames - 2) {
            A.on = false;
            if (B != null && auto) startMix();
            else setDeck(m, null);
        }
        if (voiceReq) { voiceReq = false; if (voice != null) voicePos = 0; }
        Integer pq;
        while ((pq = padQueue.poll()) != null) padsOn.add(new int[]{pq, 0});
        boolean rv = reverbOn, fl = flangerOn;

        for (int i = 0; i < n; i++) {
            // deslizador automático
            if (animating) {
                if (animDelay > 0) animDelay--;
                else {
                    animPos++;
                    float t = Math.min(1f, (float) animPos / animLen);
                    xf = animFrom + (animTo - animFrom) * t;
                    if (animPos >= animLen) endAnim();
                }
            }
            int mm = xf < 0.5f ? 0 : 1;
            // freno y devolver (afectan el plato que más suena)
            if (brakeHeld) bfac = Math.max(0, bfac - 1.0 / (SR * 1.1));
            else if (bfac < 1) bfac = Math.min(1, bfac + 1.0 / (SR * 0.45));
            double back = 0;
            if (backLeft > 0) {
                double t = 1.0 - (double) backLeft / backTotal;
                back = -3.2 * (1 - t);
                backLeft--;
                if (backLeft == 0) bfac = 0;
            }
            double sf = 1;
            if (scratchLeft > 0) {
                double t = (double) (scratchTotal - scratchLeft) / SR;
                sf = 1 + 2.4 * Math.sin(2 * Math.PI * 3.4 * t);
                scratchLeft--;
            }
            if (stutterLeft > 0) { if (--stutterLeft == 0) stutterSlot = -1; }

            float L = 0, R = 0;
            double a = xf * Math.PI / 2;
            for (int s = 0; s < 2; s++) {
                Deck d = s == 0 ? d0 : d1;
                if (d == null || !d.on) continue;
                if (d.delay > 0) { d.delay--; continue; }
                double r = d.rate;
                if (s == mm) r = backLeft > 0 ? back : r * bfac * sf;
                read(d, r, s);
                float g = (float) (s == 0 ? Math.cos(a) : Math.sin(a));
                L += rl * g;
                R += rr * g;
            }
            // ecualizador y filtro
            L = filt.left(eqHi.left(eqMid.left(eqLo.left(L))));
            R = filt.right(eqHi.right(eqMid.right(eqLo.right(R))));
            // avión
            flMix += ((fl ? 1f : 0f) - flMix) * 0.0005f;
            if (flMix > 0.001f) {
                flanger.process(L, R);
                L = L * (1 - flMix) + flanger.outL * flMix;
                R = R * (1 - flMix) + flanger.outR * flMix;
            }
            // botonera
            for (int k = padsOn.size() - 1; k >= 0; k--) {
                int[] p = padsOn.get(k);
                short[] sp = padData[p[0]];
                if (p[1] >= sp.length) { padsOn.remove(k); continue; }
                float v = sp[p[1]++] / 32768f * 0.85f;
                L += v;
                R += v;
            }
            // eco que se va apagando
            float el = dl[di], er = dr[di];
            float inL = 0, inR = 0;
            if (echoLeft > 0) { inL = L; inR = R; echoLeft--; }
            dl[di] = inL + er * 0.45f;
            dr[di] = inR + el * 0.45f;
            if (++di >= delayLen) di = 0;
            L += el * 0.55f;
            R += er * 0.55f;
            // salón grande
            revMix += ((rv ? 1f : 0f) - revMix) * 0.0005f;
            if (revMix > 0.001f) {
                reverb.process((L + R) * 0.5f);
                L += reverb.outL * 0.35f * revMix;
                R += reverb.outR * 0.35f * revMix;
            }
            // su voz (ya viene con efectos de locutor): baja la música mientras habla
            float v = 0;
            if (voicePos >= 0) {
                short[] vo = voice;
                if (vo != null && voicePos < vo.length) v = vo[voicePos++] / 32768f;
                else voicePos = -1;
            }
            float duckT = voicePos >= 0 ? 0.3f : 1f;
            duck += (duckT - duck) * (duckT < duck ? 0.002f : 0.0004f);
            L = L * duck + v;
            R = R * duck + v;
            out[2 * i] = limit(L * 0.9f);
            out[2 * i + 1] = limit(R * 0.9f);
        }
        // después de empatar, vuelve suave a su velocidad normal
        Deck c = deck(main());
        if (c != null && !animating && Math.abs(c.rate - c.rateTarget) > 1e-4) {
            double stepR = (double) n / (SR * 10.0) * 0.08;
            double diff = c.rateTarget - c.rate;
            c.rate += Math.signum(diff) * Math.min(Math.abs(diff), stepR);
        }
    }

    /** Limitador suave: nunca rompe el sonido aunque esté muy alto. */
    private static short limit(float x) {
        float ax = Math.abs(x);
        if (ax > 0.85f) {
            float over = (ax - 0.85f) / 0.15f;
            ax = 0.85f + 0.15f * (float) Math.tanh(over);
            x = Math.signum(x) * ax;
        }
        return (short) (Math.max(-1f, Math.min(1f, x)) * 32767f);
    }

    // ---------------- grabar la mezcla

    static final class Recorder implements Runnable {
        final File file;
        final Aac aac;
        final LinkedBlockingQueue<short[]> q = new LinkedBlockingQueue<>();
        volatile boolean stop;
        Thread t;

        Recorder(File f) throws Exception { file = f; aac = new Aac(f, 192000); }

        void start() { t = new Thread(this, "grabar"); t.start(); }

        void feed(short[] b) { q.add(b); }

        void stopAndWait() {
            stop = true;
            try { t.join(15000); } catch (InterruptedException ignored) {}
        }

        @Override
        public void run() {
            try {
                while (!stop || !q.isEmpty()) {
                    short[] b = q.poll(100, TimeUnit.MILLISECONDS);
                    if (b != null) aac.write(b, 0, b.length / 2);
                }
            } catch (Exception ignored) {
            } finally {
                aac.finish();
            }
        }
    }
}
