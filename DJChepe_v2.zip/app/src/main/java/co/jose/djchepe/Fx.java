package co.jose.djchepe;

/** Efectos de sonido hechos aquí mismo: ecualizador, filtro, salón grande (reverberación), avión (flanger) y la voz de locutor. */
public final class Fx {

    /** Filtro de dos polos para dos canales (izquierdo y derecho). */
    public static final class Biquad {
        double b0 = 1, b1, b2, a1, a2;
        double l1, l2, r1, r2;
        boolean on;

        void set(double nb0, double nb1, double nb2, double a0, double na1, double na2) {
            b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0;
        }

        public void off() { on = false; }

        public void lowShelf(double f, double db) {
            double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), s = Math.sin(w);
            double al = s / 2 * Math.sqrt(2), sa = 2 * Math.sqrt(A) * al;
            set(A * ((A + 1) - (A - 1) * c + sa), 2 * A * ((A - 1) - (A + 1) * c), A * ((A + 1) - (A - 1) * c - sa),
                    (A + 1) + (A - 1) * c + sa, -2 * ((A - 1) + (A + 1) * c), (A + 1) + (A - 1) * c - sa);
            on = Math.abs(db) > 0.2;
        }

        public void highShelf(double f, double db) {
            double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), s = Math.sin(w);
            double al = s / 2 * Math.sqrt(2), sa = 2 * Math.sqrt(A) * al;
            set(A * ((A + 1) + (A - 1) * c + sa), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - sa),
                    (A + 1) - (A - 1) * c + sa, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - sa);
            on = Math.abs(db) > 0.2;
        }

        public void peak(double f, double q, double db) {
            double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), al = Math.sin(w) / (2 * q);
            set(1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
            on = Math.abs(db) > 0.2;
        }

        public void lowPass(double f, double q) {
            double w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), al = Math.sin(w) / (2 * q);
            set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al);
            on = true;
        }

        public void highPass(double f, double q) {
            double w = 2 * Math.PI * f / Engine.SR, c = Math.cos(w), al = Math.sin(w) / (2 * q);
            set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
            on = true;
        }

        public float left(float x) {
            if (!on) return x;
            double y = b0 * x + l1;
            l1 = b1 * x - a1 * y + l2;
            l2 = b2 * x - a2 * y;
            return (float) y;
        }

        public float right(float x) {
            if (!on) return x;
            double y = b0 * x + r1;
            r1 = b1 * x - a1 * y + r2;
            r2 = b2 * x - a2 * y;
            return (float) y;
        }
    }

    /** Salón grande: reverberación tipo Freeverb (8 peines y 4 pasa-todo). */
    public static final class Reverb {
        private final float[][] comb = new float[8][];
        private final int[] ci = new int[8];
        private final float[] cf = new float[8];
        private final float[][] ap = new float[4][];
        private final int[] ai = new int[4];
        public float room = 0.84f, damp = 0.25f;

        public Reverb() {
            int[] cl = {1116, 1188, 1277, 1356, 1139, 1211, 1300, 1379};
            for (int i = 0; i < 8; i++) comb[i] = new float[cl[i]];
            int[] al = {556, 441, 579, 464};
            for (int i = 0; i < 4; i++) ap[i] = new float[al[i]];
        }

        private float combAt(int k, float in) {
            float[] b = comb[k];
            float o = b[ci[k]];
            cf[k] = o * (1 - damp) + cf[k] * damp;
            b[ci[k]] = in + cf[k] * room;
            if (++ci[k] >= b.length) ci[k] = 0;
            return o;
        }

        private float apAt(int k, float in) {
            float[] b = ap[k];
            float o = b[ai[k]];
            b[ai[k]] = in + o * 0.5f;
            if (++ai[k] >= b.length) ai[k] = 0;
            return o - in;
        }

        public float outL, outR;

        public void process(float in) {
            in *= 0.015f;
            float l = 0, r = 0;
            for (int k = 0; k < 4; k++) l += combAt(k, in);
            for (int k = 4; k < 8; k++) r += combAt(k, in);
            l = apAt(0, l); l = apAt(1, l);
            r = apAt(2, r); r = apAt(3, r);
            outL = l * 3f;
            outR = r * 3f;
        }
    }

    /** Avión: retraso cortico que sube y baja. */
    public static final class Flanger {
        private final float[] bl = new float[2048], br = new float[2048];
        private int w;
        private double ph;

        public float outL, outR;

        public void process(float l, float r) {
            ph += 0.22 / Engine.SR;
            if (ph >= 1) ph -= 1;
            double d = (0.0008 + 0.0035 * (1 + Math.sin(2 * Math.PI * ph)) / 2) * Engine.SR;
            double rp = w - d;
            if (rp < 0) rp += bl.length;
            int i0 = (int) rp, i1 = (i0 + 1) % bl.length;
            float t = (float) (rp - i0);
            float dl = bl[i0] + (bl[i1] - bl[i0]) * t;
            float dr = br[i0] + (br[i1] - br[i0]) * t;
            bl[w] = l + dl * 0.55f;
            br[w] = r + dr * 0.55f;
            if (++w >= bl.length) w = 0;
            outL = (l + dl) * 0.6f;
            outR = (r + dr) * 0.6f;
        }
    }

    /**
     * Voz de locutor: limpia los bajos, le da brillo, la comprime para que suene fuerte y pareja,
     * le pone salón grande y eco que repite el final ("…Gallego… allego… llego").
     * eco: 0 = poquito, 1 = mucho.
     */
    public static short[] locutor(short[] in, float eco) {
        int n = in.length;
        if (n == 0) return in;
        float[] x = new float[n];
        Biquad hp = new Biquad();
        hp.highPass(95, 0.7);
        Biquad pres = new Biquad();
        pres.peak(3200, 1.0, 4.5);
        Biquad air = new Biquad();
        air.highShelf(9000, 2.5);
        float peak = 1e-6f;
        for (int i = 0; i < n; i++) {
            float v = in[i] / 32768f;
            v = air.left(pres.left(hp.left(v)));
            x[i] = v;
            peak = Math.max(peak, Math.abs(v));
        }
        for (int i = 0; i < n; i++) x[i] *= 0.5f / peak;
        // compresor: todo lo que pase de -20 dB se aplasta 4 a 1
        float env = 0, thr = 0.1f;
        float atk = (float) Math.exp(-1.0 / (0.004 * Engine.SR)), rel = (float) Math.exp(-1.0 / (0.15 * Engine.SR));
        peak = 1e-6f;
        for (int i = 0; i < n; i++) {
            float a = Math.abs(x[i]);
            env = a > env ? atk * env + (1 - atk) * a : rel * env + (1 - rel) * a;
            float g = env > thr ? (float) (thr * Math.pow(env / thr, 0.25) / env) : 1f;
            x[i] *= g;
            peak = Math.max(peak, Math.abs(x[i]));
        }
        for (int i = 0; i < n; i++) x[i] *= 0.9f / peak;

        eco = Math.max(0f, Math.min(1f, eco));
        int tail = (int) (Engine.SR * (1.5 + 2.5 * eco));
        int total = n + tail;
        float[] out = new float[total];
        int dLen = (int) (Engine.SR * 0.30);
        float[] dl = new float[dLen];
        int di = 0;
        float fb = 0.30f + 0.32f * eco, wetE = 0.35f + 0.45f * eco, wetR = 0.18f + 0.22f * eco;
        int endZone = (int) (Engine.SR * 0.9);
        Reverb rv = new Reverb();
        rv.room = 0.80f + 0.08f * eco;
        Biquad echoTone = new Biquad();
        echoTone.lowPass(4500, 0.7);
        peak = 1e-6f;
        for (int i = 0; i < total; i++) {
            float dry = i < n ? x[i] : 0f;
            // el eco toma sobre todo las últimas palabras
            float w = i < n - endZone ? 0.12f : 1f;
            float e = dl[di];
            dl[di] = echoTone.left(dry * w + e * fb);
            if (++di >= dLen) di = 0;
            rv.process(dry + e * 0.5f);
            float v = dry + e * wetE + (rv.outL + rv.outR) * 0.5f * wetR;
            out[i] = v;
            peak = Math.max(peak, Math.abs(v));
        }
        // corta el silencio del final del eco
        int last = total - 1;
        float floor = peak * 0.004f;
        while (last > n && Math.abs(out[last]) < floor) last--;
        short[] res = new short[last + 1];
        float k = 0.97f / peak;
        for (int i = 0; i <= last; i++) {
            float v = out[i] * k;
            if (i > last - 2000) v *= (last - i) / 2000f;
            res[i] = (short) Math.max(-32767, Math.min(32767, v * 32767f));
        }
        return res;
    }

    private Fx() {}
}
