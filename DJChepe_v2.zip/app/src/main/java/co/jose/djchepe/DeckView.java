package co.jose.djchepe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/** Los dos platos A y B: cada uno gira si está sonando y muestra cuánto se oye. Tocar un plato lo arranca o lo para. */
public class DeckView extends View {

    public interface OnDeck { void tap(int slot); }

    public final String[] name = {"—", "—"};
    public final float[] bpm = new float[2], gain = new float[2];
    public final boolean[] on = new boolean[2];
    public String center = "";
    public OnDeck onDeck;
    private final float[] angle = new float[2];
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private static final int[] COL = {0xFF5DCAA5, 0xFFEF9F27};

    public DeckView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        tp.setTypeface(Typeface.DEFAULT_BOLD);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF151515);
        c.drawRoundRect(0, 0, w, h, 10 * dp, 10 * dp, p);
        float r = Math.min(h * 0.30f, w * 0.17f);
        float cy = h * 0.38f;
        boolean anim = false;
        for (int s = 0; s < 2; s++) {
            float cx = s == 0 ? w * 0.24f : w * 0.76f;
            if (on[s]) { angle[s] += 9f; anim = true; }
            drawPlate(c, cx, cy, r, COL[s], angle[s], s == 0 ? "A" : "B", on[s]);
            tp.setColor(Color.WHITE);
            tp.setTextSize(12.5f * dp);
            CharSequence nm = TextUtils.ellipsize(name[s], tp, w * 0.44f, TextUtils.TruncateAt.END);
            float nw = tp.measureText(nm, 0, nm.length());
            c.drawText(nm, 0, nm.length(), cx - nw / 2f, cy + r + 17 * dp, tp);
            String info = (on[s] ? "🔊 " + Math.round(gain[s] * 100) + " %" : "⏸ parado")
                    + (bpm[s] > 0 ? String.format(Locale.US, " · ritmo %.0f", bpm[s]) : "");
            tp.setColor(COL[s]);
            float iw = tp.measureText(info);
            c.drawText(info, cx - iw / 2f, cy + r + 33 * dp, tp);
            // barra de cuánto suena
            float bx = cx - w * 0.18f, bw = w * 0.36f, by = cy + r + 40 * dp;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF333333);
            c.drawRoundRect(bx, by, bx + bw, by + 6 * dp, 3 * dp, 3 * dp, p);
            p.setColor(COL[s]);
            float g = on[s] ? gain[s] : 0;
            c.drawRoundRect(bx, by, bx + bw * g, by + 6 * dp, 3 * dp, 3 * dp, p);
        }
        tp.setColor(0xFFFAC775);
        tp.setTextSize(13 * dp);
        float cw = tp.measureText(center);
        c.drawText(center, (w - cw) / 2f, cy + 5 * dp, tp);
        if (anim) postInvalidateOnAnimation();
    }

    private void drawPlate(Canvas c, float cx, float cy, float r, int col, float ang, String letter, boolean active) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4 * dp);
        p.setColor(active ? col : 0xFF555555);
        c.drawCircle(cx, cy, r, p);
        p.setStrokeWidth(1 * dp);
        p.setColor(0x55FFFFFF);
        c.drawCircle(cx, cy, r * 0.72f, p);
        c.drawCircle(cx, cy, r * 0.5f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(active ? col : 0xFF555555);
        c.drawCircle(cx, cy, r * 0.26f, p);
        tp.setColor(0xFF111111);
        tp.setTextSize(r * 0.3f);
        float lw = tp.measureText(letter);
        c.drawText(letter, cx - lw / 2f, cy + r * 0.11f, tp);
        double a = Math.toRadians(ang);
        p.setColor(Color.WHITE);
        c.drawCircle(cx + (float) Math.cos(a) * r * 0.85f, cy + (float) Math.sin(a) * r * 0.85f, 3.5f * dp, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_UP && onDeck != null)
            onDeck.tap(e.getX() < getWidth() / 2f ? 0 : 1);
        return true;
    }
}
