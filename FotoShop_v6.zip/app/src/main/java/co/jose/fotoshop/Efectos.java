package co.jose.fotoshop;

/**
 * ChpFoto v6 — 🎨 Efectos: filtros, mejorar la foto, restaurar fotos viejas y caricatura.
 * Todo funciona en el celular, gratis y sin internet. Trabaja con los puntos de la foto (ARGB)
 * y respeta la transparencia de las capas recortadas.
 *
 * Regla de la caricatura: la CARA queda tal cual (idéntica a la foto), solo con la piel suave y
 * el color vivo; lo de caricatura va en el pelo, la ropa y el fondo.
 */
public final class Efectos {

    private Efectos() {}

    public static final String[] FILTROS = {"🌈 Vivo", "☀ Cálido", "❄ Frío", "📻 Vintage", "🎬 Cine", "⚫ Blanco y negro",
            "🟤 Sepia", "✨ Dorado", "☁ Sueño", "💥 Pop"};

    // ------------------------------------------------------------------ utilidades

    private static int cl(float v) { return v < 0 ? 0 : v > 255 ? 255 : (int) (v + 0.5f); }

    private static float[][] canales(int[] p) {
        int n = p.length;
        float[] r = new float[n], g = new float[n], b = new float[n];
        for (int i = 0; i < n; i++) {
            int c = p[i];
            r[i] = (c >> 16) & 255; g[i] = (c >> 8) & 255; b[i] = c & 255;
        }
        return new float[][]{r, g, b};
    }

    private static int[] juntar(int[] alfaDe, float[] r, float[] g, float[] b) {
        int n = alfaDe.length;
        int[] o = new int[n];
        for (int i = 0; i < n; i++) o[i] = (alfaDe[i] & 0xFF000000) | (cl(r[i]) << 16) | (cl(g[i]) << 8) | cl(b[i]);
        return o;
    }

    /** Mezcla «cuánto» del efecto con la foto original (0 = original, 1 = efecto completo). */
    private static int[] mezclar(int[] orig, int[] efecto, float cuanto) {
        if (cuanto >= 0.999f) return efecto;
        int n = orig.length;
        int[] o = new int[n];
        float k = Math.max(0, cuanto);
        for (int i = 0; i < n; i++) {
            int a = orig[i], e = efecto[i];
            int r = cl(((a >> 16) & 255) * (1 - k) + ((e >> 16) & 255) * k);
            int g = cl(((a >> 8) & 255) * (1 - k) + ((e >> 8) & 255) * k);
            int b = cl((a & 255) * (1 - k) + (e & 255) * k);
            o[i] = (a & 0xFF000000) | (r << 16) | (g << 8) | b;
        }
        return o;
    }

    /** Desenfoque rápido (caja, 2 pasadas ≈ gaussiano). */
    static float[] borroso(float[] src, int w, int h, int rad) {
        if (rad < 1) return src.clone();
        float[] a = src.clone(), t = new float[src.length];
        for (int pasada = 0; pasada < 2; pasada++) {
            for (int y = 0; y < h; y++) {
                int o = y * w;
                float s = 0; int cnt = 0;
                for (int x = -rad; x <= rad; x++) if (x >= 0 && x < w) { s += a[o + x]; cnt++; }
                for (int x = 0; x < w; x++) {
                    t[o + x] = s / cnt;
                    int xo = x - rad, xi = x + rad + 1;
                    if (xo >= 0) { s -= a[o + xo]; cnt--; }
                    if (xi < w) { s += a[o + xi]; cnt++; }
                }
            }
            for (int x = 0; x < w; x++) {
                float s = 0; int cnt = 0;
                for (int y = -rad; y <= rad; y++) if (y >= 0 && y < h) { s += t[y * w + x]; cnt++; }
                for (int y = 0; y < h; y++) {
                    a[y * w + x] = s / cnt;
                    int yo = y - rad, yi = y + rad + 1;
                    if (yo >= 0) { s -= t[yo * w + x]; cnt--; }
                    if (yi < h) { s += t[yi * w + x]; cnt++; }
                }
            }
        }
        return a;
    }

    private static float lum(float r, float g, float b) { return 0.299f * r + 0.587f * g + 0.114f * b; }

    /** Saturación: 1 = igual, >1 más color, 0 = gris. */
    private static void saturar(float[] r, float[] g, float[] b, int i, float s) {
        float l = lum(r[i], g[i], b[i]);
        r[i] = l + (r[i] - l) * s; g[i] = l + (g[i] - l) * s; b[i] = l + (b[i] - l) * s;
    }

    private static float percentil(float[] v, float q) {
        int[] hist = new int[256];
        for (float x : v) hist[Math.max(0, Math.min(255, (int) x))]++;
        int obj = (int) (v.length * q), acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc >= obj) return i; }
        return 255;
    }

    // ------------------------------------------------------------------ 🎨 Filtros

    public static int[] filtro(int[] p, int w, int h, int tipo, float cuanto) {
        float[][] c = canales(p);
        float[] r = c[0], g = c[1], b = c[2];
        int n = p.length;
        float cx = w / 2f, cy = h / 2f, dmax = (float) Math.sqrt(cx * cx + cy * cy);
        float[] brillo = null;
        if (tipo == 7 || tipo == 8) {
            float[] L = new float[n];
            for (int i = 0; i < n; i++) {
                float l = lum(r[i], g[i], b[i]);
                L[i] = tipo == 7 ? Math.max(0, l - 150) * 1.6f : l;
            }
            brillo = borroso(L, w, h, Math.max(3, Math.min(w, h) / 60));
        }
        for (int i = 0; i < n; i++) {
            float R = r[i], G = g[i], B = b[i];
            float l = lum(R, G, B);
            switch (tipo) {
                case 0: { // Vivo
                    r[i] = R; g[i] = G; b[i] = B; saturar(r, g, b, i, 1.45f);
                    r[i] = (r[i] - 128) * 1.1f + 128; g[i] = (g[i] - 128) * 1.1f + 128; b[i] = (b[i] - 128) * 1.1f + 128;
                    break;
                }
                case 1: r[i] = R * 1.08f + 6; g[i] = G * 1.02f + 2; b[i] = B * 0.88f; saturar(r, g, b, i, 1.12f); break;
                case 2: r[i] = R * 0.90f; g[i] = G * 1.0f + 2; b[i] = B * 1.08f + 8; break;
                case 3: { // Vintage: negros lavados, tono crema, viñeta
                    float sr = l * 1.05f + 20, sg = l * 0.95f + 14, sb = l * 0.78f + 8;
                    r[i] = R * 0.55f + sr * 0.45f; g[i] = G * 0.55f + sg * 0.45f; b[i] = B * 0.55f + sb * 0.45f;
                    r[i] = r[i] * 0.86f + 26; g[i] = g[i] * 0.86f + 22; b[i] = b[i] * 0.86f + 18;
                    break;
                }
                case 4: { // Cine: sombras verde-azuladas, luces naranja
                    float t = l / 255f;
                    r[i] = R + (t - 0.5f) * 40; g[i] = G + (0.5f - Math.abs(t - 0.5f)) * 6; b[i] = B - (t - 0.5f) * 44;
                    r[i] = (r[i] - 128) * 1.12f + 128; g[i] = (g[i] - 128) * 1.12f + 128; b[i] = (b[i] - 128) * 1.12f + 128;
                    break;
                }
                case 5: { float v = (l - 128) * 1.15f + 128; r[i] = v; g[i] = v; b[i] = v; break; }
                case 6: r[i] = l * 1.07f + 18; g[i] = l * 0.92f + 8; b[i] = l * 0.70f; break;
                case 7: { // Dorado con brillo
                    r[i] = R * 1.06f + 10 + brillo[i] * 0.55f; g[i] = G * 0.98f + 4 + brillo[i] * 0.42f; b[i] = B * 0.82f + brillo[i] * 0.12f;
                    break;
                }
                case 8: { // Sueño: brillo suave
                    float bb = brillo[i];
                    r[i] = 255 - (255 - R) * (255 - bb * 0.9f) / 255f; g[i] = 255 - (255 - G) * (255 - bb * 0.9f) / 255f; b[i] = 255 - (255 - B) * (255 - bb * 0.9f) / 255f;
                    r[i] = r[i] * 0.92f + 12; g[i] = g[i] * 0.92f + 10; b[i] = b[i] * 0.92f + 14;
                    break;
                }
                default: { // Pop
                    r[i] = R; g[i] = G; b[i] = B; saturar(r, g, b, i, 1.9f);
                    r[i] = Math.round(r[i] / 42f) * 42f; g[i] = Math.round(g[i] / 42f) * 42f; b[i] = Math.round(b[i] / 42f) * 42f;
                    break;
                }
            }
            if (tipo == 3 || tipo == 4 || tipo == 7) { // viñeta
                int x = i % w, y = i / w;
                float d = (float) Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / dmax;
                float v = 1 - 0.38f * Math.max(0, d - 0.45f) / 0.55f;
                r[i] *= v; g[i] *= v; b[i] *= v;
            }
        }
        return mezclar(p, juntar(p, r, g, b), cuanto);
    }

    // ------------------------------------------------------------------ ✨ Mejorar

    public static int[] mejorar(int[] p, int w, int h, float cuanto) {
        float[][] c = canales(p);
        float[] r = c[0], g = c[1], b = c[2];
        int n = p.length;
        // balance de blancos suave (mundo gris a medias)
        double sr = 0, sg = 0, sb = 0;
        for (int i = 0; i < n; i++) { sr += r[i]; sg += g[i]; sb += b[i]; }
        double m = (sr + sg + sb) / 3;
        float kr = (float) (1 + 0.5 * (m / Math.max(1, sr) - 1)), kg = (float) (1 + 0.5 * (m / Math.max(1, sg) - 1)), kb = (float) (1 + 0.5 * (m / Math.max(1, sb) - 1));
        float[] L = new float[n];
        for (int i = 0; i < n; i++) { r[i] *= kr; g[i] *= kg; b[i] *= kb; L[i] = lum(r[i], g[i], b[i]); }
        // niveles automáticos
        float lo = percentil(L, 0.005f), hi = percentil(L, 0.995f);
        float esc = 255f / Math.max(40, hi - lo);
        for (int i = 0; i < n; i++) {
            r[i] = (r[i] - lo) * esc; g[i] = (g[i] - lo) * esc; b[i] = (b[i] - lo) * esc;
            saturar(r, g, b, i, 1.15f);
        }
        enfocar(r, g, b, w, h, 0.6f);
        return mezclar(p, juntar(p, r, g, b), cuanto);
    }

    private static void enfocar(float[] r, float[] g, float[] b, int w, int h, float k) {
        float[] br = borroso(r, w, h, 2), bg = borroso(g, w, h, 2), bb = borroso(b, w, h, 2);
        for (int i = 0; i < r.length; i++) {
            r[i] += (r[i] - br[i]) * k; g[i] += (g[i] - bg[i]) * k; b[i] += (b[i] - bb[i]) * k;
        }
    }

    // ------------------------------------------------------------------ 📜 Foto vieja

    /** Busca lo que se sale mucho de sus vecinos (motas, rayones) y lo tapa con el color de alrededor. */
    private static float[][] limpiarMotas(float[] r, float[] g, float[] b, float[] L, int w, int h, float umbral) {
        int n = r.length;
        boolean[] malo = new boolean[n];
        float[] nueve = new float[9];
        for (int y = 1; y < h - 1; y++) for (int x = 1; x < w - 1; x++) {
            int k = 0;
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) nueve[k++] = L[(y + dy) * w + x + dx];
            java.util.Arrays.sort(nueve);
            if (Math.abs(L[y * w + x] - nueve[4]) > umbral) malo[y * w + x] = true;
        }
        // agrandar un poquito la marca para tapar todo el rayón
        boolean[] marca = malo.clone();
        for (int y = 1; y < h - 1; y++) for (int x = 1; x < w - 1; x++) if (malo[y * w + x]) {
            marca[y * w + x - 1] = true; marca[y * w + x + 1] = true; marca[(y - 1) * w + x] = true; marca[(y + 1) * w + x] = true;
        }
        float[] vr = new float[49], vg = new float[49], vb = new float[49];
        float[] r2 = r.clone(), g2 = g.clone(), b2 = b.clone();
        for (int y = 3; y < h - 3; y++) for (int x = 3; x < w - 3; x++) {
            int i = y * w + x;
            if (!marca[i]) continue;
            int k = 0;
            for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) {
                int j = i + dy * w + dx;
                if (marca[j]) continue;
                vr[k] = r[j]; vg[k] = g[j]; vb[k] = b[j]; k++;
            }
            if (k < 3) continue;
            java.util.Arrays.sort(vr, 0, k); java.util.Arrays.sort(vg, 0, k); java.util.Arrays.sort(vb, 0, k);
            r2[i] = vr[k / 2]; g2[i] = vg[k / 2]; b2[i] = vb[k / 2];
        }
        return new float[][]{r2, g2, b2};
    }


    public static int[] fotoVieja(int[] p, int w, int h, float cuanto) {
        int n = p.length;
        float[][] c = canales(p);
        float[] r = c[0], g = c[1], b = c[2];
        float[] L = new float[n];
        for (int i = 0; i < n; i++) L[i] = lum(r[i], g[i], b[i]);
        // 1. puntos, motas y rayones finos: dos pasadas
        for (int pasada = 0; pasada < 2; pasada++) {
            for (int i = 0; i < n; i++) L[i] = lum(r[i], g[i], b[i]);
            float[][] lim = limpiarMotas(r, g, b, L, w, h, 62 - 34 * cuanto - pasada * 6);
            r = lim[0]; g = lim[1]; b = lim[2];
        }
        // 2. quitar el grano (suave, respeta los bordes)
        float[] sr = borroso(r, w, h, 1), sg = borroso(g, w, h, 1), sb = borroso(b, w, h, 1);
        for (int i = 0; i < n; i++) {
            float d = Math.abs(r[i] - sr[i]) + Math.abs(g[i] - sg[i]) + Math.abs(b[i] - sb[i]);
            float k = cuanto * 0.75f * Math.max(0, 1 - d / 60f);
            r[i] += (sr[i] - r[i]) * k; g[i] += (sg[i] - g[i]) * k; b[i] += (sb[i] - b[i]) * k;
        }
        // 3. revivir el color: quita lo amarillo y lo desteñido canal por canal
        float[][] can = {r, g, b};
        for (float[] ch : can) {
            float lo = percentil(ch, 0.01f), hi = percentil(ch, 0.99f);
            float e = 255f / Math.max(40, hi - lo);
            for (int i = 0; i < n; i++) {
                float v = (ch[i] - lo) * e;
                ch[i] = ch[i] + (v - ch[i]) * cuanto;
            }
        }
        for (int i = 0; i < n; i++) {
            saturar(r, g, b, i, 1 + 0.35f * cuanto);
            r[i] = (r[i] - 128) * (1 + 0.08f * cuanto) + 128; g[i] = (g[i] - 128) * (1 + 0.08f * cuanto) + 128; b[i] = (b[i] - 128) * (1 + 0.08f * cuanto) + 128;
        }
        // 4. nitidez
        enfocar(r, g, b, w, h, 0.55f * cuanto);
        return juntar(p, r, g, b);
    }

    // ------------------------------------------------------------------ 🎭 Caricatura

    /** Cambia el tamaño de una imagen (bilineal). */
    static int[] tamano(int[] p, int w, int h, int nw, int nh) {
        int[] o = new int[nw * nh];
        float sx = (float) w / nw, sy = (float) h / nh;
        for (int y = 0; y < nh; y++) {
            float fy = (y + 0.5f) * sy - 0.5f; int y0 = Math.max(0, Math.min(h - 1, (int) Math.floor(fy))); int y1 = Math.min(h - 1, y0 + 1); float ty = Math.max(0, Math.min(1, fy - y0));
            for (int x = 0; x < nw; x++) {
                float fx = (x + 0.5f) * sx - 0.5f; int x0 = Math.max(0, Math.min(w - 1, (int) Math.floor(fx))); int x1 = Math.min(w - 1, x0 + 1); float tx = Math.max(0, Math.min(1, fx - x0));
                int a = p[y0 * w + x0], b = p[y0 * w + x1], c = p[y1 * w + x0], d = p[y1 * w + x1];
                int res = 0;
                for (int s = 0; s <= 24; s += 8) {
                    float va = (a >> s) & 255, vb = (b >> s) & 255, vc = (c >> s) & 255, vd = (d >> s) & 255;
                    float v = (va * (1 - tx) + vb * tx) * (1 - ty) + (vc * (1 - tx) + vd * tx) * ty;
                    res |= cl(v) << s;
                }
                o[y * nw + x] = res;
            }
        }
        return o;
    }

    static float[] tamano(float[] p, int w, int h, int nw, int nh) {
        float[] o = new float[nw * nh];
        float sx = (float) w / nw, sy = (float) h / nh;
        for (int y = 0; y < nh; y++) {
            float fy = (y + 0.5f) * sy - 0.5f; int y0 = Math.max(0, Math.min(h - 1, (int) Math.floor(fy))); int y1 = Math.min(h - 1, y0 + 1); float ty = Math.max(0, Math.min(1, fy - y0));
            for (int x = 0; x < nw; x++) {
                float fx = (x + 0.5f) * sx - 0.5f; int x0 = Math.max(0, Math.min(w - 1, (int) Math.floor(fx))); int x1 = Math.min(w - 1, x0 + 1); float tx = Math.max(0, Math.min(1, fx - x0));
                o[y * nw + x] = (p[y0 * w + x0] * (1 - tx) + p[y0 * w + x1] * tx) * (1 - ty) + (p[y1 * w + x0] * (1 - tx) + p[y1 * w + x1] * tx) * ty;
            }
        }
        return o;
    }

    /** Filtro de pintura (Kuwahara): deja zonas planas y bordes limpios. */
    private static void kuwahara(float[] r, float[] g, float[] b, int w, int h, int rad) {
        int W1 = w + 1, n1 = (w + 1) * (h + 1);
        double[] ir = new double[n1], ig = new double[n1], ib = new double[n1], il = new double[n1], il2 = new double[n1];
        for (int y = 0; y < h; y++) {
            double sr = 0, sg = 0, sb = 0, sl = 0, sl2 = 0;
            for (int x = 0; x < w; x++) {
                int i = y * w + x; float l = lum(r[i], g[i], b[i]);
                sr += r[i]; sg += g[i]; sb += b[i]; sl += l; sl2 += l * l;
                int j = (y + 1) * W1 + x + 1;
                ir[j] = ir[j - W1] + sr; ig[j] = ig[j - W1] + sg; ib[j] = ib[j - W1] + sb; il[j] = il[j - W1] + sl; il2[j] = il2[j - W1] + sl2;
            }
        }
        float[] or = new float[r.length], og = new float[r.length], ob = new float[r.length];
        int[][] q = {{-rad, 0, -rad, 0}, {0, rad, -rad, 0}, {-rad, 0, 0, rad}, {0, rad, 0, rad}};
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double mejor = Double.MAX_VALUE; double mr = 0, mg = 0, mb = 0;
            for (int[] qq : q) {
                int x0 = Math.max(0, x + qq[0]), x1 = Math.min(w - 1, x + qq[1]), y0 = Math.max(0, y + qq[2]), y1 = Math.min(h - 1, y + qq[3]);
                int A = y0 * W1 + x0, B = y0 * W1 + x1 + 1, C = (y1 + 1) * W1 + x0, D = (y1 + 1) * W1 + x1 + 1;
                double cnt = (x1 - x0 + 1) * (y1 - y0 + 1);
                double sl = il[D] - il[B] - il[C] + il[A], sl2 = il2[D] - il2[B] - il2[C] + il2[A];
                double var = sl2 / cnt - (sl / cnt) * (sl / cnt);
                if (var < mejor) {
                    mejor = var;
                    mr = (ir[D] - ir[B] - ir[C] + ir[A]) / cnt; mg = (ig[D] - ig[B] - ig[C] + ig[A]) / cnt; mb = (ib[D] - ib[B] - ib[C] + ib[A]) / cnt;
                }
            }
            int i = y * w + x; or[i] = (float) mr; og[i] = (float) mg; ob[i] = (float) mb;
        }
        System.arraycopy(or, 0, r, 0, r.length); System.arraycopy(og, 0, g, 0, g.length); System.arraycopy(ob, 0, b, 0, b.length);
    }

    private static void rgb2hsv(float r, float g, float b, float[] o) {
        float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b)), d = mx - mn, hh;
        if (d < 1e-6f) hh = 0;
        else if (mx == r) hh = ((g - b) / d) % 6;
        else if (mx == g) hh = (b - r) / d + 2;
        else hh = (r - g) / d + 4;
        hh *= 60; if (hh < 0) hh += 360;
        o[0] = hh; o[1] = mx <= 0 ? 0 : d / mx; o[2] = mx;
    }

    private static void hsv2rgb(float hh, float s, float v, float[] o) {
        float c = v * s, x = c * (1 - Math.abs((hh / 60) % 2 - 1)), m = v - c, r, g, b;
        if (hh < 60) { r = c; g = x; b = 0; } else if (hh < 120) { r = x; g = c; b = 0; } else if (hh < 180) { r = 0; g = c; b = x; }
        else if (hh < 240) { r = 0; g = x; b = c; } else if (hh < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
        o[0] = r + m; o[1] = g + m; o[2] = b + m;
    }

    /**
     * Caricatura con colores vivos de dibujos animados clásicos.
     * @param cara máscara 0..1 de la cara (misma medida de la foto) o null si no se encontró cara.
     * @param cuanto 0..1 fuerza de la caricatura; @param lineas 0..1 cuántas líneas negras.
     */
    public static int[] caricatura(int[] p, int w, int h, float[] cara, float cuanto, float lineas) {
        // 1. trabajar en pequeño (rápido) y luego volver al tamaño
        float esc = Math.min(1f, 760f / Math.max(w, h));
        int sw = Math.max(8, Math.round(w * esc)), sh = Math.max(8, Math.round(h * esc));
        int[] pq = tamano(p, w, h, sw, sh);
        float[][] c = canales(pq);
        float[] r = c[0], g = c[1], b = c[2];
        kuwahara(r, g, b, sw, sh, 3);
        kuwahara(r, g, b, sw, sh, 2);
        // 2. colores planos y vivos
        float[] hsv = new float[3], rgb = new float[3];
        int niveles = 5;
        for (int i = 0; i < r.length; i++) {
            rgb2hsv(r[i], g[i], b[i], hsv);
            float v = Math.round(hsv[2] / 255f * niveles) / (float) niveles * 255f * 0.85f + 38;
            float s = Math.min(1, hsv[1] * 1.55f + 0.04f);
            hsv2rgb(hsv[0], s, Math.min(255, v), rgb);
            r[i] = rgb[0]; g[i] = rgb[1]; b[i] = rgb[2];
        }
        // 3. líneas negras de contorno (Sobel sobre la imagen ya suavizada)
        float[] L = new float[r.length];
        for (int i = 0; i < L.length; i++) L[i] = lum(r[i], g[i], b[i]);
        L = borroso(L, sw, sh, 1);
        float[] borde = new float[L.length];
        float umbral = 60 - 40 * lineas;
        for (int y = 1; y < sh - 1; y++) for (int x = 1; x < sw - 1; x++) {
            int i = y * sw + x;
            float gx = -L[i - sw - 1] - 2 * L[i - 1] - L[i + sw - 1] + L[i - sw + 1] + 2 * L[i + 1] + L[i + sw + 1];
            float gy = -L[i - sw - 1] - 2 * L[i - sw] - L[i - sw + 1] + L[i + sw - 1] + 2 * L[i + sw] + L[i + sw + 1];
            float mag = (float) Math.sqrt(gx * gx + gy * gy) / 4f;
            borde[i] = Math.max(0, Math.min(1, (mag - umbral) / 12f));
        }
        // quitar puntitos sueltos
        float[] limpio = borde.clone();
        for (int y = 1; y < sh - 1; y++) for (int x = 1; x < sw - 1; x++) {
            int i = y * sw + x;
            if (borde[i] <= 0) continue;
            int vec = 0;
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if ((dx != 0 || dy != 0) && borde[i + dy * sw + dx] > 0.3f) vec++;
            if (vec < 2) limpio[i] = 0;
        }
        // 4. volver al tamaño de la foto
        float[] R = tamano(r, sw, sh, w, h), G = tamano(g, sw, sh, w, h), B = tamano(b, sw, sh, w, h);
        float[] E = tamano(limpio, sw, sh, w, h);
        float grosor = Math.max(1f, Math.max(w, h) / 900f);
        if (grosor > 1.2f) E = borroso(E, w, h, Math.round(grosor * 0.6f));
        int n = p.length;
        for (int i = 0; i < n; i++) {
            float e = Math.max(0, Math.min(1, (E[i] - 0.18f) * 3.2f));
            R[i] = R[i] * (1 - e) + 25 * e; G[i] = G[i] * (1 - e) + 20 * e; B[i] = B[i] * (1 - e) + 22 * e;
        }
        int[] dibujo = juntar(p, R, G, B);
        // 5. la CARA tal cual: piel suave y color vivo, sin deformar nada
        if (cara != null) {
            float[][] o = canales(p);
            float[] fr = o[0], fg = o[1], fb = o[2];
            int rad = Math.max(1, Math.round(Math.max(w, h) / 700f));
            float[] br = borroso(fr, w, h, rad), bg = borroso(fg, w, h, rad), bb = borroso(fb, w, h, rad);
            for (int i = 0; i < n; i++) {
                if (cara[i] <= 0.001f) continue;
                float d = Math.abs(fr[i] - br[i]) + Math.abs(fg[i] - bg[i]) + Math.abs(fb[i] - bb[i]);
                float k = 0.6f * Math.max(0, 1 - d / 45f);            // suaviza la piel, respeta ojos y boca
                fr[i] += (br[i] - fr[i]) * k; fg[i] += (bg[i] - fg[i]) * k; fb[i] += (bb[i] - fb[i]) * k;
                saturar(fr, fg, fb, i, 1.22f);
                fr[i] = fr[i] * 1.05f + 6; fg[i] = fg[i] * 1.05f + 6; fb[i] = fb[i] * 1.05f + 6;
                float m = cara[i];
                int dc = dibujo[i];
                float dr = (dc >> 16) & 255, dg = (dc >> 8) & 255, db = dc & 255;
                dibujo[i] = (p[i] & 0xFF000000) | (cl(dr * (1 - m) + fr[i] * m) << 16) | (cl(dg * (1 - m) + fg[i] * m) << 8) | cl(db * (1 - m) + fb[i] * m);
            }
        }
        return mezclar(p, dibujo, cuanto);
    }

    /** Suaviza el borde de la máscara de la cara para que no se note la unión. */
    public static float[] suavizarMascara(float[] m, int w, int h) {
        int rad = Math.max(2, Math.round(Math.min(w, h) / 90f));
        return borroso(m, w, h, rad);
    }
}
