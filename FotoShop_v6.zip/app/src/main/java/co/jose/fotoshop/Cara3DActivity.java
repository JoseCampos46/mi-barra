package co.jose.fotoshop;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.facemesh.FaceMesh;
import com.google.mlkit.vision.facemesh.FaceMeshDetection;
import com.google.mlkit.vision.facemesh.FaceMeshDetector;
import com.google.mlkit.vision.facemesh.FaceMeshDetectorOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 🗿 Cara 3D: con varias fotos de la misma persona (desde distintos ángulos) arma una máscara 3D
 * con sus rasgos, que se gira con el dedo, se guarda y se le sacan fotos en otras posturas.
 */
public class Cara3DActivity extends Activity {

    public static final String EXTRA_FOTO = "foto_cara3d";
    private static final int PEDIR_FOTOS = 21;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Bitmap> fotos = new ArrayList<>();
    private final List<Caras.Malla> mallas = new ArrayList<>();
    private Vista vista;
    private TextView estado;
    private String nombre = null;

    // el modelo armado
    private float[] F;            // 468 puntos 3D
    private int[] tri;            // triángulos
    private int[] fotoDe;         // de qué foto sale la piel de cada triángulo
    private float[] uv;           // dónde está cada triángulo en su foto (6 números por triángulo)
    private float frente = 1;     // signo de los triángulos que miran a la cámara
    private float cerca = 1;      // signo de la profundidad «hacia la cámara»

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF151A26);
        getWindow().setNavigationBarColor(0xFF151A26);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(0xFF151A26);
        col.setPadding(dp(4), dp(4), dp(4), dp(4));

        LinearLayout arriba = new LinearLayout(this);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        arriba.addView(icono("←", this::finish), new LinearLayout.LayoutParams(dp(44), -1));
        TextView t = new TextView(this);
        t.setText("🗿 Cara 3D · ChpFoto " + FotoShopActivity.VERSION);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        arriba.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
        arriba.addView(icono("✕", this::finish), new LinearLayout.LayoutParams(dp(44), -1));
        col.addView(arriba, new LinearLayout.LayoutParams(-1, dp(46)));

        estado = new TextView(this);
        estado.setTextColor(0xFFFFD54A);
        estado.setTextSize(13);
        estado.setPadding(dp(6), 0, dp(6), dp(4));
        estado.setText("1. Toque ➕ Fotos y escoja varias fotos de la MISMA persona: de frente, de medio lado a cada lado, un poco de arriba y de abajo.");
        col.addView(estado);

        vista = new Vista();
        col.addView(vista, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout f1 = new LinearLayout(this);
        f1.addView(boton("➕ Fotos", 0xFF00897B, this::pedirFotos), peso());
        f1.addView(boton("🔄 Armar", 0xFF1E88E5, this::detectarTodas), peso());
        f1.addView(boton("📸 Foto", 0xFFFB8C00, this::tomarFoto), peso());
        col.addView(f1, new LinearLayout.LayoutParams(-1, dp(50)));
        LinearLayout f2 = new LinearLayout(this);
        f2.addView(boton("💾 Guardar", 0xFF43A047, this::guardar), peso());
        f2.addView(boton("📂 Abrir", 0xFF5E35B1, this::abrir), peso());
        f2.addView(boton("⬇ OBJ / STL", 0xFF37474F, this::exportar), peso());
        f2.addView(boton("🎯 Centrar", 0xFF37474F, () -> vista.reiniciar()), peso());
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(46));
        p2.topMargin = dp(4);
        col.addView(f2, p2);
        setContentView(col);
    }

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String s, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView icono(String s, Runnable r) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // =====================================================================
    // Fotos y malla de cada una
    // =====================================================================

    private void pedirFotos() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(Intent.createChooser(i, "Escoja varias fotos de la misma persona"), PEDIR_FOTOS); }
        catch (Exception e) { aviso("No se pudo abrir la galería"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req != PEDIR_FOTOS || res != RESULT_OK || d == null) return;
        List<Uri> us = new ArrayList<>();
        ClipData cd = d.getClipData();
        if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) us.add(cd.getItemAt(i).getUri());
        else if (d.getData() != null) us.add(d.getData());
        estado.setText("Abriendo " + us.size() + " foto(s)…");
        new Thread(() -> {
            int ok = 0;
            for (Uri u : us) {
                try { Bitmap b = leer(u, 1280); synchronized (fotos) { fotos.add(b); } ok++; } catch (Throwable ignored) {}
            }
            final int n = ok;
            h.post(() -> {
                estado.setText("📷 " + fotos.size() + " foto(s) listas. Puede agregar más, o toque 🔄 Armar.");
                if (n > 0) detectarTodas();
            });
        }, "fotos3d").start();
    }

    private Bitmap leer(Uri u, int maximo) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int lado = Math.max(o.outWidth, o.outHeight), m = 1;
        while (lado / m > maximo * 2) m *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = m;
        Bitmap b;
        try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
        if (b == null) throw new Exception("sin imagen");
        int giro = 0;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            giro = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
        } catch (Exception ignored) {}
        float esc = Math.min(1f, (float) maximo / Math.max(b.getWidth(), b.getHeight()));
        Matrix mm = new Matrix();
        mm.postScale(esc, esc);
        if (giro != 0) mm.postRotate(giro);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mm, true);
    }

    /** Busca la cara en cada foto, una por una. */
    private void detectarTodas() {
        if (fotos.isEmpty()) { aviso("Primero toque ➕ Fotos"); return; }
        mallas.clear();
        final List<Bitmap> buenas = new ArrayList<>();
        FaceMeshDetector det;
        try {
            det = FaceMeshDetection.getClient(new FaceMeshDetectorOptions.Builder().setUseCase(FaceMeshDetectorOptions.FACE_MESH).build());
        } catch (Throwable t) { aviso("Este celular no pudo buscar caras"); return; }
        estado.setText("Buscando la cara en las fotos…");
        siguiente(det, 0, buenas);
    }

    private void siguiente(FaceMeshDetector det, int i, List<Bitmap> buenas) {
        if (i >= fotos.size()) {
            det.close();
            int malas = fotos.size() - buenas.size();
            fotos.clear();
            fotos.addAll(buenas);
            if (mallas.isEmpty()) { estado.setText("❌ No encontré la cara en ninguna foto. Use fotos claras, sin lentes oscuros, con la cara completa."); return; }
            estado.setText("Armando la cara con " + mallas.size() + " foto(s)…" + (malas > 0 ? " (" + malas + " sin cara clara, se dejaron por fuera)" : ""));
            new Thread(() -> {
                try {
                    armar();
                    h.post(() -> {
                        vista.reiniciar();
                        estado.setText("✔ Cara armada con " + mallas.size() + " foto(s). Un dedo la gira, dos dedos la acercan y la ladean. 📸 Foto saca la postura.");
                    });
                } catch (Throwable t) { h.post(() -> estado.setText("❌ No se pudo armar la cara")); }
            }, "armar3d").start();
            return;
        }
        Bitmap b = fotos.get(i);
        det.process(InputImage.fromBitmap(b, 0))
                .addOnSuccessListener(lista -> {
                    if (lista != null && !lista.isEmpty()) {
                        FaceMesh mejor = lista.get(0);
                        for (FaceMesh f : lista) if (f.getBoundingBox().width() > mejor.getBoundingBox().width()) mejor = f;
                        mallas.add(Caras.desde(mejor));
                        buenas.add(b);
                    }
                    estado.setText("Buscando la cara… " + (i + 1) + " de " + fotos.size());
                    siguiente(det, i + 1, buenas);
                })
                .addOnFailureListener(e -> siguiente(det, i + 1, buenas));
    }

    // =====================================================================
    // Armar el modelo combinando todas las fotos
    // =====================================================================

    private static float area2D(float[] p, int a, int b, int c) {
        return (p[b * 3] - p[a * 3]) * (p[c * 3 + 1] - p[a * 3 + 1]) - (p[b * 3 + 1] - p[a * 3 + 1]) * (p[c * 3] - p[a * 3]);
    }

    private static float area3D(float[] p, int a, int b, int c) {
        float ux = p[b * 3] - p[a * 3], uy = p[b * 3 + 1] - p[a * 3 + 1], uz = p[b * 3 + 2] - p[a * 3 + 2];
        float vx = p[c * 3] - p[a * 3], vy = p[c * 3 + 1] - p[a * 3 + 1], vz = p[c * 3 + 2] - p[a * 3 + 2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        return (float) Math.sqrt(nx * nx + ny * ny + nz * nz) + 1e-9f;
    }

    private void armar() {
        int nf = mallas.size();
        tri = mallas.get(0).tri;
        int nt = tri.length / 3;
        float[][] P = new float[nf][];
        float[][] cara = new float[nf][nt];     // qué tanto mira cada triángulo a la cámara en cada foto
        float[][] vis = new float[nf][468];      // qué tan bien se ve cada punto en cada foto
        float[] signo = new float[nf];
        int ref = 0;
        float mejor = -1e9f;
        for (int k = 0; k < nf; k++) {
            P[k] = Caras.normalizar(mallas.get(k));
            float suma = 0;
            for (int t = 0; t < nt; t++) suma += area2D(P[k], tri[t * 3], tri[t * 3 + 1], tri[t * 3 + 2]);
            signo[k] = suma >= 0 ? 1 : -1;
            float total = 0;
            int[] cuenta = new int[468];
            for (int t = 0; t < nt; t++) {
                int a = tri[t * 3], b = tri[t * 3 + 1], c = tri[t * 3 + 2];
                float f = signo[k] * area2D(P[k], a, b, c) / area3D(P[k], a, b, c);
                cara[k][t] = f;
                total += Math.max(0, f);
                vis[k][a] += f; vis[k][b] += f; vis[k][c] += f;
                cuenta[a]++; cuenta[b]++; cuenta[c]++;
            }
            for (int i = 0; i < 468; i++) vis[k][i] = Math.max(0.03f, Math.min(1f, cuenta[i] > 0 ? vis[k][i] / cuenta[i] : 0.03f));
            if (total > mejor) { mejor = total; ref = k; }
        }
        frente = signo[ref];
        // alinear todas con la foto más de frente y promediar, dando más peso a lo que mejor se ve
        float[] suma = new float[468 * 3];
        float[] pesos = new float[468];
        for (int k = 0; k < nf; k++) {
            float[] w = new float[468];
            for (int i = 0; i < 468; i++) w[i] = vis[k][i] * vis[ref][i];
            float[] A = k == ref ? P[k] : Caras.aplicar(Caras.rotacion(P[k], P[ref], w), P[k]);
            for (int i = 0; i < 468; i++) {
                float wi = vis[k][i] * vis[k][i];
                suma[i * 3] += A[i * 3] * wi; suma[i * 3 + 1] += A[i * 3 + 1] * wi; suma[i * 3 + 2] += A[i * 3 + 2] * wi;
                pesos[i] += wi;
            }
        }
        F = new float[468 * 3];
        for (int i = 0; i < 468; i++) for (int j = 0; j < 3; j++) F[i * 3 + j] = suma[i * 3 + j] / Math.max(1e-6f, pesos[i]);
        // la nariz está más cerca de la cámara: así se sabe qué es «adelante»
        float zm = 0;
        for (int i = 0; i < 468; i++) zm += F[i * 3 + 2];
        zm /= 468;
        cerca = (F[3 + 2] - zm) >= 0 ? 1 : -1;
        // la piel de cada triángulo sale de la foto donde mejor se ve
        fotoDe = new int[nt];
        uv = new float[nt * 6];
        for (int t = 0; t < nt; t++) {
            int k0 = 0;
            for (int k = 1; k < nf; k++) if (cara[k][t] > cara[k0][t]) k0 = k;
            fotoDe[t] = k0;
            Caras.Malla m = mallas.get(k0);
            for (int j = 0; j < 3; j++) { int i = tri[t * 3 + j]; uv[t * 6 + j * 2] = m.x[i]; uv[t * 6 + j * 2 + 1] = m.y[i]; }
        }
        vista.preparar();
    }

    // =====================================================================
    // La vista 3D
    // =====================================================================

    private class Vista extends View {
        float yaw = 0, pitch = 0, roll = 0, zoom = 1;
        Paint[] pinturas = new Paint[0];
        private float ax, ay, d0, a0, z0, r0;
        private boolean dos;

        Vista() {
            super(Cara3DActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void preparar() {
            Paint[] p = new Paint[fotos.size()];
            for (int k = 0; k < p.length; k++) {
                p[k] = new Paint(Paint.FILTER_BITMAP_FLAG);
                p[k].setShader(new BitmapShader(fotos.get(k), Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            }
            pinturas = p;
            postInvalidate();
        }

        void reiniciar() { yaw = 0; pitch = 0; roll = 0; zoom = 1; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(0xFF2A2F3A);
            if (F == null) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(0xFFB0BEC5);
                p.setTextSize(dp(15));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText("Aquí aparece la cara en 3D", getWidth() / 2f, getHeight() / 2f, p);
                return;
            }
            dibujar(c, getWidth(), getHeight(), true);
        }

        /** Dibuja la cara girada. */
        void dibujar(Canvas c, int w, int hh, boolean conFondo) {
            if (pinturas.length != fotos.size()) preparar();
            double a = Math.toRadians(yaw), t = Math.toRadians(pitch), r = Math.toRadians(roll);
            float ca = (float) Math.cos(a), sa = (float) Math.sin(a), ct = (float) Math.cos(t), st = (float) Math.sin(t);
            float cr = (float) Math.cos(r), sr = (float) Math.sin(r);
            float esc = Math.min(w, hh) * 0.36f * zoom;
            float[] Q = new float[468 * 3];
            for (int i = 0; i < 468; i++) {
                float X = F[i * 3], Y = F[i * 3 + 1], Z = F[i * 3 + 2];
                float X1 = X * ca + Z * sa, Z1 = -X * sa + Z * ca;
                float Y2 = Y * ct - Z1 * st, Z2 = Y * st + Z1 * ct;
                float X3 = X1 * cr - Y2 * sr, Y3 = X1 * sr + Y2 * cr;
                Q[i * 3] = w / 2f + X3 * esc;
                Q[i * 3 + 1] = hh / 2f + Y3 * esc;
                Q[i * 3 + 2] = Z2 * cerca;
            }
            int nt = tri.length / 3;
            Integer[] orden = new Integer[nt];
            float[] prof = new float[nt];
            int n = 0;
            for (int k = 0; k < nt; k++) {
                int i0 = tri[k * 3], i1 = tri[k * 3 + 1], i2 = tri[k * 3 + 2];
                float ar = (Q[i1 * 3] - Q[i0 * 3]) * (Q[i2 * 3 + 1] - Q[i0 * 3 + 1]) - (Q[i1 * 3 + 1] - Q[i0 * 3 + 1]) * (Q[i2 * 3] - Q[i0 * 3]);
                if (ar * frente <= 0) continue;      // mira hacia atrás: no se ve
                prof[k] = Q[i0 * 3 + 2] + Q[i1 * 3 + 2] + Q[i2 * 3 + 2];
                orden[n++] = k;
            }
            Integer[] vis = Arrays.copyOf(orden, n);
            Arrays.sort(vis, (x, y) -> Float.compare(prof[x], prof[y]));   // lo de atrás primero
            float[] v = new float[6], tx = new float[6];
            for (int k : vis) {
                // un poquito más grande para que no se vean rayitas entre triángulos
                float mx = 0, my = 0;
                for (int j = 0; j < 3; j++) { mx += Q[tri[k * 3 + j] * 3]; my += Q[tri[k * 3 + j] * 3 + 1]; }
                mx /= 3; my /= 3;
                for (int j = 0; j < 3; j++) {
                    int i = tri[k * 3 + j];
                    v[j * 2] = mx + (Q[i * 3] - mx) * 1.04f;
                    v[j * 2 + 1] = my + (Q[i * 3 + 1] - my) * 1.04f;
                    tx[j * 2] = uv[k * 6 + j * 2];
                    tx[j * 2 + 1] = uv[k * 6 + j * 2 + 1];
                }
                int f = fotoDe[k];
                if (f < pinturas.length) c.drawVertices(Canvas.VertexMode.TRIANGLES, 6, v, 0, tx, 0, null, 0, null, 0, 0, pinturas[f]);
            }
        }

        private float dist(MotionEvent e) { return (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)); }
        private float ang(MotionEvent e) { return (float) Math.toDegrees(Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))); }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: ax = e.getX(); ay = e.getY(); dos = false; return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (e.getPointerCount() == 2) { dos = true; d0 = dist(e); a0 = ang(e); z0 = zoom; r0 = roll; }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dos && e.getPointerCount() >= 2) {
                        zoom = Math.max(0.3f, Math.min(5f, z0 * dist(e) / Math.max(1, d0)));
                        roll = r0 + (ang(e) - a0);
                    } else if (!dos) {
                        yaw = Math.max(-75, Math.min(75, yaw + (e.getX() - ax) * 0.35f));
                        pitch = Math.max(-50, Math.min(50, pitch - (e.getY() - ay) * 0.35f));
                        ax = e.getX();
                        ay = e.getY();
                    }
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dos = false;
                    return true;
            }
            return true;
        }
    }

    // =====================================================================
    // Foto de la postura, guardar, abrir y exportar
    // =====================================================================

    private void tomarFoto() {
        if (F == null) { aviso("Primero arme la cara"); return; }
        Bitmap b = Bitmap.createBitmap(1400, 1400, Bitmap.Config.ARGB_8888);
        vista.dibujar(new Canvas(b), 1400, 1400, false);
        final Bitmap foto = recortar(b);
        new AlertDialog.Builder(this).setTitle("📸 Foto de esta postura")
                .setItems(new String[]{"➕ Ponerla en la hoja de ChpFoto (como capa)", "💾 Guardarla en Descargas/MiBarra/ChpFoto"}, (d, w) -> {
                    if (w == 0) {
                        try {
                            File f = new File(getCacheDir(), "cara3d_" + System.currentTimeMillis() + ".png");
                            try (FileOutputStream o = new FileOutputStream(f)) { foto.compress(Bitmap.CompressFormat.PNG, 100, o); }
                            setResult(RESULT_OK, new Intent().putExtra(EXTRA_FOTO, f.getPath()));
                            finish();
                        } catch (Exception e) { aviso("No se pudo pasar la foto"); }
                    } else {
                        try {
                            Uri u = nuevoArchivo("ChpFoto_Cara3D_" + fecha() + ".png", "image/png");
                            try (OutputStream o = getContentResolver().openOutputStream(u)) { foto.compress(Bitmap.CompressFormat.PNG, 100, o); }
                            aviso("✔ Guardada en Descargas/MiBarra/ChpFoto/Caras3D");
                        } catch (Exception e) { aviso("No se pudo guardar"); }
                    }
                }).show();
    }

    private static Bitmap recortar(Bitmap b) {
        int w = b.getWidth(), hh = b.getHeight();
        int[] px = new int[w * hh];
        b.getPixels(px, 0, w, 0, 0, w, hh);
        int x0 = w, y0 = hh, x1 = -1, y1 = -1;
        for (int y = 0; y < hh; y++) for (int x = 0; x < w; x++) if ((px[y * w + x] >>> 24) > 0) {
            x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y);
        }
        if (x1 < 0) return b;
        return Bitmap.createBitmap(b, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
    }

    private String fecha() { return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()); }

    private Uri nuevoArchivo(String nombre, String tipo) {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, tipo);
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/ChpFoto/Caras3D");
        return getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
    }

    private File carpeta() {
        File f = new File(getFilesDir(), "caras3d");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private void guardar() {
        if (F == null) { aviso("Primero arme la cara"); return; }
        EditText e = new EditText(this);
        e.setText(nombre != null ? nombre : "Cara " + new SimpleDateFormat("dd-MM HH.mm", Locale.US).format(new Date()));
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("💾 Nombre de la cara").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty()) n = "Cara";
                    nombre = n;
                    final String fin = n;
                    new Thread(() -> {
                        try {
                            File dir = new File(carpeta(), fin);
                            dir.mkdirs();
                            for (int k = 0; k < fotos.size(); k++)
                                try (FileOutputStream o = new FileOutputStream(new File(dir, "foto" + k + ".jpg"))) { fotos.get(k).compress(Bitmap.CompressFormat.JPEG, 88, o); }
                            JSONObject j = new JSONObject();
                            j.put("F", arr(F)); j.put("uv", arr(uv)); j.put("tri", arr(tri)); j.put("fotoDe", arr(fotoDe));
                            j.put("frente", frente); j.put("cerca", cerca); j.put("fotos", fotos.size());
                            try (FileWriter wr = new FileWriter(new File(dir, "modelo.json"))) { wr.write(j.toString()); }
                            h.post(() -> aviso("✔ Cara «" + fin + "» guardada. Se abre con 📂 Abrir"));
                        } catch (Throwable t) { h.post(() -> aviso("No se pudo guardar")); }
                    }, "guardar3d").start();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void abrir() {
        File[] dirs = carpeta().listFiles(File::isDirectory);
        if (dirs == null || dirs.length == 0) { aviso("Todavía no hay caras guardadas"); return; }
        Arrays.sort(dirs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        String[] nombres = new String[dirs.length];
        for (int i = 0; i < dirs.length; i++) nombres[i] = "🗿 " + dirs[i].getName();
        new AlertDialog.Builder(this).setTitle("📂 Caras guardadas").setItems(nombres, (d, w) -> {
            File dir = dirs[w];
            new AlertDialog.Builder(this).setTitle(dir.getName()).setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                if (w2 == 1) {
                    File[] hs = dir.listFiles();
                    if (hs != null) for (File x : hs) x.delete();
                    dir.delete();
                    aviso("Borrada");
                    return;
                }
                estado.setText("Abriendo…");
                new Thread(() -> {
                    try {
                        JSONObject j = new JSONObject(new String(Files.readAllBytes(new File(dir, "modelo.json").toPath()), StandardCharsets.UTF_8));
                        int nf = j.getInt("fotos");
                        List<Bitmap> fs = new ArrayList<>();
                        for (int k = 0; k < nf; k++) fs.add(BitmapFactory.decodeFile(new File(dir, "foto" + k + ".jpg").getPath()));
                        float[] F2 = farr(j.getJSONArray("F")), uv2 = farr(j.getJSONArray("uv"));
                        int[] tri2 = iarr(j.getJSONArray("tri")), fd2 = iarr(j.getJSONArray("fotoDe"));
                        float fr = (float) j.getDouble("frente"), ce = (float) j.getDouble("cerca");
                        h.post(() -> {
                            fotos.clear(); fotos.addAll(fs); mallas.clear();
                            F = F2; uv = uv2; tri = tri2; fotoDe = fd2; frente = fr; cerca = ce;
                            nombre = dir.getName();
                            vista.preparar();
                            vista.reiniciar();
                            estado.setText("✔ «" + nombre + "» abierta. Gírela y toque 📸 Foto.");
                        });
                    } catch (Throwable t) { h.post(() -> estado.setText("❌ No se pudo abrir")); }
                }, "abrir3d").start();
            }).show();
        }).show();
    }

    /** El archivo 3D: OBJ (para otros programas) y STL (para imprimir en 3D), en milímetros aproximados. */
    private void exportar() {
        if (F == null) { aviso("Primero arme la cara"); return; }
        new Thread(() -> {
            try {
                float mm = 60f;   // la cara queda de unos 15 cm de alto
                StringBuilder obj = new StringBuilder("# ChpFoto - Cara 3D\n");
                for (int i = 0; i < 468; i++)
                    obj.append(String.format(Locale.US, "v %.3f %.3f %.3f\n", F[i * 3] * mm, -F[i * 3 + 1] * mm, -F[i * 3 + 2] * mm * cerca));
                StringBuilder stl = new StringBuilder("solid cara\n");
                for (int t = 0; t < tri.length; t += 3) {
                    int a = tri[t], b, c;
                    if (frente > 0) { b = tri[t + 1]; c = tri[t + 2]; } else { b = tri[t + 2]; c = tri[t + 1]; }
                    obj.append("f ").append(a + 1).append(' ').append(b + 1).append(' ').append(c + 1).append('\n');
                    stl.append(" facet normal 0 0 0\n  outer loop\n");
                    for (int i : new int[]{a, b, c})
                        stl.append(String.format(Locale.US, "   vertex %.3f %.3f %.3f\n", F[i * 3] * mm, -F[i * 3 + 1] * mm, -F[i * 3 + 2] * mm * cerca));
                    stl.append("  endloop\n endfacet\n");
                }
                stl.append("endsolid cara\n");
                String base = "ChpFoto_Cara3D_" + (nombre != null ? nombre.replaceAll("[^A-Za-z0-9]", "") + "_" : "") + fecha();
                Uri u1 = nuevoArchivo(base + ".obj", "application/octet-stream");
                try (OutputStream o = getContentResolver().openOutputStream(u1)) { o.write(obj.toString().getBytes(StandardCharsets.UTF_8)); }
                Uri u2 = nuevoArchivo(base + ".stl", "application/octet-stream");
                try (OutputStream o = getContentResolver().openOutputStream(u2)) { o.write(stl.toString().getBytes(StandardCharsets.UTF_8)); }
                h.post(() -> aviso("✔ OBJ y STL guardados en Descargas/MiBarra/ChpFoto/Caras3D"));
            } catch (Throwable t) { h.post(() -> aviso("No se pudo exportar")); }
        }, "exportar3d").start();
    }

    private static JSONArray arr(float[] a) throws Exception { JSONArray j = new JSONArray(); for (float x : a) j.put((double) x); return j; }
    private static JSONArray arr(int[] a) { JSONArray j = new JSONArray(); for (int x : a) j.put(x); return j; }
    private static float[] farr(JSONArray j) throws Exception { float[] a = new float[j.length()]; for (int i = 0; i < a.length; i++) a[i] = (float) j.getDouble(i); return a; }
    private static int[] iarr(JSONArray j) throws Exception { int[] a = new int[j.length()]; for (int i = 0; i < a.length; i++) a[i] = j.getInt(i); return a; }
}
