package co.jose.fotoshop;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import org.json.JSONObject;

/**
 * Un texto que se puede volver a editar: el escrito y todo su estilo
 * (fuente, ancho, espaciado, color, degradado, borde, sombra, fondo, 3D, curva, inclinación y perspectiva).
 */
public class Texto {

    public static final String[] FUENTES = {"sans-serif", "sans-serif-condensed", "sans-serif-black", "sans-serif-medium",
            "sans-serif-light", "sans-serif-thin", "serif", "monospace", "serif-monospace", "casual", "cursive", "sans-serif-smallcaps"};
    public static final String[] NOMBRES_FUENTES = {"Normal", "Angosta", "Gruesa", "Media", "Delgada", "Fina", "Clásica",
            "Máquina", "Máquina 2", "A mano", "Cursiva", "Versalitas"};

    public String txt = "Texto";
    public String fuente = "sans-serif";
    public boolean negrita = true, cursiva = false, subrayado = false, tachado = false;
    public int alinear = 1;              // 0 izquierda, 1 centro, 2 derecha
    public float tam = 90;
    public float ancho = 1f;             // 0,5 angosta … 2 ancha
    public float espacio = 0f;           // entre letras
    public float interlineado = 1f;      // entre renglones
    public int color = Color.BLACK;
    public boolean degradado = false;
    public int color2 = 0xFF1E88E5;
    public float borde = 0;              // grosor del borde de la letra
    public int colorBorde = 0xFFE53935;
    public float sombra = 0;             // distancia de la sombra
    public float sombraBlur = 6;
    public int colorSombra = 0x99000000;
    public boolean fondo = false;
    public int colorFondo = Color.BLACK;
    public int opFondo = 255;
    public float redondeo = 12;
    public float margen = 18;
    public int prof3d = 0;
    public int color3d = 0xFF424242;
    public float curva = 0;              // -100 … 100 (arriba ∩ positivo, abajo ∪ negativo)
    public float inclinar = 0;           // -60 … 60
    public float perspectiva = 0;        // -60 … 60 (% de lo que se achica arriba)

    public Texto copia() {
        Texto t = new Texto();
        try { t.cargar(guardar(true)); } catch (Exception ignored) {}
        return t;
    }

    /** Copia solo el estilo (no el escrito). */
    public void ponerEstilo(Texto otro) {
        String guardado = txt;
        try { cargar(otro.guardar(false)); } catch (Exception ignored) {}
        txt = guardado;
    }

    public JSONObject guardar(boolean conTexto) {
        JSONObject j = new JSONObject();
        try {
            if (conTexto) j.put("txt", txt);
            j.put("fuente", fuente); j.put("neg", negrita); j.put("cur", cursiva); j.put("sub", subrayado); j.put("tac", tachado);
            j.put("ali", alinear); j.put("tam", tam); j.put("ancho", ancho); j.put("esp", espacio); j.put("inter", interlineado);
            j.put("color", color); j.put("deg", degradado); j.put("color2", color2);
            j.put("borde", borde); j.put("cBorde", colorBorde);
            j.put("sombra", sombra); j.put("sBlur", sombraBlur); j.put("cSombra", colorSombra);
            j.put("fondo", fondo); j.put("cFondo", colorFondo); j.put("opFondo", opFondo); j.put("red", redondeo); j.put("marg", margen);
            j.put("p3d", prof3d); j.put("c3d", color3d);
            j.put("curva", curva); j.put("incl", inclinar); j.put("persp", perspectiva);
        } catch (Exception ignored) {}
        return j;
    }

    public void cargar(JSONObject j) {
        txt = j.optString("txt", txt);
        fuente = j.optString("fuente", fuente);
        negrita = j.optBoolean("neg", negrita); cursiva = j.optBoolean("cur", cursiva);
        subrayado = j.optBoolean("sub", subrayado); tachado = j.optBoolean("tac", tachado);
        alinear = j.optInt("ali", alinear); tam = (float) j.optDouble("tam", tam); ancho = (float) j.optDouble("ancho", ancho);
        espacio = (float) j.optDouble("esp", espacio); interlineado = (float) j.optDouble("inter", interlineado);
        color = j.optInt("color", color); degradado = j.optBoolean("deg", degradado); color2 = j.optInt("color2", color2);
        borde = (float) j.optDouble("borde", borde); colorBorde = j.optInt("cBorde", colorBorde);
        sombra = (float) j.optDouble("sombra", sombra); sombraBlur = (float) j.optDouble("sBlur", sombraBlur); colorSombra = j.optInt("cSombra", colorSombra);
        fondo = j.optBoolean("fondo", fondo); colorFondo = j.optInt("cFondo", colorFondo); opFondo = j.optInt("opFondo", opFondo);
        redondeo = (float) j.optDouble("red", redondeo); margen = (float) j.optDouble("marg", margen);
        prof3d = j.optInt("p3d", prof3d); color3d = j.optInt("c3d", color3d);
        curva = (float) j.optDouble("curva", curva); inclinar = (float) j.optDouble("incl", inclinar); perspectiva = (float) j.optDouble("persp", perspectiva);
    }

    // =====================================================================
    // Dibujar
    // =====================================================================

    private Paint pintura() {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        int estilo = (negrita ? Typeface.BOLD : 0) | (cursiva ? Typeface.ITALIC : 0);
        p.setTypeface(Typeface.create(fuente, estilo));
        p.setTextSize(Math.max(8, tam));
        p.setTextScaleX(Math.max(0.3f, ancho));
        p.setLetterSpacing(espacio);
        p.setUnderlineText(subrayado);
        p.setStrikeThruText(tachado);
        return p;
    }

    /** El texto como imagen, recortada justo a lo que se ve. */
    public Bitmap dibujar() {
        String[] lineas = (txt == null || txt.isEmpty() ? " " : txt).split("\n", -1);
        Paint p = pintura();
        Paint.FontMetrics fm = p.getFontMetrics();
        float altoLinea = (fm.descent - fm.ascent) * Math.max(0.5f, interlineado);
        float[] anchos = new float[lineas.length];
        float maxAncho = 1;
        for (int i = 0; i < lineas.length; i++) { anchos[i] = p.measureText(lineas[i]); maxAncho = Math.max(maxAncho, anchos[i]); }
        float extra = borde + Math.abs(sombra) + sombraBlur * 2 + prof3d * 1.2f + tam * 0.3f + 4;
        boolean curvo = Math.abs(curva) >= 3;

        int W, H;
        float ox, oy;          // dónde va el primer renglón (recto) o el centro del arco (curvo)
        float R = 0, ang = 0;
        if (!curvo) {
            W = Math.round(maxAncho + extra * 2);
            H = Math.round(altoLinea * lineas.length + extra * 2);
            ox = extra;
            oy = extra - fm.ascent;
        } else {
            ang = (float) Math.toRadians(Math.abs(curva) / 100f * 330f);
            R = Math.max(tam, maxAncho / ang);
            float medio = ang / 2f;
            float bw = (float) (2 * R * Math.sin(Math.min(medio, Math.PI / 2)));
            float bh = (float) (R * (1 - Math.cos(Math.min(medio, Math.PI))));
            float bloque = altoLinea * lineas.length;
            W = Math.round(bw + 2 * (bloque + extra + tam));
            H = Math.round(bh + 2 * (bloque + extra + tam));
            ox = W / 2f;
            oy = curva > 0 ? (bloque + extra + tam) + R : H - (bloque + extra + tam) - R;
        }
        W = Math.max(4, Math.min(W, 3600));
        H = Math.max(4, Math.min(H, 3600));
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);

        // 1. 3D: copias corridas hacia abajo y a la derecha
        if (prof3d > 0) {
            Paint p3 = pintura();
            p3.setColor(color3d);
            Paint p3b = null;
            if (borde > 0) { p3b = pintura(); p3b.setStyle(Paint.Style.STROKE); p3b.setStrokeWidth(borde * 2); p3b.setStrokeJoin(Paint.Join.ROUND); p3b.setColor(color3d); }
            for (int k = prof3d; k >= 1; k--) {
                if (p3b != null) escribir(c, p3b, lineas, anchos, maxAncho, altoLinea, ox + k * 0.6f, oy + k, curvo, R, ang);
                escribir(c, p3, lineas, anchos, maxAncho, altoLinea, ox + k * 0.6f, oy + k, curvo, R, ang);
            }
        }
        // 2. Sombra
        if (sombra != 0) {
            Paint ps = pintura();
            ps.setColor(colorSombra);
            if (sombraBlur > 0) ps.setMaskFilter(new BlurMaskFilter(sombraBlur, BlurMaskFilter.Blur.NORMAL));
            if (borde > 0) { ps.setStyle(Paint.Style.FILL_AND_STROKE); ps.setStrokeWidth(borde * 2); ps.setStrokeJoin(Paint.Join.ROUND); }
            escribir(c, ps, lineas, anchos, maxAncho, altoLinea, ox + sombra, oy + sombra, curvo, R, ang);
        }
        // 3. Borde de la letra
        if (borde > 0) {
            Paint pb = pintura();
            pb.setStyle(Paint.Style.STROKE);
            pb.setStrokeWidth(borde * 2);
            pb.setStrokeJoin(Paint.Join.ROUND);
            pb.setColor(colorBorde);
            escribir(c, pb, lineas, anchos, maxAncho, altoLinea, ox, oy, curvo, R, ang);
        }
        // 4. La letra (color o degradado)
        Paint pr = pintura();
        pr.setColor(color);
        if (degradado) pr.setShader(new LinearGradient(0, curvo ? 0 : oy + fm.ascent, 0, curvo ? H : oy + fm.ascent + altoLinea * lineas.length,
                color, color2, Shader.TileMode.CLAMP));
        escribir(c, pr, lineas, anchos, maxAncho, altoLinea, ox, oy, curvo, R, ang);

        Bitmap out = recortar(b);

        // 5. Fondo detrás del texto
        if (fondo) {
            int m = Math.round(margen);
            Bitmap conFondo = Bitmap.createBitmap(out.getWidth() + 2 * m, out.getHeight() + 2 * m, Bitmap.Config.ARGB_8888);
            Canvas cf = new Canvas(conFondo);
            Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
            pf.setColor(colorFondo);
            pf.setAlpha(opFondo);
            cf.drawRoundRect(new RectF(0, 0, conFondo.getWidth(), conFondo.getHeight()), redondeo, redondeo, pf);
            cf.drawBitmap(out, m, m, null);
            out = conFondo;
        }
        // 6. Inclinar y perspectiva
        if (inclinar != 0 || perspectiva != 0) out = deformar(out);
        return out;
    }

    /** Escribe todos los renglones, rectos o en arco. */
    private void escribir(Canvas c, Paint p, String[] lineas, float[] anchos, float maxAncho, float altoLinea,
                          float ox, float oy, boolean curvo, float R, float ang) {
        for (int i = 0; i < lineas.length; i++) {
            if (!curvo) {
                float x = ox;
                if (alinear == 1) x = ox + (maxAncho - anchos[i]) / 2f;
                else if (alinear == 2) x = ox + (maxAncho - anchos[i]);
                c.drawText(lineas[i], x, oy + i * altoLinea, p);
            } else {
                float r = curva > 0 ? R - i * altoLinea : R + i * altoLinea;
                if (r < 4) continue;
                Path arco = new Path();
                RectF ov = new RectF(ox - r, oy - r, ox + r, oy + r);
                float grados = (float) Math.toDegrees(Math.max(ang, anchos[i] / r));
                grados = Math.min(grados, 359f);
                if (curva > 0) arco.addArc(ov, 270 - grados / 2f, grados);
                else arco.addArc(ov, 90 + grados / 2f, -grados);
                float largo = (float) Math.toRadians(grados) * r;
                c.drawTextOnPath(lineas[i], arco, Math.max(0, (largo - anchos[i]) / 2f), 0, p);
            }
        }
    }

    /** Quita lo transparente de los lados. */
    private static Bitmap recortar(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if ((px[y * w + x] >>> 24) > 0) {
                    if (x < x0) x0 = x;
                    if (x > x1) x1 = x;
                    if (y < y0) y0 = y;
                    if (y > y1) y1 = y;
                }
        if (x1 < 0) return Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888);
        x0 = Math.max(0, x0 - 2); y0 = Math.max(0, y0 - 2);
        x1 = Math.min(w - 1, x1 + 2); y1 = Math.min(h - 1, y1 + 2);
        return Bitmap.createBitmap(b, x0, y0, x1 - x0 + 1, y1 - y0 + 1).copy(Bitmap.Config.ARGB_8888, true);
    }

    /** Inclinar (como cursiva grande) y perspectiva (más angosto arriba o abajo). */
    private Bitmap deformar(Bitmap b) {
        float w = b.getWidth(), h = b.getHeight();
        float s = (float) Math.tan(Math.toRadians(inclinar)) * h;
        float p = Math.abs(perspectiva) / 100f * w / 2f;
        float[] src = {0, 0, w, 0, w, h, 0, h};
        float[] dst;
        if (perspectiva >= 0) dst = new float[]{p + s, 0, w - p + s, 0, w, h, 0, h};
        else dst = new float[]{s, 0, w + s, 0, w - p, h, p, h};
        float minX = Math.min(Math.min(dst[0], dst[6]), 0), maxX = Math.max(Math.max(dst[2], dst[4]), w);
        for (int i = 0; i < 8; i += 2) dst[i] -= minX;
        Matrix m = new Matrix();
        m.setPolyToPoly(src, 0, dst, 0, 4);
        Bitmap out = Bitmap.createBitmap(Math.max(4, Math.round(maxX - minX)), Math.max(4, Math.round(h)), Bitmap.Config.ARGB_8888);
        new Canvas(out).drawBitmap(b, m, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return recortar(out);
    }
}
