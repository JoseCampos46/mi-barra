package co.jose.fotoshop;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

import com.google.mlkit.vision.common.PointF3D;
import com.google.mlkit.vision.common.Triangle;
import com.google.mlkit.vision.facemesh.FaceMesh;
import com.google.mlkit.vision.facemesh.FaceMeshPoint;

import java.util.List;

/**
 * Herramientas de caras: la malla de 468 puntos (programa gratis de Google, sin internet),
 * quitar líneas de expresión, cachetes, sonrisa suave, girar la cabeza en la foto,
 * y las cuentas para armar la cara 3D con varias fotos.
 */
public final class Caras {

    private Caras() {}

    /** Los 468 puntos de una cara (en puntos de la foto) y sus triángulos. */
    public static class Malla {
        public final float[] x = new float[468], y = new float[468], z = new float[468];
        public int[] tri = new int[0];
        public float anchoCara, altoCara, cx, cy;
    }

    public static final int[] OVALO = {10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152,
            148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109};
    static final int[] OJO_IZQ = {33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246};
    static final int[] OJO_DER = {263, 249, 390, 373, 374, 380, 381, 382, 362, 398, 384, 385, 386, 387, 388, 466};
    static final int[] CEJA_IZQ = {70, 63, 105, 66, 107, 55, 65, 52, 53, 46};
    static final int[] CEJA_DER = {300, 293, 334, 296, 336, 285, 295, 282, 283, 276};
    static final int[] BOCA = {61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185};

    public static Malla desde(FaceMesh f) {
        Malla m = new Malla();
        for (FaceMeshPoint p : f.getAllPoints()) {
            int i = p.getIndex();
            if (i < 0 || i >= 468) continue;
            PointF3D q = p.getPosition();
            m.x[i] = q.getX();
            m.y[i] = q.getY();
            m.z[i] = q.getZ();
        }
        List<Triangle<FaceMeshPoint>> ts = f.getAllTriangles();
        m.tri = new int[ts.size() * 3];
        int k = 0;
        for (Triangle<FaceMeshPoint> t : ts) {
            List<FaceMeshPoint> ps = t.getAllPoints();
            m.tri[k++] = ps.get(0).getIndex();
            m.tri[k++] = ps.get(1).getIndex();
            m.tri[k++] = ps.get(2).getIndex();
        }
        medir(m);
        return m;
    }

    static void medir(Malla m) {
        float x0 = 1e9f, x1 = -1e9f, y0 = 1e9f, y1 = -1e9f;
        for (int i : OVALO) { x0 = Math.min(x0, m.x[i]); x1 = Math.max(x1, m.x[i]); y0 = Math.min(y0, m.y[i]); y1 = Math.max(y1, m.y[i]); }
        m.anchoCara = Math.max(10, x1 - x0);
        m.altoCara = Math.max(10, y1 - y0);
        m.cx = (x0 + x1) / 2f;
        m.cy = (y0 + y1) / 2f;
    }

    private static Path poligono(Malla m, int[] idx, float crecer) {
        float cx = 0, cy = 0;
        for (int i : idx) { cx += m.x[i]; cy += m.y[i]; }
        cx /= idx.length;
        cy /= idx.length;
        Path p = new Path();
        for (int k = 0; k < idx.length; k++) {
            float px = cx + (m.x[idx[k]] - cx) * crecer, py = cy + (m.y[idx[k]] - cy) * crecer;
            if (k == 0) p.moveTo(px, py); else p.lineTo(px, py);
        }
        p.close();
        return p;
    }

    private static Bitmap difuminar(Bitmap b, float factor) {
        int w = Math.max(1, Math.round(b.getWidth() / factor)), h = Math.max(1, Math.round(b.getHeight() / factor));
        Bitmap chica = Bitmap.createScaledBitmap(b, w, h, true);
        return Bitmap.createScaledBitmap(chica, b.getWidth(), b.getHeight(), true);
    }

    // =====================================================================
    // Quitar líneas de expresión (con porcentaje)
    // =====================================================================

    public static Bitmap suavizar(Bitmap b, Malla m, float pct) {
        int w = b.getWidth(), h = b.getHeight();
        // máscara: el óvalo de la cara, sin ojos, cejas ni boca, con el borde suave
        Bitmap mascara = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cm = new Canvas(mascara);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        cm.drawPath(poligono(m, OVALO, 0.97f), p);
        Paint borra = new Paint(Paint.ANTI_ALIAS_FLAG);
        borra.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        cm.drawPath(poligono(m, OJO_IZQ, 1.5f), borra);
        cm.drawPath(poligono(m, OJO_DER, 1.5f), borra);
        cm.drawPath(poligono(m, CEJA_IZQ, 1.2f), borra);
        cm.drawPath(poligono(m, CEJA_DER, 1.2f), borra);
        cm.drawPath(poligono(m, BOCA, 1.15f), borra);
        mascara = difuminar(mascara, Math.max(2f, m.anchoCara / 25f));
        // la piel lisa: copia borrosa de la foto
        float f = Math.max(2f, m.anchoCara / 45f);
        Bitmap lisa = difuminar(b, f);
        Bitmap capa = lisa.copy(Bitmap.Config.ARGB_8888, true);
        Paint pm = new Paint();
        pm.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        new Canvas(capa).drawBitmap(mascara, 0, 0, pm);
        Bitmap out = b.copy(Bitmap.Config.ARGB_8888, true);
        Paint pf = new Paint(Paint.FILTER_BITMAP_FLAG);
        pf.setAlpha(Math.round(255 * Math.max(0f, Math.min(1f, pct)) * 0.85f));
        pf.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        new Canvas(out).drawBitmap(capa, 0, 0, pf);
        return out;
    }

    // =====================================================================
    // Deformar la foto moviendo puntos de la cara (cachetes, sonrisa, girar)
    // =====================================================================

    /**
     * Mueve cada punto de control de (sx,sy) a (dx,dy); lo de alrededor se arrastra suavemente
     * según «alcance». Lo que está lejos no se mueve.
     */
    public static Bitmap deformar(Bitmap b, float[] sx, float[] sy, float[] dx, float[] dy, float alcance) {
        int w = b.getWidth(), h = b.getHeight();
        int gw = 56, gh = Math.max(8, Math.round(56f * h / w));
        float[] v = new float[(gw + 1) * (gh + 1) * 2];
        float s2 = 2 * alcance * alcance;
        int n = sx.length;
        int k = 0;
        for (int j = 0; j <= gh; j++) {
            float py = (float) h * j / gh;
            for (int i = 0; i <= gw; i++) {
                float px = (float) w * i / gw;
                float sw = 0, mx = 0, my = 0;
                for (int c = 0; c < n; c++) {
                    float ex = px - sx[c], ey = py - sy[c];
                    float d2 = ex * ex + ey * ey;
                    if (d2 > s2 * 9) continue;
                    float wt = (float) Math.exp(-d2 / s2);
                    sw += wt;
                    mx += wt * (dx[c] - sx[c]);
                    my += wt * (dy[c] - sy[c]);
                }
                float div = Math.max(1f, sw);
                boolean borde = i == 0 || j == 0 || i == gw || j == gh;
                v[k++] = borde ? px : px + mx / div;
                v[k++] = borde ? py : py + my / div;
            }
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        new Canvas(out).drawBitmapMesh(b, gw, gh, v, 0, null, 0, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return out;
    }

    private static final int[] CACHETE_IZQ = {234, 93, 132, 58, 172, 136, 150, 177, 215, 213, 147, 123};
    private static final int[] CACHETE_DER = {454, 323, 361, 288, 397, 365, 379, 401, 435, 433, 376, 352};
    private static final int[] QUIETOS_CACHETES = {1, 4, 6, 168, 152, 10, 33, 263, 133, 362, 0, 17, 61, 291};

    /** Reduce los cachetes empujándolos hacia el centro de la cara. pct 0…1. */
    public static Bitmap cachetes(Bitmap b, Malla m, float pct) {
        int n = CACHETE_IZQ.length + CACHETE_DER.length + QUIETOS_CACHETES.length;
        float[] sx = new float[n], sy = new float[n], dx = new float[n], dy = new float[n];
        int k = 0;
        float cx = m.x[4];
        for (int i : CACHETE_IZQ) { sx[k] = m.x[i]; sy[k] = m.y[i]; dx[k] = m.x[i] + (cx - m.x[i]) * 0.14f * pct; dy[k] = m.y[i]; k++; }
        for (int i : CACHETE_DER) { sx[k] = m.x[i]; sy[k] = m.y[i]; dx[k] = m.x[i] + (cx - m.x[i]) * 0.14f * pct; dy[k] = m.y[i]; k++; }
        for (int i : QUIETOS_CACHETES) { sx[k] = m.x[i]; sy[k] = m.y[i]; dx[k] = m.x[i]; dy[k] = m.y[i]; k++; }
        return deformar(b, sx, sy, dx, dy, m.anchoCara * 0.11f);
    }

    /** Sonrisa suave: sube un poquito las comisuras de la boca. pct 0…1. */
    public static Bitmap sonrisa(Bitmap b, Malla m, float pct) {
        int[] esquinas = {61, 291};
        int[] medias = {40, 270, 185, 409, 146, 375};
        int[] quietos = {0, 17, 13, 14, 1, 152, 10, 234, 454};
        int n = esquinas.length + medias.length + quietos.length;
        float[] sx = new float[n], sy = new float[n], dx = new float[n], dy = new float[n];
        float sube = m.altoCara * 0.028f * pct, abre = m.anchoCara * 0.012f * pct;
        float cx = (m.x[61] + m.x[291]) / 2f;
        int k = 0;
        for (int i : esquinas) { sx[k] = m.x[i]; sy[k] = m.y[i]; dx[k] = m.x[i] + Math.signum(m.x[i] - cx) * abre; dy[k] = m.y[i] - sube; k++; }
        for (int i : medias) { sx[k] = m.x[i]; sy[k] = m.y[i]; dx[k] = m.x[i] + Math.signum(m.x[i] - cx) * abre * 0.4f; dy[k] = m.y[i] - sube * 0.45f; k++; }
        for (int i : quietos) { sx[k] = m.x[i]; sy[k] = m.y[i]; dx[k] = m.x[i]; dy[k] = m.y[i]; k++; }
        return deformar(b, sx, sy, dx, dy, m.anchoCara * 0.06f);
    }

    /** Gira la cabeza dentro de la misma foto (hasta unos 25°), conservando pelo y fondo. */
    public static Bitmap girar(Bitmap b, Malla m, float yawGrados, float pitchGrados) {
        float mz = 0;
        for (int i = 0; i < 468; i++) mz += m.z[i];
        mz /= 468f;
        double a = Math.toRadians(yawGrados), t = Math.toRadians(pitchGrados);
        float ca = (float) Math.cos(a), sa = (float) Math.sin(a), ct = (float) Math.cos(t), st = (float) Math.sin(t);
        int anillo = 24;
        int n = 468 + anillo;
        float[] sx = new float[n], sy = new float[n], dx = new float[n], dy = new float[n];
        for (int i = 0; i < 468; i++) {
            float X = m.x[i] - m.cx, Y = m.y[i] - m.cy, Z = m.z[i] - mz;
            float X1 = X * ca + Z * sa, Z1 = -X * sa + Z * ca;     // izquierda / derecha
            float Y2 = Y * ct - Z1 * st;                          // arriba / abajo
            sx[i] = m.x[i];
            sy[i] = m.y[i];
            dx[i] = X1 + m.cx;
            dy[i] = Y2 + m.cy;
        }
        // un anillo quieto alrededor de la cabeza, para que el fondo no se mueva
        float r = Math.max(m.anchoCara, m.altoCara) * 1.15f;
        for (int k = 0; k < anillo; k++) {
            double ang = 2 * Math.PI * k / anillo;
            int i = 468 + k;
            sx[i] = dx[i] = m.cx + (float) Math.cos(ang) * r;
            sy[i] = dy[i] = m.cy + (float) Math.sin(ang) * r * 1.2f;
        }
        return deformar(b, sx, sy, dx, dy, m.anchoCara * 0.16f);
    }

    /** La versión gris y clara de la foto, para el pincel de canas. */
    public static Bitmap canas(Bitmap b) {
        Bitmap out = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
        ColorMatrix gris = new ColorMatrix();
        gris.setSaturation(0);
        ColorMatrix claro = new ColorMatrix(new float[]{
                0.75f, 0, 0, 0, 95,
                0, 0.75f, 0, 0, 95,
                0, 0, 0.78f, 0, 100,
                0, 0, 0, 1, 0});
        gris.postConcat(claro);
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(gris));
        new Canvas(out).drawBitmap(b, 0, 0, p);
        return out;
    }

    // =====================================================================
    // Cuentas para la cara 3D: alinear varias fotos (método de Horn)
    // =====================================================================

    /** Centra los puntos y los deja de tamaño 1. Devuelve una copia [x0,y0,z0,x1,…]. */
    public static float[] normalizar(Malla m) {
        float[] p = new float[468 * 3];
        float cx = 0, cy = 0, cz = 0;
        for (int i = 0; i < 468; i++) { cx += m.x[i]; cy += m.y[i]; cz += m.z[i]; }
        cx /= 468; cy /= 468; cz /= 468;
        double s = 0;
        for (int i = 0; i < 468; i++) {
            float X = m.x[i] - cx, Y = m.y[i] - cy, Z = m.z[i] - cz;
            p[i * 3] = X; p[i * 3 + 1] = Y; p[i * 3 + 2] = Z;
            s += X * X + Y * Y + Z * Z;
        }
        float esc = (float) (1.0 / Math.sqrt(Math.max(1e-9, s / 468)));
        for (int i = 0; i < p.length; i++) p[i] *= esc;
        return p;
    }

    /** La rotación (matriz 3×3) que lleva los puntos «a» lo más cerca posible de «b». */
    public static float[] rotacion(float[] a, float[] b, float[] peso) {
        double sxx = 0, sxy = 0, sxz = 0, syx = 0, syy = 0, syz = 0, szx = 0, szy = 0, szz = 0;
        int n = a.length / 3;
        for (int i = 0; i < n; i++) {
            double w = peso == null ? 1 : peso[i];
            double ax = a[i * 3], ay = a[i * 3 + 1], az = a[i * 3 + 2];
            double bx = b[i * 3], by = b[i * 3 + 1], bz = b[i * 3 + 2];
            sxx += w * ax * bx; sxy += w * ax * by; sxz += w * ax * bz;
            syx += w * ay * bx; syy += w * ay * by; syz += w * ay * bz;
            szx += w * az * bx; szy += w * az * by; szz += w * az * bz;
        }
        double[][] N = {
                {sxx + syy + szz, syz - szy, szx - sxz, sxy - syx},
                {syz - szy, sxx - syy - szz, sxy + syx, szx + sxz},
                {szx - sxz, sxy + syx, -sxx + syy - szz, syz + szy},
                {sxy - syx, szx + sxz, syz + szy, -sxx - syy + szz}};
        double[] q = mayorVector(N);
        double q0 = q[0], qx = q[1], qy = q[2], qz = q[3];
        return new float[]{
                (float) (q0 * q0 + qx * qx - qy * qy - qz * qz), (float) (2 * (qx * qy - q0 * qz)), (float) (2 * (qx * qz + q0 * qy)),
                (float) (2 * (qy * qx + q0 * qz)), (float) (q0 * q0 - qx * qx + qy * qy - qz * qz), (float) (2 * (qy * qz - q0 * qx)),
                (float) (2 * (qz * qx - q0 * qy)), (float) (2 * (qz * qy + q0 * qx)), (float) (q0 * q0 - qx * qx - qy * qy + qz * qz)};
    }

    public static float[] aplicar(float[] R, float[] p) {
        float[] o = new float[p.length];
        for (int i = 0; i < p.length; i += 3) {
            float x = p[i], y = p[i + 1], z = p[i + 2];
            o[i] = R[0] * x + R[1] * y + R[2] * z;
            o[i + 1] = R[3] * x + R[4] * y + R[5] * z;
            o[i + 2] = R[6] * x + R[7] * y + R[8] * z;
        }
        return o;
    }

    /** El vector propio del valor propio más grande (matriz simétrica 4×4, método de Jacobi). */
    private static double[] mayorVector(double[][] A0) {
        double[][] a = new double[4][4];
        double[][] v = new double[4][4];
        for (int i = 0; i < 4; i++) { System.arraycopy(A0[i], 0, a[i], 0, 4); v[i][i] = 1; }
        for (int barrido = 0; barrido < 60; barrido++) {
            double fuera = 0;
            for (int i = 0; i < 4; i++) for (int j = i + 1; j < 4; j++) fuera += Math.abs(a[i][j]);
            if (fuera < 1e-12) break;
            for (int p = 0; p < 4; p++)
                for (int q = p + 1; q < 4; q++) {
                    if (Math.abs(a[p][q]) < 1e-15) continue;
                    double th = (a[q][q] - a[p][p]) / (2 * a[p][q]);
                    double t = Math.signum(th) / (Math.abs(th) + Math.sqrt(th * th + 1));
                    if (th == 0) t = 1;
                    double c = 1 / Math.sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < 4; k++) {
                        double akp = a[k][p], akq = a[k][q];
                        a[k][p] = c * akp - s * akq;
                        a[k][q] = s * akp + c * akq;
                    }
                    for (int k = 0; k < 4; k++) {
                        double apk = a[p][k], aqk = a[q][k];
                        a[p][k] = c * apk - s * aqk;
                        a[q][k] = s * apk + c * aqk;
                    }
                    for (int k = 0; k < 4; k++) {
                        double vkp = v[k][p], vkq = v[k][q];
                        v[k][p] = c * vkp - s * vkq;
                        v[k][q] = s * vkp + c * vkq;
                    }
                }
        }
        int mejor = 0;
        for (int i = 1; i < 4; i++) if (a[i][i] > a[mejor][mejor]) mejor = i;
        double[] q = {v[0][mejor], v[1][mejor], v[2][mejor], v[3][mejor]};
        double nn = Math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
        for (int i = 0; i < 4; i++) q[i] /= nn;
        return q;
    }
}
