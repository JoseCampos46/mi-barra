package co.jose.mischats;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

/** Guarda archivos en Descargas/MiBarra/ChpChat/<carpeta>. Si el usuario mueve la carpeta, Android la vuelve a crear. */
final class Descargas {

    private Descargas() {}

    static String ruta(String sub) {
        String r = Environment.DIRECTORY_DOWNLOADS + "/MiBarra/ChpChat/";
        if (sub != null && !sub.isEmpty()) r += limpio(sub) + "/";
        return r;
    }

    static String limpio(String s) {
        String x = s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", "_").trim();
        return x.isEmpty() ? "chat" : x;
    }

    /** Crea el archivo y devuelve su dirección para escribirle. */
    static Uri crear(Context c, String sub, String nombre, String mime) {
        ContentResolver r = c.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, limpio(nombre));
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, ruta(sub));
        return r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
    }
}
