package co.jose.mischats;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** El chat tal cual WhatsApp: fechas, globos, fotos, audios, lupa para buscar y exportar. */
public class ChatActivity extends Base {

    private static final int BURBUJA_MIA = 0xFFD9FDD3, BURBUJA_OTRO = 0xFFFFFFFF, FONDO_CHAT = 0xFFEFE7DD;
    private static final int RESALTE = 0xFFFFE066, RESALTE_ACTUAL = 0xFFFFA726;

    private Importador.Guardado g;
    private Chat ch;
    private String yo = "";
    private final List<Object> filas = new ArrayList<>();
    private ListView lv;
    private Adaptador ad;

    private LinearLayout barraBuscar;
    private EditText campo;
    private TextView cuenta;
    private String buscar = "";
    private final List<Integer> hallados = new ArrayList<>();
    private int actual = -1;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService hilo = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };

    private MediaPlayer mp;
    private String sonando;
    private TextView etiquetaSonando;
    private Button botonSonando;
    private boolean trabajando;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(VERDE_OSCURO);
        String d = getIntent().getStringExtra("dir");
        if (d == null) {
            finish();
            return;
        }
        g = Importador.abrir(new File(d));
        try {
            ch = g.leer();
        } catch (Exception e) {
            aviso("No pude leer el chat");
            finish();
            return;
        }
        yo = g.m("yo");
        armarFilas();

        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(FONDO_CHAT);
        raiz.addView(barra(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        raiz.addView(barraBuscar(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        lv = new ListView(this);
        lv.setDivider(null);
        lv.setDividerHeight(0);
        lv.setPadding(dp(6), dp(4), dp(6), dp(8));
        lv.setClipToPadding(false);
        ad = new Adaptador();
        lv.setAdapter(ad);
        raiz.addView(lv, relleno());
        setContentView(raiz);
        lv.setSelection(filas.size() - 1);
    }

    private void armarFilas() {
        filas.clear();
        String ultima = null;
        for (Chat.Msg m : ch.msgs) {
            if (!m.fecha.equals(ultima)) {
                filas.add(Chat.fechaLarga(m.fecha));
                ultima = m.fecha;
            }
            filas.add(m);
        }
    }

    // ---------- Barras ----------

    private View barra() {
        LinearLayout f = horizontal();
        f.setBackgroundColor(VERDE_OSCURO);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(0, 0, dp(6), 0);
        Button atras = boton("←", VERDE_OSCURO, Color.WHITE, 24);
        atras.setOnClickListener(v -> finish());
        f.addView(atras, new LinearLayout.LayoutParams(dp(48), dp(56)));
        Button menu = boton("☰", VERDE_OSCURO, Color.WHITE, 22);
        menu.setOnClickListener(v -> menu());
        f.addView(menu, new LinearLayout.LayoutParams(dp(46), dp(56)));
        LinearLayout t = vertical();
        TextView nom = texto(ch.contacto.isEmpty() ? "Chat" : ch.contacto, 19, true, Color.WHITE);
        nom.setSingleLine(true);
        t.addView(nom);
        TextView sub = texto(ch.mensajes() + " mensajes · del " + ch.desde() + " al " + ch.hasta(), 13, false, VERDE_CLARO);
        sub.setSingleLine(true);
        t.addView(sub);
        f.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button lupa = boton("🔍", VERDE_OSCURO, Color.WHITE, 20);
        lupa.setOnClickListener(v -> abrirBuscar());
        f.addView(lupa, new LinearLayout.LayoutParams(dp(48), dp(56)));
        TextView ver = texto(InicioActivity.VERSION, 14, true, VERDE_OSCURO);
        ver.setBackground(fondo(Color.WHITE, dp(6)));
        ver.setPadding(dp(6), dp(2), dp(6), dp(2));
        f.addView(ver);
        return f;
    }

    private View barraBuscar() {
        barraBuscar = horizontal();
        barraBuscar.setBackgroundColor(Color.WHITE);
        barraBuscar.setGravity(Gravity.CENTER_VERTICAL);
        barraBuscar.setPadding(dp(6), dp(4), dp(4), dp(4));
        barraBuscar.setVisibility(View.GONE);
        campo = new EditText(this);
        campo.setHint("Mensaje, nombre, teléfono o fecha");
        campo.setTextSize(17);
        campo.setSingleLine(true);
        campo.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        campo.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                hacerBusqueda(e.toString());
            }
        });
        campo.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                esconderTeclado();
                return true;
            }
            return false;
        });
        barraBuscar.addView(campo, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cuenta = texto("", 14, true, GRIS);
        cuenta.setPadding(dp(4), 0, dp(4), 0);
        barraBuscar.addView(cuenta);
        Button arriba = boton("▲", TARJETA, NEGRO, 18);
        arriba.setOnClickListener(v -> mover(-1));
        barraBuscar.addView(arriba, new LinearLayout.LayoutParams(dp(44), dp(44)));
        Button abajo = boton("▼", TARJETA, NEGRO, 18);
        abajo.setOnClickListener(v -> mover(1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMargins(dp(4), 0, dp(4), 0);
        barraBuscar.addView(abajo, lp);
        Button cerrar = boton("✕", TARJETA, ROJO, 18);
        cerrar.setOnClickListener(v -> cerrarBuscar());
        barraBuscar.addView(cerrar, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return barraBuscar;
    }

    private void abrirBuscar() {
        barraBuscar.setVisibility(View.VISIBLE);
        campo.requestFocus();
        InputMethodManager im = getSystemService(InputMethodManager.class);
        if (im != null) im.showSoftInput(campo, InputMethodManager.SHOW_IMPLICIT);
    }

    private void cerrarBuscar() {
        campo.setText("");
        barraBuscar.setVisibility(View.GONE);
        esconderTeclado();
    }

    private void esconderTeclado() {
        InputMethodManager im = getSystemService(InputMethodManager.class);
        if (im != null) im.hideSoftInputFromWindow(campo.getWindowToken(), 0);
    }

    // ---------- Buscar ----------

    private static String digitos(String s) {
        return s == null ? "" : s.replaceAll("[^0-9]", "");
    }

    private boolean coincide(Chat.Msg m, String q) {
        String ql = q.toLowerCase(Locale.ROOT);
        if (m.texto.toLowerCase(Locale.ROOT).contains(ql)) return true;
        if (m.quien.toLowerCase(Locale.ROOT).contains(ql)) return true;
        if (m.archivo.toLowerCase(Locale.ROOT).contains(ql)) return true;
        if ((m.fecha + " " + m.hora).toLowerCase(Locale.ROOT).contains(ql)) return true;
        String dq = digitos(q);
        if (dq.length() >= 4 && dq.length() == q.replaceAll("[\\s+()\\-.]", "").length()) {
            return digitos(m.quien).contains(dq) || digitos(m.texto).contains(dq);
        }
        return false;
    }

    private void hacerBusqueda(String q) {
        buscar = q.trim();
        hallados.clear();
        actual = -1;
        if (!buscar.isEmpty()) {
            for (int i = 0; i < filas.size(); i++) {
                Object o = filas.get(i);
                if (o instanceof Chat.Msg && coincide((Chat.Msg) o, buscar)) hallados.add(i);
            }
            if (!hallados.isEmpty()) actual = hallados.size() - 1;
        }
        actualizarCuenta();
        ad.notifyDataSetChanged();
        if (actual >= 0) irA(hallados.get(actual));
    }

    private void mover(int paso) {
        if (hallados.isEmpty()) return;
        actual = (actual + paso + hallados.size()) % hallados.size();
        actualizarCuenta();
        ad.notifyDataSetChanged();
        irA(hallados.get(actual));
    }

    private void actualizarCuenta() {
        if (buscar.isEmpty()) cuenta.setText("");
        else if (hallados.isEmpty()) cuenta.setText("0");
        else cuenta.setText((actual + 1) + " de " + hallados.size());
    }

    private void irA(int pos) {
        lv.setSelectionFromTop(pos, dp(60));
    }

    private CharSequence resaltar(String s, boolean esActual) {
        if (buscar.isEmpty() || s.isEmpty()) return s;
        String bajo = s.toLowerCase(Locale.ROOT), q = buscar.toLowerCase(Locale.ROOT);
        int i = bajo.indexOf(q);
        if (i < 0) return s;
        SpannableString sp = new SpannableString(s);
        while (i >= 0) {
            sp.setSpan(new BackgroundColorSpan(esActual ? RESALTE_ACTUAL : RESALTE), i, i + q.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            i = bajo.indexOf(q, i + q.length());
        }
        return sp;
    }

    // ---------- Lista ----------

    private class Adaptador extends BaseAdapter {
        @Override
        public int getCount() {
            return filas.size();
        }

        @Override
        public Object getItem(int i) {
            return filas.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View vieja, ViewGroup padre) {
            Object o = filas.get(pos);
            if (o instanceof String) return filaFecha((String) o);
            Chat.Msg m = (Chat.Msg) o;
            if (m.sistema) return filaSistema(m);
            boolean esActual = actual >= 0 && hallados.get(actual) == pos;
            boolean hallado = !buscar.isEmpty() && hallados.contains(pos);
            return filaMensaje(m, hallado, esActual);
        }
    }

    private View filaFecha(String f) {
        LinearLayout l = horizontal();
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(8), 0, dp(6));
        TextView t = texto(f, 14, true, 0xFF0C447C);
        t.setBackground(fondo(0xFFE1F3FB, dp(8)));
        t.setPadding(dp(12), dp(4), dp(12), dp(4));
        l.addView(t);
        return l;
    }

    private View filaSistema(Chat.Msg m) {
        LinearLayout l = horizontal();
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(20), dp(4), dp(20), dp(4));
        TextView t = texto(m.texto, 13, false, GRIS);
        t.setGravity(Gravity.CENTER);
        t.setBackground(fondo(0xFFFAEEDA, dp(8)));
        t.setPadding(dp(10), dp(4), dp(10), dp(4));
        l.addView(t);
        return l;
    }

    private View filaMensaje(Chat.Msg m, boolean hallado, boolean esActual) {
        boolean mio = m.esMio(yo);
        int anchoMax = (int) (getResources().getDisplayMetrics().widthPixels * 0.80f);
        LinearLayout fila = horizontal();
        fila.setGravity(mio ? Gravity.END : Gravity.START);
        fila.setPadding(0, dp(2), 0, dp(2));

        LinearLayout bur = vertical();
        bur.setBackground(fondo(esActual ? 0xFFFFF3C4 : (mio ? BURBUJA_MIA : BURBUJA_OTRO), dp(10)));
        bur.setPadding(dp(9), dp(5), dp(9), dp(5));
        int interior = anchoMax - dp(18);

        if (!mio && (ch.remitentes.size() > 2 || yo.isEmpty())) {
            TextView q = texto("", 14, true, VERDE);
            q.setText(resaltar(m.quien, esActual));
            q.setMaxWidth(interior);
            bur.addView(q);
        }

        if (!m.archivo.isEmpty()) {
            File f = g.archivo(m.archivo);
            if (m.tipo == Chat.FOTO) bur.addView(vistaFoto(f, interior));
            else if (m.tipo == Chat.AUDIO) bur.addView(vistaAudio(f, interior));
            else bur.addView(vistaArchivo(m, f, interior));
            TextView nombre = texto("", 12, false, GRIS);
            nombre.setText(resaltar(m.archivo, esActual));
            nombre.setMaxWidth(interior);
            bur.addView(nombre);
        }

        if (!m.texto.isEmpty()) {
            TextView t = texto("", 17, false, NEGRO);
            t.setText(hallado ? resaltar(m.texto, esActual) : m.texto);
            t.setMaxWidth(interior);
            t.setTextIsSelectable(false);
            bur.addView(t);
        }

        TextView hora = texto("", 12, false, GRIS);
        hora.setText(resaltar((m.editado ? "editado · " : "") + m.fecha + " " + m.hora, esActual));
        hora.setGravity(Gravity.END);
        LinearLayout.LayoutParams lh = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lh.gravity = Gravity.END;
        bur.addView(hora, lh);

        bur.setOnLongClickListener(v -> {
            opcionesMensaje(m);
            return true;
        });
        fila.addView(bur, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return fila;
    }

    private View vistaFoto(File f, int ancho) {
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        int w = Math.min(ancho, dp(240)), hh = dp(200);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (o.outWidth > 0 && o.outHeight > 0) {
            hh = Math.min(dp(300), Math.round(w * (float) o.outHeight / o.outWidth));
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
        iv.setLayoutParams(new LinearLayout.LayoutParams(w, hh));
        iv.setBackgroundColor(0xFFD3D1C7);
        if (!f.exists()) {
            LinearLayout l = vertical();
            l.addView(texto("(la foto no vino en el zip)", 14, false, GRIS));
            return l;
        }
        String clave = f.getAbsolutePath();
        iv.setTag(clave);
        Bitmap ya = cache.get(clave);
        if (ya != null) iv.setImageBitmap(ya);
        else {
            final int ww = w;
            hilo.execute(() -> {
                Bitmap bm = decodificar(f, ww * 2);
                if (bm == null) return;
                cache.put(clave, bm);
                h.post(() -> {
                    if (clave.equals(iv.getTag())) iv.setImageBitmap(bm);
                });
            });
        }
        iv.setOnClickListener(v -> verFoto(f));
        return iv;
    }

    private static Bitmap decodificar(File f, int anchoQuiero) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (o.outWidth / (s * 2) >= anchoQuiero) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Throwable t) {
            return null;
        }
    }

    private void verFoto(File f) {
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setBackgroundColor(Color.BLACK);
        Bitmap bm = decodificar(f, getResources().getDisplayMetrics().widthPixels);
        if (bm == null) {
            aviso("No pude abrir la foto");
            return;
        }
        iv.setImageBitmap(bm);
        new AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
                .setView(iv)
                .setPositiveButton("Cerrar", null)
                .setNeutralButton("Abrir con…", (d, w) -> abrirAfuera(f))
                .show();
    }

    private View vistaAudio(File f, int ancho) {
        LinearLayout l = horizontal();
        l.setGravity(Gravity.CENTER_VERTICAL);
        String clave = f.getAbsolutePath();
        boolean este = clave.equals(sonando) && mp != null;
        Button b = boton(este && mp.isPlaying() ? "⏸" : "▶", VERDE, Color.WHITE, 20);
        l.addView(b, new LinearLayout.LayoutParams(dp(50), dp(46)));
        TextView t = texto(f.exists() ? "Nota de voz" : "(el audio no vino en el zip)", 15, false, NEGRO);
        t.setPadding(dp(10), 0, 0, 0);
        l.addView(t, new LinearLayout.LayoutParams(Math.min(ancho - dp(60), dp(190)), ViewGroup.LayoutParams.WRAP_CONTENT));
        if (este) {
            etiquetaSonando = t;
            botonSonando = b;
            pintarProgreso();
        }
        b.setOnClickListener(v -> {
            if (!f.exists()) return;
            tocar(f, b, t);
        });
        return l;
    }

    private void tocar(File f, Button b, TextView t) {
        String clave = f.getAbsolutePath();
        if (clave.equals(sonando) && mp != null) {
            if (mp.isPlaying()) {
                mp.pause();
                b.setText("▶");
            } else {
                mp.start();
                b.setText("⏸");
                h.post(progreso);
            }
            return;
        }
        parar();
        try {
            mp = new MediaPlayer();
            mp.setDataSource(clave);
            mp.prepare();
            mp.setOnCompletionListener(x -> {
                if (botonSonando != null) botonSonando.setText("▶");
                pintarProgreso();
            });
            mp.start();
            sonando = clave;
            etiquetaSonando = t;
            botonSonando = b;
            b.setText("⏸");
            h.post(progreso);
        } catch (Exception e) {
            parar();
            aviso("No pude reproducir el audio");
        }
    }

    private final Runnable progreso = new Runnable() {
        @Override
        public void run() {
            pintarProgreso();
            if (mp != null && mp.isPlaying()) h.postDelayed(this, 500);
        }
    };

    private void pintarProgreso() {
        if (mp == null || etiquetaSonando == null) return;
        try {
            int p = mp.getCurrentPosition() / 1000, d = mp.getDuration() / 1000;
            etiquetaSonando.setText(String.format(Locale.US, "%d:%02d / %d:%02d", p / 60, p % 60, d / 60, d % 60));
        } catch (Exception ignored) {}
    }

    private void parar() {
        h.removeCallbacks(progreso);
        if (mp != null) {
            try { mp.release(); } catch (Exception ignored) {}
        }
        mp = null;
        sonando = null;
        if (botonSonando != null) botonSonando.setText("▶");
        etiquetaSonando = null;
        botonSonando = null;
    }

    private View vistaArchivo(Chat.Msg m, File f, int ancho) {
        String que = m.tipo == Chat.VIDEO ? "▶  Ver video" : "📄  Abrir archivo";
        Button b = boton(que, TARJETA, NEGRO, 16);
        b.setOnClickListener(v -> {
            if (f.exists()) abrirAfuera(f);
            else aviso("Ese archivo no vino en el zip");
        });
        b.setLayoutParams(new LinearLayout.LayoutParams(Math.min(ancho, dp(220)), dp(48)));
        return b;
    }

    private void abrirAfuera(File f) {
        try {
            Uri u = Archivos.uri(this, f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, Chat.mime(f.getName()));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Abrir con"));
        } catch (Exception e) {
            aviso("No encontré una app para abrirlo");
        }
    }

    private void opcionesMensaje(Chat.Msg m) {
        String[] op = {"Copiar el texto con fecha y hora"};
        new AlertDialog.Builder(this).setTitle(m.quien + " · " + m.fecha + " " + m.hora).setItems(op, (d, w) -> {
            String s = "📅 " + m.fecha + " · " + m.hora + " · " + m.quien + ":\n"
                    + (m.archivo.isEmpty() ? "" : "[" + m.archivo + "]\n") + m.texto;
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("mensaje", s.trim()));
            aviso("Copiado");
        }).show();
    }

    // ---------- Menú y exportar ----------

    private boolean miniaturas() {
        return Reglas.p(this).getBoolean("miniaturas", true);
    }

    private void menu() {
        String[] op = {
                "Exportar en hojas carta (imágenes y PDF)",
                "Exportar paquete comprimido (zip)",
                "Miniaturas de fotos al exportar: " + (miniaturas() ? "SÍ" : "NO"),
                "¿Quién soy yo en este chat?",
                "Ir al principio del chat",
                "Ir al final del chat"};
        new AlertDialog.Builder(this).setTitle("ChpChat " + InicioActivity.VERSION).setItems(op, (d, w) -> {
            switch (w) {
                case 0: confirmarExportar(false); break;
                case 1: confirmarExportar(true); break;
                case 2:
                    Reglas.p(this).edit().putBoolean("miniaturas", !miniaturas()).apply();
                    aviso("Miniaturas: " + (miniaturas() ? "SÍ" : "NO"));
                    break;
                case 3:
                    InicioActivity.escogerYo(this, g, () -> {
                        yo = g.m("yo");
                        ad.notifyDataSetChanged();
                    });
                    break;
                case 4: lv.setSelection(0); break;
                default: lv.setSelection(filas.size() - 1);
            }
        }).show();
    }

    private void confirmarExportar(boolean paquete) {
        String m = (paquete
                ? "Se arma un zip con el chat en PDF (hojas carta de 3 columnas) y todas las fotos, audios y videos con su mismo nombre.\n\n"
                : "Se arman hojas carta de 3 columnas: en imágenes (para mandar por WhatsApp) y en PDF (para imprimir).\n\n")
                + (miniaturas()
                ? "Ojo: las fotos salen en miniatura. Si en el chat hay documentos (cédula, tarjetas), quien lo reciba los va a ver. "
                + "Puede quitar las miniaturas en el menú ☰."
                : "Las fotos salen solo con su referencia (sin miniatura).");
        new AlertDialog.Builder(this).setTitle(paquete ? "Exportar paquete comprimido" : "Exportar en hojas carta")
                .setMessage(m)
                .setPositiveButton("Exportar", (d, w) -> exportar(paquete))
                .setNegativeButton("Cancelar", null).show();
    }

    private void exportar(boolean paquete) {
        if (trabajando) return;
        trabajando = true;
        TextView estado = texto("Preparando…", 17, false, NEGRO);
        estado.setPadding(dp(20), dp(16), dp(20), dp(8));
        AlertDialog esp = new AlertDialog.Builder(this).setTitle("Exportando").setView(estado).setCancelable(false).show();
        new Thread(() -> {
            try {
                Exportador ex = new Exportador(this, g, ch, miniaturas());
                Exportador.Avance av = que -> h.post(() -> estado.setText(que));
                Exportador.Resultado r = paquete ? ex.paquete(av) : ex.hojas(av);
                h.post(() -> {
                    trabajando = false;
                    esp.dismiss();
                    listo(r, paquete);
                });
            } catch (Throwable e) {
                h.post(() -> {
                    trabajando = false;
                    esp.dismiss();
                    new AlertDialog.Builder(this).setTitle("No se pudo exportar").setMessage(String.valueOf(e.getMessage()))
                            .setPositiveButton("Entendido", null).show();
                });
            }
        }).start();
    }

    private void listo(Exportador.Resultado r, boolean paquete) {
        String donde = "Descargas/MiBarra/ChpChat/" + Descargas.limpio(r.carpeta);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Listo")
                .setMessage((paquete ? "Paquete comprimido guardado" : r.paginas + (r.paginas == 1 ? " hoja guardada" : " hojas guardadas"))
                        + " en:\n" + donde);
        if (paquete) {
            b.setPositiveButton("Compartir paquete", (d, w) -> compartir(listaDe(r.zip), "application/zip"));
        } else {
            b.setPositiveButton("Compartir hojas", (d, w) -> compartir(new ArrayList<>(r.hojas), "image/jpeg"));
            b.setNeutralButton("Compartir PDF", (d, w) -> compartir(listaDe(r.pdf), "application/pdf"));
        }
        b.setNegativeButton("Cerrar", null).show();
    }

    private static ArrayList<Uri> listaDe(Uri u) {
        ArrayList<Uri> l = new ArrayList<>();
        if (u != null) l.add(u);
        return l;
    }

    private void compartir(ArrayList<Uri> uris, String mime) {
        if (uris.isEmpty()) return;
        Intent i;
        if (uris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        i.setType(mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "Compartir"));
        } catch (Exception e) {
            aviso("No encontré con qué compartir");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mp != null && mp.isPlaying()) {
            mp.pause();
            if (botonSonando != null) botonSonando.setText("▶");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        parar();
        hilo.shutdownNow();
    }
}
