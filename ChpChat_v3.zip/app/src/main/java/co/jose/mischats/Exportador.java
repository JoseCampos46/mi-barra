package co.jose.mischats;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Arma las hojas tamaño carta en 3 columnas (tipo periódico): columna 1, luego arriba la 2, luego la 3.
 * Todo en negro nítido para imprimir. Las fotos salen en miniatura con su nombre; los audios con su referencia.
 */
final class Exportador {

    interface Avance {
        void va(String que);
    }

    static final class Resultado {
        String carpeta = "";
        Uri pdf, zip;
        final List<Uri> hojas = new ArrayList<>();
        int paginas;
    }

    // Hoja carta a 200 puntos por pulgada.
    private static final int W = 1700, H = 2200, M = 90, GUT = 28, HEAD = 150, FOOT = 70;
    private static final int CW = (W - 2 * M - 2 * GUT) / 3;
    private static final int BW = (int) (CW * 0.88f);
    private static final int PAD = 12, LH = 29, MINI_ALTO = 230;
    private static final int TOP = M + HEAD, BOTTOM = H - M - FOOT;

    private final Context c;
    private final Importador.Guardado g;
    private final Chat ch;
    private final boolean miniaturas;
    private final String yo;
    private final Paint pCuerpo, pNegrita, pMeta, pTitulo, pSub, pLinea, pBorde, pBlanco;
    private final List<Bloque> bloques = new ArrayList<>();
    private final List<List<int[]>> paginas = new ArrayList<>();

    private static final class Bloque {
        boolean esFecha;
        String fecha = "";
        Chat.Msg m;
        boolean mio;
        List<String> lineasRef = new ArrayList<>(), lineasTexto = new ArrayList<>();
        File foto;
        int miniW, miniH, alto;
    }

    Exportador(Context c, Importador.Guardado g, Chat ch, boolean miniaturas) {
        this.c = c;
        this.g = g;
        this.ch = ch;
        this.miniaturas = miniaturas;
        this.yo = g.m("yo");
        Typeface normal = Typeface.create("sans-serif-condensed", Typeface.NORMAL);
        Typeface negra = Typeface.create("sans-serif-condensed", Typeface.BOLD);
        pCuerpo = pintura(23, normal);
        pNegrita = pintura(23, negra);
        pMeta = pintura(19, normal);
        pTitulo = pintura(36, Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        pSub = pintura(22, Typeface.SANS_SERIF);
        pLinea = new Paint(Paint.ANTI_ALIAS_FLAG);
        pLinea.setColor(Color.BLACK);
        pLinea.setStyle(Paint.Style.STROKE);
        pBorde = new Paint(Paint.ANTI_ALIAS_FLAG);
        pBorde.setColor(Color.BLACK);
        pBorde.setStyle(Paint.Style.STROKE);
        pBorde.setStrokeWidth(2);
        pBlanco = new Paint();
        pBlanco.setColor(Color.WHITE);
        pBlanco.setStyle(Paint.Style.FILL);
        armar();
    }

    private static Paint pintura(float tam, Typeface tf) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTextSize(tam);
        p.setTypeface(tf);
        return p;
    }

    // ---------- Armar los bloques y repartirlos en columnas y hojas ----------

    private void armar() {
        String ultimaFecha = null;
        int inner = BW - 2 * PAD;
        for (Chat.Msg m : ch.msgs) {
            if (!m.fecha.equals(ultimaFecha)) {
                Bloque f = new Bloque();
                f.esFecha = true;
                f.fecha = Chat.fechaLarga(m.fecha);
                f.alto = 54;
                bloques.add(f);
                ultimaFecha = m.fecha;
            }
            if (m.sistema) continue;
            Bloque b = new Bloque();
            b.m = m;
            b.mio = m.esMio(yo);
            if (!m.archivo.isEmpty()) {
                String que;
                switch (m.tipo) {
                    case Chat.FOTO: que = "Ver imagen"; break;
                    case Chat.AUDIO: que = "Escuchar audio"; break;
                    case Chat.VIDEO: que = "Ver video"; break;
                    default: que = "Ver archivo";
                }
                b.lineasRef = envolver("[ " + que + " del " + m.fecha + " a las " + m.hora + " ]", pNegrita, inner);
                if (m.tipo == Chat.FOTO && miniaturas) {
                    File f = g.archivo(m.archivo);
                    if (f.exists()) {
                        BitmapFactory.Options o = new BitmapFactory.Options();
                        o.inJustDecodeBounds = true;
                        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                        if (o.outWidth > 0 && o.outHeight > 0) {
                            float esc = Math.min((float) inner / o.outWidth, (float) MINI_ALTO / o.outHeight);
                            b.foto = f;
                            b.miniW = Math.max(1, Math.round(o.outWidth * esc));
                            b.miniH = Math.max(1, Math.round(o.outHeight * esc));
                        }
                    }
                }
            }
            if (!m.texto.isEmpty()) b.lineasTexto = envolver(m.texto, pCuerpo, inner);
            int n = b.lineasRef.size() + (m.archivo.isEmpty() ? 0 : 1) + b.lineasTexto.size();
            b.alto = PAD + 24 + (b.foto != null ? b.miniH + 8 : 0) + n * LH + 24 + PAD + 10;
            bloques.add(b);
        }

        List<int[]> actual = new ArrayList<>();
        int col = 0, y = TOP;
        for (int i = 0; i < bloques.size(); i++) {
            int h = bloques.get(i).alto;
            if (y + h > BOTTOM && y > TOP) {
                col++;
                y = TOP;
                if (col == 3) {
                    paginas.add(actual);
                    actual = new ArrayList<>();
                    col = 0;
                }
            }
            actual.add(new int[]{i, col, y});
            y += Math.min(h, BOTTOM - TOP);
        }
        if (!actual.isEmpty() || paginas.isEmpty()) paginas.add(actual);
    }

    private static List<String> envolver(String texto, Paint p, int ancho) {
        List<String> out = new ArrayList<>();
        for (String parrafo : texto.split("\n", -1)) {
            String actual = "";
            for (String w : parrafo.split(" ")) {
                String prueba = actual.isEmpty() ? w : actual + " " + w;
                if (p.measureText(prueba) <= ancho) {
                    actual = prueba;
                    continue;
                }
                if (!actual.isEmpty()) out.add(actual);
                while (p.measureText(w) > ancho && w.length() > 1) {
                    int k = w.length();
                    while (k > 1 && p.measureText(w, 0, k) > ancho) k--;
                    out.add(w.substring(0, k));
                    w = w.substring(k);
                }
                actual = w;
            }
            out.add(actual);
        }
        return out;
    }

    // ---------- Dibujar una hoja ----------

    private void dibujarHoja(Canvas cv, int i) {
        cv.drawColor(Color.WHITE);
        int n = paginas.size();
        String contacto = ch.contacto.isEmpty() ? "chat" : ch.contacto;
        cv.drawText("Chat de WhatsApp con " + contacto, M, M + 34, pTitulo);
        String sub = "Del " + ch.desde() + " al " + ch.hasta() + "  ·  " + ch.mensajes() + " mensajes  ·  "
                + ch.contar(Chat.FOTO) + " imágenes  ·  " + ch.contar(Chat.AUDIO) + " audios";
        if (ch.contar(Chat.VIDEO) > 0) sub += "  ·  " + ch.contar(Chat.VIDEO) + " videos";
        cv.drawText(sub, M, M + 80, pSub);
        pLinea.setStrokeWidth(3);
        cv.drawLine(M, M + HEAD - 30, W - M, M + HEAD - 30, pLinea);
        pLinea.setStrokeWidth(1);
        for (int k = 1; k <= 2; k++) {
            float cx = M + k * CW + (k - 1) * GUT + GUT / 2f;
            cv.drawLine(cx, TOP, cx, BOTTOM, pLinea);
        }
        for (int[] p : paginas.get(i)) dibujarBloque(cv, bloques.get(p[0]), M + p[1] * (CW + GUT), p[2]);
        pLinea.setStrokeWidth(2);
        cv.drawLine(M, H - M - FOOT + 20, W - M, H - M - FOOT + 20, pLinea);
        cv.drawText("ChpChat v3 · para buscar en WhatsApp por fecha y hora", M, H - M - FOOT + 54, pSub);
        String pie = "Hoja " + (i + 1) + " de " + n;
        cv.drawText(pie, W - M - pSub.measureText(pie), H - M - FOOT + 54, pSub);
    }

    private void dibujarBloque(Canvas cv, Bloque b, int x, int y) {
        if (b.esFecha) {
            float tw = pMeta.measureText(b.fecha);
            float bx = x + (CW - tw) / 2f - 14;
            RectF r = new RectF(bx, y + 4, bx + tw + 28, y + 38);
            cv.drawRoundRect(r, 8, 8, pBlanco);
            pLinea.setStrokeWidth(1);
            cv.drawRoundRect(r, 8, 8, pLinea);
            cv.drawText(b.fecha, bx + 14, y + 28, pMeta);
            return;
        }
        int alto = Math.min(b.alto, BOTTOM - TOP) - 10;
        float bx = x + (b.mio ? CW - BW : 0);
        RectF r = new RectF(bx, y, bx + BW, y + alto);
        cv.drawRoundRect(r, 10, 10, pBlanco);
        cv.drawRoundRect(r, 10, 10, pBorde);
        cv.save();
        cv.clipRect(r);
        float ty = y + PAD;
        cv.drawText(b.m.quien, bx + PAD, ty + 18, pMeta);
        ty += 24;
        if (b.foto != null) {
            Bitmap mini = miniatura(b.foto, b.miniW, b.miniH);
            if (mini != null) {
                cv.drawBitmap(mini, null, new RectF(bx + PAD, ty, bx + PAD + b.miniW, ty + b.miniH), null);
                mini.recycle();
            }
            pLinea.setStrokeWidth(1);
            cv.drawRect(bx + PAD, ty, bx + PAD + b.miniW, ty + b.miniH, pLinea);
            ty += b.miniH + 8;
        }
        for (String l : b.lineasRef) {
            cv.drawText(l, bx + PAD, ty + 22, pNegrita);
            ty += LH;
        }
        if (!b.m.archivo.isEmpty()) {
            cv.drawText(b.m.archivo, bx + PAD, ty + 22, pMeta);
            ty += LH;
        }
        for (String l : b.lineasTexto) {
            cv.drawText(l, bx + PAD, ty + 22, pCuerpo);
            ty += LH;
        }
        String meta = (b.m.editado ? "editado · " : "") + b.m.fecha + " " + b.m.hora;
        cv.drawText(meta, bx + BW - PAD - pMeta.measureText(meta), Math.min(ty + 22, y + alto - 8), pMeta);
        cv.restore();
    }

    private static Bitmap miniatura(File f, int w, int h) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (o.outWidth / (s * 2) >= w && o.outHeight / (s * 2) >= h) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- Salidas ----------

    int paginas() {
        return paginas.size();
    }

    private void escribirPdf(OutputStream o, Avance av) throws Exception {
        PdfDocument doc = new PdfDocument();
        float esc = 612f / W;
        try {
            for (int i = 0; i < paginas.size(); i++) {
                if (av != null) av.va("PDF: hoja " + (i + 1) + " de " + paginas.size());
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(612, 792, i + 1).create();
                PdfDocument.Page pg = doc.startPage(info);
                Canvas cv = pg.getCanvas();
                cv.scale(esc, esc);
                dibujarHoja(cv, i);
                doc.finishPage(pg);
            }
            doc.writeTo(o);
        } finally {
            doc.close();
        }
    }

    static String carpetaNueva(Chat ch) {
        String hoy = new SimpleDateFormat("yyyy-MM-dd HH.mm", Locale.US).format(new Date());
        return (ch.contacto.isEmpty() ? "Chat" : ch.contacto) + " " + hoy;
    }

    private String base() {
        return "Chat_" + Descargas.limpio(ch.contacto.isEmpty() ? "WhatsApp" : ch.contacto).replace(' ', '_');
    }

    /** Tipo 1: hojas carta en imágenes (para WhatsApp) y en PDF (para imprimir). */
    Resultado hojas(Avance av) throws Exception {
        Resultado res = new Resultado();
        res.carpeta = carpetaNueva(ch);
        res.paginas = paginas.size();
        ContentResolver r = c.getContentResolver();

        res.pdf = Descargas.crear(c, res.carpeta, base() + ".pdf", "application/pdf");
        if (res.pdf == null) throw new Exception("No pude crear el PDF en Descargas.");
        try (OutputStream o = r.openOutputStream(res.pdf)) {
            escribirPdf(o, av);
        }

        for (int i = 0; i < paginas.size(); i++) {
            if (av != null) av.va("Imagen: hoja " + (i + 1) + " de " + paginas.size());
            Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.RGB_565);
            try {
                dibujarHoja(new Canvas(bm), i);
                Uri u = Descargas.crear(c, res.carpeta, base() + "_hoja" + (i + 1) + ".jpg", "image/jpeg");
                if (u == null) continue;
                try (OutputStream o = r.openOutputStream(u)) {
                    bm.compress(Bitmap.CompressFormat.JPEG, 80, o);
                }
                res.hojas.add(u);
            } finally {
                bm.recycle();
            }
        }
        return res;
    }

    /** Tipo 3: un zip con el PDF, el texto original y todas las fotos, audios y videos con su mismo nombre. */
    Resultado paquete(Avance av) throws Exception {
        Resultado res = new Resultado();
        res.carpeta = carpetaNueva(ch);
        res.paginas = paginas.size();
        File tmpPdf = new File(c.getCacheDir(), "paquete.pdf");
        try (OutputStream o = new FileOutputStream(tmpPdf)) {
            escribirPdf(o, av);
        }
        res.zip = Descargas.crear(c, res.carpeta, base() + "_paquete.zip", "application/zip");
        if (res.zip == null) throw new Exception("No pude crear el zip en Descargas.");
        try (OutputStream o = c.getContentResolver().openOutputStream(res.zip); ZipOutputStream z = new ZipOutputStream(o)) {
            z.putNextEntry(new ZipEntry(base() + ".pdf"));
            Importador.copiar(tmpPdf, z);
            z.closeEntry();

            z.putNextEntry(new ZipEntry("Chat de WhatsApp con " + Descargas.limpio(ch.contacto) + ".txt"));
            Importador.copiar(g.chatTxt(), z);
            z.closeEntry();

            File[] l = g.archivos().listFiles();
            int k = 0, total = l == null ? 0 : l.length;
            if (l != null) {
                for (File f : l) {
                    k++;
                    if (av != null) av.va("Paquete: archivo " + k + " de " + total);
                    z.putNextEntry(new ZipEntry("archivos/" + f.getName()));
                    Importador.copiar(f, z);
                    z.closeEntry();
                }
            }

            StringBuilder leeme = new StringBuilder();
            leeme.append("CHAT DE WHATSAPP CON ").append(ch.contacto.toUpperCase()).append("\n")
                    .append("Del ").append(ch.desde()).append(" al ").append(ch.hasta()).append("\n\n")
                    .append("- ").append(base()).append(".pdf: el chat completo en hojas carta de 3 columnas.\n")
                    .append("- Carpeta \"archivos\": las fotos, audios y videos con el mismo nombre que aparece en las hojas.\n")
                    .append("  Busque el nombre (por ejemplo IMG-20260716-WA0006.jpg) y ahí está el archivo.\n")
                    .append("- También puede buscarlo en su WhatsApp por la fecha y la hora que dicen las hojas.\n");
            if (!g.iguales().isEmpty()) {
                leeme.append("\nFotos repetidas (se guardaron una sola vez):\n");
                for (String n : g.iguales().stringPropertyNames()) {
                    leeme.append("  ").append(n).append("  =  ").append(g.iguales().getProperty(n)).append("\n");
                }
            }
            leeme.append("\nHecho con ChpChat v3.\n");
            z.putNextEntry(new ZipEntry("LEAME.txt"));
            z.write(leeme.toString().getBytes(StandardCharsets.UTF_8));
            z.closeEntry();
        } finally {
            tmpPdf.delete();
        }
        return res;
    }
}
