package co.jose.mischats;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Deja que otra app (el reproductor de video, un visor de PDF) abra un archivo guardado dentro de ChpChat,
 * solo para leerlo y solo cuando uno lo toca.
 */
public class Archivos extends ContentProvider {

    static final String AUTORIDAD = "co.jose.mischats.archivos";

    static Uri uri(Context c, File f) {
        String base = Importador.raiz(c).getAbsolutePath();
        String rel = f.getAbsolutePath().substring(base.length() + 1);
        return new Uri.Builder().scheme("content").authority(AUTORIDAD).path(rel).build();
    }

    private File archivo(Uri u) throws FileNotFoundException {
        File raiz = Importador.raiz(getContext());
        String p = u.getPath();
        if (p == null) throw new FileNotFoundException();
        File f = new File(raiz, p);
        try {
            if (!f.getCanonicalPath().startsWith(raiz.getCanonicalPath() + File.separator)) throw new FileNotFoundException();
        } catch (java.io.IOException e) {
            throw new FileNotFoundException();
        }
        if (!f.isFile()) throw new FileNotFoundException();
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(archivo(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        String p = uri.getLastPathSegment();
        return Chat.mime(p == null ? "" : p);
    }

    @Override
    public Cursor query(Uri uri, String[] proj, String sel, String[] args, String orden) {
        try {
            File f = archivo(uri);
            MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues v) {
        return null;
    }

    @Override
    public int delete(Uri uri, String s, String[] a) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues v, String s, String[] a) {
        return 0;
    }
}
