package co.jose.mischats;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lee el archivo de texto que exporta WhatsApp y lo convierte en mensajes. */
final class Chat {

    static final int TEXTO = 0, FOTO = 1, AUDIO = 2, VIDEO = 3, DOC = 4;

    static final class Msg {
        String fecha = "", hora = "", quien = "", texto = "", archivo = "";
        boolean editado, sistema;
        int tipo = TEXTO;

        boolean esMio(String yo) {
            return yo != null && !yo.isEmpty() && yo.equals(quien);
        }
    }

    String contacto = "";
    final List<Msg> msgs = new ArrayList<>();
    final Map<String, Integer> remitentes = new LinkedHashMap<>();

    private static final Pattern LINEA = Pattern.compile(
            "^\\[?(\\d{1,2}/\\d{1,2}/\\d{2,4}),?\\s+(\\d{1,2}:\\d{2}(?::\\d{2})?(?:\\s*[aApP]\\.?\\s?[mM]\\.?)?)\\]?\\s*(?:-\\s)?(.*)$");

    static Chat leer(String todo) {
        Chat ch = new Chat();
        String t = todo.replace("‎", "").replace("‏", "").replace(" ", " ").replace(" ", " ")
                .replace("\r", "");
        Msg ultimo = null;
        for (String linea : t.split("\n")) {
            Matcher m = LINEA.matcher(linea);
            if (m.matches()) {
                Msg x = new Msg();
                x.fecha = m.group(1);
                x.hora = m.group(2).trim();
                String resto = m.group(3);
                int dos = resto.indexOf(": ");
                if (dos > 0 && dos < 60) {
                    x.quien = resto.substring(0, dos).trim();
                    x.texto = resto.substring(dos + 2);
                } else if (resto.endsWith(":") && resto.length() < 60) {
                    x.quien = resto.substring(0, resto.length() - 1).trim();
                    x.texto = "";
                } else {
                    x.sistema = true;
                    x.texto = resto;
                }
                ch.msgs.add(x);
                ultimo = x;
            } else if (ultimo != null) {
                ultimo.texto += "\n" + linea;
            }
        }
        for (Msg x : ch.msgs) {
            arreglar(x);
            if (!x.sistema) {
                Integer n = ch.remitentes.get(x.quien);
                ch.remitentes.put(x.quien, n == null ? 1 : n + 1);
            }
        }
        return ch;
    }

    private static void arreglar(Msg x) {
        String s = x.texto;
        String[] marcas = {"<Se editó este mensaje.>", "<This message was edited>", "<Se editó este mensaje>"};
        for (String k : marcas) {
            if (s.contains(k)) {
                x.editado = true;
                s = s.replace(k, "");
            }
        }
        s = s.trim();
        if (x.sistema) {
            x.texto = s;
            return;
        }
        String primera = s, resto = "";
        int salto = s.indexOf('\n');
        if (salto >= 0) {
            primera = s.substring(0, salto).trim();
            resto = s.substring(salto + 1).trim();
        }
        String archivo = null;
        String[] fin = {" (archivo adjunto)", " (file attached)"};
        for (String k : fin) {
            if (primera.endsWith(k)) archivo = primera.substring(0, primera.length() - k.length()).trim();
        }
        String[] ini = {"<adjunto: ", "<attached: "};
        for (String k : ini) {
            if (primera.startsWith(k) && primera.endsWith(">")) archivo = primera.substring(k.length(), primera.length() - 1).trim();
        }
        if (archivo != null) {
            x.archivo = archivo;
            x.tipo = tipoDe(archivo);
            x.texto = resto;
        } else if (s.equals("<Multimedia omitido>") || s.equals("<Media omitted>")) {
            x.texto = "(foto o archivo que no vino en la exportación)";
        } else if (s.isEmpty()) {
            x.texto = "(mensaje sin contenido)";
        } else {
            x.texto = s;
        }
    }

    static int tipoDe(String nombre) {
        String n = nombre.toLowerCase();
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".gif")) return FOTO;
        if (n.endsWith(".opus") || n.endsWith(".m4a") || n.endsWith(".mp3") || n.endsWith(".ogg") || n.endsWith(".aac") || n.endsWith(".amr") || n.endsWith(".wav")) return AUDIO;
        if (n.endsWith(".mp4") || n.endsWith(".3gp") || n.endsWith(".mov") || n.endsWith(".mkv") || n.endsWith(".webm")) return VIDEO;
        return DOC;
    }

    static String mime(String nombre) {
        String n = nombre.toLowerCase();
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (tipoDe(n) == FOTO) return "image/jpeg";
        if (n.endsWith(".opus") || n.endsWith(".ogg")) return "audio/ogg";
        if (n.endsWith(".m4a") || n.endsWith(".aac")) return "audio/mp4";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        if (n.endsWith(".amr")) return "audio/amr";
        if (n.endsWith(".wav")) return "audio/wav";
        if (n.endsWith(".mp4")) return "video/mp4";
        if (n.endsWith(".3gp")) return "video/3gpp";
        if (n.endsWith(".webm") || n.endsWith(".mkv")) return "video/webm";
        if (n.endsWith(".mov")) return "video/quicktime";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".vcf")) return "text/x-vcard";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        return "application/octet-stream";
    }

    private static final String[] MESES = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
            "agosto", "septiembre", "octubre", "noviembre", "diciembre"};

    static String fechaLarga(String f) {
        try {
            String[] p = f.split("/");
            int d = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
            String a = p[2].length() == 2 ? "20" + p[2] : p[2];
            return d + " de " + MESES[m - 1] + " de " + a;
        } catch (Exception e) {
            return f;
        }
    }

    int contar(int tipo) {
        int n = 0;
        for (Msg x : msgs) if (!x.sistema && x.tipo == tipo && !x.archivo.isEmpty()) n++;
        return n;
    }

    int mensajes() {
        int n = 0;
        for (Msg x : msgs) if (!x.sistema) n++;
        return n;
    }

    String desde() {
        return msgs.isEmpty() ? "" : msgs.get(0).fecha;
    }

    String hasta() {
        return msgs.isEmpty() ? "" : msgs.get(msgs.size() - 1).fecha;
    }

    /** Si el chat es de dos personas y una es el contacto, la otra es "yo". */
    String adivinarYo() {
        if (remitentes.size() == 2 && remitentes.containsKey(contacto)) {
            for (String k : remitentes.keySet()) if (!k.equals(contacto)) return k;
        }
        if (remitentes.size() == 1 && !remitentes.containsKey(contacto)) {
            return remitentes.keySet().iterator().next();
        }
        return "";
    }
}
