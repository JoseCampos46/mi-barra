package co.jose.mischats;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Mete en ChpChat el zip que exporta WhatsApp (o los archivos sueltos).
 * Las fotos se achican a 1280 de lado (se ven igual en el celular) y las repetidas se guardan una sola vez.
 * Los audios y videos se guardan tal cual.
 */
final class Importador {

    interface Avance {
        void va(String que);
    }

    /** Un chat guardado dentro de ChpChat. */
    static final class Guardado {
        File dir;
        Properties meta = new Properties();

        String m(String k) {
            return meta.getProperty(k, "");
        }

        File chatTxt() {
            return new File(dir, "chat.txt");
        }

        File archivos() {
            return new File(dir, "archivos");
        }

        /** Busca el archivo; si era una foto repetida, devuelve la que quedó guardada. */
        File archivo(String nombre) {
            File f = new File(archivos(), nombre);
            if (f.exists()) return f;
            String otro = iguales().getProperty(nombre);
            if (otro != null) return new File(archivos(), otro);
            return f;
        }

        private Properties iguales;

        Properties iguales() {
            if (iguales == null) {
                iguales = new Properties();
                cargar(new File(dir, "iguales.properties"), iguales);
            }
            return iguales;
        }

        void guardarMeta() {
            guardar(new File(dir, "meta.properties"), meta);
        }

        Chat leer() throws Exception {
            Chat ch = Chat.leer(leerTexto(chatTxt()));
            ch.contacto = m("contacto");
            return ch;
        }
    }

    static File raiz(Context c) {
        File f = new File(c.getExternalFilesDir(null), "chats");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    static List<Guardado> todos(Context c) {
        List<Guardado> l = new ArrayList<>();
        File[] ds = raiz(c).listFiles();
        if (ds == null) return l;
        for (File d : ds) {
            if (!d.isDirectory() || !new File(d, "chat.txt").exists()) continue;
            Guardado g = new Guardado();
            g.dir = d;
            cargar(new File(d, "meta.properties"), g.meta);
            l.add(g);
        }
        l.sort((a, b) -> b.m("importado").compareTo(a.m("importado")));
        return l;
    }

    static Guardado abrir(File dir) {
        Guardado g = new Guardado();
        g.dir = dir;
        cargar(new File(dir, "meta.properties"), g.meta);
        return g;
    }

    static Guardado importar(Context c, List<Uri> uris, Avance av) throws Exception {
        ContentResolver r = c.getContentResolver();
        String marca = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File dir = new File(raiz(c), "chat_" + marca);
        File arch = new File(dir, "archivos");
        arch.mkdirs();

        Estado e = new Estado();
        e.dir = dir;
        e.arch = arch;
        e.av = av;

        for (Uri u : uris) {
            String nombre = nombreDe(c, u);
            long tam = tamanoDe(c, u);
            if (tam > 0) e.pesoAntes += tam;
            if (nombre.toLowerCase().endsWith(".zip")) {
                boolean sumarZip = tam <= 0;
                try (InputStream in = r.openInputStream(u); ZipInputStream z = new ZipInputStream(in)) {
                    ZipEntry ze;
                    while ((ze = z.getNextEntry()) != null) {
                        if (ze.isDirectory()) continue;
                        String n = new File(ze.getName()).getName();
                        long k = e.recibir(n, z);
                        if (sumarZip) e.pesoAntes += k;
                    }
                }
            } else {
                try (InputStream in = r.openInputStream(u)) {
                    long k = e.recibir(nombre, in);
                    if (tam <= 0) e.pesoAntes += k;
                }
            }
        }

        if (e.txtNombre == null) {
            borrarTodo(dir);
            throw new Exception("En lo que escogió no encontré el texto del chat (.txt). Exporte el chat desde WhatsApp y escoja el zip.");
        }
        if (!e.iguales.isEmpty()) guardar(new File(dir, "iguales.properties"), e.iguales);

        Guardado g = new Guardado();
        g.dir = dir;
        String contacto = e.txtNombre.replaceAll("(?i)\\.txt$", "");
        String[] quitar = {"Chat de WhatsApp con ", "WhatsApp Chat with ", "WhatsApp Chat - ", "Chat de WhatsApp - "};
        for (String q : quitar) if (contacto.startsWith(q)) contacto = contacto.substring(q.length());
        if (contacto.equals("_chat")) contacto = "";
        Chat ch = Chat.leer(leerTexto(g.chatTxt()));
        if (contacto.isEmpty()) {
            for (String k : ch.remitentes.keySet()) { contacto = k; break; }
        }
        ch.contacto = contacto;
        g.meta.setProperty("contacto", contacto);
        g.meta.setProperty("yo", ch.adivinarYo());
        g.meta.setProperty("importado", marca);
        g.meta.setProperty("desde", ch.desde());
        g.meta.setProperty("hasta", ch.hasta());
        g.meta.setProperty("mensajes", String.valueOf(ch.mensajes()));
        g.meta.setProperty("fotos", String.valueOf(ch.contar(Chat.FOTO)));
        g.meta.setProperty("audios", String.valueOf(ch.contar(Chat.AUDIO)));
        g.meta.setProperty("videos", String.valueOf(ch.contar(Chat.VIDEO)));
        g.meta.setProperty("pesoAntes", String.valueOf(e.pesoAntes));
        g.meta.setProperty("pesoAhora", String.valueOf(peso(dir)));
        g.meta.setProperty("repetidas", String.valueOf(e.iguales.size()));
        g.guardarMeta();
        return g;
    }

    private static final class Estado {
        File dir, arch;
        Avance av;
        String txtNombre;
        long pesoAntes;
        int n;
        final Map<String, String> huellas = new HashMap<>();
        final Properties iguales = new Properties();

        /** Devuelve cuántos bytes traía el archivo. Audios y videos van directo al disco (no se cargan en memoria). */
        long recibir(String nombre, InputStream in) throws Exception {
            String bajo = nombre.toLowerCase();
            if (bajo.endsWith(".txt") || Chat.tipoDe(nombre) == Chat.FOTO) {
                byte[] b = leerTodo(in);
                recibir(nombre, b);
                return b.length;
            }
            n++;
            if (av != null) av.va("Archivo " + n + ": " + nombre);
            File tmp = new File(dir, "tmp_" + n);
            MessageDigest md = MessageDigest.getInstance("MD5");
            long total = 0;
            try (OutputStream o = new FileOutputStream(tmp)) {
                byte[] buf = new byte[65536];
                int k;
                while ((k = in.read(buf)) > 0) {
                    o.write(buf, 0, k);
                    md.update(buf, 0, k);
                    total += k;
                }
            }
            StringBuilder hs = new StringBuilder();
            for (byte x : md.digest()) hs.append(String.format("%02x", x));
            String h = hs + "_" + total;
            String ya = huellas.get(h);
            if (ya != null) {
                tmp.delete();
                iguales.setProperty(nombre, ya);
            } else {
                huellas.put(h, nombre);
                File dest = new File(arch, nombre);
                if (!tmp.renameTo(dest)) {
                    try (OutputStream o = new FileOutputStream(dest)) { copiar(tmp, o); }
                    tmp.delete();
                }
            }
            return total;
        }

        void recibir(String nombre, byte[] b) throws Exception {
            n++;
            if (av != null) av.va("Archivo " + n + ": " + nombre);
            if (nombre.toLowerCase().endsWith(".txt") && (txtNombre == null || nombre.toLowerCase().contains("chat"))) {
                if (txtNombre == null || b.length > new File(dir, "chat.txt").length()) {
                    escribir(new File(dir, "chat.txt"), b);
                    txtNombre = nombre;
                }
                return;
            }
            String h = huella(b);
            String ya = huellas.get(h);
            if (ya != null) {
                iguales.setProperty(nombre, ya);
                return;
            }
            huellas.put(h, nombre);
            byte[] fin = b;
            if (Chat.tipoDe(nombre) == Chat.FOTO && !nombre.toLowerCase().endsWith(".gif")
                    && !nombre.toLowerCase().endsWith(".webp")) {
                byte[] chica = achicarFoto(b);
                if (chica != null && chica.length < b.length) fin = chica;
            }
            escribir(new File(arch, nombre), fin);
        }
    }

    static byte[] achicarFoto(byte[] b) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(b, 0, b.length, o);
            int lado = Math.max(o.outWidth, o.outHeight);
            if (lado <= 0) return null;
            int s = 1;
            while (lado / (s * 2) >= 1280) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length, o2);
            if (bm == null) return null;
            int l2 = Math.max(bm.getWidth(), bm.getHeight());
            if (l2 > 1280) {
                float f = 1280f / l2;
                Bitmap esc = Bitmap.createScaledBitmap(bm, Math.round(bm.getWidth() * f), Math.round(bm.getHeight() * f), true);
                if (esc != bm) bm.recycle();
                bm = esc;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 72, out);
            bm.recycle();
            return out.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- Ayudantes ----------

    static String nombreDe(Context c, Uri u) {
        try (Cursor cur = c.getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst() && cur.getString(0) != null) return cur.getString(0);
        } catch (Exception ignored) {}
        String p = u.getLastPathSegment();
        return p == null ? "archivo" : new File(p).getName();
    }

    static long tamanoDe(Context c, Uri u) {
        try (Cursor cur = c.getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (cur != null && cur.moveToFirst() && !cur.isNull(0)) return cur.getLong(0);
        } catch (Exception ignored) {}
        return -1;
    }

    static byte[] leerTodo(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int k;
        while ((k = in.read(buf)) > 0) o.write(buf, 0, k);
        return o.toByteArray();
    }

    static String leerTexto(File f) throws Exception {
        try (Reader rd = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
            StringBuilder b = new StringBuilder();
            char[] buf = new char[16384];
            int k;
            while ((k = rd.read(buf)) > 0) b.append(buf, 0, k);
            String s = b.toString();
            if (s.startsWith("﻿")) s = s.substring(1);
            return s;
        }
    }

    static void escribir(File f, byte[] b) throws Exception {
        try (OutputStream o = new FileOutputStream(f)) {
            o.write(b);
        }
    }

    static void copiar(File f, OutputStream o) throws Exception {
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[65536];
            int k;
            while ((k = in.read(buf)) > 0) o.write(buf, 0, k);
        }
    }

    static String huella(byte[] b) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(b);
            StringBuilder s = new StringBuilder();
            for (byte x : d) s.append(String.format("%02x", x));
            return s.toString() + "_" + b.length;
        } catch (Exception e) {
            return String.valueOf(b.length);
        }
    }

    static void cargar(File f, Properties p) {
        if (!f.exists()) return;
        try (Reader rd = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
            p.load(rd);
        } catch (Exception ignored) {}
    }

    static void guardar(File f, Properties p) {
        try (java.io.Writer w = new java.io.OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            p.store(w, "ChpChat");
        } catch (Exception ignored) {}
    }

    static long peso(File f) {
        if (f.isFile()) return f.length();
        long t = 0;
        File[] l = f.listFiles();
        if (l != null) for (File x : l) t += peso(x);
        return t;
    }

    static void borrarTodo(File f) {
        File[] l = f.listFiles();
        if (l != null) for (File x : l) borrarTodo(x);
        f.delete();
    }

    static String megas(long b) {
        if (b < 1024 * 1024) return Math.max(1, b / 1024) + " KB";
        return String.format(new Locale("es", "CO"), "%.1f MB", b / 1048576.0);
    }
}
