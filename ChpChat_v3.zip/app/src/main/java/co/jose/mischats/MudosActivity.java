package co.jose.mischats;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Silenciar las llamadas de WhatsApp de quien uno escoja (a la otra persona le sigue timbrando). */
public class MudosActivity extends Base {

    private LinearLayout l;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(VERDE_OSCURO);
        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(FONDO);
        LinearLayout barra = horizontal();
        barra.setBackgroundColor(VERDE_OSCURO);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        Button atras = boton("←", VERDE_OSCURO, Color.WHITE, 24);
        atras.setOnClickListener(v -> finish());
        barra.addView(atras, new LinearLayout.LayoutParams(dp(52), dp(56)));
        barra.addView(texto("Silenciar llamadas de WhatsApp", 19, true, Color.WHITE),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        raiz.addView(barra, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        ScrollView sc = new ScrollView(this);
        l = vertical();
        l.setPadding(dp(6), dp(6), dp(6), dp(10));
        sc.addView(l);
        raiz.addView(sc, relleno());
        setContentView(raiz);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pintar();
    }

    private void pintar() {
        l.removeAllViews();
        List<Reglas.Entrada> lista = Reglas.lista(this);
        int enWa = 0;
        for (Reglas.Entrada e : lista) if (e.wa) enWa++;
        LinearLayout met = horizontal();
        met.addView(cifra("Calladas hoy", String.valueOf(Reglas.mudasHoy(this))), peso(1));
        met.addView(cifra("En la lista", enWa + (enWa == 1 ? " persona" : " personas")), peso(1));
        l.addView(met, ancho());

        l.addView(subtitulo("Lista de mudos en WhatsApp"));
        if (enWa == 0) l.addView(nota("La lista está vacía. Agregue con los botones de abajo."));
        for (Reglas.Entrada e : lista) {
            if (!e.wa) continue;
            String det = e.numero.isEmpty() ? "por nombre de WhatsApp" : Reglas.formato(e.numero);
            l.addView(fila(e.titulo(), det, () -> editar(e)));
        }

        LinearLayout b1 = horizontal();
        Button num = boton("Escribir número", TARJETA, NEGRO, 16);
        num.setOnClickListener(v -> nuevo(false));
        Button nom = boton("Nombre de WhatsApp", TARJETA, NEGRO, 16);
        nom.setOnClickListener(v -> nuevo(true));
        b1.addView(num, peso(1));
        b1.addView(nom, peso(1));
        l.addView(b1, alto(62));

        l.addView(subtitulo("Reglas generales"));
        l.addView(interruptor("Números que no tengo guardados: mudos", "desconocidos"));
        l.addView(interruptor("De noche (10 p. m. a 6 a. m.) solo suenan mis contactos", "noche"));

        l.addView(subtitulo("Quién llamó mudo y a qué hora"));
        List<Reglas.Muda> m = Reglas.mudas(this);
        int n = 0;
        for (Reglas.Muda x : m) {
            if (!"WhatsApp".equals(x.via)) continue;
            if (++n > 30) break;
            String quien = !x.nombre.isEmpty() ? x.nombre : (x.numero.isEmpty() ? "Sin nombre" : Reglas.formato(x.numero));
            l.addView(nota(Reglas.fecha(x.cuando) + " · " + quien + " · " + x.motivo));
        }
        if (n == 0) l.addView(nota("Todavía no ha callado ninguna llamada de WhatsApp."));

        l.addView(subtitulo("Permisos (actívelos una sola vez)"));
        l.addView(permiso("1. Avisos de WhatsApp",
                "Para callar las llamadas de WhatsApp. Busque \"ChpChat\" en la lista y actívelo.",
                avisosOk(), () -> abrirAjuste(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        l.addView(permiso("2. No molestar",
                "Para quitar también la vibración. Busque \"ChpChat\" y actívelo.",
                noMolestarOk(), () -> abrirAjuste(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));
        l.addView(permiso("3. Contactos",
                "Para reconocer a sus contactos por el nombre. Toque \"Permitir\".",
                Reglas.puede(this, Manifest.permission.READ_CONTACTS), this::pedirContactos));
        TextView xi = texto("En Xiaomi: si deja de funcionar, en Ajustes > Apps > ChpChat ponga \"Inicio automático\" activado y Ahorro de batería en \"Sin restricciones\".\n\n"
                + "Las llamadas normales del teléfono las silencia Mi Barra.", 14, false, GRIS);
        xi.setPadding(dp(6), dp(8), dp(6), dp(4));
        l.addView(xi);
    }

    private View cifra(String titulo, String valor) {
        LinearLayout v = vertical();
        v.setBackground(fondo(TARJETA, dp(10)));
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        v.addView(texto(titulo, 14, false, GRIS));
        v.addView(texto(valor, 22, true, NEGRO));
        return v;
    }

    private TextView subtitulo(String s) {
        TextView t = texto(s, 19, true, VERDE_OSCURO);
        t.setPadding(dp(6), dp(14), dp(6), dp(4));
        return t;
    }

    private TextView nota(String s) {
        TextView t = texto(s, 15, false, GRIS);
        t.setPadding(dp(8), dp(4), dp(8), dp(4));
        return t;
    }

    private View fila(String titulo, String det, Runnable toque) {
        LinearLayout f = horizontal();
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(8), dp(8), dp(8), dp(8));
        TextView x = texto("✕", 18, true, ROJO);
        x.setGravity(Gravity.CENTER);
        x.setBackground(fondo(ROJO_CLARO, dp(20)));
        f.addView(x, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout v = vertical();
        v.setPadding(dp(10), 0, 0, 0);
        v.addView(texto(titulo, 17, true, NEGRO));
        v.addView(texto(det, 14, false, GRIS));
        f.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        f.setOnClickListener(z -> toque.run());
        LinearLayout envol = vertical();
        envol.addView(f);
        envol.addView(separador());
        return envol;
    }

    private View interruptor(String texto, String clave) {
        CheckBox c = new CheckBox(this);
        c.setText(texto);
        c.setTextSize(17);
        c.setTextColor(NEGRO);
        c.setPadding(dp(4), dp(8), dp(4), dp(8));
        SharedPreferences sp = Reglas.p(this);
        c.setChecked(sp.getBoolean(clave, false));
        c.setOnCheckedChangeListener((b, si) -> sp.edit().putBoolean(clave, si).apply());
        return c;
    }

    private View permiso(String titulo, String explica, boolean listo, Runnable activar) {
        LinearLayout f = horizontal();
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout v = vertical();
        v.addView(texto(titulo, 17, true, NEGRO));
        v.addView(texto(explica, 14, false, GRIS));
        f.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (listo) {
            TextView ok = texto("Listo ✓", 16, true, VERDE_VIVO);
            ok.setGravity(Gravity.CENTER);
            f.addView(ok, new LinearLayout.LayoutParams(dp(96), dp(50)));
        } else {
            Button b = boton("Activar", ROJO, Color.WHITE, 16);
            b.setOnClickListener(x -> activar.run());
            f.addView(b, new LinearLayout.LayoutParams(dp(96), dp(50)));
        }
        LinearLayout envol = vertical();
        envol.addView(f);
        envol.addView(separador());
        return envol;
    }

    private void editar(Reglas.Entrada e) {
        String[] op = {"Cambiar nombre", "Quitar de la lista"};
        new AlertDialog.Builder(this).setTitle(e.titulo()).setItems(op, (d, w) -> {
            List<Reglas.Entrada> lista = Reglas.lista(this);
            Reglas.Entrada x = null;
            for (Reglas.Entrada y : lista) if (y.numero.equals(e.numero) && y.nombre.equals(e.nombre)) x = y;
            if (x == null) return;
            if (w == 0) {
                final Reglas.Entrada z = x;
                EditText et = new EditText(this);
                et.setText(z.nombre);
                et.setTextSize(19);
                new AlertDialog.Builder(this).setTitle("Nombre").setView(et)
                        .setPositiveButton("Guardar", (d2, w2) -> {
                            z.nombre = et.getText().toString().trim();
                            Reglas.guardarLista(this, lista);
                            pintar();
                        }).setNegativeButton("Cancelar", null).show();
                return;
            }
            if (x.tel) x.wa = false;
            else lista.remove(x);
            Reglas.guardarLista(this, lista);
            pintar();
        }).show();
    }

    private void nuevo(boolean porNombre) {
        LinearLayout v = vertical();
        v.setPadding(dp(18), dp(8), dp(18), 0);
        EditText nom = new EditText(this);
        nom.setHint(porNombre ? "Nombre tal cual sale en WhatsApp" : "Nombre (si quiere)");
        nom.setTextSize(19);
        v.addView(nom);
        EditText num = new EditText(this);
        if (!porNombre) {
            num.setHint("Número");
            num.setInputType(InputType.TYPE_CLASS_PHONE);
            num.setTextSize(22);
            v.addView(num);
        }
        new AlertDialog.Builder(this).setTitle(porNombre ? "Mudo por nombre de WhatsApp" : "Agregar a mudos").setView(v)
                .setPositiveButton("Agregar", (d, w) -> {
                    String n = nom.getText().toString();
                    String nu = porNombre ? "" : num.getText().toString();
                    if (n.trim().isEmpty() && Reglas.digitos(nu).isEmpty()) {
                        aviso("Escriba un número o un nombre");
                        return;
                    }
                    Reglas.agregar(this, n, nu, false, true);
                    aviso("Agregado a mudos de WhatsApp");
                    pintar();
                }).setNegativeButton("Cancelar", null).show();
    }

    private boolean avisosOk() {
        try {
            return getSystemService(NotificationManager.class)
                    .isNotificationListenerAccessGranted(new ComponentName(this, OyenteWhatsApp.class));
        } catch (Exception e) {
            return false;
        }
    }

    private boolean noMolestarOk() {
        try {
            return getSystemService(NotificationManager.class).isNotificationPolicyAccessGranted();
        } catch (Exception e) {
            return false;
        }
    }

    private void pedirContactos() {
        List<String> p = new ArrayList<>();
        p.add(Manifest.permission.READ_CONTACTS);
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(p.toArray(new String[0]), 11);
    }

    private void abrirAjuste(String accion) {
        try {
            startActivity(new Intent(accion));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        pintar();
    }
}
