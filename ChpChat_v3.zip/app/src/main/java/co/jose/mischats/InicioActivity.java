package co.jose.mischats;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Pantalla de inicio de ChpChat: los chats que ya se subieron y el botón para abrir un zip nuevo. */
public class InicioActivity extends Base {

    static final String VERSION = "v3";
    private static final int ABRIR = 21;

    private LinearLayout lista;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean trabajando;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(VERDE_OSCURO);
        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(FONDO);

        raiz.addView(barra(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        ScrollView sc = new ScrollView(this);
        lista = vertical();
        lista.setPadding(dp(6), dp(6), dp(6), dp(6));
        sc.addView(lista);
        raiz.addView(sc, relleno());

        Button abrir = boton("Abrir zip de WhatsApp", VERDE, Color.WHITE, 19);
        abrir.setOnClickListener(v -> escogerZip());
        raiz.addView(abrir, alto(64));

        setContentView(raiz);
        recibir(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        recibir(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pintar();
    }

    private View barra() {
        LinearLayout f = horizontal();
        f.setBackgroundColor(VERDE_OSCURO);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(4), 0, dp(10), 0);
        Button menu = boton("☰", VERDE_OSCURO, Color.WHITE, 24);
        menu.setOnClickListener(v -> menu());
        f.addView(menu, new LinearLayout.LayoutParams(dp(54), dp(54)));
        TextView t = texto("ChpChat", 22, true, Color.WHITE);
        f.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = texto(VERSION, 16, true, VERDE_OSCURO);
        v.setBackground(fondo(Color.WHITE, dp(6)));
        v.setPadding(dp(8), dp(2), dp(8), dp(2));
        f.addView(v);
        return f;
    }

    private void pintar() {
        lista.removeAllViews();
        List<Importador.Guardado> l = Importador.todos(this);
        if (l.isEmpty()) {
            TextView t = texto("Todavía no ha subido ningún chat.\n\n"
                    + "1. Abra WhatsApp y entre al chat.\n"
                    + "2. Toque los tres puntos (⋮) arriba a la derecha.\n"
                    + "3. Toque Más.\n"
                    + "4. Toque Exportar chat.\n"
                    + "5. Escoja Incluir archivos.\n"
                    + "6. En la lista de apps escoja ChpChat (o guarde el zip y toque el botón verde de abajo).", 18, false, NEGRO);
            t.setPadding(dp(10), dp(14), dp(10), dp(10));
            lista.addView(t);
            return;
        }
        TextView tit = texto("Mis chats guardados (" + l.size() + ")", 18, true, VERDE_OSCURO);
        tit.setPadding(dp(6), dp(6), dp(6), dp(4));
        lista.addView(tit);
        for (Importador.Guardado g : l) lista.addView(tarjeta(g));
    }

    private View tarjeta(Importador.Guardado g) {
        LinearLayout f = horizontal();
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setBackground(fondo(TARJETA, dp(12)));
        f.setPadding(dp(10), dp(10), dp(10), dp(10));
        TextView ini = texto(iniciales(g.m("contacto")), 18, true, VERDE_OSCURO);
        ini.setGravity(Gravity.CENTER);
        ini.setBackground(fondo(VERDE_CLARO, dp(24)));
        f.addView(ini, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout v = vertical();
        v.setPadding(dp(10), 0, 0, 0);
        v.addView(texto(g.m("contacto").isEmpty() ? "Chat" : g.m("contacto"), 19, true, NEGRO));
        v.addView(texto("Del " + g.m("desde") + " al " + g.m("hasta"), 15, false, GRIS));
        String det = g.m("mensajes") + " mensajes · " + g.m("fotos") + " fotos · " + g.m("audios") + " audios";
        if (!"0".equals(g.m("videos")) && !g.m("videos").isEmpty()) det += " · " + g.m("videos") + " videos";
        v.addView(texto(det, 15, false, GRIS));
        long antes = parse(g.m("pesoAntes")), ahora = parse(g.m("pesoAhora"));
        if (antes > 0 && ahora > 0) {
            v.addView(texto("Pesaba " + Importador.megas(antes) + " → ahora " + Importador.megas(ahora), 15, false, VERDE));
        }
        f.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        f.setOnClickListener(x -> abrirChat(g));
        f.setOnLongClickListener(x -> {
            opciones(g);
            return true;
        });
        LinearLayout.LayoutParams lp = ancho();
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        f.setLayoutParams(lp);
        return f;
    }

    private static long parse(String s) {
        try {
            return Long.parseLong(s);
        } catch (Exception e) {
            return 0;
        }
    }

    private void abrirChat(Importador.Guardado g) {
        Intent i = new Intent(this, ChatActivity.class);
        i.putExtra("dir", g.dir.getAbsolutePath());
        startActivity(i);
    }

    private void opciones(Importador.Guardado g) {
        String[] op = {"Abrir", "¿Quién soy yo en este chat?", "Borrar de ChpChat"};
        new AlertDialog.Builder(this).setTitle(g.m("contacto")).setItems(op, (d, w) -> {
            if (w == 0) abrirChat(g);
            else if (w == 1) escogerYo(this, g, null);
            else new AlertDialog.Builder(this).setTitle("¿Borrar este chat de ChpChat?")
                        .setMessage("Se borra solo de ChpChat. Lo que ya exportó a Descargas no se toca.")
                        .setPositiveButton("Borrar", (d2, w2) -> {
                            Importador.borrarTodo(g.dir);
                            pintar();
                        }).setNegativeButton("Cancelar", null).show();
        }).show();
    }

    /** Pregunta cuál de los que escriben en el chat es uno (para ponerlo a la derecha). */
    static void escogerYo(Base a, Importador.Guardado g, Runnable luego) {
        try {
            Chat ch = g.leer();
            List<String> nombres = new ArrayList<>(ch.remitentes.keySet());
            if (nombres.isEmpty()) return;
            String[] op = new String[nombres.size()];
            for (int i = 0; i < op.length; i++) op[i] = nombres.get(i) + "  (" + ch.remitentes.get(nombres.get(i)) + " mensajes)";
            new AlertDialog.Builder(a).setTitle("¿Cuál es usted? (sus mensajes van a la derecha)").setItems(op, (d, w) -> {
                g.meta.setProperty("yo", nombres.get(w));
                g.guardarMeta();
                a.getSharedPreferences("mischats", MODE_PRIVATE).edit().putString("yoGeneral", nombres.get(w)).apply();
                if (luego != null) luego.run();
            }).show();
        } catch (Exception e) {
            a.aviso("No pude leer el chat: " + e.getMessage());
        }
    }

    private void menu() {
        String[] op = {"Silenciar llamadas de WhatsApp", "Cómo exportar un chat de WhatsApp", "Dónde se guardan las cosas", "Acerca de ChpChat"};
        new AlertDialog.Builder(this).setTitle("ChpChat " + VERSION).setItems(op, (d, w) -> {
            if (w == 0) startActivity(new Intent(this, MudosActivity.class));
            else if (w == 1) ayuda("Cómo exportar un chat",
                    "1. Abra WhatsApp y entre al chat.\n"
                            + "2. Toque los tres puntos (⋮) arriba a la derecha.\n"
                            + "3. Toque Más.\n"
                            + "4. Toque Exportar chat.\n"
                            + "5. Escoja Incluir archivos.\n"
                            + "6. En la lista de apps escoja ChpChat.\n\n"
                            + "Si no sale ChpChat: guarde el zip en el celular, abra ChpChat y toque «Abrir zip de WhatsApp».");
            else if (w == 2) ayuda("Dónde se guardan las cosas",
                    "• Los chats que sube quedan dentro de ChpChat, con las fotos achicadas y las repetidas una sola vez.\n\n"
                            + "• Lo que exporta (hojas en imagen, PDF y paquete zip) queda en Descargas/MiBarra/ChpChat, "
                            + "en una carpeta con el nombre del contacto y la fecha.\n\n"
                            + "• Si mueve esa carpeta a la nube, ChpChat la vuelve a crear la próxima vez.");
            else ayuda("ChpChat " + VERSION,
                        "Antes se llamaba Mis Chats.\n\n"
                                + "• Sube el chat que exporta WhatsApp y lo muestra igual que WhatsApp.\n"
                                + "• Lupa para buscar por mensaje, nombre, teléfono o fecha.\n"
                                + "• Exporta en hojas carta de 3 columnas (imagen y PDF) o en paquete comprimido.\n"
                                + "• Silencia las llamadas de WhatsApp de quien usted escoja.\n\n"
                                + "Las llamadas normales del teléfono las maneja Mi Barra.");
        }).show();
    }

    private void ayuda(String t, String m) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("Entendido", null).show();
    }

    private void escogerZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream", "text/plain"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, ABRIR);
        } catch (Exception e) {
            aviso("No encontré cómo abrir archivos en este celular.");
        }
    }

    @Override
    protected void onActivityResult(int code, int res, Intent data) {
        super.onActivityResult(code, res, data);
        if (code != ABRIR || res != RESULT_OK || data == null) return;
        List<Uri> l = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int k = 0; k < data.getClipData().getItemCount(); k++) l.add(data.getClipData().getItemAt(k).getUri());
        } else if (data.getData() != null) {
            l.add(data.getData());
        }
        importar(l);
    }

    private void recibir(Intent i) {
        if (i == null || i.getAction() == null) return;
        List<Uri> l = new ArrayList<>();
        String a = i.getAction();
        try {
            if (Intent.ACTION_SEND.equals(a)) {
                Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) l.add(u);
            } else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) {
                ArrayList<Parcelable> ps = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (ps != null) for (Parcelable p : ps) if (p instanceof Uri) l.add((Uri) p);
            } else if (Intent.ACTION_VIEW.equals(a) && i.getData() != null) {
                l.add(i.getData());
            }
        } catch (Exception ignored) {}
        setIntent(new Intent(this, InicioActivity.class));
        if (!l.isEmpty()) importar(l);
    }

    private void importar(List<Uri> uris) {
        if (trabajando || uris.isEmpty()) return;
        trabajando = true;
        TextView estado = texto("Abriendo el chat…", 17, false, NEGRO);
        estado.setPadding(dp(20), dp(16), dp(20), dp(8));
        AlertDialog esp = new AlertDialog.Builder(this).setTitle("Subiendo el chat a ChpChat").setView(estado)
                .setCancelable(false).show();
        new Thread(() -> {
            try {
                Importador.Guardado g = Importador.importar(this, uris, que -> h.post(() -> estado.setText(que)));
                h.post(() -> {
                    trabajando = false;
                    esp.dismiss();
                    pintar();
                    String yo = g.m("yo");
                    String general = getSharedPreferences("mischats", MODE_PRIVATE).getString("yoGeneral", "");
                    if (yo.isEmpty() && !general.isEmpty()) {
                        try {
                            if (g.leer().remitentes.containsKey(general)) {
                                g.meta.setProperty("yo", general);
                                g.guardarMeta();
                                yo = general;
                            }
                        } catch (Exception ignored) {}
                    }
                    String msg = "Listo: " + g.m("mensajes") + " mensajes, " + g.m("fotos") + " fotos y " + g.m("audios") + " audios.\n"
                            + "Pesaba " + Importador.megas(parse(g.m("pesoAntes"))) + " y ahora " + Importador.megas(parse(g.m("pesoAhora"))) + ".";
                    if (!"0".equals(g.m("repetidas"))) msg += "\nFotos repetidas guardadas una sola vez: " + g.m("repetidas") + ".";
                    final boolean preguntar = yo.isEmpty();
                    new AlertDialog.Builder(this).setTitle("Chat con " + g.m("contacto")).setMessage(msg)
                            .setPositiveButton("Ver el chat", (d, w) -> {
                                if (preguntar) escogerYo(this, g, () -> abrirChat(g));
                                else abrirChat(g);
                            })
                            .setNegativeButton("Cerrar", null).show();
                });
            } catch (Throwable e) {
                h.post(() -> {
                    trabajando = false;
                    esp.dismiss();
                    new AlertDialog.Builder(this).setTitle("No se pudo subir").setMessage(String.valueOf(e.getMessage()))
                            .setPositiveButton("Entendido", null).show();
                });
            }
        }).start();
    }
}
