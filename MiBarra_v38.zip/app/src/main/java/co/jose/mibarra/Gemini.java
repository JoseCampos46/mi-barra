package co.jose.mibarra;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Versión 38: el arreglador de textos con Gemini (llave gratis de Google AI Studio).
 * Lo usan el botón flotante «✨ Organizar» y Mi Voz, para que los dos arreglen igual.
 * La llave se guarda en un archivo (y no en preferencias) porque Mi Voz y el botón flotante
 * corren en procesos distintos y así los dos leen siempre la misma llave.
 */
final class Gemini {

    static final String PAGINA_LLAVE = "https://aistudio.google.com/apikey";

    private static final String[] MODELOS = {"gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash"};

    private static final String INSTRUCCION =
            "Eres el corrector de mensajes de José, un señor de Colombia que dicta por voz sus mensajes de WhatsApp para clientes y familiares. "
            + "Organiza y corrige el texto que te doy: ordena las ideas para que se entiendan claras y en buen orden, corrige gramática, ortografía, tildes y puntuación, "
            + "quita palabras repetidas y muletillas propias del dictado, escribe el dinero como $350.000 y separa en párrafos cortos solo si hay varias ideas. "
            + "Conserva el sentido, el tono cercano y respetuoso de José, y deja exactos los nombres, cifras, medidas, fechas, horas y direcciones. "
            + "No agregues información nueva, no inventes saludos ni despedidas que no estén, no pongas emojis nuevos, comillas, títulos ni explicaciones. "
            + "Responde únicamente con el mensaje final listo para enviar.";

    interface Respuesta {
        void listo(String texto);
        void error(String mensaje);
    }

    private Gemini() {}

    private static File archivo(Context c) { return new File(c.getFilesDir(), "gemini_llave.txt"); }

    static String llave(Context c) {
        try {
            File f = archivo(c);
            if (!f.exists()) return "";
            return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).trim();
        } catch (Exception e) { return ""; }
    }

    static boolean hayLlave(Context c) { return llave(c).length() > 20; }

    static boolean guardarLlave(Context c, String llave) {
        try {
            Files.write(archivo(c).toPath(), llave.trim().getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (Exception e) { return false; }
    }

    /** Arregla el texto en otro hilo; la respuesta llega en otro hilo (el que llama la pasa a la pantalla). */
    static void organizar(Context c, String texto, boolean otraVez, Respuesta r) {
        final String llave = llave(c);
        new Thread(() -> {
            if (llave.length() < 20) { r.error("Falta la llave de Gemini"); return; }
            String ultimo = "No se pudo organizar. Intente otra vez.";
            for (String modelo : MODELOS) {
                try {
                    String hecho = pedir(llave, modelo, texto, otraVez);
                    if (hecho != null && !hecho.trim().isEmpty()) { r.listo(hecho.trim()); return; }
                } catch (Fallo f) {
                    ultimo = f.getMessage();
                    if (f.parar) break;
                } catch (Exception e) {
                    ultimo = "📶 No hay internet para organizar el texto. Revise el Wi‑Fi o los datos.";
                    break;
                }
            }
            r.error(ultimo);
        }).start();
    }

    private static final class Fallo extends Exception {
        final boolean parar;
        Fallo(String m, boolean parar) { super(m); this.parar = parar; }
    }

    private static String pedir(String llave, String modelo, String texto, boolean otraVez) throws Exception {
        JSONObject cuerpo = new JSONObject();
        cuerpo.put("systemInstruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", INSTRUCCION))));
        cuerpo.put("contents", new JSONArray().put(new JSONObject().put("role", "user")
                .put("parts", new JSONArray().put(new JSONObject().put("text", texto)))));
        JSONObject gen = new JSONObject().put("temperature", otraVez ? 0.8 : 0.3);
        // en los modelos 2.5 se apaga el «pensar» para que responda rápido
        if (modelo.startsWith("gemini-2.5")) gen.put("thinkingConfig", new JSONObject().put("thinkingBudget", 0));
        cuerpo.put("generationConfig", gen);

        HttpURLConnection con = (HttpURLConnection) new URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" + modelo + ":generateContent").openConnection();
        con.setConnectTimeout(12000);
        con.setReadTimeout(40000);
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        con.setRequestProperty("x-goog-api-key", llave);
        try (OutputStream o = con.getOutputStream()) { o.write(cuerpo.toString().getBytes(StandardCharsets.UTF_8)); }
        int codigo = con.getResponseCode();
        String resp = leer(codigo >= 400 ? con.getErrorStream() : con.getInputStream());
        if (codigo == 400 && resp.contains("API_KEY_INVALID"))
            throw new Fallo("🔑 La llave de Gemini no sirve. Revísela en ✨ Organizar → 🔑 Llave.", true);
        if (codigo == 401 || codigo == 403)
            throw new Fallo("🔑 Google no aceptó la llave de Gemini. Revísela en ✨ Organizar → 🔑 Llave.", true);
        if (codigo == 429) throw new Fallo("⏳ Gemini está ocupado o se llegó al límite gratis del momento. Espere un minuto e intente otra vez.", false);
        if (codigo >= 400) throw new Fallo("No se pudo organizar (Gemini respondió " + codigo + "). Intente otra vez.", false);

        JSONArray cand = new JSONObject(resp).optJSONArray("candidates");
        if (cand == null || cand.length() == 0) return null;
        JSONObject cont = cand.getJSONObject(0).optJSONObject("content");
        if (cont == null) return null;
        JSONArray partes = cont.optJSONArray("parts");
        if (partes == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < partes.length(); i++) {
            JSONObject p = partes.getJSONObject(i);
            if (p.optBoolean("thought", false)) continue;
            sb.append(p.optString("text", ""));
        }
        return sb.toString();
    }

    private static String leer(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (InputStream i = in) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = i.read(buf)) > 0) bo.write(buf, 0, n);
        }
        return bo.toString("UTF-8");
    }
}
