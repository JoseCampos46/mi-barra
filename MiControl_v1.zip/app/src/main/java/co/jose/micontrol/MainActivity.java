package co.jose.micontrol;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Mi Control: control remoto para Samsung y LG por Wi‑Fi, y otros televisores (y la cajita de Claro) por Bluetooth.
 * Pantalla principal sencilla; todo lo demás va en el menú ☰.
 */
public class MainActivity extends Activity {

    static final String VERSION = "v1";

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private JSONArray tvs;
    private int actual;
    private Tv tv;

    private TextView estado, chipTv, dormirTxt;
    private FrameLayout padCaja;
    private LinearLayout filaApps;
    private EditText canal;
    private String pendienteProy;

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void aviso(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show()); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Tv.prefs(this);
        tvs = Tv.lista(this);
        actual = prefs.getInt("actual", 0);
        if (actual >= tvs.length()) actual = 0;
        getWindow().setStatusBarColor(0xFF12172A);
        getWindow().setNavigationBarColor(0xFF0B0F1E);
        tv = new Tv(this, new Tv.Oyente() {
            @Override public void estado(String s) { ponerEstado(s); if (s.startsWith("✅")) guardarTvs(); }
            @Override public void entradasLg(JSONArray d) { runOnUiThread(() -> elegirEntradaLg(d)); }
        });
        BtHid.get().oyente((s, con, dev) -> {
            ponerEstado(s);
            if (con && dev != null) runOnUiThread(() -> recordarBt(dev));
        });
        pintar();
        if (tvs.length() == 0) h.postDelayed(this::bienvenida, 400); else conectar();
    }

    @Override protected void onResume() {
        super.onResume();
        refrescarDormir();
        if (pendienteProy != null) {
            String que = pendienteProy;
            pendienteProy = null;
            h.postDelayed(() -> new AlertDialog.Builder(this).setTitle("¿Ya se ve el celular en el televisor?")
                    .setPositiveButton("camara".equals(que) ? "📷 Abrir la cámara" : "🖼 Abrir la galería", (d, w) -> { if ("camara".equals(que)) abrirCamara(); else abrirGaleria(); })
                    .setNegativeButton("Todavía no", null).show(), 500);
        }
    }

    @Override protected void onDestroy() { tv.desconectar(); h.removeCallbacksAndMessages(null); super.onDestroy(); }

    private void guardarTvs() { prefs.edit().putString("tvs", tvs.toString()).putInt("actual", actual).apply(); }
    private JSONObject tvActual() { return tvs.optJSONObject(actual); }
    private void conectar() { pintarChip(); tv.conectar(tvActual(), this::guardarTvs); }

    // ======================= Pantalla =======================

    private GradientDrawable forma(int color, float radio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radio));
        return g;
    }

    private void vibrar(View v) { if (prefs.getBoolean("vibrar", true)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING); }

    private TextView boton(String t, float tam, int color, float radio, Runnable r) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(tam);
        v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setBackground(forma(color, radio));
        v.setOnClickListener(x -> { vibrar(x); r.run(); });
        return v;
    }

    private void pintar() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(8), dp(12), dp(16));

        // --- Arriba: ☰, televisor, versión, prender/apagar ---
        LinearLayout arriba = new LinearLayout(this);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        TextView menu = boton("☰", 28, 0x00000000, 10, this::menu);
        arriba.addView(menu, new LinearLayout.LayoutParams(dp(50), dp(52)));
        chipTv = boton("", 16, 0xFF1E6FD9, 24, this::elegirTv);
        chipTv.setPadding(dp(14), 0, dp(14), 0);
        chipTv.setSingleLine(true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        cp.setMargins(dp(4), 0, dp(8), 0);
        arriba.addView(chipTv, cp);
        TextView ver = new TextView(this);
        ver.setText(VERSION);
        ver.setTextColor(0xFFC8CDE0);
        ver.setTextSize(13);
        ver.setPadding(0, 0, dp(8), 0);
        arriba.addView(ver);
        TextView pw = boton("⏻", 26, 0xFFD93636, 30, this::power);
        arriba.addView(pw, new LinearLayout.LayoutParams(dp(56), dp(56)));
        l.addView(arriba);

        estado = new TextView(this);
        estado.setTextColor(0xFFC8CDE0);
        estado.setTextSize(13);
        estado.setPadding(dp(6), dp(4), 0, 0);
        l.addView(estado);
        dormirTxt = new TextView(this);
        dormirTxt.setTextColor(0xFFFFD54F);
        dormirTxt.setTextSize(13);
        dormirTxt.setPadding(dp(6), dp(2), 0, 0);
        dormirTxt.setVisibility(View.GONE);
        dormirTxt.setOnClickListener(v -> dormir());
        l.addView(dormirTxt);

        // --- Voz ---
        TextView voz = boton("🎤  Diga qué quiere ver", 19, 0xFFF0603A, 30, this::voz);
        voz.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(58));
        vp.topMargin = dp(10);
        l.addView(voz, vp);

        // --- Canal + Ir ---
        LinearLayout fc = new LinearLayout(this);
        fc.setGravity(Gravity.CENTER_VERTICAL);
        fc.setBackground(forma(0xFF2A2F45, 16));
        fc.setPadding(dp(12), dp(6), dp(6), dp(6));
        TextView lc = new TextView(this);
        lc.setText("Canal");
        lc.setTextColor(0xFFC8CDE0);
        lc.setTextSize(15);
        fc.addView(lc);
        canal = new EditText(this);
        canal.setInputType(InputType.TYPE_CLASS_NUMBER);
        canal.setHint("1006");
        canal.setTextSize(20);
        canal.setTextColor(0xFF111111);
        canal.setHintTextColor(0xFF9E9E9E);
        canal.setBackground(forma(Color.WHITE, 10));
        canal.setPadding(dp(12), 0, dp(12), 0);
        canal.setImeOptions(EditorInfo.IME_ACTION_GO);
        canal.setOnEditorActionListener((v, a, e) -> { irCanal(); return true; });
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(46), 1f);
        ep.setMargins(dp(10), 0, dp(8), 0);
        fc.addView(canal, ep);
        TextView ir = boton("Ir", 18, 0xFF1E6FD9, 10, this::irCanal);
        ir.setTypeface(Typeface.DEFAULT_BOLD);
        fc.addView(ir, new LinearLayout.LayoutParams(dp(70), dp(46)));
        LinearLayout.LayoutParams fcp = new LinearLayout.LayoutParams(-1, -2);
        fcp.topMargin = dp(10);
        l.addView(fc, fcp);

        // --- Flechas (o modo táctil) ---
        padCaja = new FrameLayout(this);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(240));
        pp.topMargin = dp(12);
        l.addView(padCaja, pp);
        pintarPad();

        // --- Reproducción ---
        LinearLayout fr = new LinearLayout(this);
        TextView atr = boton("⏪\nAtrasar", 14, 0xFF2A2F45, 16, () -> tecla("LEFT"));
        mantener(atr, () -> tecla("REWIND"));
        TextView pp2 = boton("⏯\nPlay / Pausa", 14, 0xFF1E6FD9, 16, () -> tecla("PLAYPAUSE"));
        TextView ade = boton("⏩\nAdelantar", 14, 0xFF2A2F45, 16, () -> tecla("RIGHT"));
        mantener(ade, () -> tecla("FF"));
        fr.addView(atr, peso(1, dp(64)));
        fr.addView(pp2, peso(1.3f, dp(64)));
        fr.addView(ade, peso(1, dp(64)));
        l.addView(fr);

        // --- Atrás, Inicio, Menú ---
        LinearLayout f3 = new LinearLayout(this);
        f3.addView(boton("↩\nAtrás", 15, 0xFF2A2F45, 16, () -> tecla("BACK")), peso(1, dp(62)));
        f3.addView(boton("🏠\nInicio", 15, 0xFF2A2F45, 16, () -> tecla("HOME")), peso(1, dp(62)));
        f3.addView(boton("☰\nMenú TV", 15, 0xFF2A2F45, 16, () -> tecla("MENU")), peso(1, dp(62)));
        l.addView(f3);

        // --- Volumen, silencio, canal ---
        LinearLayout f4 = new LinearLayout(this);
        f4.setGravity(Gravity.CENTER_VERTICAL);
        f4.addView(pastilla("＋", "VOL", "−", () -> tecla("VOLUP"), () -> tecla("VOLDOWN")), new LinearLayout.LayoutParams(dp(80), dp(140)));
        TextView sil = boton("🔇\nSilencio", 16, 0xFF2A2F45, 18, () -> tecla("MUTE"));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(140), 1f);
        sp.setMargins(dp(10), 0, dp(10), 0);
        f4.addView(sil, sp);
        f4.addView(pastilla("▲", "CANAL", "▼", () -> tecla("CHUP"), () -> tecla("CHDOWN")), new LinearLayout.LayoutParams(dp(80), dp(140)));
        LinearLayout.LayoutParams f4p = new LinearLayout.LayoutParams(-1, -2);
        f4p.setMargins(dp(4), dp(8), dp(4), 0);
        l.addView(f4, f4p);

        // --- Apps ---
        filaApps = new LinearLayout(this);
        filaApps.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams fap = new LinearLayout.LayoutParams(-1, -2);
        fap.topMargin = dp(12);
        l.addView(filaApps, fap);
        pintarApps();
        TextView ayudaApps = new TextView(this);
        ayudaApps.setText("Deje el dedo en una app para moverla, quitarla o cambiarla");
        ayudaApps.setTextColor(0xFFC8CDE0);
        ayudaApps.setTextSize(12);
        ayudaApps.setGravity(Gravity.CENTER);
        l.addView(ayudaApps);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF12172A);
        sv.addView(l);
        setContentView(sv);
        pintarChip();
    }

    private LinearLayout.LayoutParams peso(float w, int alto) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, alto, w);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        return p;
    }

    private View pastilla(String arriba, String nombre, String abajo, Runnable sube, Runnable baja) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(forma(0xFF2A2F45, 40));
        TextView a = boton(arriba, 28, 0x00000000, 40, sube);
        repetir(a, sube);
        TextView n = new TextView(this);
        n.setText(nombre);
        n.setTextColor(0xFFC8CDE0);
        n.setTextSize(12);
        n.setGravity(Gravity.CENTER);
        TextView b = boton(abajo, 28, 0x00000000, 40, baja);
        repetir(b, baja);
        p.addView(a, new LinearLayout.LayoutParams(-1, 0, 1f));
        p.addView(n, new LinearLayout.LayoutParams(-1, -2));
        p.addView(b, new LinearLayout.LayoutParams(-1, 0, 1f));
        return p;
    }

    /** Dejando presionado repite (volumen, flechas). */
    @SuppressLint("ClickableViewAccessibility")
    private void repetir(View v, Runnable r) {
        final Runnable[] rep = new Runnable[1];
        rep[0] = () -> { r.run(); h.postDelayed(rep[0], 180); };
        v.setOnLongClickListener(x -> { h.post(rep[0]); return true; });
        v.setOnTouchListener((x, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) h.removeCallbacks(rep[0]);
            return false;
        });
    }

    /** Dejando presionado hace otra cosa (ej. atrasar rápido) y la repite. */
    @SuppressLint("ClickableViewAccessibility")
    private void mantener(View v, Runnable r) {
        final Runnable[] rep = new Runnable[1];
        rep[0] = () -> { r.run(); h.postDelayed(rep[0], 600); };
        v.setOnLongClickListener(x -> { vibrar(x); h.post(rep[0]); return true; });
        v.setOnTouchListener((x, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) h.removeCallbacks(rep[0]);
            return false;
        });
    }

    private void pintarChip() {
        if (chipTv == null) return;
        JSONObject o = tvActual();
        chipTv.setText(o == null ? "＋ Agregar televisor" : ("bt".equals(o.optString("m")) ? "🔵 " : "📺 ") + o.optString("n") + "  ▾");
    }

    @SuppressLint("ClickableViewAccessibility")
    private void pintarPad() {
        padCaja.removeAllViews();
        int t = dp(240);
        if (prefs.getBoolean("tactil", false)) {
            TextView z = new TextView(this);
            z.setText("👆 Modo táctil\n\nDeslice el dedo para moverse\nToque una vez para OK");
            z.setTextColor(0xFFC8CDE0);
            z.setTextSize(15);
            z.setGravity(Gravity.CENTER);
            z.setBackground(forma(0xFF1F2540, 24));
            final float[] ini = new float[2];
            z.setOnTouchListener((v, e) -> {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { ini[0] = e.getX(); ini[1] = e.getY(); }
                else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    float dx = e.getX() - ini[0], dy = e.getY() - ini[1];
                    vibrar(v);
                    if (Math.abs(dx) < dp(20) && Math.abs(dy) < dp(20)) tecla("ENTER");
                    else if (Math.abs(dx) > Math.abs(dy)) tecla(dx > 0 ? "RIGHT" : "LEFT");
                    else tecla(dy > 0 ? "DOWN" : "UP");
                }
                return true;
            });
            padCaja.addView(z, new FrameLayout.LayoutParams(-1, -1));
            return;
        }
        FrameLayout pad = new FrameLayout(this);
        GradientDrawable gp = new GradientDrawable();
        gp.setShape(GradientDrawable.OVAL);
        gp.setColor(0xFF1F2540);
        gp.setStroke(dp(1), 0xFF3A4160);
        pad.setBackground(gp);
        String[][] dir = {{"▲", "UP"}, {"▼", "DOWN"}, {"◀", "LEFT"}, {"▶", "RIGHT"}};
        int[][] pos = {{t / 2 - dp(32), dp(6)}, {t / 2 - dp(32), t - dp(70)}, {dp(6), t / 2 - dp(32)}, {t - dp(70), t / 2 - dp(32)}};
        for (int i = 0; i < 4; i++) {
            final String k = dir[i][1];
            TextView d = boton(dir[i][0], 30, 0x00000000, 32, () -> tecla(k));
            repetir(d, () -> tecla(k));
            FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dp(64), dp(64));
            fl.leftMargin = pos[i][0]; fl.topMargin = pos[i][1];
            pad.addView(d, fl);
        }
        TextView ok = boton("OK", 24, 0xFF3A4478, 50, () -> tecla("ENTER"));
        ok.setTypeface(Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams okp = new FrameLayout.LayoutParams(dp(96), dp(96));
        okp.leftMargin = t / 2 - dp(48); okp.topMargin = t / 2 - dp(48);
        pad.addView(ok, okp);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(t, t);
        pl.gravity = Gravity.CENTER_HORIZONTAL;
        padCaja.addView(pad, pl);
    }

    // ======================= Apps de abajo =======================

    private List<String> misApps() {
        List<String> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString("apps", "[\"youtube\",\"netflix\",\"prime\",\"disney\"]"));
            for (int i = 0; i < a.length(); i++) if (Tv.app(a.getString(i)) != null) r.add(a.getString(i));
        } catch (Exception ignored) {}
        return r;
    }

    private void guardarApps(List<String> l) { prefs.edit().putString("apps", new JSONArray(l).toString()).apply(); pintarApps(); }

    private void pintarApps() {
        filaApps.removeAllViews();
        List<String> l = misApps();
        LinearLayout fila = null;
        for (int i = 0; i < l.size(); i++) {
            if (i % 4 == 0) { fila = new LinearLayout(this); filaApps.addView(fila); }
            final int k = i;
            Object[] a = Tv.app(l.get(i));
            TextView v = boton((String) a[1], 15, (Integer) a[2], 12, () -> { if (!tv.abrirApp((String) a[0], null)) noConectado(); });
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setTextColor((Integer) a[3]);
            v.setOnLongClickListener(x -> { vibrar(x); opcionesApp(k); return true; });
            fila.addView(v, peso(1, dp(48)));
        }
        if (l.isEmpty() || l.size() % 4 != 0) {
            if (fila == null || l.size() % 4 == 0) { fila = new LinearLayout(this); filaApps.addView(fila); }
            TextView mas = boton("＋", 20, 0xFF2A2F45, 12, this::agregarApp);
            fila.addView(mas, peso(l.isEmpty() ? 4 : 4 - l.size() % 4, dp(48)));
        }
    }

    private void opcionesApp(int k) {
        List<String> l = misApps();
        String nombre = (String) Tv.app(l.get(k))[1];
        new AlertDialog.Builder(this).setTitle(nombre)
                .setItems(new String[]{"⬅ Mover a la izquierda", "➡ Mover a la derecha", "🔁 Cambiar por otra app", "🗑 Quitar", "＋ Agregar otra app"}, (d, w) -> {
                    if (w == 0 && k > 0) { l.add(k - 1, l.remove(k)); guardarApps(l); }
                    else if (w == 1 && k < l.size() - 1) { l.add(k + 1, l.remove(k)); guardarApps(l); }
                    else if (w == 2) escogerApp(c -> { l.set(k, c); guardarApps(l); });
                    else if (w == 3) { l.remove(k); guardarApps(l); }
                    else if (w == 4) agregarApp();
                }).show();
    }

    private void agregarApp() {
        List<String> l = misApps();
        if (l.size() >= 8) { aviso("Ya hay 8 apps. Quite una para poner otra."); return; }
        escogerApp(c -> { l.add(c); guardarApps(l); });
    }

    interface Escogida { void app(String clave); }

    private void escogerApp(Escogida e) {
        String[] n = new String[Tv.APPS.length];
        for (int i = 0; i < n.length; i++) n[i] = (String) Tv.APPS[i][1];
        new AlertDialog.Builder(this).setTitle("Escoja la app").setItems(n, (d, w) -> e.app((String) Tv.APPS[w][0])).show();
    }

    // ======================= Acciones =======================

    private void ponerEstado(String s) { runOnUiThread(() -> { if (estado != null) estado.setText(s); }); }

    private void noConectado() {
        ponerEstado(tvActual() == null ? "Primero agregue su televisor: toque ☰ → Mis televisores" : "No está conectado. Toque el nombre del televisor para volver a conectar.");
    }

    private void tecla(String k) { if (!tv.tecla(k)) noConectado(); }

    private void irCanal() {
        String n = canal.getText().toString().trim();
        if (n.isEmpty()) { aviso("Escriba el número del canal, ej. 1006"); return; }
        if (!tv.conectado()) { noConectado(); return; }
        tv.irACanal(n);
        ponerEstado("📺 Yendo al canal " + n);
    }

    private void power() {
        JSONObject o = tvActual();
        if (o == null) { bienvenida(); return; }
        if (tv.conectado()) { tecla("POWER"); return; }
        List<String> ops = new ArrayList<>();
        List<Runnable> acc = new ArrayList<>();
        String mac = o.optString("mac");
        String st = prefs.getString("st", "");
        boolean samsung = "samsung".equals(o.optString("m"));
        if (samsung && !mac.isEmpty()) {
            ops.add("⏻ Prender (estando en la casa)");
            acc.add(() -> new Thread(() -> {
                ponerEstado(Tv.despertar(mac) ? "Prendiendo… espere unos segundos" : "No pude mandar la señal de prender");
                try { Thread.sleep(8000); } catch (Exception ignored) {}
                runOnUiThread(this::conectar);
            }).start());
        }
        if (samsung && !st.isEmpty()) {
            ops.add("🌍 Prender desde fuera de casa");
            acc.add(() -> confirmarNube(true));
            ops.add("🌍 Apagar desde fuera de casa");
            acc.add(() -> confirmarNube(false));
        }
        ops.add("🔄 Volver a conectar");
        acc.add(this::conectar);
        new AlertDialog.Builder(this).setTitle("El televisor no está conectado")
                .setItems(ops.toArray(new String[0]), (d, w) -> acc.get(w).run()).setNegativeButton("Cerrar", null).show();
    }

    private void confirmarNube(boolean prender) {
        new AlertDialog.Builder(this).setTitle(prender ? "¿Seguro que quiere PRENDER el televisor?" : "¿Seguro que quiere APAGAR el televisor?")
                .setMessage("Se hace por internet. Si alguien está viendo televisión, se le " + (prender ? "prende" : "apaga") + ".")
                .setPositiveButton(prender ? "Sí, prender" : "Sí, apagar", (d, w) -> new Thread(() -> ponerEstado(Tv.nubeSamsung(prefs.getString("st", ""), prender))).start())
                .setNegativeButton("No", null).show();
    }

    private void elegirTv() {
        if (tvs.length() == 0) { bienvenida(); return; }
        List<String> ops = new ArrayList<>();
        for (int i = 0; i < tvs.length(); i++) {
            JSONObject o = tvs.optJSONObject(i);
            ops.add((i == actual ? "✔ " : "    ") + ("bt".equals(o.optString("m")) ? "🔵 " : "📺 ") + o.optString("n"));
        }
        ops.add("＋ Agregar otro televisor");
        new AlertDialog.Builder(this).setTitle("¿Cuál televisor?").setItems(ops.toArray(new String[0]), (d, w) -> {
            if (w < tvs.length()) { actual = w; guardarTvs(); conectar(); }
            else agregarTv();
        }).show();
    }

    // ======================= Menú ☰ =======================

    private void menu() {
        boolean tactil = prefs.getBoolean("tactil", false);
        String[] ops = {
                "🌙  Dormir (apagar en un rato)",
                "🌐  Idioma y subtítulos",
                "🐢  Cámara lenta (YouTube)",
                "⏺  Grabar",
                "⭐  Mis canales",
                "⌨  Escribir en el televisor",
                "🔢  Números",
                "🎬  Entrada (HDMI, antena, cajita)",
                tactil ? "🎯  Volver a las flechas" : "👆  Modo táctil (deslizar el dedo)",
                "📡  Proyectar el celular en el TV",
                "📷  Cámara al TV",
                "🖼  Galería (fotos y videos) al TV",
                "📺  Mis televisores",
                "🔵  Agregar por Bluetooth (otros TV y cajita Claro)",
                "🌍  Samsung fuera de casa",
                "🧩  Apps de abajo",
                "⚙  Ajustes",
                "❓  Ayuda",
        };
        Runnable[] acc = {
                this::dormir, this::idioma, this::lento, this::grabar, this::misCanales, this::escribirTexto, this::numeros, this::entrada,
                () -> { prefs.edit().putBoolean("tactil", !tactil).apply(); pintarPad(); },
                this::proyectar, () -> { pendienteProy = "camara"; proyectar(); }, () -> { pendienteProy = "galeria"; proyectar(); },
                this::misTelevisores, this::agregarBluetooth, this::samsungNube, this::appsDeAbajo, this::ajustes, this::ayuda,
        };
        new AlertDialog.Builder(this).setTitle("Mi Control " + VERSION).setItems(ops, (d, w) -> acc[w].run()).setNegativeButton("Cerrar", null).show();
    }

    // --- Dormir ---

    private void dormir() {
        boolean activo = prefs.getLong("dormir", 0) > System.currentTimeMillis();
        String[] ops = activo ? new String[]{"15 minutos", "30 minutos", "45 minutos", "1 hora", "1 hora y media", "Otro tiempo…", "❌ Cancelar el Dormir"}
                : new String[]{"15 minutos", "30 minutos", "45 minutos", "1 hora", "1 hora y media", "Otro tiempo…"};
        int[] min = {15, 30, 45, 60, 90};
        new AlertDialog.Builder(this).setTitle("🌙 Apagar el televisor en…").setItems(ops, (d, w) -> {
            if (w < 5) ponerDormir(min[w]);
            else if (w == 5) {
                EditText e = new EditText(this);
                e.setInputType(InputType.TYPE_CLASS_NUMBER);
                e.setHint("Minutos, ej. 20");
                new AlertDialog.Builder(this).setTitle("¿En cuántos minutos?").setView(e).setPositiveButton("Listo", (d2, w2) -> {
                    try { int m = Integer.parseInt(e.getText().toString().trim()); if (m > 0) ponerDormir(m); } catch (Exception ignored) {}
                }).setNegativeButton("Cancelar", null).show();
            } else { DormirReceiver.cancelar(this); refrescarDormir(); aviso("Dormir cancelado"); }
        }).show();
    }

    private void ponerDormir(int m) {
        if (tvActual() == null) { noConectado(); return; }
        DormirReceiver.programar(this, m);
        refrescarDormir();
        aviso("El televisor se apaga en " + m + " minutos. Deje el celular con Wi‑Fi en la casa.");
    }

    private final Runnable tickDormir = this::refrescarDormir;

    private void refrescarDormir() {
        h.removeCallbacks(tickDormir);
        if (dormirTxt == null) return;
        long fin = prefs.getLong("dormir", 0);
        long falta = fin - System.currentTimeMillis();
        if (falta <= 0) { dormirTxt.setVisibility(View.GONE); return; }
        long min = (falta + 59_999) / 60_000;
        dormirTxt.setText("🌙 Se apaga en " + min + " min  (toque para cambiar)");
        dormirTxt.setVisibility(View.VISIBLE);
        h.postDelayed(tickDormir, 20_000);
    }

    // --- Idioma, lento, grabar ---

    private void idioma() {
        new AlertDialog.Builder(this).setTitle("🌐 Idioma y subtítulos")
                .setItems(new String[]{"🗣 Cambiar el idioma del canal (TV normal)", "💬 Subtítulos del canal (TV normal)", "🎬 Idioma en Netflix, Prime o Disney+"}, (d, w) -> {
                    if (w == 0) { tecla("MTS"); ponerEstado("Cada toque cambia el idioma, si el canal lo trae"); }
                    else if (w == 1) { tecla("CAPTION"); ponerEstado("Subtítulos: cada toque los prende o cambia"); }
                    else new AlertDialog.Builder(this).setTitle("Idioma en la película")
                            .setMessage("1. Con la película andando, toque ▼ (flecha abajo).\n2. Escoja con las flechas el cuadrito de \"Audio y subtítulos\" o \"Idiomas\".\n3. Toque OK y escoja el idioma.\n4. Toque Atrás para seguir viendo.")
                            .setPositiveButton("Toque ▼ por mí", (x, y) -> tecla("DOWN")).setNegativeButton("Cerrar", null).show();
                }).show();
    }

    private void lento() {
        new AlertDialog.Builder(this).setTitle("🐢 Cámara lenta")
                .setMessage("Solo YouTube tiene cámara lenta. Netflix, Prime y Disney+ no la traen.\n\nEn YouTube:\n1. Con el video andando, toque ▼.\n2. Busque el engranaje ⚙ (Configuración) y toque OK.\n3. Entre a \"Velocidad\" y escoja 0,25 o 0,5.\n\nPara ver bien una parte en otras apps: Pausa y Atrasar de a 10 segundos.")
                .setPositiveButton("Toque ▼ por mí", (x, y) -> tecla("DOWN")).setNegativeButton("Cerrar", null).show();
    }

    private void grabar() {
        new AlertDialog.Builder(this).setTitle("⏺ Grabar")
                .setMessage("Solo graba canales de antena (TDT), si el televisor trae esa opción y tiene una memoria USB puesta.\n\nNetflix, Prime, Disney+ y YouTube no dejan grabar.")
                .setPositiveButton("⏺ Grabar ahora", (x, y) -> tecla("REC")).setNegativeButton("Cerrar", null).show();
    }

    // --- Mis canales ---

    private JSONArray canales() { try { return new JSONArray(prefs.getString("canales", "[]")); } catch (Exception e) { return new JSONArray(); } }

    private void misCanales() {
        JSONArray c = canales();
        List<String> ops = new ArrayList<>();
        for (int i = 0; i < c.length(); i++) ops.add("📺 " + c.optJSONObject(i).optString("n") + "  ·  " + c.optJSONObject(i).optString("num"));
        ops.add("＋ Guardar un canal");
        if (c.length() > 0) ops.add("🗑 Quitar un canal");
        new AlertDialog.Builder(this).setTitle("⭐ Mis canales").setItems(ops.toArray(new String[0]), (d, w) -> {
            if (w < c.length()) {
                if (!tv.conectado()) { noConectado(); return; }
                tv.irACanal(c.optJSONObject(w).optString("num"));
                ponerEstado("📺 Yendo a " + c.optJSONObject(w).optString("n"));
            } else if (w == c.length()) {
                LinearLayout f = new LinearLayout(this);
                f.setOrientation(LinearLayout.VERTICAL);
                f.setPadding(dp(18), dp(8), dp(18), 0);
                EditText n = new EditText(this); n.setHint("Nombre, ej. Caracol"); f.addView(n);
                EditText num = new EditText(this); num.setHint("Número, ej. 1006"); num.setInputType(InputType.TYPE_CLASS_NUMBER); f.addView(num);
                new AlertDialog.Builder(this).setTitle("Guardar canal").setView(f).setPositiveButton("Guardar", (d2, w2) -> {
                    if (num.getText().toString().trim().isEmpty()) return;
                    try {
                        c.put(new JSONObject().put("n", n.getText().toString().trim().isEmpty() ? "Canal" : n.getText().toString().trim()).put("num", num.getText().toString().trim()));
                        prefs.edit().putString("canales", c.toString()).apply();
                    } catch (Exception ignored) {}
                }).setNegativeButton("Cancelar", null).show();
            } else {
                String[] q = new String[c.length()];
                for (int i = 0; i < q.length; i++) q[i] = c.optJSONObject(i).optString("n") + " · " + c.optJSONObject(i).optString("num");
                new AlertDialog.Builder(this).setTitle("¿Cuál quita?").setItems(q, (d2, w2) -> { c.remove(w2); prefs.edit().putString("canales", c.toString()).apply(); }).show();
            }
        }).show();
    }

    // --- Escribir, números, entrada ---

    private void escribirTexto() {
        EditText e = new EditText(this);
        e.setHint("Escriba o hable con el 🎤 del teclado");
        new AlertDialog.Builder(this).setTitle("⌨ Escribir en el televisor")
                .setMessage("Primero abra en el televisor la lupa o el cuadro de búsqueda.")
                .setView(e).setPositiveButton("Mandar", (d, w) -> { if (!tv.escribir(e.getText().toString())) noConectado(); }).setNegativeButton("Cancelar", null).show();
    }

    private void numeros() {
        String[] n = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
        new AlertDialog.Builder(this).setTitle("🔢 Números").setItems(n, (d, w) -> tecla(n[w])).show();
    }

    private void entrada() { if (!tv.conectado()) { noConectado(); return; } tv.entrada(); }

    private void elegirEntradaLg(JSONArray d) {
        if (d == null) return;
        String[] n = new String[d.length()];
        for (int i = 0; i < d.length(); i++) n[i] = d.optJSONObject(i).optString("label", d.optJSONObject(i).optString("id"));
        new AlertDialog.Builder(this).setTitle("🎬 Entrada").setItems(n, (x, w) -> tv.cambiarEntradaLg(d.optJSONObject(w).optString("id"))).show();
    }

    // --- Proyectar, cámara, galería ---

    private void proyectar() {
        aviso("Escoja su televisor en la lista. Si el TV pregunta, toque Permitir.");
        String[] acciones = {Settings.ACTION_CAST_SETTINGS, "android.settings.WIFI_DISPLAY_SETTINGS", Settings.ACTION_WIRELESS_SETTINGS};
        for (String a : acciones) {
            try { startActivity(new Intent(a)); return; } catch (Exception ignored) {}
        }
        aviso("Este celular no deja abrir la proyección desde aquí: baje la cortina de arriba y toque \"Transmitir\" o \"Enviar pantalla\".");
    }

    private void abrirCamara() {
        try { startActivity(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); }
        catch (Exception e) { aviso("No encontré la cámara"); }
    }

    private void abrirGaleria() {
        try { startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)); return; } catch (Exception ignored) {}
        try { startActivity(new Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)); return; } catch (Exception ignored) {}
        try { startActivity(getPackageManager().getLaunchIntentForPackage("com.google.android.apps.photos")); } catch (Exception e) { aviso("No encontré la galería"); }
    }

    // --- Televisores ---

    private void bienvenida() {
        new AlertDialog.Builder(this).setTitle("👋 Bienvenida a Mi Control " + VERSION)
                .setMessage("Primero agreguemos el televisor.\n\n• Samsung o LG: por Wi‑Fi (el televisor prendido y en el mismo Wi‑Fi).\n• Otros televisores o la cajita inteligente de Claro: por Bluetooth.")
                .setPositiveButton("📺 Buscar por Wi‑Fi", (d, w) -> buscar())
                .setNeutralButton("🔵 Bluetooth", (d, w) -> agregarBluetooth())
                .setNegativeButton("Después", null).show();
    }

    private void misTelevisores() {
        List<String> ops = new ArrayList<>();
        for (int i = 0; i < tvs.length(); i++) {
            JSONObject o = tvs.optJSONObject(i);
            ops.add(("bt".equals(o.optString("m")) ? "🔵 " : "📺 ") + o.optString("n") + ("bt".equals(o.optString("m")) ? "" : "  (" + o.optString("ip") + ")"));
        }
        ops.add("🔎 Buscar en el Wi‑Fi (Samsung, LG)");
        ops.add("✍ Escribir la dirección a mano");
        ops.add("🔵 Agregar por Bluetooth");
        new AlertDialog.Builder(this).setTitle("📺 Mis televisores").setItems(ops.toArray(new String[0]), (d, w) -> {
            if (w < tvs.length()) opcionesTv(w);
            else if (w == tvs.length()) buscar();
            else if (w == tvs.length() + 1) aMano();
            else agregarBluetooth();
        }).show();
    }

    private void agregarTv() {
        new AlertDialog.Builder(this).setTitle("Agregar televisor").setItems(new String[]{"🔎 Buscar en el Wi‑Fi (Samsung, LG)", "✍ Escribir la dirección a mano", "🔵 Por Bluetooth (otros TV y cajita Claro)"}, (d, w) -> {
            if (w == 0) buscar(); else if (w == 1) aMano(); else agregarBluetooth();
        }).show();
    }

    private void opcionesTv(int k) {
        JSONObject o = tvs.optJSONObject(k);
        new AlertDialog.Builder(this).setTitle(o.optString("n")).setItems(new String[]{"✔ Usar este", "✎ Cambiar el nombre", "🗑 Quitar este televisor"}, (d, w) -> {
            if (w == 0) { actual = k; guardarTvs(); conectar(); }
            else if (w == 1) {
                EditText e = new EditText(this);
                e.setText(o.optString("n"));
                new AlertDialog.Builder(this).setTitle("Nombre del televisor").setView(e).setPositiveButton("Guardar", (d2, w2) -> {
                    try { o.put("n", e.getText().toString().trim()); } catch (Exception ignored) {}
                    guardarTvs(); pintarChip();
                }).show();
            } else {
                tvs.remove(k);
                actual = 0;
                guardarTvs();
                tv.desconectar();
                conectar();
            }
        }).show();
    }

    private void buscar() {
        ponerEstado("🔎 Buscando televisores en el Wi‑Fi…");
        new Thread(() -> {
            Map<String, String[]> enc = Tv.buscar(this);
            runOnUiThread(() -> {
                List<String> ops = new ArrayList<>();
                List<String[]> datos = new ArrayList<>();
                for (Map.Entry<String, String[]> e : enc.entrySet()) {
                    ops.add("📺 " + e.getValue()[1] + "   (" + e.getKey() + ")");
                    datos.add(new String[]{e.getValue()[0], e.getValue()[1], e.getKey()});
                }
                ops.add("✍ Escribir la dirección a mano");
                ops.add("🔵 Es otra marca: por Bluetooth");
                ponerEstado(enc.isEmpty() ? "No encontré televisores. ¿Están prendidos y en el mismo Wi‑Fi?" : "Encontré " + enc.size());
                new AlertDialog.Builder(this).setTitle(enc.isEmpty() ? "No encontré televisores prendidos" : "Televisores encontrados")
                        .setItems(ops.toArray(new String[0]), (d, w) -> {
                            if (w < datos.size()) agregar(datos.get(w)[0], datos.get(w)[1], datos.get(w)[2]);
                            else if (w == datos.size()) aMano();
                            else agregarBluetooth();
                        }).setNegativeButton("Cerrar", null).show();
            });
        }).start();
    }

    private void aMano() {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(18), dp(8), dp(18), 0);
        EditText ip = new EditText(this);
        ip.setHint("Ej: 192.168.0.17");
        ip.setInputType(InputType.TYPE_CLASS_PHONE);
        f.addView(ip);
        TextView n = new TextView(this);
        n.setText("La dirección sale en el televisor: Configuración → General → Red → Estado de red → Configuración IP.");
        f.addView(n);
        new AlertDialog.Builder(this).setTitle("¿Qué marca es?").setView(f)
                .setPositiveButton("Samsung", (d, w) -> agregar("samsung", "Samsung", ip.getText().toString().trim()))
                .setNeutralButton("LG", (d, w) -> agregar("lg", "LG", ip.getText().toString().trim()))
                .setNegativeButton("Cancelar", null).show();
    }

    private void agregar(String marca, String nombre, String ip) {
        if (ip.isEmpty()) return;
        try {
            for (int i = 0; i < tvs.length(); i++) if (ip.equals(tvs.getJSONObject(i).optString("ip"))) { actual = i; guardarTvs(); conectar(); return; }
            tvs.put(new JSONObject().put("n", nombre + (tvs.length() == 0 ? " sala" : " " + (tvs.length() + 1))).put("m", marca).put("ip", ip));
            actual = tvs.length() - 1;
            guardarTvs();
            conectar();
            aviso("Mire el televisor: si sale un aviso, acéptelo con el control normal (una sola vez)");
        } catch (Exception ignored) {}
    }

    // --- Bluetooth ---

    private static final int PERMISOS_BT = 71;

    private boolean permisosBt() {
        if (android.os.Build.VERSION.SDK_INT < 31) return true;
        String[] p = {Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE};
        for (String x : p) if (checkSelfPermission(x) != PackageManager.PERMISSION_GRANTED) { requestPermissions(p, PERMISOS_BT); return false; }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r != PERMISOS_BT) return;
        for (int x : g) if (x != PackageManager.PERMISSION_GRANTED) { aviso("Sin el permiso de Bluetooth no se puede usar esta opción"); return; }
        agregarBluetooth();
    }

    @SuppressLint("MissingPermission")
    private void agregarBluetooth() {
        if (!permisosBt()) return;
        BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
        if (a == null) { aviso("Este celular no tiene Bluetooth"); return; }
        if (!a.isEnabled()) {
            try { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); } catch (Exception ignored) {}
            aviso("Prenda el Bluetooth y vuelva a tocar esta opción");
            return;
        }
        BtHid.get().iniciar(this, null);
        new AlertDialog.Builder(this).setTitle("🔵 Agregar por Bluetooth")
                .setMessage("Sirve para televisores Android TV / Google TV (TCL, Hisense, Sony, Xiaomi, Kalley…) y la cajita inteligente de Claro.\n\n"
                        + "1. Toque \"Hacer visible el celular\".\n"
                        + "2. En el televisor o la cajita: Configuración → Controles remotos y accesorios → Agregar accesorio.\n"
                        + "3. Escoja \"" + a.getName() + "\" y acepte en las dos pantallas.\n\n"
                        + "Si ya los había emparejado antes, toque \"Escoger de la lista\".")
                .setPositiveButton("Hacer visible el celular", (d, w) -> {
                    try { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 180)); }
                    catch (Exception e) { aviso("No pude hacer visible el celular"); }
                })
                .setNeutralButton("Escoger de la lista", (d, w) -> {
                    Set<BluetoothDevice> s = a.getBondedDevices();
                    List<BluetoothDevice> l = new ArrayList<>(s);
                    if (l.isEmpty()) { aviso("No hay aparatos emparejados todavía"); return; }
                    String[] n = new String[l.size()];
                    for (int i = 0; i < n.length; i++) n[i] = BtHid.nombre(l.get(i));
                    new AlertDialog.Builder(this).setTitle("¿Cuál es el televisor?").setItems(n, (d2, w2) -> {
                        ponerEstado("Conectando por Bluetooth con " + n[w2] + "…");
                        BtHid.get().conectar(l.get(w2));
                    }).show();
                })
                .setNegativeButton("Cerrar", null).show();
    }

    /** Cuando un televisor se conecta por Bluetooth, queda guardado en la lista. */
    private void recordarBt(BluetoothDevice d) {
        String addr = d.getAddress();
        for (int i = 0; i < tvs.length(); i++) {
            JSONObject o = tvs.optJSONObject(i);
            if ("bt".equals(o.optString("m")) && addr.equals(o.optString("ip"))) {
                if (actual != i) { actual = i; guardarTvs(); pintarChip(); tv.conectar(o, this::guardarTvs); }
                return;
            }
        }
        try {
            tvs.put(new JSONObject().put("n", BtHid.nombre(d)).put("m", "bt").put("ip", addr));
            actual = tvs.length() - 1;
            guardarTvs();
            conectar();
        } catch (Exception ignored) {}
    }

    // --- Samsung fuera de casa ---

    private void samsungNube() {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(18), dp(8), dp(18), 0);
        TextView t = new TextView(this);
        t.setText("Sirve para prender y apagar el Samsung desde la calle, con datos.\n\n"
                + "1. Toque \"Abrir página de Samsung\" y entre con su cuenta Samsung.\n"
                + "2. Toque \"Generate new token\" (Crear código nuevo).\n"
                + "3. Póngale un nombre, ej. Mi Control, y marque todas las casillas de \"Devices\".\n"
                + "4. Toque \"Generate token\", copie el código y péguelo aquí abajo.\n\n"
                + "El televisor debe tener activado: Configuración → General → Red → Configuración experta → Encender con móvil.");
        f.addView(t);
        EditText e = new EditText(this);
        e.setHint("Pegue aquí el código");
        e.setText(prefs.getString("st", ""));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        f.addView(e);
        ScrollView sv = new ScrollView(this);
        sv.addView(f);
        new AlertDialog.Builder(this).setTitle("🌍 Samsung fuera de casa").setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    prefs.edit().putString("st", e.getText().toString().trim()).apply();
                    aviso(e.getText().toString().trim().isEmpty() ? "Quedó sin código" : "Código guardado. Pruebe con el botón ⏻ cuando no esté en la casa.");
                })
                .setNeutralButton("Abrir página de Samsung", (d, w) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://account.smartthings.com/tokens"))); } catch (Exception ignored) {}
                })
                .setNegativeButton("Cerrar", null).show();
    }

    // --- Apps de abajo, ajustes, ayuda ---

    private void appsDeAbajo() {
        List<String> l = misApps();
        List<String> ops = new ArrayList<>();
        for (String c : l) ops.add((String) Tv.app(c)[1]);
        ops.add("＋ Agregar una app");
        new AlertDialog.Builder(this).setTitle("🧩 Apps de abajo (toque una para moverla o quitarla)").setItems(ops.toArray(new String[0]), (d, w) -> {
            if (w < l.size()) opcionesApp(w); else agregarApp();
        }).show();
    }

    private void ajustes() {
        String[] n = {"Vibrar suave al tocar", "Los botones de volumen del celular manejan el televisor"};
        boolean[] v = {prefs.getBoolean("vibrar", true), prefs.getBoolean("volCel", true)};
        new AlertDialog.Builder(this).setTitle("⚙ Ajustes").setMultiChoiceItems(n, v, (d, w, s) -> v[w] = s)
                .setPositiveButton("Guardar", (d, w) -> prefs.edit().putBoolean("vibrar", v[0]).putBoolean("volCel", v[1]).apply())
                .setNegativeButton("Cancelar", null).show();
    }

    private void ayuda() {
        TextView t = new TextView(this);
        t.setPadding(dp(20), dp(10), dp(20), dp(10));
        t.setTextSize(15);
        t.setText("PANTALLA PRINCIPAL\n"
                + "• ⏻ Prende o apaga. Si no está conectado, da opciones para prender.\n"
                + "• El botón azul de arriba escoge el televisor.\n"
                + "• 🎤 Diga el nombre de una película o programa.\n"
                + "• Canal: escriba el número (ej. 1006) y toque Ir.\n"
                + "• Flechas y OK para moverse. Dejando el dedo, se repite.\n"
                + "• ⏪ Atrasar y ⏩ Adelantar: un toque salta 10 segundos; dejando el dedo va rápido.\n"
                + "• Volumen y canal: dejando el dedo, sube o baja seguido.\n"
                + "• Apps de abajo: deje el dedo para moverla, quitarla o cambiarla.\n\n"
                + "MENÚ ☰\n"
                + "• Dormir: apaga el televisor en el tiempo que escoja.\n"
                + "• Idioma, cámara lenta (YouTube), grabar (antena + USB).\n"
                + "• Mis canales: guarde los canales que más ve.\n"
                + "• Proyectar, Cámara al TV y Galería al TV: lo que se ve en el celular se ve en el televisor.\n"
                + "• Bluetooth: para televisores de otras marcas y la cajita inteligente de Claro.\n"
                + "• Samsung fuera de casa: prender y apagar desde la calle.\n\n"
                + "SI NO CONECTA\n"
                + "1. Revise que el televisor esté prendido.\n"
                + "2. El celular y el televisor deben estar en el mismo Wi‑Fi.\n"
                + "3. Toque el botón azul y escoja el televisor otra vez.\n"
                + "4. Mi Control busca solo el televisor si el router le cambió el número.\n\n"
                + "Mi Control " + VERSION);
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("❓ Ayuda").setView(sv).setPositiveButton("Entendido", null).show();
    }

    // ======================= Voz =======================

    private static final int VOZ = 61;

    private void voz() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "¿Qué quiere ver?");
        try { startActivityForResult(i, VOZ); } catch (Exception e) { escribirTexto(); }
    }

    @Override
    protected void onActivityResult(int r, int res, Intent d) {
        super.onActivityResult(r, res, d);
        if (r != VOZ || res != RESULT_OK || d == null) return;
        ArrayList<String> rs = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (rs == null || rs.isEmpty()) return;
        String q = rs.get(0);
        new AlertDialog.Builder(this).setTitle("🎤 «" + q + "»")
                .setItems(new String[]{"▶ Buscarlo en YouTube", "⌨ Escribirlo en la búsqueda que está abierta en el televisor"}, (x, w) -> {
                    if (w == 0) {
                        if (tv.abrirApp("youtube", q)) ponerEstado("Buscando «" + q + "» en YouTube…"); else noConectado();
                    } else if (!tv.escribir(q)) noConectado();
                }).show();
    }

    // ======================= Botones de volumen del celular =======================

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (prefs.getBoolean("volCel", true) && tv.conectado()) {
            if (code == KeyEvent.KEYCODE_VOLUME_UP) { tv.tecla("VOLUP"); return true; }
            if (code == KeyEvent.KEYCODE_VOLUME_DOWN) { tv.tecla("VOLDOWN"); return true; }
        }
        return super.onKeyDown(code, e);
    }
}
