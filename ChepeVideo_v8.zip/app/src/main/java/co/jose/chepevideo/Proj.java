package co.jose.chepevideo;

import android.graphics.Bitmap;
import android.graphics.RectF;
import android.net.Uri;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Todo lo que el usuario va armando sobre el video. */
public final class Proj {

    public static final class Sub {
        public long startMs, endMs;
        public volatile String text, trans;
        public Sub(long s, long e, String t, String tr) { startMs = s; endMs = e; text = t; trans = tr; }
    }

    public static final class ImageLayer {
        public volatile Bitmap bmp;
        public final Bitmap original;
        public volatile boolean noBg;
        public volatile long startMs, endMs;
        public volatile float cx = 0.5f, cy = 0.55f, scale = 0.4f;
        public ImageLayer(Bitmap b, Bitmap orig, boolean nb, long s, long e) { bmp = b; original = orig; noBg = nb; startMs = s; endMs = e; }
    }

    /** Texto escrito encima del video. size = fracción del lado corto del cuadro. */
    public static final class TextLayer {
        public volatile String text;
        public volatile int color = 0xFFFFFFFF, style = 1, anim = 1;
        public volatile float cx = 0.5f, cy = 0.2f, size = 0.08f;
        public volatile long startMs, endMs;
        public TextLayer(String t, long s, long e) { text = t; startMs = s; endMs = e; }
    }

    /** Versión 6.1: un zoom grabado: de a hasta b (ms del video), cuánto (s) y el centro (cx, cy de 0 a 1). */
    public static final class Zoom {
        public volatile long a, b;
        public volatile float s, cx, cy;
        public Zoom(long a, long b, float s, float cx, float cy) { this.a = a; this.b = b; this.s = s; this.cx = cx; this.cy = cy; }
    }

    public static final List<Zoom> zooms = new CopyOnWriteArrayList<>();
    public static volatile Zoom selZoom;
    static final long ZOOM_SUAVE = 500;

    /** Cómo está el zoom en el momento t: {cuánto, cx, cy}. Entra y sale suave. */
    public static float[] zoomEn(long t) {
        for (Zoom z : zooms) {
            if (t < z.a || t >= z.b) continue;
            long largo = Math.max(1, z.b - z.a);
            long su = Math.min(ZOOM_SUAVE, largo / 3);
            float k = 1f;
            if (su > 0) k = Math.min(1f, Math.min((t - z.a) / (float) su, (z.b - t) / (float) su));
            k = k * k * (3f - 2f * k);
            float s = 1f + (z.s - 1f) * k;
            float cx = 0.5f + (z.cx - 0.5f) * k, cy = 0.5f + (z.cy - 0.5f) * k;
            float h = 0.5f / s;
            cx = Math.max(h, Math.min(1f - h, cx));
            cy = Math.max(h, Math.min(1f - h, cy));
            return new float[]{s, cx, cy};
        }
        return null;
    }

    /** Versión 6: true = la foto va delante del video recortado. */
    public static volatile boolean fotoDelante = true;

    public static final class VideoLayer {
        public final Uri uri;
        public final long durMs;
        public final float aspect; // alto / ancho
        public volatile boolean green;
        public volatile long startMs;
        public volatile float cx = 0.72f, cy = 0.62f, scale = 0.45f;
        public VideoLayer(Uri u, long d, boolean g, long s, float a) { uri = u; durMs = d; green = g; startMs = s; aspect = a; }
    }

    /** type: 0 color, 1 foto, 2 video */
    public static final class Background {
        public final int type, color;
        public final Bitmap bmp;
        public final Uri uri;
        public final long durMs;
        public volatile boolean green;
        public Background(int t, int c, Bitmap b, Uri u, boolean g, long d) { type = t; color = c; bmp = b; uri = u; green = g; durMs = d; }
    }

    /** Música de fondo. vol = volumen de la música, videoVol = volumen del sonido del video. */
    public static final class Music {
        public final Uri uri;
        public final String name;
        public final long durMs;
        public volatile float vol = 0.6f, videoVol = 1f;
        // Versión 6.1: velocidad y tono de este sonido (1 = normal)
        public volatile float speed = 1f, tono = 1f;
        public volatile boolean soft = true;
        // Versión 5: pedazo de sonido en la pista morada. a..b = parte del audio que suena; at = dónde empieza en el video
        public volatile long a, b, at;
        public volatile boolean entra = true, sale = true, repetir, delVideo;
        public Music(Uri u, String n, long d) { uri = u; name = n; durMs = d; a = 0; b = d; vol = 1f; }
        /** Lo que dura en el video (con su velocidad). */
        public long largo() { return Math.max(200, (long) ((b - a) / Math.max(0.1f, speed))); }
        /** Convierte tiempo del video (desde at) a tiempo del archivo de audio. */
        public long fuenteEn(long msVideo) { return a + (long) (msVideo * speed); }
        /** Hasta dónde llega en el video (si se repite, hasta el final del video). */
        public long finEn(long finVideo) { return repetir ? Math.max(at + largo(), finVideo) : at + largo(); }
        public Music copia() {
            Music m = new Music(uri, name, durMs);
            m.vol = vol; m.a = a; m.b = b; m.at = at; m.speed = speed; m.tono = tono; m.entra = entra; m.sale = sale; m.repetir = repetir; m.delVideo = delVideo;
            return m;
        }
    }

    /** Versión 5: los sonidos de la pista morada y el escogido. */
    public static final List<Music> sonidos = new CopyOnWriteArrayList<>();
    public static volatile Music selSon;

    /** Un video de la lista para unir. trans = transición después de este video. */
    public static final class Clip {
        public final Uri uri;
        public final String name;
        public final long durMs;
        public final int w, h;
        public volatile int trans;
        public volatile Bitmap thumb;
        // Versión 4: cada capa con su línea azul (a) y roja (b), sus candados y la marca de TikTok suavizada
        public volatile long a, b;
        public volatile boolean lockA, lockB, wm, wmArriba = true;
        public volatile float wmFuerza = 0.7f;
        public Clip(Uri u, String n, long d, int w, int h, int t) { uri = u; name = n; durMs = d; this.w = w; this.h = h; trans = t; a = 0; b = d; }
        public long dur() { return Math.max(100, b - a); }
        public Clip copia() {
            Clip c = new Clip(uri, name, durMs, w, h, trans);
            c.thumb = thumb; c.a = a; c.b = b; c.lockA = lockA; c.lockB = lockB; c.wm = wm; c.wmArriba = wmArriba; c.wmFuerza = wmFuerza;
            return c;
        }
    }

    public static volatile Uri uri;
    public static volatile String name = "";
    public static volatile long durMs;
    public static volatile int w, h;
    public static volatile float fps = 30f;
    public static volatile long trimStart, trimEnd;
    // Versión 4: candados de las líneas y marca de TikTok suavizada del video abierto
    public static volatile boolean lockA, lockB, wm, wmArriba = true;
    public static volatile float wmFuerza = 0.7f;
    public static volatile float speed = 1f;
    public static volatile boolean mute;
    public static volatile RectF crop;
    public static final List<Sub> subs = new CopyOnWriteArrayList<>();
    public static volatile int subsMode; // 0 ambos, 1 solo original, 2 ocultos
    public static volatile String lang = "en";
    public static final List<ImageLayer> images = new CopyOnWriteArrayList<>();
    public static volatile ImageLayer selImage;
    public static final List<TextLayer> texts = new CopyOnWriteArrayList<>();
    public static volatile TextLayer selText;
    public static volatile VideoLayer layer;
    public static volatile Background bg;
    public static volatile Music music;
    public static final List<Clip> clips = new CopyOnWriteArrayList<>();
    public static volatile int joinTrans = 1, joinFormat;
    public static volatile boolean joinSoft = true;

    /** keep = conservar textos, fotos y música (cuando el video nuevo sale de unir). */
    public static void reset(Uri u, Frames.VInfo i, boolean keep) {
        uri = u; durMs = i.durMs; w = i.w; h = i.h; fps = i.fps;
        trimStart = 0; trimEnd = i.durMs; speed = 1f; if (!keep) mute = false; crop = null;
        lockA = false; lockB = false; wm = false; wmArriba = true; wmFuerza = 0.7f;
        subs.clear();
        // ChpVideo v8: al juntar pedazos (keep) no se pierde el video de encima ni el fondo
        if (!keep) { layer = null; bg = null; }
        else if (layer != null && layer.startMs >= durMs) layer.startMs = 0;
        if (!keep) {
            zooms.clear(); selZoom = null;
            images.clear(); selImage = null;
            texts.clear(); selText = null;
            music = null;
            sonidos.clear(); selSon = null;
        } else {
            // los sonidos sacados de otro video ya no sirven; los de música se quedan
            for (Music m : sonidos) if (m.delVideo) sonidos.remove(m);
            if (selSon != null && !sonidos.contains(selSon)) selSon = null;
            for (Zoom z : zooms) { if (z.a >= durMs) zooms.remove(z); else if (z.b > durMs) z.b = durMs; }
            if (selZoom != null && !zooms.contains(selZoom)) selZoom = null;
            for (TextLayer t : texts) { if (t.startMs >= durMs) t.startMs = 0; if (t.endMs > durMs) t.endMs = durMs; }
            for (ImageLayer m : images) { if (m.startMs >= durMs) m.startMs = 0; if (m.endMs > durMs) m.endMs = durMs; }
        }
    }

    public static boolean anyImageAt(long t) {
        for (ImageLayer m : images) if (t >= m.startMs && t < m.endMs) return true;
        return false;
    }

    private Proj() {}
}
