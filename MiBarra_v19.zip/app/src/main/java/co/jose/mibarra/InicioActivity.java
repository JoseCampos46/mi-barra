package co.jose.mibarra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Mi Barra Inicio: la pantalla principal del celular.
 * Página 1: reloj, batería, clima, recordatorios, almanaque, frase del día, buscador y favoritas.
 * Luego: las herramientas de Mi Barra y todas las apps en orden alfabético, 5 por fila.
 * Deslizando hacia abajo: el panel rápido. Dejando presionado un ícono: moverlo, quitarlo o desinstalarlo.
 */
public class InicioActivity extends Activity {

    // ---------------- Las apps y nuestras herramientas ----------------

    static final class Item {
        String clave, nombre, emoji;
        int color;
        Drawable icono;
        Runnable abrir;
        boolean nuestra;
    }

    private final List<Item> apps = new ArrayList<>(), herramientas = new ArrayList<>();
    private final Map<String, Item> porClave = new LinkedHashMap<>();
    private SharedPreferences prefs;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Locale es = new Locale("es", "CO");

    // Vistas
    private FrameLayout raiz;
    private Fondo fondo;
    private HorizontalScrollView paginador;
    private LinearLayout paginas, puntos;
    private int pagina, anchoPantalla, altoPagina;
    private TextView tHora, tAmPm, tFecha, tBateria, tRecord, tFrase;
    private Estado estado;
    private View avisoBoton;
    private LinearLayout calendario;
    private View panel, busqueda;
    private boolean linterna;

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("inicio", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(0xFF070A18);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        raiz = new FrameLayout(this);
        fondo = new Fondo(this);
        raiz.addView(fondo, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);
        armarHerramientas();
        raiz.post(this::cargarApps);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(cambioApps, f);
        registerReceiver(bateria, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        Recordatorios.programar(this);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(cambioApps); unregisterReceiver(bateria); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override protected void onResume() { super.onResume(); pedirNumeroUnaVez(); h.post(reloj); h.post(senal); refrescarRecordatorios(); clima(); revisarBoton(); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(reloj); h.removeCallbacks(senal); }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        // Tocó el botón ● de inicio: volver a la página 1 y cerrar lo abierto
        cerrarCapas();
        irA(0, true);
    }

    @Override
    public void onBackPressed() {
        if (cerrarCapas()) return;
        if (pagina != 0) irA(0, true);
    }

    private boolean cerrarCapas() {
        boolean algo = false;
        if (panel != null) { raiz.removeView(panel); panel = null; algo = true; }
        if (busqueda != null) {
            View f = getCurrentFocus();
            if (f != null) ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(f.getWindowToken(), 0);
            raiz.removeView(busqueda); busqueda = null; algo = true;
        }
        return algo;
    }

    private final BroadcastReceiver cambioApps = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { h.postDelayed(InicioActivity.this::cargarApps, 800); }
    };

    private int nivelBateria = -1;
    private boolean cargando;
    private final BroadcastReceiver bateria = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            nivelBateria = lv < 0 ? -1 : lv * 100 / sc;
            cargando = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            pintarBateria();
        }
    };

    private Item herr(String id, String emoji, String nombre, int color, Runnable r) {
        Item it = new Item();
        color = vivo(color, id);   // versión 18: colores fuertes para encontrarlas rápido
        it.clave = "mb:" + id; it.emoji = emoji; it.nombre = nombre; it.color = color; it.abrir = r; it.nuestra = true;
        it.icono = new BitmapDrawable(getResources(), iconoEmoji(emoji, color));
        herramientas.add(it);
        return it;
    }

    private static final int[] VIVOS = {0xFFE53935, 0xFFD81B60, 0xFF8E24AA, 0xFF3949AB, 0xFF1E88E5, 0xFF00ACC1,
            0xFF00897B, 0xFF43A047, 0xFF7CB342, 0xFFF4511E, 0xFFFB8C00, 0xFFFFB300};

    /** Sube el color a uno fuerte y brillante; a los grises les da un color propio fijo. */
    static int vivo(int c, String id) {
        float[] hsv = new float[3];
        Color.colorToHSV(c, hsv);
        if (hsv[1] < 0.3f) return VIVOS[Math.abs(id.hashCode()) % VIVOS.length];
        hsv[1] = Math.max(hsv[1], 0.8f);
        hsv[2] = Math.max(hsv[2], 0.88f);
        return Color.HSVToColor(hsv);
    }

    private Runnable abrirAct(Class<?> c) { return () -> startActivity(new Intent(this, c)); }
    private Runnable abrirAct(Class<?> c, String extra, int v) { return () -> startActivity(new Intent(this, c).putExtra(extra, v)); }

    private void armarHerramientas() {
        herramientas.clear();
        herr("cuaderno", "📝", "Cuaderno", 0xFF1565C0, abrirAct(NotasActivity.class));
        herr("cuentas", "📊", "Cuentas", 0xFF2E7D32, abrirAct(HojaActivity.class));
        herr("cobro", "🧾", "Cuenta de cobro", 0xFF6D4C41, abrirAct(CobroActivity.class));
        herr("compras", "🛒", "Compras", 0xFF00838F, abrirAct(ComprasActivity.class));
        herr("proveedores", "📇", "Proveedores", 0xFF455A64, abrirAct(ProveedoresActivity.class));
        herr("escaner", "📄", "Escáner", 0xFF8E24AA, abrirAct(EscanerActivity.class));
        herr("pdf", "📑", "PDF", 0xFFC62828, abrirAct(MainActivity.class));
        herr("calculadora", "🧮", "Calculadora", 0xFF2E7D32, abrirAct(CalculadoraActivity.class, "pestana", 0));
        herr("pulgadas", "📏", "mm ↔ pulgadas", 0xFF3949AB, abrirAct(CalculadoraActivity.class, "pestana", 1));
        herr("concreto", "🏗️", "Concreto", 0xFF607D8B, abrirAct(CalculadoraActivity.class, "pestana", 2));
        herr("ladrillo", "🧱", "Ladrillo", 0xFF795548, abrirAct(CalculadoraActivity.class, "pestana", 3));
        herr("nivel", "📐", "Nivel", 0xFF6A1B9A, abrirAct(NivelActivity.class, "modo", 0));
        herr("grados", "📐", "Grados techo", 0xFF4527A0, abrirAct(NivelActivity.class, "modo", 3));
        herr("plomada", "🎯", "Plomada", 0xFF283593, abrirAct(NivelActivity.class, "modo", 2));
        herr("medidas", "📸", "Foto medidas", 0xFFEF6C00, abrirAct(MedidasActivity.class));
        herr("recordatorios", "📅", "Recordatorios", 0xFFEF6C00, abrirAct(RecordatoriosActivity.class));
        herr("reloj", "⏱", "Reloj cocina", 0xFFD84315, abrirAct(RelojActivity.class));
        herr("noche", "🌙", "Reloj noche", 0xFF283593, abrirAct(NocheActivity.class));
        herr("saludos", "💌", "Saludos", 0xFFAD1457, abrirAct(SaludosActivity.class));
        herr("enciclopedia", "📚", "Enciclopedia", 0xFF00695C, abrirAct(EnciclopediaActivity.class));
        herr("camara", "📷", "Cámara", 0xFF263238, abrirAct(CamaraActivity.class));
        herr("video", "🎬", "Video", 0xFFB71C1C, () -> startActivity(new Intent(this, CamaraActivity.class).putExtra("video", true)));
        herr("grabadora", "🎵", "Grabadora", 0xFF37474F, abrirAct(GrabadoraActivity.class));
        herr("grabarpantalla", "🎥", "Grabar pantalla", 0xFFC62828, abrirAct(GrabarActivity.class));
        herr("codigos", "🔳", "Escanear QR", 0xFF212121, abrirAct(CodigoActivity.class));
        herr("tv", "📺", "Control TV", 0xFF1A237E, abrirAct(ControlTvActivity.class));
        herr("aquiestoy", "📍", "Aquí estoy", 0xFF2E7D32, abrirAct(AquiEstoyActivity.class));
        herr("recorridos", "🛣️", "Recorridos", 0xFF1565C0, abrirAct(RecorridoActivity.class));
        herr("antesdesalir", "🏍", "Antes de salir", 0xFFF57F17, abrirAct(ChequeoActivity.class));
        herr("ruta", "🗺", "Ruta ciudades", 0xFF00838F, () -> startActivity(new Intent(this, ParadasActivity.class).putExtra("modo", "viaje")));
        herr("reparto", "📦", "Reparto", 0xFF5D4037, () -> startActivity(new Intent(this, ParadasActivity.class).putExtra("modo", "reparto")));
        herr("gasolina", "⛽", "Gasolinera", 0xFFC62828, () -> cerca("gasolinera"));
        herr("hospital", "🏥", "Hospital", 0xFFE53935, () -> cerca("hospital"));
        herr("taller", "🔧", "Taller motos", 0xFF546E7A, () -> cerca("taller de motos"));
        herr("cajero", "🏧", "Cajero", 0xFF1E88E5, () -> cerca("cajero automático"));
        herr("drogueria", "💊", "Droguería", 0xFF43A047, () -> cerca("droguería"));
        herr("ferreteria", "🔩", "Ferretería", 0xFF795548, () -> cerca("ferretería"));
        herr("teclado", "⌨", "Teclado Mi Barra", 0xFF37474F, abrirAct(TecladoAjustesActivity.class));
        herr("ajustes", "⚙", "Ajustes Inicio", 0xFF455A64, this::ajustes);
        // Versión 17
        herr("tabla", "📋", "Tabla de obra", 0xFF00695C, abrirAct(TablaActivity.class));
        herr("lugares", "📍", "Mis lugares", 0xFFD84315, abrirAct(LugaresActivity.class));
        herr("senal", "📶", "Señal y velocidad", 0xFF1565C0, abrirAct(SenalActivity.class));
        herr("wifi", "🛜", "Wi‑Fi", 0xFF0277BD, abrirAct(WifiActivity.class));
        herr("radio", "📻", "Radio", 0xFFAD1457, abrirAct(RadioActivity.class));
        herr("tv", "📺", "TV gratis", 0xFF4527A0, abrirAct(TvActivity.class));
        herr("audios", "🎧", "Reproductor", 0xFF6A1B9A, abrirAct(ReproductorActivity.class));
        herr("cerrarapps", "🧹", "Cerrar apps", 0xFF546E7A, () -> accionBarra("cerrarApps"));
        // Versión 18
        herr("precios", "💲", "Buscar precios", 0xFF2E7D32, abrirAct(PreciosActivity.class));
        herr("transporte", "🚕", "Transporte", 0xFFFFB300, abrirAct(TransporteActivity.class));
        herr("minicamara", "📷", "Mini cámara", 0xFFE53935, abrirAct(MiniCamaraActivity.class));
        herr("imprimirlargo", "📜", "Imprimir bajando", 0xFF1E88E5, () -> accionBarra("imprimirLargo"));
        herr("imprimir", "🖨", "Imprimir pantalla", 0xFF3949AB, () -> accionBarra("imprimir"));
        herr("botonflotante", "🟠", "Botón flotante", 0xFFFB8C00, this::reactivarBoton);
    }

    private void cerca(String que) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(que)));
        try { startActivity(i); } catch (Exception e) { abrirUrl("https://www.google.com/maps/search/" + Uri.encode(que + " cerca de mí")); }
    }

    private void abrirUrl(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { aviso("No se pudo abrir"); }
    }

    /** Ícono propio: la figurita sobre un cuadro redondeado de color, con brillo suave. */
    private Bitmap iconoEmoji(String emoji, int color) {
        int s = dp(56);
        Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, s, aclarar(color, 0.18f), color, Shader.TileMode.CLAMP));
        c.drawRoundRect(0, 0, s, s, s * 0.27f, s * 0.27f, p);
        p.setShader(null);
        p.setTextSize(s * 0.52f);
        p.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = p.getFontMetrics();
        c.drawText(emoji, s / 2f, s / 2f - (fm.ascent + fm.descent) / 2f, p);
        return bm;
    }

    static int aclarar(int c, float f) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void cargarApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ResolveInfo> rs = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
            List<Item> r = new ArrayList<>();
            for (ResolveInfo ri : rs) {
                if (getPackageName().equals(ri.activityInfo.packageName)) continue; // "Mi Barra" ya está como herramientas
                Item a = new Item();
                a.nombre = String.valueOf(ri.loadLabel(pm)).trim();
                a.clave = ri.activityInfo.packageName + "/" + ri.activityInfo.name;
                final String pk = ri.activityInfo.packageName, cl = ri.activityInfo.name;
                a.abrir = () -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(pk, cl)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
                    } catch (Exception e) { aviso("No se pudo abrir"); }
                };
                try { a.icono = ri.loadIcon(pm); } catch (Exception ignored) {}
                r.add(a);
            }
            r.sort((x, y) -> SaludosActivity.sinTildes(x.nombre).compareTo(SaludosActivity.sinTildes(y.nombre)));
            runOnUiThread(() -> {
                apps.clear(); apps.addAll(r);
                porClave.clear();
                for (Item i : herramientas) porClave.put(i.clave, i);
                for (Item i : apps) porClave.put(i.clave, i);
                armar();
            });
        }).start();
    }

    // ---------------- Uso, favoritas y quitadas ----------------

    private Set<String> quitadas() { return new HashSet<>(prefs.getStringSet("quitadas", new HashSet<>())); }

    private List<String> favoritas() {
        String s = prefs.getString("favoritas", null);
        List<String> r = new ArrayList<>();
        if (s == null) {
            // Para empezar: lo más común
            for (String q : new String[]{"com.whatsapp", "com.android.chrome", "org.mozilla.firefox", "com.google.android.dialer",
                    "com.android.contacts", "com.google.android.apps.maps", "com.google.android.youtube"})
                for (Item a : apps) if (a.clave.startsWith(q + "/") && !r.contains(a.clave)) { r.add(a.clave); break; }
            for (String q : new String[]{"mb:cuaderno", "mb:calculadora", "mb:recordatorios", "mb:camara", "mb:grabadora"}) r.add(q);
            return r;
        }
        for (String x : s.split("\\|")) if (!x.isEmpty() && porClave.containsKey(x)) r.add(x);
        return r;
    }

    private void guardarFavoritas(List<String> f) { prefs.edit().putString("favoritas", String.join("|", f)).apply(); }

    private void usar(Item it) {
        prefs.edit().putInt("u_" + it.clave, prefs.getInt("u_" + it.clave, 0) + 1).apply();
        cerrarCapas();
        try { it.abrir.run(); } catch (Exception e) { aviso("No se pudo abrir " + it.nombre); }
    }

    private List<Item> masUsadas(int n, List<String> fuera) {
        List<Item> todos = new ArrayList<>(herramientas);
        todos.addAll(apps);
        todos.removeIf(i -> fuera.contains(i.clave) || prefs.getInt("u_" + i.clave, 0) == 0 || quitadas().contains(i.clave));
        todos.sort((a, b) -> prefs.getInt("u_" + b.clave, 0) - prefs.getInt("u_" + a.clave, 0));
        return todos.subList(0, Math.min(n, todos.size()));
    }

    // ---------------- Armar las páginas ----------------

    private static final int COLUMNAS = 5;
    private int altoCelda;

    private void armar() {
        anchoPantalla = raiz.getWidth();
        int idEstado = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int arriba = idEstado > 0 ? getResources().getDimensionPixelSize(idEstado) : dp(24);
        int idNav = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        int abajo = idNav > 0 ? getResources().getDimensionPixelSize(idNav) : dp(40);
        altoPagina = raiz.getHeight() - arriba - abajo - dp(26);
        altoCelda = dp(96);
        int volverA = pagina;
        if (paginador != null) raiz.removeView(paginador);
        if (puntos != null) raiz.removeView(puntos);
        paginador = new HorizontalScrollView(this) {
            float x0; int pag0;
            @Override public boolean onInterceptTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { x0 = e.getX(); pag0 = pagina; }
                return super.onInterceptTouchEvent(e);
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { x0 = e.getX(); pag0 = pagina; }
                if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    super.onTouchEvent(e);
                    float dx = e.getX() - x0;
                    int destino = pag0;
                    if (dx < -anchoPantalla * 0.15f) destino = pag0 + 1;
                    else if (dx > anchoPantalla * 0.15f) destino = pag0 - 1;
                    irA(destino, true);
                    return true;
                }
                return super.onTouchEvent(e);
            }
        };
        paginador.setHorizontalScrollBarEnabled(false);
        paginador.setOverScrollMode(View.OVER_SCROLL_NEVER);
        paginas = new LinearLayout(this);
        paginador.addView(paginas);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, altoPagina);
        lp.topMargin = arriba;
        raiz.addView(paginador, 1, lp);

        paginas.addView(paginaInicio(), new LinearLayout.LayoutParams(anchoPantalla, altoPagina));
        Set<String> q = quitadas();
        List<Item> nuestras = new ArrayList<>();
        for (Item i : herramientas) if (!q.contains(i.clave)) nuestras.add(i);
        List<Item> suyas = new ArrayList<>();
        for (Item i : apps) if (!q.contains(i.clave)) suyas.add(i);
        int filas = Math.max(3, (altoPagina - dp(44)) / altoCelda);
        int porPagina = filas * COLUMNAS;
        for (int i = 0; i < nuestras.size(); i += porPagina)
            paginas.addView(paginaCuadricula("🛠 Herramientas Mi Barra", nuestras.subList(i, Math.min(nuestras.size(), i + porPagina))),
                    new LinearLayout.LayoutParams(anchoPantalla, altoPagina));
        for (int i = 0; i < suyas.size(); i += porPagina) {
            List<Item> parte = suyas.subList(i, Math.min(suyas.size(), i + porPagina));
            String de = parte.get(0).nombre.substring(0, 1).toUpperCase(es), a = parte.get(parte.size() - 1).nombre.substring(0, 1).toUpperCase(es);
            paginas.addView(paginaCuadricula("📱 Mis apps  " + de + (de.equals(a) ? "" : " – " + a), parte), new LinearLayout.LayoutParams(anchoPantalla, altoPagina));
        }
        // Puntitos de página
        puntos = new LinearLayout(this);
        puntos.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(20), Gravity.BOTTOM);
        pp.bottomMargin = abajo + dp(4);
        raiz.addView(puntos, 2, pp);
        pintarPuntos();
        refrescarRecordatorios();
        pintarBateria();
        tic();
        final int v = Math.min(volverA, paginas.getChildCount() - 1);
        paginador.post(() -> irA(v, false));
    }

    private void irA(int p, boolean suave) {
        if (paginas == null) return;
        pagina = Math.max(0, Math.min(paginas.getChildCount() - 1, p));
        if (suave) paginador.smoothScrollTo(pagina * anchoPantalla, 0); else paginador.scrollTo(pagina * anchoPantalla, 0);
        pintarPuntos();
    }

    private void pintarPuntos() {
        if (puntos == null) return;
        puntos.removeAllViews();
        int n = paginas.getChildCount();
        for (int i = 0; i < n; i++) {
            View d = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(i == pagina ? Color.WHITE : 0x66FFFFFF);
            d.setBackground(g);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(i == pagina ? 9 : 7), dp(i == pagina ? 9 : 7));
            l.setMargins(dp(4), 0, dp(4), 0);
            puntos.addView(d, l);
        }
    }

    private GradientDrawable vidrio(float radio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x26FFFFFF);
        g.setCornerRadius(dp(radio));
        g.setStroke(dp(1), 0x33FFFFFF);
        return g;
    }

    private TextView texto(String s, float tam, int color, boolean negrita) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(tam);
        t.setTextColor(color);
        if (negrita) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setShadowLayer(dp(3), 0, dp(1), 0x66000000);
        return t;
    }

    // ---- Página 1 ----

    private View paginaInicio() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(8), dp(12), 0);

        // Fila de arriba: reloj (izquierda) y almanaque (derecha)
        LinearLayout arriba = new LinearLayout(this);
        LinearLayout rel = new LinearLayout(this);
        rel.setOrientation(LinearLayout.VERTICAL);
        rel.setPadding(dp(14), dp(10), dp(12), dp(12));
        rel.setBackground(vidrio(24));
        LinearLayout hl = new LinearLayout(this);
        hl.setGravity(Gravity.BOTTOM);
        tHora = texto("", 50, Color.WHITE, false);
        tHora.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        tHora.setIncludeFontPadding(false);
        tAmPm = texto("", 16, 0xDDFFFFFF, false);
        tAmPm.setPadding(dp(4), 0, 0, dp(8));
        hl.addView(tHora);
        hl.addView(tAmPm);
        rel.addView(hl);
        tFecha = texto("", 15, 0xEEFFFFFF, false);
        rel.addView(tFecha);
        tBateria = texto("", 14, 0xDDFFFFFF, false);
        tBateria.setPadding(0, dp(4), 0, 0);
        rel.addView(tBateria);
        tRecord = texto("", 13, Color.WHITE, false);
        GradientDrawable gr = new GradientDrawable();
        gr.setColor(0x40FFA726);
        gr.setCornerRadius(dp(12));
        tRecord.setBackground(gr);
        tRecord.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(8);
        rel.addView(tRecord, rp);
        rel.setOnClickListener(v -> startActivity(new Intent(this, RecordatoriosActivity.class)));
        rel.setOnLongClickListener(v -> { try { startActivity(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)); } catch (Exception ignored) {} return true; });
        arriba.addView(rel, new LinearLayout.LayoutParams(0, -2, 1.3f));
        calendario = new LinearLayout(this);
        calendario.setOrientation(LinearLayout.VERTICAL);
        calendario.setPadding(dp(8), dp(10), dp(8), dp(8));
        calendario.setBackground(vidrio(24));
        calendario.setOnClickListener(v -> startActivity(new Intent(this, RecordatoriosActivity.class)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -1, 1f);
        cp.leftMargin = dp(10);
        arriba.addView(calendario, cp);
        l.addView(arriba);

        // Versión 15: señal de cada SIM y batería, grandes y a lo ancho
        estado = new Estado(this);
        estado.setBackground(vidrio(18));
        estado.setOnClickListener(v -> ajuste(Settings.ACTION_WIRELESS_SETTINGS));
        estado.setOnLongClickListener(v -> { ponerNumeros(); return true; });
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(44));
        ep.topMargin = dp(6);
        l.addView(estado, ep);

        // Frase del día
        tFrase = texto("✨ " + Frases.deHoy(), 14, Color.WHITE, false);
        tFrase.setTypeface(Typeface.create("serif", Typeface.ITALIC));
        tFrase.setGravity(Gravity.CENTER);
        tFrase.setPadding(dp(12), dp(6), dp(12), dp(6));
        tFrase.setBackground(vidrio(18));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(6);
        l.addView(tFrase, fp);

        // Buscador
        LinearLayout bus = new LinearLayout(this);
        bus.setGravity(Gravity.CENTER_VERTICAL);
        bus.setPadding(dp(16), 0, dp(10), 0);
        bus.setBackground(vidrio(24));
        TextView tb = texto("🔎  Buscar app o herramienta", 16, 0xEEFFFFFF, false);
        bus.addView(tb, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView mic = texto("🎤", 22, Color.WHITE, false);
        mic.setPadding(dp(8), dp(4), dp(8), dp(4));
        mic.setOnClickListener(v -> dictarBusqueda());
        bus.addView(mic);
        bus.setOnClickListener(v -> abrirBusqueda(""));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(44));
        bp.topMargin = dp(6);
        l.addView(bus, bp);

        // Favoritas y más usadas
        List<String> fav = favoritas();
        List<Item> fi = new ArrayList<>();
        for (String k : fav) if (porClave.containsKey(k) && !quitadas().contains(k)) fi.add(porClave.get(k));
        TextView t1 = texto("⭐ Mis favoritas", 14, 0xDDFFFFFF, true);
        t1.setPadding(dp(4), dp(6), 0, 0);
        l.addView(t1);
        l.addView(cuadricula(fi.subList(0, Math.min(10, fi.size())), true, dp(76)));
        // Las que más usa: hasta 3 filas (15 apps), las que quepan en el espacio que queda
        List<Item> mu = masUsadas(COLUMNAS * 3, fav);
        FrameLayout zona = new FrameLayout(this);
        l.addView(zona, new LinearLayout.LayoutParams(-1, 0, 1f));
        if (!mu.isEmpty()) {
            final int[] filasPuestas = {-1};
            zona.addOnLayoutChangeListener((v, a1, b1, c1, d1, a2, b2, c2, d2) -> {
                int alto = d1 - b1;
                int filas = Math.max(1, Math.min(3, (alto - dp(20)) / dp(72)));
                if (filas == filasPuestas[0]) return;
                filasPuestas[0] = filas;
                zona.post(() -> {
                    zona.removeAllViews();
                    LinearLayout col = new LinearLayout(this);
                    col.setOrientation(LinearLayout.VERTICAL);
                    TextView t2 = texto("🔁 Las que más usa", 13, 0xDDFFFFFF, true);
                    t2.setPadding(dp(4), dp(2), 0, 0);
                    col.addView(t2);
                    col.addView(cuadricula(mu.subList(0, Math.min(mu.size(), filas * COLUMNAS)), false, dp(72)));
                    zona.addView(col, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
                });
            });
        }
        TextView ayuda = texto("⬅ Deslice para ver más apps   ·   ⬇ Deslice hacia abajo: panel rápido", 11.5f, 0x99FFFFFF, false);
        ayuda.setGravity(Gravity.CENTER);
        ayuda.setPadding(0, dp(2), 0, dp(2));
        // Versión 15: la ayuda de deslizar ya no se muestra, para dar espacio a las 3 filas
        pintarCalendario();
        return l;
    }

    private View paginaCuadricula(String titulo, List<Item> items) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(6), dp(10), dp(6), 0);
        TextView t = texto(titulo, 16, Color.WHITE, true);
        t.setPadding(dp(10), 0, 0, dp(8));
        l.addView(t);
        l.addView(cuadricula(items, false));
        return l;
    }

    private LinearLayout cuadricula(List<Item> items, boolean esFavorita) { return cuadricula(items, esFavorita, altoCelda); }

    private LinearLayout cuadricula(List<Item> items, boolean esFavorita, int altoFila) {
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        LinearLayout fila = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % COLUMNAS == 0) {
                fila = new LinearLayout(this);
                g.addView(fila, new LinearLayout.LayoutParams(-1, altoFila));
            }
            fila.addView(celda(items.get(i), esFavorita, altoFila < altoCelda), new LinearLayout.LayoutParams(0, -1, 1f));
        }
        if (fila != null) for (int k = items.size() % COLUMNAS; k > 0 && k < COLUMNAS; k++) fila.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 1f));
        return g;
    }

    private View celda(Item it, boolean esFavorita, boolean compacta) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(0, dp(6), 0, 0);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(it.icono);
        c.addView(iv, new LinearLayout.LayoutParams(dp(compacta ? 50 : 56), dp(compacta ? 50 : 56)));
        TextView t = texto(it.nombre, compacta ? 11.5f : 12, Color.WHITE, false);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(compacta ? 1 : 2);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(dp(2), dp(4), dp(2), 0);
        c.addView(t, new LinearLayout.LayoutParams(-1, -2));
        c.setOnClickListener(v -> {
            v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(90));
            usar(it);
        });
        c.setOnLongClickListener(v -> { opciones(it); return true; });
        return c;
    }

    /** Dejar presionado: poner en favoritas, moverla, quitarla de la pantalla o desinstalar. */
    private void opciones(Item it) {
        List<String> fav = favoritas();
        boolean es = fav.contains(it.clave);
        List<String> ops = new ArrayList<>();
        if (!es) ops.add("⭐ Poner en Mis favoritas");
        else { ops.add("◀ Mover a la izquierda"); ops.add("▶ Mover a la derecha"); ops.add("✖ Quitar de favoritas"); }
        ops.add("🙈 Quitar de la pantalla");
        if (!it.nuestra) { ops.add("🗑 Desinstalar"); ops.add("ℹ Información de la app"); }
        new AlertDialog.Builder(this).setTitle(it.nombre).setItems(ops.toArray(new String[0]), (d, w) -> {
            String o = ops.get(w);
            int i = fav.indexOf(it.clave);
            if (o.startsWith("⭐")) {
                if (fav.size() >= 10) { aviso("Ya tiene 10 favoritas. Quite una primero."); return; }
                fav.add(it.clave);
            } else if (o.startsWith("◀") && i > 0) { fav.remove(i); fav.add(i - 1, it.clave); }
            else if (o.startsWith("▶") && i < fav.size() - 1) { fav.remove(i); fav.add(i + 1, it.clave); }
            else if (o.startsWith("✖")) fav.remove(it.clave);
            else if (o.startsWith("🙈")) {
                Set<String> q = quitadas(); q.add(it.clave);
                prefs.edit().putStringSet("quitadas", q).apply();
                fav.remove(it.clave);
                aviso("Quitada. Para volver a ponerla: ⚙ Ajustes Inicio");
            } else if (o.startsWith("🗑")) {
                try { startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + it.clave.split("/")[0]))); } catch (Exception e) { aviso("No se pudo"); }
                return;
            } else if (o.startsWith("ℹ")) {
                try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + it.clave.split("/")[0]))); } catch (Exception ignored) {}
                return;
            }
            guardarFavoritas(fav);
            armar();
        }).show();
    }

    // ---------------- Versión 15: señal de las SIM y batería grande ----------------

    private final int[] nivelSim = {-1, -1};
    private final String[] nombreSim = {"", ""};
    private boolean modoAvion;

    private final Runnable senal = new Runnable() {
        @Override public void run() { leerSenal(); if (estado != null) estado.invalidate(); h.postDelayed(this, 15000); }
    };

    @SuppressWarnings("deprecation")
    private void leerSenal() {
        try { modoAvion = Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0; }
        catch (Exception e) { modoAvion = false; }
        android.telephony.TelephonyManager tm = getSystemService(android.telephony.TelephonyManager.class);
        android.telephony.SubscriptionManager sm = getSystemService(android.telephony.SubscriptionManager.class);
        for (int slot = 0; slot < 2; slot++) {
            nivelSim[slot] = -1;
            nombreSim[slot] = "";
            try {
                if (tm == null) continue;
                if (tm.getSimState(slot) != android.telephony.TelephonyManager.SIM_STATE_READY) continue;
                android.telephony.TelephonyManager t = tm;
                int[] ids = sm == null ? null : sm.getSubscriptionIds(slot);
                if (ids != null && ids.length > 0) t = tm.createForSubscriptionId(ids[0]);
                android.telephony.SignalStrength ss = t.getSignalStrength();
                nivelSim[slot] = ss == null ? 0 : Math.max(0, Math.min(4, ss.getLevel()));
                String n = t.getSimOperatorName();
                // Versión 19: letra del operador + número de la SIM (E 310 123 4567)
                String num = getSharedPreferences("inicio", MODE_PRIVATE).getString("numSim" + slot, "");
                if (num.isEmpty() && ids != null && ids.length > 0) num = numeroDe(sm, ids[0]);
                nombreSim[slot] = etiquetaSim(n == null ? "" : n, num);
            } catch (Throwable ignored) {
                if (nivelSim[slot] < 0) nivelSim[slot] = 0;
            }
        }
    }

    private void pedirNumeroUnaVez() {
        SharedPreferences pr = getSharedPreferences("inicio", MODE_PRIVATE);
        if (pr.getBoolean("pidioNumero", false)) return;
        pr.edit().putBoolean("pidioNumero", true).apply();
        if (checkSelfPermission("android.permission.READ_PHONE_NUMBERS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.READ_PHONE_NUMBERS", "android.permission.READ_PHONE_STATE"}, 19);
    }

    /** E = Éxito, T = Tigo, M = Movistar, W = WOM, C = Claro… seguido del número. */
    static String etiquetaSim(String operador, String numero) {
        String o = operador.toLowerCase(java.util.Locale.ROOT);
        String letra = o.contains("xito") ? "E" : o.contains("tigo") ? "T" : o.contains("movistar") ? "M"
                : o.contains("wom") ? "W" : o.contains("claro") || o.contains("comcel") ? "C" : o.contains("etb") ? "ETB"
                : o.contains("virgin") ? "V" : o.contains("avantel") ? "A" : o.contains("flash") ? "F"
                : operador.isEmpty() ? "" : operador.substring(0, 1).toUpperCase(java.util.Locale.ROOT);
        String d = numero.replaceAll("[^0-9]", "");
        if (d.startsWith("57") && d.length() == 12) d = d.substring(2);
        if (d.length() == 10) d = d.substring(0, 3) + " " + d.substring(3, 6) + " " + d.substring(6);
        if (d.isEmpty()) return operador;
        return (letra.isEmpty() ? "" : letra + " ") + d;
    }

    @SuppressWarnings("deprecation")
    private String numeroDe(android.telephony.SubscriptionManager sm, int id) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                String n = sm.getPhoneNumber(id);
                if (n != null && !n.isEmpty()) return n;
            }
            android.telephony.SubscriptionInfo si = sm.getActiveSubscriptionInfo(id);
            if (si != null && si.getNumber() != null) return si.getNumber();
        } catch (Throwable ignored) {}
        return "";
    }

    /** Si el celular no sabe el número de la SIM, se escribe una vez y queda guardado. */
    private void ponerNumeros() {
        SharedPreferences pr = getSharedPreferences("inicio", MODE_PRIVATE);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        android.widget.EditText[] e = new android.widget.EditText[2];
        for (int i = 0; i < 2; i++) {
            TextView t = new TextView(this);
            t.setText("Número de la SIM " + (i + 1) + (nombreSim[i].isEmpty() ? "" : "  (" + nombreSim[i] + ")"));
            t.setTextSize(15);
            l.addView(t);
            e[i] = new android.widget.EditText(this);
            e[i].setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            e[i].setText(pr.getString("numSim" + i, ""));
            e[i].setHint("Ej: 310 123 4567");
            l.addView(e[i]);
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("📶 Números de las SIM")
                .setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    pr.edit().putString("numSim0", e[0].getText().toString().trim())
                            .putString("numSim1", e[1].getText().toString().trim()).apply();
                    leerSenal();
                    if (estado != null) estado.invalidate();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** La franja ancha: SIM 1 y SIM 2 con sus barritas a la izquierda, la batería con color a la derecha. */
    private class Estado extends View {
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        Estado(Context c) { super(c); }

        @Override protected void onDraw(Canvas c) {
            float alto = getHeight(), x = dp(14);
            p.setShadowLayer(dp(2), 0, dp(1), 0x66000000);
            for (int i = 0; i < 2; i++) {
                int nivel = nivelSim[i];
                float base = alto / 2 + dp(9), bw = dp(5), sep = dp(3);
                for (int k = 0; k < 4; k++) {
                    float bh = dp(5) + k * dp(4.5f);
                    p.setColor(modoAvion || nivel < 0 ? 0x55FFFFFF : (k < nivel ? Color.WHITE : 0x55FFFFFF));
                    c.drawRoundRect(x + k * (bw + sep), base - bh, x + k * (bw + sep) + bw, base, dp(1), dp(1), p);
                }
                x += 4 * (bw + sep) + dp(4);
                p.setColor(Color.WHITE);
                p.setTextSize(dp(14));
                p.setTypeface(Typeface.DEFAULT_BOLD);
                String et = modoAvion ? "✈" : nivel < 0 ? "Sin SIM" : nombreSim[i].isEmpty() ? "SIM " + (i + 1) : nombreSim[i];
                // Versión 16: el nombre completo; si no cabe, la letra se achica
                float espacio = (getWidth() * 0.62f) / 2f - (4 * (bw + sep) + dp(20));
                if (et.length() > 16) et = et.substring(0, 16);
                while (p.measureText(et) > espacio && p.getTextSize() > dp(10)) p.setTextSize(p.getTextSize() - 1);
                c.drawText(et, x, alto / 2 + dp(5), p);
                x += p.measureText(et) + dp(16);
            }
            // Batería grande a la derecha
            if (nivelBateria < 0) return;
            int col = nivelBateria <= 20 ? 0xFFFF3B30 : nivelBateria <= 60 ? 0xFFFFC107 : 0xFF34C759;
            String pct = (cargando ? "⚡" : "") + nivelBateria + " %";
            p.setTextSize(dp(19));
            p.setTypeface(Typeface.DEFAULT_BOLD);
            float tw = p.measureText(pct);
            float right = getWidth() - dp(14);
            p.setColor(col);
            c.drawText(pct, right - tw, alto / 2 + dp(7), p);
            float bR = right - tw - dp(8), bL = bR - dp(44), bT = alto / 2 - dp(10), bB = alto / 2 + dp(10);
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(dp(2.5f));
            p.setColor(Color.WHITE);
            c.drawRoundRect(bL, bT, bR, bB, dp(4), dp(4), p);
            p.setStyle(android.graphics.Paint.Style.FILL);
            c.drawRoundRect(bR + dp(1), alto / 2 - dp(4), bR + dp(4), alto / 2 + dp(4), dp(1), dp(1), p);
            p.setColor(col);
            float lleno = (bR - bL - dp(6)) * Math.max(4, nivelBateria) / 100f;
            c.drawRoundRect(bL + dp(3), bT + dp(3), bL + dp(3) + lleno, bB - dp(3), dp(2), dp(2), p);
        }
    }

    /** Si Xiaomi apagó el botón flotante, un aviso rojo arriba para volver a prenderlo de un toque. */
    /** Versión 18: vuelve a poner el botón naranja y, en Xiaomi, abre los permisos para que no lo apaguen. */
    private void reactivarBoton() {
        try { sendBroadcast(new Intent(BarraService.AVISO_BARRA).setPackage(getPackageName()).putExtra("boton", true)); } catch (Exception ignored) {}
        boolean activo = false;
        try {
            String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            activo = s != null && s.contains(getPackageName() + "/");
        } catch (Exception ignored) {}
        if (!activo) { aviso("Active «Mi Barra» en Accesibilidad"); ajuste(Settings.ACTION_ACCESSIBILITY_SETTINGS); return; }
        if (android.os.Build.MANUFACTURER.equalsIgnoreCase("xiaomi") || android.os.Build.MANUFACTURER.equalsIgnoreCase("redmi")) {
            new android.app.AlertDialog.Builder(this).setTitle("Que Xiaomi no apague el botón")
                    .setMessage("1. Inicio automático: active Mi Barra.\n2. Batería: escoja «Sin restricciones».\n\nEl botón ya quedó puesto abajo a la izquierda.")
                    .setPositiveButton("Inicio automático", (d, w) -> {
                        try {
                            startActivity(new Intent().setComponent(new android.content.ComponentName("com.miui.securitycenter",
                                    "com.miui.permcenter.autostart.AutoStartManagementActivity")));
                        } catch (Exception e) { ajuste(Settings.ACTION_APPLICATION_DETAILS_SETTINGS); }
                    })
                    .setNeutralButton("Batería", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) { ajuste(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS); }
                    })
                    .setNegativeButton("Listo", null).show();
        } else aviso("🟠 Botón puesto abajo a la izquierda");
    }

    private void revisarBoton() {
        boolean activo = false;
        try {
            String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            activo = s != null && s.contains(getPackageName() + "/");
        } catch (Exception ignored) {}
        if (activo) {
            if (avisoBoton != null) { raiz.removeView(avisoBoton); avisoBoton = null; }
            return;
        }
        if (avisoBoton != null) return;
        TextView t = texto("⚠ El botón flotante se apagó. Toque aquí y active «Mi Barra»", 14, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xEED32F2F);
        g.setCornerRadius(dp(14));
        t.setBackground(g);
        t.setOnClickListener(v -> ajuste(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        int idEstado = getResources().getIdentifier("status_bar_height", "dimen", "android");
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        lp.topMargin = (idEstado > 0 ? getResources().getDimensionPixelSize(idEstado) : dp(24)) + dp(4);
        lp.leftMargin = dp(12); lp.rightMargin = dp(12);
        raiz.addView(t, lp);
        avisoBoton = t;
    }

    // ---------------- Reloj, batería, clima, recordatorios, almanaque ----------------

    private final Runnable reloj = new Runnable() {
        @Override public void run() { tic(); h.postDelayed(this, 60000 - System.currentTimeMillis() % 60000 + 30); }
    };

    private int diaPintado = -1;

    private void tic() {
        if (tHora == null) return;
        Date ahora = new Date();
        tHora.setText(new SimpleDateFormat("h:mm", es).format(ahora));
        tAmPm.setText(new SimpleDateFormat("a", es).format(ahora).replace(". ", ".").replace("a.m.", "a. m.").replace("p.m.", "p. m."));
        String f = new SimpleDateFormat("EEEE d 'de' MMMM", es).format(ahora);
        tFecha.setText(Character.toUpperCase(f.charAt(0)) + f.substring(1));
        int d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        if (d != diaPintado) { diaPintado = d; pintarCalendario(); if (tFrase != null) tFrase.setText("✨ " + Frases.deHoy()); refrescarRecordatorios(); }
    }

    private String climaTxt = "";

    private void pintarBateria() {
        if (estado != null) estado.invalidate();
        if (tBateria == null) return;
        tBateria.setText(climaTxt);
        tBateria.setVisibility(climaTxt.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void refrescarRecordatorios() {
        if (tRecord == null) return;
        SimpleDateFormat hf = new SimpleDateFormat("h:mm a", es);
        StringBuilder s = new StringBuilder();
        int n = 0;
        for (Recordatorios.R r : Recordatorios.deHoy(this)) {
            if (r.hecho) continue;
            if (n++ >= 2) break;
            if (s.length() > 0) s.append('\n');
            s.append("📅 ").append(hf.format(new Date(r.cuando))).append("  ").append(r.texto);
        }
        tRecord.setText(s.length() == 0 ? "📅 Sin recordatorios hoy\nToque para poner uno" : s.toString());
    }

    private void pintarCalendario() {
        if (calendario == null) return;
        calendario.removeAllViews();
        Calendar hoy = Calendar.getInstance(), k = Calendar.getInstance();
        k.set(Calendar.DAY_OF_MONTH, 1);
        TextView m = texto(RecordatoriosActivity.MESES[k.get(Calendar.MONTH)].toUpperCase(es), 12, 0xFFFF6B6B, true);
        m.setPadding(dp(4), 0, 0, dp(4));
        calendario.addView(m);
        Set<Integer> conRec = new HashSet<>();
        for (Recordatorios.R r : Recordatorios.leer(this)) {
            if (r.hecho) continue;
            Calendar z = Calendar.getInstance();
            z.setTimeInMillis(r.cuando);
            if (z.get(Calendar.YEAR) == hoy.get(Calendar.YEAR) && z.get(Calendar.MONTH) == hoy.get(Calendar.MONTH)) conRec.add(z.get(Calendar.DAY_OF_MONTH));
        }
        String[] dias = {"L", "M", "M", "J", "V", "S", "D"};
        LinearLayout f = new LinearLayout(this);
        for (String d : dias) { TextView t = texto(d, 10, 0x99FFFFFF, false); t.setGravity(Gravity.CENTER); f.addView(t, new LinearLayout.LayoutParams(0, -2, 1f)); }
        calendario.addView(f);
        int primero = (k.get(Calendar.DAY_OF_WEEK) + 5) % 7, total = k.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 0; i < 42; i++) {
            if (i % 7 == 0) {
                if (i >= primero + total) break;
                f = new LinearLayout(this);
                calendario.addView(f, new LinearLayout.LayoutParams(-1, dp(19)));
            }
            int dia = i - primero + 1;
            TextView t = texto(dia >= 1 && dia <= total ? String.valueOf(dia) : "", 10.5f, Color.WHITE, false);
            t.setGravity(Gravity.CENTER);
            t.setShadowLayer(0, 0, 0, 0);
            if (dia == hoy.get(Calendar.DAY_OF_MONTH)) {
                GradientDrawable g = new GradientDrawable();
                g.setColor(0xFFE53935);
                g.setCornerRadius(dp(9));
                t.setBackground(g);
                t.setTypeface(Typeface.DEFAULT_BOLD);
            } else if (conRec.contains(dia)) { t.setTextColor(0xFFFFB74D); t.setTypeface(Typeface.DEFAULT_BOLD); }
            f.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
        }
    }

    /** Clima gratis (Open‑Meteo), con la última ubicación conocida; se actualiza cada 30 minutos. */
    private void clima() {
        long antes = prefs.getLong("climaHora", 0);
        if (System.currentTimeMillis() - antes < 30 * 60000) { climaTxt = prefs.getString("clima", ""); pintarBateria(); return; }
        if (checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        new Thread(() -> {
            try {
                android.location.LocationManager lm = getSystemService(android.location.LocationManager.class);
                android.location.Location l = null;
                for (String pr : new String[]{"network", "gps", "passive"}) {
                    try { android.location.Location x = lm.getLastKnownLocation(pr); if (x != null && (l == null || x.getTime() > l.getTime())) l = x; } catch (Exception ignored) {}
                }
                if (l == null) return;
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(String.format(Locale.US,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&current=temperature_2m,weather_code&timezone=auto",
                        l.getLatitude(), l.getLongitude())).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000);
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                try (java.io.InputStream in = c.getInputStream()) { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) bo.write(b, 0, n); }
                org.json.JSONObject cur = new org.json.JSONObject(bo.toString("UTF-8")).getJSONObject("current");
                int t = (int) Math.round(cur.getDouble("temperature_2m")), w = cur.getInt("weather_code");
                String ciudad = "";
                try {
                    List<android.location.Address> ad = new android.location.Geocoder(this, es).getFromLocation(l.getLatitude(), l.getLongitude(), 1);
                    if (ad != null && !ad.isEmpty() && ad.get(0).getLocality() != null) ciudad = " " + ad.get(0).getLocality();
                } catch (Exception ignored) {}
                String e = w == 0 ? "☀️" : w <= 2 ? "🌤" : w == 3 ? "☁️" : w <= 48 ? "🌫" : w <= 67 ? "🌧" : w <= 77 ? "🌨" : w <= 82 ? "🌦" : "⛈";
                String txt = e + " " + t + "°" + ciudad;
                prefs.edit().putString("clima", txt).putLong("climaHora", System.currentTimeMillis()).apply();
                runOnUiThread(() -> { climaTxt = txt; pintarBateria(); });
            } catch (Exception ignored) {}
        }).start();
    }

    // ---------------- Buscador ----------------

    private static final int VOZ = 501;

    private void dictarBusqueda() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO").putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        try { startActivityForResult(i, VOZ); } catch (Exception e) { abrirBusqueda(""); }
    }

    @Override
    protected void onActivityResult(int r, int res, Intent d) {
        super.onActivityResult(r, res, d);
        if (r == VOZ && res == RESULT_OK && d != null) {
            ArrayList<String> rs = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (rs != null && !rs.isEmpty()) abrirBusqueda(rs.get(0));
        } else if (r == 502 && res == RESULT_OK && d != null && d.getData() != null) {
            try {
                android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(getContentResolver(), d.getData());
                Bitmap bm = android.graphics.ImageDecoder.decodeBitmap(src, (dec, info, s2) -> {
                    int w = info.getSize().getWidth(), hh = info.getSize().getHeight(), lado = Math.max(w, hh);
                    if (lado > 2000) dec.setTargetSize(w * 2000 / lado, hh * 2000 / lado);
                    dec.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                });
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "fondo.jpg"))) {
                    bm.compress(Bitmap.CompressFormat.JPEG, 88, o);
                }
                prefs.edit().putBoolean("fondoFoto", true).apply();
                fondo.cargarFoto();
                fondo.invalidate();
            } catch (Exception e) { aviso("No se pudo poner esa foto"); }
        }
    }

    private void abrirBusqueda(String inicial) {
        cerrarCapas();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(0xF00B1020);
        int idEstado = getResources().getIdentifier("status_bar_height", "dimen", "android");
        l.setPadding(dp(12), (idEstado > 0 ? getResources().getDimensionPixelSize(idEstado) : 0) + dp(10), dp(12), dp(10));
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setBackground(vidrio(24));
        f.setPadding(dp(14), 0, dp(6), 0);
        EditText e = new EditText(this);
        e.setHint("Buscar…");
        e.setHintTextColor(0x99FFFFFF);
        e.setTextColor(Color.WHITE);
        e.setTextSize(18);
        e.setBackground(null);
        e.setSingleLine(true);
        e.setText(inicial);
        f.addView(e, new LinearLayout.LayoutParams(0, dp(50), 1f));
        TextView x = texto("✕", 20, Color.WHITE, false);
        x.setPadding(dp(10), dp(6), dp(10), dp(6));
        x.setOnClickListener(v -> cerrarCapas());
        f.addView(x);
        l.addView(f);
        LinearLayout res = new LinearLayout(this);
        res.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(res);
        l.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        Runnable buscar = () -> {
            res.removeAllViews();
            String q = SaludosActivity.sinTildes(e.getText().toString().trim());
            List<Item> todos = new ArrayList<>(herramientas);
            todos.addAll(apps);
            int n = 0;
            for (Item it : todos) {
                if (!q.isEmpty() && !SaludosActivity.sinTildes(it.nombre).contains(q)) continue;
                if (q.isEmpty() && prefs.getInt("u_" + it.clave, 0) == 0) continue;
                if (n++ > 40) break;
                LinearLayout fila = new LinearLayout(this);
                fila.setGravity(Gravity.CENTER_VERTICAL);
                fila.setPadding(dp(6), dp(6), dp(6), dp(6));
                ImageView iv = new ImageView(this);
                iv.setImageDrawable(it.icono);
                fila.addView(iv, new LinearLayout.LayoutParams(dp(46), dp(46)));
                TextView t = texto(it.nombre, 17, Color.WHITE, false);
                t.setPadding(dp(14), 0, 0, 0);
                fila.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                fila.addView(texto("➜", 18, 0x99FFFFFF, false));
                fila.setOnClickListener(v -> usar(it));
                fila.setOnLongClickListener(v -> { opciones(it); return true; });
                res.addView(fila);
            }
            String crudo = e.getText().toString().trim();
            if (!crudo.isEmpty()) {
                String[][] web = {{"🌐  Buscar en internet: ", "https://www.google.com/search?q="}, {"🗺  Buscar en Maps: ", "geo:0,0?q="},
                        {"▶  Buscar en YouTube: ", "https://www.youtube.com/results?search_query="}};
                for (String[] w : web) {
                    TextView t = texto(w[0] + crudo, 16, 0xFFBBDEFB, false);
                    t.setPadding(dp(10), dp(14), dp(10), dp(14));
                    t.setOnClickListener(v -> { cerrarCapas(); abrirUrl(w[1] + Uri.encode(crudo)); });
                    res.addView(t);
                }
            }
        };
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { buscar.run(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        e.setOnEditorActionListener((v, a, ev) -> {
            String crudo = e.getText().toString().trim();
            if (!crudo.isEmpty()) { cerrarCapas(); abrirUrl("https://www.google.com/search?q=" + Uri.encode(crudo)); }
            return true;
        });
        buscar.run();
        busqueda = l;
        raiz.addView(l, new FrameLayout.LayoutParams(-1, -1));
        e.requestFocus();
        e.setSelection(e.getText().length());
        h.postDelayed(() -> ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(e, InputMethodManager.SHOW_IMPLICIT), 200);
    }

    // ---------------- Deslizar hacia abajo: panel rápido ----------------

    private float yToque, xToque;
    private boolean decidido;

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        if (panel == null && busqueda == null) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: yToque = e.getRawY(); xToque = e.getRawX(); decidido = false; break;
                case MotionEvent.ACTION_MOVE:
                    float dy = e.getRawY() - yToque, dx = e.getRawX() - xToque;
                    if (!decidido && Math.abs(dy) > dp(90) && Math.abs(dy) > 2 * Math.abs(dx)) {
                        decidido = true;
                        MotionEvent c = MotionEvent.obtain(e);
                        c.setAction(MotionEvent.ACTION_CANCEL);
                        super.dispatchTouchEvent(c);
                        c.recycle();
                        if (dy > 0) abrirPanel(); else abrirBusqueda("");
                        return true;
                    }
                    break;
            }
            if (decidido) return true;
        }
        return super.dispatchTouchEvent(e);
    }

    private void accionBarra(String a) {
        // Versión 18: el Inicio vive en otro proceso, así que se pregunta a Android si Mi Barra está activa
        boolean activo = false;
        try {
            String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            activo = s != null && s.contains(getPackageName() + "/");
        } catch (Exception ignored) {}
        if (!activo) {
            aviso("Para esto, active Mi Barra en Accesibilidad (una sola vez)");
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception ignored) {}
            return;
        }
        sendBroadcast(new Intent(BarraService.AVISO_BARRA).setPackage(getPackageName()).putExtra("accion", a));
    }

    private void abrirPanel() {
        cerrarCapas();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(0xF2101628);
        int idEstado = getResources().getIdentifier("status_bar_height", "dimen", "android");
        l.setPadding(dp(14), (idEstado > 0 ? getResources().getDimensionPixelSize(idEstado) : 0) + dp(10), dp(14), dp(14));
        LinearLayout cab = new LinearLayout(this);
        cab.setGravity(Gravity.CENTER_VERTICAL);
        cab.addView(texto("⚡ Panel rápido", 22, Color.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = texto("✕", 22, Color.WHITE, false);
        x.setPadding(dp(12), dp(4), dp(8), dp(4));
        x.setOnClickListener(v -> cerrarCapas());
        cab.addView(x);
        l.addView(cab);
        Object[][] botones = {
                {"📸", "Pantallazo", (Runnable) () -> { cerrarCapas(); accionBarra("pantallazo"); }},
                {"🎥", "Grabar pantalla", (Runnable) () -> startActivity(new Intent(this, GrabarActivity.class))},
                {"📄", "Copiar a Word", (Runnable) () -> { cerrarCapas(); aviso("Abra la app que quiere copiar y use el botón redondo 🔴"); }},
                {"🔦", "Linterna", (Runnable) this::linterna},
                {"🌙", "Luz azul", (Runnable) () -> accionBarra("luz")},
                {"🔄", "Rotar pantalla", (Runnable) this::rotar},
                {"✈", "Modo avión", (Runnable) () -> ajuste(Settings.ACTION_AIRPLANE_MODE_SETTINGS)},
                {"📶", "Wi‑Fi", (Runnable) () -> ajuste(Settings.Panel.ACTION_WIFI)},
                {"📱", "Datos", (Runnable) () -> ajuste(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)},
                {"🔗", "Punto de acceso", (Runnable) this::puntoAcceso},
                {"📳", "Vibrar / sonar", (Runnable) this::vibrar},
                {"🌙", "No molestar", (Runnable) this::noMolestar},
                {"🔒", "Bloquear", (Runnable) () -> { cerrarCapas(); accionBarra("bloquear"); }},
                {"📺", "Transmitir a TV", (Runnable) this::transmitir},
                {"🔳", "Escanear QR", (Runnable) () -> startActivity(new Intent(this, CodigoActivity.class))},
                {"🎮", "Control TV", (Runnable) () -> startActivity(new Intent(this, ControlTvActivity.class))},
        };
        LinearLayout fila = null;
        for (int i = 0; i < botones.length; i++) {
            if (i % 4 == 0) { fila = new LinearLayout(this); l.addView(fila, new LinearLayout.LayoutParams(-1, dp(98))); }
            Object[] b = botones[i];
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView r = texto((String) b[0], 26, Color.WHITE, false);
            r.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(("Linterna".equals(b[1]) && linterna) ? 0xFF1E88E5 : 0x33FFFFFF);
            r.setBackground(g);
            c.addView(r, new LinearLayout.LayoutParams(dp(62), dp(62)));
            TextView t = texto((String) b[1], 12, Color.WHITE, false);
            t.setGravity(Gravity.CENTER);
            t.setMaxLines(2);
            c.addView(t, new LinearLayout.LayoutParams(-1, -2));
            Runnable acc = (Runnable) b[2];
            c.setOnClickListener(v -> acc.run());
            fila.addView(c, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        // Brillo y volumen
        l.addView(barra("☀ Brillo", brilloActual(), 255, v -> brillo(v)));
        android.media.AudioManager am = getSystemService(android.media.AudioManager.class);
        int max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
        l.addView(barra("🔊 Volumen", am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC), max,
                v -> am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0)));
        TextView ay = texto("⬆ Deslice hacia arriba o toque ✕ para cerrar", 12, 0x99FFFFFF, false);
        ay.setGravity(Gravity.CENTER);
        ay.setPadding(0, dp(12), 0, 0);
        l.addView(ay);
        final float[] y0 = new float[1];
        l.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) y0[0] = e.getRawY();
            if (e.getActionMasked() == MotionEvent.ACTION_UP && y0[0] - e.getRawY() > dp(80)) cerrarCapas();
            return true;
        });
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        sv.setBackgroundColor(0xF2101628);
        panel = sv;
        raiz.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        sv.setTranslationY(-raiz.getHeight());
        sv.animate().translationY(0).setDuration(220).start();
    }

    interface AlCambiar { void cambio(int v); }

    private View barra(String nombre, int valor, int max, AlCambiar a) {
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(14), 0, dp(8), 0);
        f.setBackground(vidrio(26));
        f.addView(texto(nombre, 15, Color.WHITE, false), new LinearLayout.LayoutParams(dp(110), -2));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(valor);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { if (u) a.cambio(v); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        f.addView(sb, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        f.setLayoutParams(lp);
        return f;
    }

    private void ajuste(String accion) {
        try { startActivity(new Intent(accion)); } catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
    }

    private boolean puedeEscribirAjustes() {
        if (Settings.System.canWrite(this)) return true;
        aviso("Permita a Mi Barra «Modificar la configuración del sistema» y vuelva a tocar");
        try { startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
        return false;
    }

    private void rotar() {
        if (!puedeEscribirAjustes()) return;
        int v = Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);
        Settings.System.putInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, v == 1 ? 0 : 1);
        aviso(v == 1 ? "🔒 Pantalla fija (no gira)" : "🔄 La pantalla gira sola");
    }

    private int brilloActual() {
        try { return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS); } catch (Exception e) { return 128; }
    }

    private boolean pidioBrillo;

    private void brillo(int v) {
        if (!Settings.System.canWrite(this)) { if (!pidioBrillo) { pidioBrillo = true; puedeEscribirAjustes(); } return; }
        Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
        Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, Math.max(5, v));
    }

    private void linterna() {
        try {
            android.hardware.camera2.CameraManager cm = getSystemService(android.hardware.camera2.CameraManager.class);
            for (String id : cm.getCameraIdList()) {
                Boolean fl = cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(fl)) { linterna = !linterna; cm.setTorchMode(id, linterna); break; }
            }
            if (panel != null) abrirPanel();
        } catch (Exception e) { aviso("La linterna está ocupada"); }
    }

    private void puntoAcceso() {
        try { startActivity(new Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")); }
        catch (Exception e) { ajuste(Settings.ACTION_WIRELESS_SETTINGS); }
    }

    private void vibrar() {
        android.media.AudioManager am = getSystemService(android.media.AudioManager.class);
        try {
            boolean vib = am.getRingerMode() == android.media.AudioManager.RINGER_MODE_VIBRATE;
            am.setRingerMode(vib ? android.media.AudioManager.RINGER_MODE_NORMAL : android.media.AudioManager.RINGER_MODE_VIBRATE);
            aviso(vib ? "🔔 Con sonido" : "📳 Solo vibra");
        } catch (Exception e) { pedirNoMolestar(); }
    }

    private void pedirNoMolestar() {
        aviso("Permita a Mi Barra el acceso a «No molestar» y vuelva a tocar");
        try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); } catch (Exception ignored) {}
    }

    private void noMolestar() {
        android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
        if (!nm.isNotificationPolicyAccessGranted()) { pedirNoMolestar(); return; }
        boolean activo = nm.getCurrentInterruptionFilter() != android.app.NotificationManager.INTERRUPTION_FILTER_ALL;
        nm.setInterruptionFilter(activo ? android.app.NotificationManager.INTERRUPTION_FILTER_ALL : android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        aviso(activo ? "🔔 No molestar: apagado" : "🌙 No molestar: prendido (las alarmas sí suenan)");
    }

    private void transmitir() {
        for (String a : new String[]{"android.settings.CAST_SETTINGS", "android.settings.WIFI_DISPLAY_SETTINGS"}) {
            try { startActivity(new Intent(a)); return; } catch (Exception ignored) {}
        }
        try { startActivity(new Intent().setClassName("com.milink.service", "com.xiaomi.mirror.settings.MirrorSettingsActivity")); return; } catch (Exception ignored) {}
        aviso("En Xiaomi: baje la cortina y use «Transmitir» o «Proyectar»");
    }

    // ---------------- Ajustes del Launcher ----------------

    private void ajustes() {
        List<String> ops = new ArrayList<>(Arrays.asList(
                "🏠 Poner Mi Barra como pantalla principal",
                "↩ Volver a poner lo que quité de la pantalla",
                "🖼 Fondo: " + (prefs.getBoolean("fondoFoto", false) ? "mi foto (toque para volver al de Mi Barra)" : "Mi Barra (toque para usar una foto mía)"),
                prefs.getBoolean("botonAyuda", true) ? "🔴 Ocultar el botón redondo de ayudas" : "🔴 Mostrar el botón redondo de ayudas",
                "⌨ Teclado Mi Barra",
                "♿ Activar Mi Barra en Accesibilidad (pantallazo, Word, grabar)",
                (new java.io.File(getFilesDir(), "reloj_bloqueo_no").exists() ? "🌙 Prender" : "🌙 Apagar") + " el reloj en la pantalla de bloqueo"));
        new AlertDialog.Builder(this).setTitle("⚙ Ajustes de Inicio").setItems(ops.toArray(new String[0]), (d, w) -> {
            switch (w) {
                case 0: ajuste(Settings.ACTION_HOME_SETTINGS); aviso("Escoja «Mi Barra Inicio»"); break;
                case 1: restaurar(); break;
                case 2:
                    if (prefs.getBoolean("fondoFoto", false)) { prefs.edit().putBoolean("fondoFoto", false).apply(); fondo.foto = null; fondo.invalidate(); }
                    else try { startActivityForResult(Intent.createChooser(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), "Escoja la foto de fondo"), 502); } catch (Exception ignored) {}
                    break;
                case 3: {
                    boolean v = !prefs.getBoolean("botonAyuda", true);
                    prefs.edit().putBoolean("botonAyuda", v).apply();
                    sendBroadcast(new Intent(BarraService.AVISO_BARRA).setPackage(getPackageName()).putExtra("boton", v));
                    break;
                }
                case 4: startActivity(new Intent(this, TecladoAjustesActivity.class)); break;
                case 6: {
                    java.io.File f = new java.io.File(getFilesDir(), "reloj_bloqueo_no");
                    try { if (f.exists()) { f.delete(); aviso("🌙 El reloj saldrá en la pantalla de bloqueo"); } else { f.createNewFile(); aviso("🌙 Listo: ya no sale en la pantalla de bloqueo"); } } catch (Exception ignored) {}
                    break;
                }
                default: ajuste(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            }
        }).show();
    }

    private void restaurar() {
        Set<String> q = quitadas();
        if (q.isEmpty()) { aviso("No hay nada quitado"); return; }
        List<String> claves = new ArrayList<>(q);
        String[] n = new String[claves.size()];
        boolean[] marca = new boolean[claves.size()];
        for (int i = 0; i < n.length; i++) n[i] = porClave.containsKey(claves.get(i)) ? porClave.get(claves.get(i)).nombre : claves.get(i);
        new AlertDialog.Builder(this).setTitle("¿Cuáles vuelvo a poner?").setMultiChoiceItems(n, marca, (d, w, s) -> marca[w] = s)
                .setPositiveButton("Poner", (d, w) -> {
                    for (int i = 0; i < n.length; i++) if (marca[i]) q.remove(claves.get(i));
                    prefs.edit().putStringSet("quitadas", q).apply();
                    armar();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- El fondo: azul profundo con ondas de luz (o una foto suya) ----------------

    final class Fondo extends View {
        Bitmap foto;
        private final Random r = new Random(7);
        Fondo(Context c) {
            super(c);
            if (prefs.getBoolean("fondoFoto", false)) cargarFoto();
        }
        void cargarFoto() {
            try {
                java.io.File f = new java.io.File(getFilesDir(), "fondo.jpg");
                if (f.exists()) foto = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
            } catch (Throwable ignored) {}
        }
        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), hh = getHeight();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (foto != null) {
                float esc = Math.max((float) w / foto.getWidth(), (float) hh / foto.getHeight());
                float fw = foto.getWidth() * esc, fh = foto.getHeight() * esc;
                c.drawBitmap(foto, null, new android.graphics.RectF((w - fw) / 2, (hh - fh) / 2, (w + fw) / 2, (hh + fh) / 2), new Paint(Paint.FILTER_BITMAP_FLAG));
                c.drawColor(0x55000000);
                return;
            }
            p.setShader(new LinearGradient(0, 0, w * 0.3f, hh, new int[]{0xFF141B3D, 0xFF0D1230, 0xFF070A1A}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, hh, p);
            p.setShader(new RadialGradient(w * 0.85f, hh * 0.12f, w * 0.9f, 0x664A5FC1, 0x004A5FC1, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, hh, p);
            p.setShader(new RadialGradient(w * 0.1f, hh * 0.85f, w * 0.8f, 0x4426A69A, 0x0026A69A, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, hh, p);
            // Ondas de luz, como seda
            int[][] col = {{0x553F51B5, 0x0000BCD4}, {0x44FFB74D, 0x00FF7043}, {0x335C6BC0, 0x00AB47BC}};
            for (int k = 0; k < 3; k++) {
                Path o = new Path();
                float base = hh * (0.45f + k * 0.12f);
                o.moveTo(0, base);
                o.cubicTo(w * 0.3f, base - hh * (0.18f - k * 0.04f), w * 0.6f, base + hh * 0.16f, w, base - hh * 0.06f);
                o.lineTo(w, base + hh * 0.05f);
                o.cubicTo(w * 0.6f, base + hh * 0.22f, w * 0.3f, base - hh * 0.08f, 0, base + hh * 0.08f);
                o.close();
                p.setShader(new LinearGradient(0, base - hh * 0.2f, w, base + hh * 0.2f, col[k][0], col[k][1], Shader.TileMode.CLAMP));
                c.drawPath(o, p);
            }
            p.setShader(null);
            p.setColor(Color.WHITE);
            for (int i = 0; i < 70; i++) {
                p.setAlpha(40 + r.nextInt(120));
                c.drawCircle(r.nextFloat() * w, r.nextFloat() * hh * 0.6f, dp(0.6f + r.nextFloat() * 1.2f), p);
            }
            r.setSeed(7);
        }
    }

}
