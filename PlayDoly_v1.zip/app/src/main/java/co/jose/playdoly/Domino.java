package co.jose.playdoly;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 🁫 Dominó de doble seis, usted contra el celular, a 100 puntos. Si no lleva, roba del pozo; si no hay, pasa. */
final class Domino {
    private final JuegosActivity a;
    private final List<int[]> mano = new ArrayList<>(), celu = new ArrayList<>(), pozo = new ArrayList<>(), mesa = new ArrayList<>();
    private int puntosYo, puntosCelu, pases;
    private boolean miTurno, fin;
    private TextView tMsg, tPuntas, tMarcador;
    private LinearLayout fMesa, fMano, fCelu;
    private HorizontalScrollView sMesa;
    private Button bRobar;

    Domino(JuegosActivity a) { this.a = a; }

    void nuevaPartida() {
        puntosYo = 0;
        puntosCelu = 0;
        nuevaMano(true);
    }

    private int izq() { return mesa.isEmpty() ? -1 : mesa.get(0)[0]; }
    private int der() { return mesa.isEmpty() ? -1 : mesa.get(mesa.size() - 1)[1]; }
    private static int suma(List<int[]> l) { int s = 0; for (int[] f : l) s += f[0] + f[1]; return s; }
    private boolean pega(int[] f) { return mesa.isEmpty() || f[0] == izq() || f[1] == izq() || f[0] == der() || f[1] == der(); }

    private void nuevaMano(boolean primera) {
        mano.clear(); celu.clear(); pozo.clear(); mesa.clear();
        pases = 0;
        fin = false;
        for (int i = 0; i <= 6; i++) for (int j = i; j <= 6; j++) pozo.add(new int[]{i, j});
        Collections.shuffle(pozo, a.azar());
        for (int i = 0; i < 7; i++) { mano.add(pozo.remove(0)); celu.add(pozo.remove(0)); }
        ordenar();
        // Empieza el que tenga el doble más alto
        int mio = mejorDoble(mano), suyo = mejorDoble(celu);
        miTurno = mio >= suyo;
        Musica.tocar(a, R.raw.musica_domino);
        pantalla();
        if (!miTurno) { msg("🤖 El celular tiene el doble más alto: empieza él"); a.manejador().postDelayed(this::juegaCelu, 1300); }
        else msg("🟢 Empieza usted: toque una ficha");
    }

    private static int mejorDoble(List<int[]> l) { int m = -1; for (int[] f : l) if (f[0] == f[1]) m = Math.max(m, f[0]); return m; }

    private void ordenar() { mano.sort((x, y) -> (x[0] + x[1]) - (y[0] + y[1])); }

    // ---------------- Pantalla ----------------

    private void pantalla() {
        LinearLayout l = a.vertical();
        l.setPadding(a.dp(10), a.dp(10), a.dp(10), a.dp(16));
        tMarcador = a.letra("", 16, Color.WHITE, true);
        tMarcador.setGravity(Gravity.CENTER);
        l.addView(tMarcador);
        fCelu = a.horizontal();
        fCelu.setGravity(Gravity.CENTER);
        l.addView(fCelu, new LinearLayout.LayoutParams(-1, a.dp(60)));

        fMesa = a.horizontal();
        fMesa.setGravity(Gravity.CENTER_VERTICAL);
        fMesa.setPadding(a.dp(16), 0, a.dp(16), 0);
        sMesa = new HorizontalScrollView(a);
        sMesa.addView(fMesa);
        sMesa.setBackground(a.caja(0x22FFFFFF, 22));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, a.dp(170));
        mp.topMargin = a.dp(10);
        l.addView(sMesa, mp);
        tPuntas = a.letra("", 15, 0xFFFFEB3B, true);
        tPuntas.setGravity(Gravity.CENTER);
        tPuntas.setPadding(0, a.dp(6), 0, a.dp(6));
        l.addView(tPuntas);
        tMsg = a.letra("", 17, Color.WHITE, true);
        tMsg.setGravity(Gravity.CENTER);
        tMsg.setPadding(0, a.dp(6), 0, a.dp(8));
        l.addView(tMsg);

        fMano = a.horizontal();
        fMano.setGravity(Gravity.CENTER);
        HorizontalScrollView sm = new HorizontalScrollView(a);
        sm.addView(fMano);
        l.addView(sm, new LinearLayout.LayoutParams(-1, a.dp(96)));

        LinearLayout bs = a.horizontal();
        bRobar = a.boton("🀫 Robar del pozo", 0xFFEF6C00);
        bRobar.setOnClickListener(v -> robarOPasar());
        Button nueva = a.boton("↺ Nueva partida", 0xFF455A64);
        nueva.setOnClickListener(v -> nuevaPartida());
        bs.addView(bRobar, a.peso(1.3f));
        bs.addView(nueva, a.peso(1));
        l.addView(bs, a.ancho(58));
        TextView ay = a.letra("Gana la mano el que pegue todas, o el de menos puntos si se tranca. Se suma lo que le queda al otro. A 100 puntos.", 12, 0xFFC8E6C9, false);
        ay.setGravity(Gravity.CENTER);
        ay.setPadding(a.dp(8), a.dp(8), a.dp(8), 0);
        l.addView(ay);
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF1B5E20, 0xFF0D3B12}));
        sv.addView(l);
        a.setContentView(sv);
        pintar();
    }

    private void msg(String s) { if (tMsg != null) tMsg.setText(s); }

    private void pintar() {
        tMarcador.setText("😊 Usted: " + puntosYo + "   ·   🤖 Celular: " + puntosCelu + "   (a 100)");
        fCelu.removeAllViews();
        for (int i = 0; i < celu.size(); i++) fCelu.addView(new Ficha(a, 0, 0, true, false), new LinearLayout.LayoutParams(a.dp(26), a.dp(50)) {{ setMargins(a.dp(2), 0, a.dp(2), 0); }});
        fMesa.removeAllViews();
        for (int[] f : mesa) {
            boolean doble = f[0] == f[1];
            fMesa.addView(new Ficha(a, f[0], f[1], false, !doble),
                    new LinearLayout.LayoutParams(a.dp(doble ? 34 : 68), a.dp(doble ? 68 : 34)) {{ setMargins(a.dp(1), 0, a.dp(1), 0); }});
        }
        sMesa.post(() -> sMesa.smoothScrollTo(Math.max(0, fMesa.getWidth() / 2 - sMesa.getWidth() / 2), 0));
        tPuntas.setText(mesa.isEmpty() ? "La mesa está vacía · Pozo: " + pozo.size()
                : "Puntas: " + izq() + " y " + der() + "   ·   Pozo: " + pozo.size());
        fMano.removeAllViews();
        for (int[] f : mano) {
            Ficha v = new Ficha(a, f[0], f[1], false, false);
            boolean puede = miTurno && !fin && pega(f);
            v.setAlpha(puede || !miTurno ? 1f : 0.45f);
            v.setOnClickListener(x -> jugarYo(f));
            fMano.addView(v, new LinearLayout.LayoutParams(a.dp(42), a.dp(84)) {{ setMargins(a.dp(3), 0, a.dp(3), 0); }});
        }
        boolean llevo = false;
        for (int[] f : mano) if (pega(f)) llevo = true;
        bRobar.setText(pozo.isEmpty() ? "🙅 Paso" : "🀫 Robar del pozo");
        bRobar.setEnabled(miTurno && !fin && !llevo);
        bRobar.setAlpha(miTurno && !fin && !llevo ? 1f : 0.4f);
    }

    // ---------------- Jugar ----------------

    private void poner(int[] f, boolean alaIzq) {
        if (mesa.isEmpty()) { mesa.add(new int[]{f[0], f[1]}); return; }
        if (alaIzq) {
            int i = izq();
            mesa.add(0, f[1] == i ? new int[]{f[0], f[1]} : new int[]{f[1], f[0]});
        } else {
            int d = der();
            mesa.add(f[0] == d ? new int[]{f[0], f[1]} : new int[]{f[1], f[0]});
        }
    }

    private void jugarYo(int[] f) {
        if (!miTurno || fin) return;
        if (!pega(f)) { msg("Esa no pega. Busque un " + izq() + " o un " + der()); return; }
        boolean vaIzq = !mesa.isEmpty() && (f[0] == izq() || f[1] == izq());
        boolean vaDer = !mesa.isEmpty() && (f[0] == der() || f[1] == der());
        if (vaIzq && vaDer && izq() != der()) {
            new AlertDialog.Builder(a).setTitle("¿Dónde la pone?")
                    .setItems(new String[]{"◀ En la punta del " + izq(), "▶ En la punta del " + der()}, (d, w) -> terminarJugadaYo(f, w == 0)).show();
            return;
        }
        terminarJugadaYo(f, vaIzq && !vaDer);
    }

    private void terminarJugadaYo(int[] f, boolean izqd) {
        mano.remove(f);
        poner(f, izqd);
        pases = 0;
        if (mano.isEmpty()) { finMano(true, false); return; }
        miTurno = false;
        msg("🤖 Juega el celular…");
        pintar();
        a.manejador().postDelayed(this::juegaCelu, 1100);
    }

    private void robarOPasar() {
        if (!miTurno || fin) return;
        if (!pozo.isEmpty()) {
            int[] f = pozo.remove(0);
            mano.add(f);
            ordenar();
            msg(pega(f) ? "Robó el " + f[0] + "|" + f[1] + ": ¡esa sí pega!" : "Robó el " + f[0] + "|" + f[1] + "… siga robando");
            pintar();
            return;
        }
        pases++;
        msg("🙅 Usted pasó");
        if (pases >= 2) { finMano(false, true); return; }
        miTurno = false;
        pintar();
        a.manejador().postDelayed(this::juegaCelu, 1100);
    }

    /** El celular: pega la ficha más pesada que pueda (prefiere los dobles); si no, roba o pasa. */
    private void juegaCelu() {
        if (fin) return;
        int[] mejor = null;
        while (true) {
            for (int[] f : celu) {
                if (!pega(f)) continue;
                int v = f[0] + f[1] + (f[0] == f[1] ? 4 : 0);
                if (mejor == null || v > mejor[0] + mejor[1] + (mejor[0] == mejor[1] ? 4 : 0)) mejor = f;
            }
            if (mejor != null || pozo.isEmpty()) break;
            celu.add(pozo.remove(0));
        }
        if (mejor == null) {
            pases++;
            msg("🤖 El celular pasó. ¡Su turno!");
            if (pases >= 2) { finMano(false, true); return; }
        } else {
            celu.remove(mejor);
            boolean izqd = !mesa.isEmpty() && (mejor[0] == izq() || mejor[1] == izq());
            // si pega en las dos, la pone donde le deje la punta más difícil a usted
            if (izqd && (mejor[0] == der() || mejor[1] == der()) && a.azar().nextBoolean()) izqd = false;
            poner(mejor, izqd);
            pases = 0;
            msg("🤖 El celular puso el " + mejor[0] + "|" + mejor[1] + ". ¡Su turno!");
            if (celu.isEmpty()) { finMano(false, false); return; }
        }
        miTurno = true;
        pintar();
    }

    private void finMano(boolean ganeYo, boolean tranque) {
        fin = true;
        int mios = suma(mano), suyos = suma(celu);
        String porque;
        if (tranque) {
            ganeYo = mios < suyos || (mios == suyos && a.azar().nextBoolean());
            porque = "🔒 ¡Se trancó! Usted tiene " + mios + " y el celular " + suyos + ".";
        } else porque = ganeYo ? "🎉 ¡Pegó todas sus fichas!" : "🤖 El celular pegó todas sus fichas.";
        int gana = tranque ? mios + suyos : (ganeYo ? suyos : mios);
        if (ganeYo) puntosYo += gana; else puntosCelu += gana;
        pintar();
        String texto = porque + "\n" + (ganeYo ? "Usted" : "El celular") + " se lleva " + gana + " puntos.\n\nUsted: " + puntosYo + "  ·  Celular: " + puntosCelu;
        if (puntosYo >= 100 || puntosCelu >= 100) {
            a.resultado("dom", puntosYo >= 100, "Marcador final: usted " + puntosYo + " · celular " + puntosCelu);
            return;
        }
        a.tono(ganeYo);
        new AlertDialog.Builder(a).setTitle(ganeYo ? "🎉 ¡Mano para usted!" : "😊 Mano para el celular").setMessage(texto)
                .setPositiveButton("▶ Siguiente mano", (d, w) -> nuevaMano(false)).setCancelable(false).show();
    }

    // ---------------- La ficha dibujada ----------------

    static final class Ficha extends View {
        private final int x, y;
        private final boolean tapada, acostada;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Ficha(Context c, int x, int y, boolean tapada, boolean acostada) {
            super(c); this.x = x; this.y = y; this.tapada = tapada; this.acostada = acostada;
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = Math.min(w, h) * 0.16f, b = Math.min(w, h) * 0.05f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x55000000);
            c.drawRoundRect(new RectF(b, b * 2, w, h), r, r, p);
            p.setColor(tapada ? 0xFFC8E6C9 : 0xFFFFFDF5);
            c.drawRoundRect(new RectF(0, 0, w - b, h - b * 2), r, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(b);
            p.setColor(0xFF263238);
            c.drawRoundRect(new RectF(b / 2, b / 2, w - b * 1.5f, h - b * 2.5f), r, r, p);
            if (tapada) return;
            float W = w - b, H = h - b * 2;
            if (acostada) {
                c.drawLine(W / 2, H * 0.15f, W / 2, H * 0.85f, p);
                puntos(c, x, 0, 0, W / 2, H);
                puntos(c, y, W / 2, 0, W / 2, H);
            } else {
                c.drawLine(W * 0.15f, H / 2, W * 0.85f, H / 2, p);
                puntos(c, x, 0, 0, W, H / 2);
                puntos(c, y, 0, H / 2, W, H / 2);
            }
        }

        private static final float[][][] P = {
                {}, {{.5f, .5f}}, {{.25f, .25f}, {.75f, .75f}}, {{.25f, .25f}, {.5f, .5f}, {.75f, .75f}},
                {{.27f, .27f}, {.73f, .27f}, {.27f, .73f}, {.73f, .73f}},
                {{.27f, .27f}, {.73f, .27f}, {.5f, .5f}, {.27f, .73f}, {.73f, .73f}},
                {{.27f, .22f}, {.73f, .22f}, {.27f, .5f}, {.73f, .5f}, {.27f, .78f}, {.73f, .78f}}};

        private void puntos(Canvas c, int n, float x0, float y0, float w, float h) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(n == 6 ? 0xFF1565C0 : n == 5 ? 0xFFC62828 : n == 4 ? 0xFF2E7D32 : 0xFF212121);
            float rad = Math.min(w, h) * 0.1f;
            for (float[] q : P[n]) c.drawCircle(x0 + q[0] * w, y0 + q[1] * h, rad, p);
        }
    }
}
