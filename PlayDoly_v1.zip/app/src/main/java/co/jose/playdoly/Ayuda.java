package co.jose.playdoly;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Ayudas comunes de Play Doly: letras bonitas, botones redondeados, cajas. */
public abstract class Ayuda extends Activity {

    private static Typeface cursiva, normal, negrilla;

    static Typeface cursiva(Context c) { if (cursiva == null) cursiva = letraVar(c, "fonts/dancing.ttf", 700); return cursiva; }
    static Typeface normal(Context c) { if (normal == null) normal = letraVar(c, "fonts/nunito.ttf", 600); return normal; }
    static Typeface negrilla(Context c) { if (negrilla == null) negrilla = letraVar(c, "fonts/nunito.ttf", 850); return negrilla; }

    private static Typeface letraVar(Context c, String f, int peso) {
        try { return new Typeface.Builder(c.getAssets(), f).setFontVariationSettings("'wght' " + peso).build(); }
        catch (Exception e) { return peso > 650 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT; }
    }

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }

    LinearLayout.LayoutParams peso(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    LinearLayout.LayoutParams ancho(int altoDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(altoDp));
        p.topMargin = dp(8);
        return p;
    }

    GradientDrawable caja(int color, float radio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radio));
        return g;
    }

    Button boton(String t, int color) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(negrilla(this));
        b.setTextColor(Color.WHITE);
        b.setBackground(caja(color, 16));
        b.setStateListAnimator(null);
        return b;
    }

    TextView letra(String s, float tam, int color, boolean gruesa) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(tam);
        t.setTextColor(color);
        t.setTypeface(gruesa ? negrilla(this) : normal(this));
        return t;
    }
}
