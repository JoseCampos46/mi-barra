package co.jose.playdoly;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 🎲 Parqués de dos jugadores: usted escoge su color y el celular otro.
 * Se sale de la cárcel con pares (salen todas), los pares dan otro tiro, hay seguros,
 * y si cae donde está una ficha del otro (fuera de seguro) la manda a la cárcel. Gana quien meta las 4.
 */
final class Parques {
    private final JuegosActivity a;

    static final int[] COLOR = {0xFFE53935, 0xFF1E88E5, 0xFF43A047, 0xFFFDD835};
    static final String[] NOMBRE = {"Rojo", "Azul", "Verde", "Amarillo"};
    static final String[] PUNTO = {"🔴", "🔵", "🟢", "🟡"};

    // Recorrido de 52 casillas en una cuadrícula de 15 x 15 (fila, columna)
    static final int[][] RECORRIDO = new int[52][];
    static final int[][][] CASA = new int[4][5][];
    static final int[] SALIDA = {0, 13, 26, 39};
    static final java.util.Set<Integer> SEGUROS = new java.util.HashSet<>(java.util.Arrays.asList(0, 8, 13, 21, 26, 34, 39, 47));
    // Patio (cárcel) de cada color: esquina superior izquierda de su cuadro de 6 x 6
    static final int[][] PATIO = {{0, 0}, {0, 9}, {9, 9}, {9, 0}};

    static {
        int k = 0;
        for (int c = 1; c <= 5; c++) RECORRIDO[k++] = new int[]{6, c};
        for (int r = 5; r >= 0; r--) RECORRIDO[k++] = new int[]{r, 6};
        RECORRIDO[k++] = new int[]{0, 7};
        for (int r = 0; r <= 5; r++) RECORRIDO[k++] = new int[]{r, 8};
        for (int c = 9; c <= 14; c++) RECORRIDO[k++] = new int[]{6, c};
        RECORRIDO[k++] = new int[]{7, 14};
        for (int c = 14; c >= 9; c--) RECORRIDO[k++] = new int[]{8, c};
        for (int r = 9; r <= 14; r++) RECORRIDO[k++] = new int[]{r, 8};
        RECORRIDO[k++] = new int[]{14, 7};
        for (int r = 14; r >= 9; r--) RECORRIDO[k++] = new int[]{r, 6};
        for (int c = 5; c >= 0; c--) RECORRIDO[k++] = new int[]{8, c};
        RECORRIDO[k++] = new int[]{7, 0};
        RECORRIDO[k] = new int[]{6, 0};
        for (int i = 0; i < 5; i++) {
            CASA[0][i] = new int[]{7, 1 + i};
            CASA[1][i] = new int[]{1 + i, 7};
            CASA[2][i] = new int[]{7, 13 - i};
            CASA[3][i] = new int[]{13 - i, 7};
        }
    }

    // Estado: jugador 0 = usted, 1 = celular. Progreso: -1 cárcel, 0..50 recorrido, 51..55 su camino, 56 llegada
    private final int[] color = new int[2];
    private final int[][] fichas = new int[2][4];
    private int d1 = 1, d2 = 1, turno, intentos;
    private boolean tiro, terminado;
    private Tablero tablero;
    private TextView tMsg, tDado1, tDado2, tTurno;
    private Button bTirar;

    Parques(JuegosActivity a) { this.a = a; }

    // ---------------- Escoger color ----------------

    void escogerColor() {
        Musica.tocar(a, R.raw.musica_parques);
        LinearLayout l = a.vertical();
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(a.dp(20), a.dp(30), a.dp(20), a.dp(20));
        TextView t = a.letra("🎲 Parqués", 32, 0xFF333333, true);
        l.addView(t);
        TextView p = a.letra("¿Con qué color quiere jugar?", 20, 0xFF333333, true);
        p.setPadding(0, a.dp(16), 0, a.dp(16));
        l.addView(p);
        for (int fila = 0; fila < 2; fila++) {
            LinearLayout f = a.horizontal();
            for (int k = 0; k < 2; k++) {
                final int c = fila * 2 + k;
                Button b = a.boton("●\n" + NOMBRE[c], COLOR[c]);
                b.setTextSize(22);
                b.setTextColor(c == 3 ? 0xFF333333 : Color.WHITE);
                b.setOnClickListener(v -> escogido(c));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, a.dp(140), 1f);
                lp.setMargins(a.dp(8), a.dp(8), a.dp(8), a.dp(8));
                f.addView(b, lp);
            }
            l.addView(f);
        }
        TextView ay = a.letra("Después el celular escoge el suyo entre los que quedan.", 14, 0xFF666666, false);
        ay.setGravity(Gravity.CENTER);
        ay.setPadding(0, a.dp(14), 0, 0);
        l.addView(ay);
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(0xFFFDF6E3);
        sv.setFillViewport(true);
        sv.addView(l);
        a.setContentView(sv);
    }

    private void escogido(int c) {
        color[0] = c;
        int o;
        do { o = a.azar().nextInt(4); } while (o == c);
        color[1] = o;
        for (int j = 0; j < 2; j++) for (int i = 0; i < 4; i++) fichas[j][i] = -1;
        turno = 0; intentos = 0; tiro = false; terminado = false;
        pantalla();
        msg("Usted: " + PUNTO[color[0]] + " " + NOMBRE[color[0]] + "  ·  El celular escogió " + PUNTO[color[1]] + " " + NOMBRE[color[1]]
                + "\nTire los dados: con pares saca sus fichas de la cárcel");
    }

    // ---------------- Pantalla del juego ----------------

    private void pantalla() {
        LinearLayout l = a.vertical();
        l.setPadding(a.dp(6), a.dp(8), a.dp(6), a.dp(16));
        tTurno = a.letra("", 16, 0xFF333333, true);
        tTurno.setGravity(Gravity.CENTER);
        l.addView(tTurno);
        tablero = new Tablero(a);
        int lado = a.getResources().getDisplayMetrics().widthPixels - a.dp(12);
        l.addView(tablero, new LinearLayout.LayoutParams(lado, lado));
        LinearLayout dados = a.horizontal();
        dados.setGravity(Gravity.CENTER);
        tDado1 = dado();
        tDado2 = dado();
        dados.addView(tDado1, new LinearLayout.LayoutParams(a.dp(72), a.dp(72)) {{ setMargins(a.dp(8), a.dp(8), a.dp(8), 0); }});
        dados.addView(tDado2, new LinearLayout.LayoutParams(a.dp(72), a.dp(72)) {{ setMargins(a.dp(8), a.dp(8), a.dp(8), 0); }});
        l.addView(dados);
        tMsg = a.letra("", 15, 0xFF333333, true);
        tMsg.setGravity(Gravity.CENTER);
        tMsg.setPadding(a.dp(8), a.dp(8), a.dp(8), a.dp(4));
        l.addView(tMsg);
        LinearLayout bs = a.horizontal();
        bTirar = a.boton("🎲 Tirar dados", COLOR[color[0]]);
        bTirar.setTextSize(19);
        bTirar.setTextColor(color[0] == 3 ? 0xFF333333 : Color.WHITE);
        bTirar.setOnClickListener(v -> tirar());
        Button nueva = a.boton("↺ Nueva", 0xFF455A64);
        nueva.setOnClickListener(v -> escogerColor());
        bs.addView(bTirar, a.peso(1.6f));
        bs.addView(nueva, a.peso(1));
        l.addView(bs, a.ancho(60));
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(0xFFFDF6E3);
        sv.addView(l);
        a.setContentView(sv);
        pintar();
    }

    private TextView dado() {
        TextView t = a.letra("⚀", 52, 0xFF222222, false);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(a.dp(14));
        g.setStroke(a.dp(2), 0xFF333333);
        t.setBackground(g);
        t.setIncludeFontPadding(false);
        return t;
    }

    private void msg(String s) { if (tMsg != null) tMsg.setText(s); }

    private void pintar() {
        if (tTurno == null) return;
        tTurno.setText(terminado ? "🏁 Partida terminada" : turno == 0 ? "🟢 Su turno " + PUNTO[color[0]] : "🤖 Turno del celular " + PUNTO[color[1]]);
        boolean puedo = turno == 0 && !tiro && !terminado;
        bTirar.setEnabled(puedo);
        bTirar.setAlpha(puedo ? 1f : 0.45f);
        tablero.invalidate();
    }

    private static final String CARAS = "⚀⚁⚂⚃⚄⚅";

    private void tirar() {
        if (turno != 0 || tiro || terminado) return;
        animarDados(() -> despuesDeTirar(0));
    }

    private void animarDados(Runnable fin) {
        tiro = true;
        pintar();
        final int[] n = {0};
        a.manejador().post(new Runnable() {
            @Override public void run() {
                d1 = 1 + a.azar().nextInt(6);
                d2 = 1 + a.azar().nextInt(6);
                tDado1.setText(String.valueOf(CARAS.charAt(d1 - 1)));
                tDado2.setText(String.valueOf(CARAS.charAt(d2 - 1)));
                if (++n[0] < 9) { a.manejador().postDelayed(this, 70); return; }
                fin.run();
            }
        });
    }

    private boolean pares() { return d1 == d2; }
    private int enCarcel(int j) { int n = 0; for (int p : fichas[j]) if (p < 0) n++; return n; }

    /** ¿A dónde llega esa ficha con lo que sacó? -1 si no puede moverse. */
    private int destino(int j, int i) {
        int p = fichas[j][i];
        if (p < 0 || p >= 56) return -1;
        int q = p + d1 + d2;
        return q > 56 ? -1 : q;
    }

    private boolean algunaSeMueve(int j) { for (int i = 0; i < 4; i++) if (destino(j, i) >= 0) return true; return false; }

    private void despuesDeTirar(int j) {
        String quien = j == 0 ? "Usted sacó" : "🤖 El celular sacó";
        if (pares() && enCarcel(j) > 0) {
            for (int i = 0; i < 4; i++) if (fichas[j][i] < 0) { fichas[j][i] = 0; comer(j, i); }
            intentos = 0;
            msg(quien + " " + d1 + " y " + d2 + ": ¡PARES! Salen sus fichas de la cárcel y vuelve a tirar 🎉");
            otraVez(j);
            return;
        }
        if (!algunaSeMueve(j)) {
            if (enCarcel(j) == 4 || enCarcel(j) + llegadas(j) == 4) {
                intentos++;
                if (intentos < 3) {
                    msg(quien + " " + d1 + " y " + d2 + ". Necesita pares para salir: le quedan " + (3 - intentos) + " intentos");
                    otraVez(j);
                    return;
                }
            }
            intentos = 0;
            msg(quien + " " + d1 + " y " + d2 + " y no tiene jugada. Pasa el turno.");
            cambiarTurno(j);
            return;
        }
        if (j == 0) {
            msg("Sacó " + d1 + " y " + d2 + " (" + (d1 + d2) + "): toque la ficha que quiere mover");
            tablero.invalidate();
        } else a.manejador().postDelayed(this::mueveCelu, 900);
    }

    private int llegadas(int j) { int n = 0; for (int p : fichas[j]) if (p == 56) n++; return n; }

    private void otraVez(int j) {
        pintar();
        if (j == 0) { tiro = false; pintar(); }
        else a.manejador().postDelayed(() -> animarDados(() -> despuesDeTirar(1)), 1200);
    }

    private void cambiarTurno(int j) {
        turno = 1 - j;
        tiro = false;
        intentos = 0;
        pintar();
        if (turno == 1) a.manejador().postDelayed(() -> animarDados(() -> despuesDeTirar(1)), 1300);
    }

    /** Casilla del recorrido (0..51) donde está una ficha, o -1 si no está en el recorrido. */
    private int casilla(int j, int p) { return p < 0 || p > 50 ? -1 : (SALIDA[color[j]] + p) % 52; }

    /** Si cayó encima de una ficha del otro (y no es seguro), la manda a la cárcel. */
    private boolean comer(int j, int i) {
        int c = casilla(j, fichas[j][i]);
        if (c < 0 || SEGUROS.contains(c)) return false;
        boolean comio = false;
        int o = 1 - j;
        for (int k = 0; k < 4; k++) if (casilla(o, fichas[o][k]) == c) { fichas[o][k] = -1; comio = true; }
        return comio;
    }

    private void mover(int j, int i) {
        int q = destino(j, i);
        if (q < 0) return;
        fichas[j][i] = q;
        boolean comio = comer(j, i);
        String quien = j == 0 ? "Usted" : "🤖 El celular";
        if (llegadas(j) == 4) {
            terminado = true;
            pintar();
            final boolean gane = j == 0;
            a.manejador().postDelayed(() -> a.resultado("par", gane, gane ? "Metió sus 4 fichas antes que el celular" : "El celular metió sus 4 fichas"), 800);
            return;
        }
        String extra = comio ? (j == 0 ? " ¡y mandó una del celular a la cárcel! 😄" : " y mandó una suya a la cárcel 😅") : q == 56 ? " ¡y coronó una ficha! 👑" : "";
        if (pares()) { msg(quien + " movió" + extra + " · Sacó pares: tira otra vez"); otraVez(j); }
        else { msg(quien + " movió" + extra); cambiarTurno(j); }
    }

    /** El celular: prefiere comer, coronar o quedar en seguro; si no, adelanta la que va más atrás. */
    private void mueveCelu() {
        int mejor = -1, puntos = Integer.MIN_VALUE;
        for (int i = 0; i < 4; i++) {
            int q = destino(1, i);
            if (q < 0) continue;
            int v = 0, c = q <= 50 ? (SALIDA[color[1]] + q) % 52 : -1;
            if (c >= 0 && !SEGUROS.contains(c)) for (int k = 0; k < 4; k++) if (casilla(0, fichas[0][k]) == c) v += 100;
            if (q == 56) v += 80;
            if (q > 50) v += 40;
            if (c >= 0 && SEGUROS.contains(c)) v += 25;
            v += 10 - fichas[1][i] / 6 + a.azar().nextInt(6);
            if (v > puntos) { puntos = v; mejor = i; }
        }
        if (mejor >= 0) mover(1, mejor); else cambiarTurno(1);
    }

    private void tocar(int fila, int col) {
        if (turno != 0 || !tiro || terminado) return;
        for (int i = 0; i < 4; i++) {
            int[] rc = celda(0, i);
            if (rc != null && rc[0] == fila && rc[1] == col && destino(0, i) >= 0) { mover(0, i); return; }
        }
        // si tocó una ficha que no se puede mover
        for (int i = 0; i < 4; i++) { int[] rc = celda(0, i); if (rc != null && rc[0] == fila && rc[1] == col) { msg("Esa ficha no alcanza con " + (d1 + d2) + ". Toque otra"); return; } }
    }

    /** Fila y columna donde se dibuja la ficha i del jugador j (en la cárcel: su puesto en el patio). */
    private int[] celda(int j, int i) {
        int p = fichas[j][i], c = color[j];
        if (p < 0) return new int[]{PATIO[c][0] + (i < 2 ? 1 : 4), PATIO[c][1] + (i % 2 == 0 ? 1 : 4)};
        if (p <= 50) return RECORRIDO[(SALIDA[c] + p) % 52];
        if (p <= 55) return CASA[c][p - 51];
        return new int[]{7, 7};
    }

    // ---------------- El tablero ----------------

    final class Tablero extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Tablero(Context c) { super(c); }

        @Override protected void onDraw(Canvas cv) {
            float s = getWidth() / 15f;
            cv.drawColor(0xFFFFFFFF);
            // Patios: los colores escogidos con su casa; los otros, solo de adorno
            for (int c = 0; c < 4; c++) {
                float x = PATIO[c][1] * s, y = PATIO[c][0] * s;
                p.setStyle(Paint.Style.FILL);
                p.setColor(COLOR[c]);
                cv.drawRect(x, y, x + 6 * s, y + 6 * s, p);
                boolean juega = c == color[0] || c == color[1];
                if (juega) {
                    p.setColor(0xFFFFFFFF);
                    cv.drawRoundRect(x + s * 0.6f, y + s * 0.6f, x + s * 5.4f, y + s * 5.4f, s * 0.8f, s * 0.8f, p);
                    p.setColor(COLOR[c] & 0x55FFFFFF);
                    for (int k = 0; k < 4; k++) cv.drawCircle(x + s * (k % 2 == 0 ? 1.5f : 4.5f), y + s * (k < 2 ? 1.5f : 4.5f), s * 0.7f, p);
                } else {
                    p.setColor(0x33FFFFFF);
                    cv.drawCircle(x + 3 * s, y + 3 * s, s * 2f, p);
                }
            }
            // Casillas del recorrido
            for (int k = 0; k < 52; k++) {
                int[] rc = RECORRIDO[k];
                int fondo = 0xFFFFFFFF;
                for (int c = 0; c < 4; c++) if (SALIDA[c] == k) fondo = COLOR[c];
                casillaDibujo(cv, rc, s, fondo, SEGUROS.contains(k));
            }
            for (int c = 0; c < 4; c++) for (int[] rc : CASA[c]) casillaDibujo(cv, rc, s, COLOR[c] & 0x99FFFFFF | 0x66000000 & 0, false);
            // Centro: llegada en cuatro triángulos
            float cx = 7.5f * s, cy = 7.5f * s;
            float[][] esq = {{6, 6}, {9, 6}, {9, 9}, {6, 9}};
            int[] orden = {1, 2, 3, 0}; // arriba azul, derecha verde, abajo amarillo, izquierda rojo
            for (int k = 0; k < 4; k++) {
                Path t = new Path();
                t.moveTo(esq[k][0] * s, esq[k][1] * s);
                t.lineTo(esq[(k + 1) % 4][0] * s, esq[(k + 1) % 4][1] * s);
                t.lineTo(cx, cy);
                t.close();
                p.setColor(COLOR[orden[k]]);
                cv.drawPath(t, p);
            }
            p.setColor(0xFFFFFFFF);
            p.setTextSize(s * 0.55f);
            p.setTextAlign(Paint.Align.CENTER);
            p.setFakeBoldText(true);
            cv.drawText("🏁", cx, cy + s * 0.2f, p);
            // Fichas
            for (int j = 1; j >= 0; j--) {
                java.util.Map<String, Integer> pila = new java.util.HashMap<>();
                for (int i = 0; i < 4; i++) {
                    int[] rc = celda(j, i);
                    String key = rc[0] + "," + rc[1];
                    int n = pila.getOrDefault(key, 0);
                    pila.put(key, n + 1);
                    float fx = rc[1] * s + s / 2 + (n % 2) * s * 0.2f - (fichas[j][i] == 56 ? (j == 0 ? s * 0.6f : -s * 0.6f) : 0);
                    float fy = rc[0] * s + s / 2 - (n / 2) * s * 0.2f + (fichas[j][i] == 56 ? (i - 1.5f) * s * 0.3f : 0);
                    boolean puede = j == 0 && turno == 0 && tiro && !terminado && destino(0, i) >= 0;
                    if (puede) { p.setColor(0xFFFFEB3B); cv.drawCircle(fx, fy, s * 0.52f, p); }
                    p.setColor(0xFF263238);
                    cv.drawCircle(fx, fy + s * 0.05f, s * 0.38f, p);
                    p.setColor(COLOR[color[j]]);
                    cv.drawCircle(fx, fy, s * 0.34f, p);
                    p.setColor(0x88FFFFFF);
                    cv.drawCircle(fx - s * 0.1f, fy - s * 0.1f, s * 0.11f, p);
                }
            }
        }

        private void casillaDibujo(Canvas cv, int[] rc, float s, int fondo, boolean seguro) {
            float x = rc[1] * s, y = rc[0] * s;
            p.setStyle(Paint.Style.FILL);
            p.setColor(fondo);
            cv.drawRect(x, y, x + s, y + s, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1, s * 0.04f));
            p.setColor(0xFF9E9E9E);
            cv.drawRect(x, y, x + s, y + s, p);
            p.setStyle(Paint.Style.FILL);
            if (seguro) {
                p.setColor(0x99FFFFFF & 0xFF757575);
                p.setTextSize(s * 0.6f);
                p.setTextAlign(Paint.Align.CENTER);
                cv.drawText("★", x + s / 2, y + s * 0.72f, p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                float s = getWidth() / 15f;
                tocar((int) (e.getY() / s), (int) (e.getX() / s));
            }
            return true;
        }
    }
}
