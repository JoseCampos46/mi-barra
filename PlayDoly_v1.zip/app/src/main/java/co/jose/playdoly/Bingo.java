package co.jose.playdoly;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * 🅱️ Bingo de 75 balotas: usted juega con 1 a 4 cartones y el celular con 2.
 * El celular canta las balotas en voz alta. Modos: línea, 4 esquinas o cartón lleno.
 */
final class Bingo {
    private final JuegosActivity a;
    private TextToSpeech voz;
    private boolean vozLista;

    static final String LETRAS = "BINGO";
    static final int[] COL = {0xFFE53935, 0xFFFB8C00, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA};
    static final String[] MODOS = {"Línea", "4 esquinas", "Cartón lleno"};

    private int nCartones = 1, modo = 0;
    private int[][][] mios, celu;          // [cartón][fila][columna], 0 = casilla libre del centro
    private boolean[][][] marcaMia;
    private final boolean[] salio = new boolean[76];
    private final List<Integer> bolsa = new ArrayList<>(), cantadas = new ArrayList<>();
    private int verCarton;
    private boolean auto, marcarSolo = true, terminado, celuVaAGanar;
    private TextView tBalota, tUltimas, tCelu, tCarton;
    private Button bAuto, bMarcar;
    private Carton vista;

    private final Runnable cantarSolo = new Runnable() {
        @Override public void run() {
            if (!auto || terminado || celuVaAGanar) return;
            siguiente();
            a.manejador().postDelayed(this, 5000);
        }
    };

    Bingo(JuegosActivity a) {
        this.a = a;
        voz = new TextToSpeech(a.getApplicationContext(), s -> {
            if (s == TextToSpeech.SUCCESS) {
                int r = voz.setLanguage(new Locale("es", "CO"));
                if (r < 0) voz.setLanguage(new Locale("es"));
                voz.setSpeechRate(0.9f);
                vozLista = true;
            }
        });
    }

    private void decir(String s) { if (vozLista) voz.speak(s, TextToSpeech.QUEUE_FLUSH, null, "bingo"); }

    void parar() {
        auto = false;
        a.manejador().removeCallbacks(cantarSolo);
        if (voz != null) voz.stop();
    }

    void cerrar() {
        parar();
        if (voz != null) { voz.shutdown(); voz = null; vozLista = false; }
    }

    // ---------------- Preparar partida ----------------

    void empezar() {
        parar();
        Musica.tocar(a, R.raw.musica_bingo);
        LinearLayout l = a.vertical();
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(20));
        l.addView(a.letra("🅱️ Bingo", 32, 0xFF4A148C, true));
        TextView p = a.letra("¿Con cuántos cartones quiere jugar?", 19, 0xFF333333, true);
        p.setPadding(0, a.dp(16), 0, a.dp(8));
        l.addView(p);
        LinearLayout fc = a.horizontal();
        Button[] bc = new Button[4];
        for (int i = 0; i < 4; i++) {
            final int n = i + 1;
            bc[i] = a.boton(String.valueOf(n), 0xFF9E9E9E);
            bc[i].setTextSize(26);
            bc[i].setOnClickListener(v -> { nCartones = n; for (int k = 0; k < 4; k++) bc[k].setBackground(a.caja(k + 1 == n ? 0xFF6A1B9A : 0xFFBDBDBD, 16)); });
            fc.addView(bc[i], new LinearLayout.LayoutParams(0, a.dp(70), 1f) {{ setMargins(a.dp(5), a.dp(5), a.dp(5), a.dp(5)); }});
        }
        l.addView(fc, new LinearLayout.LayoutParams(-1, -2));
        TextView p2 = a.letra("¿Cómo se gana?", 19, 0xFF333333, true);
        p2.setPadding(0, a.dp(18), 0, a.dp(8));
        l.addView(p2);
        Button[] bm = new Button[3];
        String[] ayuda = {"una fila, columna o diagonal", "las 4 puntas del cartón", "todo el cartón marcado"};
        for (int i = 0; i < 3; i++) {
            final int m = i;
            bm[i] = a.boton(MODOS[i] + "\n" + ayuda[i], 0xFFBDBDBD);
            bm[i].setTextSize(17);
            bm[i].setOnClickListener(v -> { modo = m; for (int k = 0; k < 3; k++) bm[k].setBackground(a.caja(k == m ? 0xFF6A1B9A : 0xFFBDBDBD, 16)); });
            l.addView(bm[i], a.ancho(76));
        }
        for (int k = 0; k < 4; k++) bc[k].setBackground(a.caja(k + 1 == nCartones ? 0xFF6A1B9A : 0xFFBDBDBD, 16));
        for (int k = 0; k < 3; k++) bm[k].setBackground(a.caja(k == modo ? 0xFF6A1B9A : 0xFFBDBDBD, 16));
        TextView t3 = a.letra("El celular juega con 2 cartones y canta las balotas en voz alta.", 14, 0xFF666666, false);
        t3.setGravity(Gravity.CENTER);
        t3.setPadding(0, a.dp(14), 0, 0);
        l.addView(t3);
        Button ir = a.boton("▶ ¡A jugar!", 0xFF2E7D32);
        ir.setTextSize(22);
        ir.setOnClickListener(v -> nueva());
        l.addView(ir, a.ancho(72));
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(0xFFF3E5F5);
        sv.addView(l);
        a.setContentView(sv);
    }

    private int[][] carton() {
        int[][] c = new int[5][5];
        for (int col = 0; col < 5; col++) {
            List<Integer> n = new ArrayList<>();
            for (int k = 1; k <= 15; k++) n.add(col * 15 + k);
            Collections.shuffle(n, a.azar());
            List<Integer> cinco = n.subList(0, 5);
            Collections.sort(cinco);
            for (int f = 0; f < 5; f++) c[f][col] = cinco.get(f);
        }
        c[2][2] = 0;
        return c;
    }

    private void nueva() {
        mios = new int[nCartones][][];
        marcaMia = new boolean[nCartones][5][5];
        for (int i = 0; i < nCartones; i++) { mios[i] = carton(); marcaMia[i][2][2] = true; }
        celu = new int[][][]{carton(), carton()};
        java.util.Arrays.fill(salio, false);
        bolsa.clear();
        cantadas.clear();
        for (int k = 1; k <= 75; k++) bolsa.add(k);
        Collections.shuffle(bolsa, a.azar());
        verCarton = 0;
        terminado = false;
        celuVaAGanar = false;
        auto = false;
        pantalla();
        decir("Empezamos el bingo. ¡Buena suerte!");
    }

    // ---------------- Pantalla del juego ----------------

    private void pantalla() {
        LinearLayout l = a.vertical();
        l.setPadding(a.dp(10), a.dp(10), a.dp(10), a.dp(18));
        TextView modoT = a.letra("Modo: " + MODOS[modo], 15, 0xFF4A148C, true);
        modoT.setGravity(Gravity.CENTER);
        l.addView(modoT);
        tBalota = a.letra("¿Listo?", 44, Color.WHITE, true);
        tBalota.setGravity(Gravity.CENTER);
        tBalota.setBackground(a.caja(0xFF6A1B9A, 60));
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(-1, a.dp(96));
        lb.setMargins(a.dp(30), a.dp(6), a.dp(30), a.dp(4));
        l.addView(tBalota, lb);
        tUltimas = a.letra("", 15, 0xFF555555, false);
        tUltimas.setGravity(Gravity.CENTER);
        l.addView(tUltimas);
        // Cambiar de cartón
        LinearLayout nav = a.horizontal();
        nav.setGravity(Gravity.CENTER_VERTICAL);
        Button ant = a.boton("◀", 0xFF7E57C2);
        ant.setTextSize(22);
        ant.setOnClickListener(v -> { verCarton = (verCarton + nCartones - 1) % nCartones; refrescar(); });
        Button sig = a.boton("▶", 0xFF7E57C2);
        sig.setTextSize(22);
        sig.setOnClickListener(v -> { verCarton = (verCarton + 1) % nCartones; refrescar(); });
        tCarton = a.letra("", 17, 0xFF333333, true);
        tCarton.setGravity(Gravity.CENTER);
        nav.addView(ant, new LinearLayout.LayoutParams(a.dp(60), a.dp(48)));
        nav.addView(tCarton, new LinearLayout.LayoutParams(0, -2, 1f));
        nav.addView(sig, new LinearLayout.LayoutParams(a.dp(60), a.dp(48)));
        if (nCartones == 1) { ant.setVisibility(View.INVISIBLE); sig.setVisibility(View.INVISIBLE); }
        l.addView(nav, new LinearLayout.LayoutParams(-1, -2) {{ topMargin = a.dp(6); }});
        vista = new Carton(a);
        int lado = Math.min(a.getResources().getDisplayMetrics().widthPixels - a.dp(20), a.dp(420));
        LinearLayout.LayoutParams lv = new LinearLayout.LayoutParams(lado, lado * 6 / 5);
        lv.gravity = Gravity.CENTER_HORIZONTAL;
        lv.topMargin = a.dp(6);
        l.addView(vista, lv);
        tCelu = a.letra("", 15, 0xFF333333, true);
        tCelu.setGravity(Gravity.CENTER);
        tCelu.setPadding(0, a.dp(6), 0, a.dp(2));
        l.addView(tCelu);
        Button bs = a.boton("🎱 Siguiente balota", 0xFF6A1B9A);
        bs.setTextSize(20);
        bs.setOnClickListener(v -> { if (!auto) siguiente(); });
        l.addView(bs, a.ancho(64));
        LinearLayout f = a.horizontal();
        bAuto = a.boton("", 0xFF5C6BC0);
        bAuto.setOnClickListener(v -> {
            auto = !auto;
            a.manejador().removeCallbacks(cantarSolo);
            if (auto) a.manejador().post(cantarSolo);
            refrescar();
        });
        bMarcar = a.boton("", 0xFF26A69A);
        bMarcar.setOnClickListener(v -> {
            marcarSolo = !marcarSolo;
            if (marcarSolo) marcarTodo();
            refrescar();
        });
        f.addView(bAuto, a.peso(1));
        f.addView(bMarcar, a.peso(1));
        l.addView(f, a.ancho(64));
        Button bb = a.boton("🎉 ¡BINGO!", 0xFFD81B60);
        bb.setTextSize(24);
        bb.setOnClickListener(v -> reclamar());
        l.addView(bb, a.ancho(70));
        Button sal = a.boton("↺ Cambiar cartones o modo", 0xFF78909C);
        sal.setOnClickListener(v -> empezar());
        l.addView(sal, a.ancho(52));
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(0xFFF3E5F5);
        sv.addView(l);
        a.setContentView(sv);
        refrescar();
    }

    private void refrescar() {
        if (vista == null) return;
        tCarton.setText(nCartones > 1 ? "Cartón " + (verCarton + 1) + " de " + nCartones : "Su cartón");
        bAuto.setText(auto ? "⏸ Cantar solo: SÍ" : "⏵ Cantar solo cada 5 s");
        bAuto.setBackground(a.caja(auto ? 0xFF283593 : 0xFF7986CB, 16));
        bMarcar.setText(marcarSolo ? "✔ Marcar solo: SÍ" : "✋ Marcar solo: NO");
        bMarcar.setBackground(a.caja(marcarSolo ? 0xFF00796B : 0xFF80CBC4, 16));
        int falta = 99;
        for (int[][] c : celu) falta = Math.min(falta, faltan(c, null));
        tCelu.setText("🤖 Al celular le falta" + (falta == 1 ? " 1 número" : "n " + falta + " números") + " · Balotas: " + cantadas.size() + " de 75");
        if (!cantadas.isEmpty()) {
            StringBuilder s = new StringBuilder("Anteriores: ");
            for (int i = cantadas.size() - 2, k = 0; i >= 0 && k < 6; i--, k++) s.append(nombre(cantadas.get(i))).append("  ");
            tUltimas.setText(cantadas.size() > 1 ? s.toString().trim() : "");
        }
        vista.invalidate();
    }

    static String nombre(int n) { return LETRAS.charAt((n - 1) / 15) + "-" + n; }

    private void siguiente() {
        if (terminado || celuVaAGanar) return;
        if (bolsa.isEmpty()) { a.aviso("Ya salieron todas las balotas"); return; }
        int n = bolsa.remove(bolsa.size() - 1);
        salio[n] = true;
        cantadas.add(n);
        char letra = LETRAS.charAt((n - 1) / 15);
        tBalota.setText(letra + "  " + n);
        tBalota.setBackground(a.caja(COL[(n - 1) / 15], 60));
        decir(letra + ". " + n);
        if (marcarSolo) marcarTodo();
        refrescar();
        // ¿El celular completó?
        for (int[][] c : celu) if (faltan(c, null) == 0) {
            celuVaAGanar = true;
            a.manejador().removeCallbacks(cantarSolo);
            // le da unos segundos a usted por si también tiene bingo
            a.manejador().postDelayed(this::celuGana, 4500);
            break;
        }
    }

    private void marcarTodo() {
        for (int i = 0; i < nCartones; i++)
            for (int f = 0; f < 5; f++) for (int c = 0; c < 5; c++) if (mios[i][f][c] > 0 && salio[mios[i][f][c]]) marcaMia[i][f][c] = true;
    }

    /** Cuántos números le faltan a un cartón para ganar en el modo actual (con marcas propias o con lo que ha salido). */
    private int faltan(int[][] c, boolean[][] marca) {
        boolean[][] m = new boolean[5][5];
        for (int f = 0; f < 5; f++) for (int k = 0; k < 5; k++)
            m[f][k] = c[f][k] == 0 || (marca != null ? marca[f][k] && salio[c[f][k]] : salio[c[f][k]]);
        if (modo == 2) { int n = 0; for (boolean[] fila : m) for (boolean b : fila) if (!b) n++; return n; }
        if (modo == 1) { int n = 0; for (int[] e : new int[][]{{0, 0}, {0, 4}, {4, 0}, {4, 4}}) if (!m[e[0]][e[1]]) n++; return n; }
        int mejor = 5;
        for (int i = 0; i < 5; i++) {
            int nf = 0, nc = 0;
            for (int k = 0; k < 5; k++) { if (!m[i][k]) nf++; if (!m[k][i]) nc++; }
            mejor = Math.min(mejor, Math.min(nf, nc));
        }
        int d1 = 0, d2 = 0;
        for (int k = 0; k < 5; k++) { if (!m[k][k]) d1++; if (!m[k][4 - k]) d2++; }
        return Math.min(mejor, Math.min(d1, d2));
    }

    private void reclamar() {
        if (terminado) return;
        for (int i = 0; i < nCartones; i++) if (faltan(mios[i], marcaMia[i]) == 0) {
            terminado = true;
            parar();
            decir("¡Bingo! ¡Felicitaciones, usted ganó!");
            final int n = i + 1;
            a.manejador().postDelayed(() -> a.resultado("bin", true, "Bingo en " + (nCartones > 1 ? "el cartón " + n : "su cartón") + " con " + cantadas.size() + " balotas · " + MODOS[modo]), 1200);
            return;
        }
        int mejor = 99;
        for (int i = 0; i < nCartones; i++) mejor = Math.min(mejor, faltan(mios[i], marcaMia[i]));
        a.aviso("Todavía no 😊 Le falta" + (mejor == 1 ? " 1 número" : "n " + mejor + " números") + (marcarSolo ? "" : " (revise que esté marcado)"));
    }

    private void celuGana() {
        if (terminado) return;
        terminado = true;
        parar();
        decir("¡Bingo! Esta vez gané yo. ¡Juguemos otra!");
        a.manejador().postDelayed(() -> a.resultado("bin", false, "El celular cantó bingo con " + cantadas.size() + " balotas · " + MODOS[modo]), 1800);
    }

    private void tocar(int f, int c) {
        if (terminado || f < 0 || f > 4 || c < 0 || c > 4) return;
        int n = mios[verCarton][f][c];
        if (n == 0) return;
        if (!salio[n]) { a.aviso("El " + n + " todavía no ha salido"); return; }
        marcaMia[verCarton][f][c] = !marcaMia[verCarton][f][c];
        vista.invalidate();
    }

    // ---------------- Dibujo del cartón ----------------

    final class Carton extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Carton(Context c) { super(c); p.setTypeface(Ayuda.negrilla(c)); p.setTextAlign(Paint.Align.CENTER); }

        @Override protected void onDraw(Canvas cv) {
            if (mios == null) return;
            float s = getWidth() / 5f;
            int[][] c = mios[verCarton];
            boolean[][] m = marcaMia[verCarton];
            for (int k = 0; k < 5; k++) {
                p.setColor(COL[k]);
                cv.drawRoundRect(k * s + 3, 3, (k + 1) * s - 3, s - 3, s * 0.2f, s * 0.2f, p);
                p.setColor(Color.WHITE);
                p.setTextSize(s * 0.6f);
                cv.drawText(String.valueOf(LETRAS.charAt(k)), k * s + s / 2, s * 0.72f, p);
            }
            for (int f = 0; f < 5; f++) for (int k = 0; k < 5; k++) {
                float x = k * s, y = (f + 1) * s;
                boolean esquina = modo == 1 && (f == 0 || f == 4) && (k == 0 || k == 4);
                p.setColor(esquina ? 0xFFFFF8E1 : Color.WHITE);
                cv.drawRect(x + 2, y + 2, x + s - 2, y + s - 2, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2);
                p.setColor(0xFFB39DDB);
                cv.drawRect(x + 2, y + 2, x + s - 2, y + s - 2, p);
                p.setStyle(Paint.Style.FILL);
                int n = c[f][k];
                if (n == 0) {
                    p.setColor(0xFFFFD54F);
                    cv.drawCircle(x + s / 2, y + s / 2, s * 0.4f, p);
                    p.setColor(0xFF6A1B9A);
                    p.setTextSize(s * 0.4f);
                    cv.drawText("★", x + s / 2, y + s * 0.64f, p);
                    continue;
                }
                if (m[f][k]) {
                    p.setColor(COL[k] & 0xCCFFFFFF);
                    cv.drawCircle(x + s / 2, y + s / 2, s * 0.42f, p);
                } else if (salio[n]) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(s * 0.06f);
                    p.setColor(0xFFFFB300);
                    cv.drawCircle(x + s / 2, y + s / 2, s * 0.4f, p);
                    p.setStyle(Paint.Style.FILL);
                }
                p.setColor(m[f][k] ? Color.WHITE : 0xFF212121);
                p.setTextSize(s * 0.45f);
                cv.drawText(String.valueOf(n), x + s / 2, y + s * 0.66f, p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                float s = getWidth() / 5f;
                tocar((int) (e.getY() / s) - 1, (int) (e.getX() / s));
            }
            return true;
        }
    }
}
