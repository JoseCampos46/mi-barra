package co.jose.playdoly;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Versión 22: juegos sin internet y sin propaganda. Escalera (usted contra el celular) y Sudoku. */
public class JuegosActivity extends Ayuda {

    private static final int FONDO = 0xFF1B2140;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random azar = new Random();
    private SharedPreferences pr;
    private int enJuego; // 0 menú, 1 escalera, 2 sudoku

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pr = getSharedPreferences("juegos", MODE_PRIVATE);
        menu();
    }

    @Override public void onBackPressed() { if (enJuego != 0) menu(); else super.onBackPressed(); }
    @Override protected void onPause() { super.onPause(); Musica.pausar(); }
    @Override protected void onResume() { super.onResume(); if (Musica.prendida(this)) Musica.seguir(); }
    @Override protected void onDestroy() { h.removeCallbacksAndMessages(null); Musica.parar(); if (bingo != null) bingo.cerrar(); super.onDestroy(); }

    Handler manejador() { return h; }
    Random azar() { return azar; }
    SharedPreferences prefs() { return pr; }

    private Parques parques;
    private Domino domino;
    private Bingo bingo;

    // ================= Menú de Play Doly =================

    void menu() {
        enJuego = 0;
        h.removeCallbacksAndMessages(null);
        if (bingo != null) bingo.parar();
        Musica.tocar(this, R.raw.musica_menu);
        LinearLayout l = vertical();
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(dp(16), dp(26), dp(16), dp(20));
        TextView dado = letra("🎲", 56, Color.WHITE, false);
        dado.setGravity(Gravity.CENTER);
        dado.setBackground(caja(Color.WHITE, 28));
        dado.setElevation(dp(6));
        l.addView(dado, new LinearLayout.LayoutParams(dp(104), dp(104)));
        TextView t = letra("Play Doly", 58, Color.WHITE, false);
        t.setTypeface(cursiva(this));
        t.setShadowLayer(dp(4), 0, dp(2), 0x66000000);
        l.addView(t);
        TextView fr = letra("✨ " + Frases.deHoy(), 16, Color.WHITE, false);
        fr.setGravity(Gravity.CENTER);
        fr.setPadding(dp(16), dp(10), dp(16), dp(10));
        fr.setBackground(caja(0x33FFFFFF, 18));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(4);
        fp.bottomMargin = dp(10);
        l.addView(fr, fp);
        String[][] js = {
                {"🎲", "Parqués", "Escoja su color · contra el celular · ganadas " + pr.getInt("parGanadas", 0), "#E53935"},
                {"🁫", "Dominó", "A 100 puntos · ganadas " + pr.getInt("domGanadas", 0), "#2E7D32"},
                {"🅱️", "Bingo", "1 a 4 cartones · el celular canta · bingos " + pr.getInt("binGanadas", 0), "#6A1B9A"},
                {"🐍🪜", "Escalera", "Dado contra el celular · ganadas " + pr.getInt("escGanadas", 0), "#EF6C00"},
                {"🔢", "Sudoku", "Fácil, medio y difícil · mejor " + tiempo(pr.getLong("sudMejor", 0)), "#1565C0"}};
        for (int i = 0; i < js.length; i++) {
            final int k = i;
            LinearLayout c = horizontal();
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.setPadding(dp(12), dp(10), dp(14), dp(10));
            c.setBackground(caja(Color.WHITE, 18));
            c.setElevation(dp(3));
            TextView e = letra(js[i][0], 30, Color.WHITE, false);
            e.setGravity(Gravity.CENTER);
            e.setBackground(caja(Color.parseColor(js[i][3]), 14));
            c.addView(e, new LinearLayout.LayoutParams(dp(58), dp(58)));
            LinearLayout tx = vertical();
            tx.setPadding(dp(12), 0, 0, 0);
            tx.addView(letra(js[i][1], 20, 0xFF222222, true));
            tx.addView(letra(js[i][2], 13, 0xFF666666, false));
            c.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
            c.addView(letra("›", 26, 0xFFBBBBBB, true));
            c.setOnClickListener(v -> {
                if (k == 0) { if (parques == null) parques = new Parques(this); parques.escogerColor(); }
                else if (k == 1) { if (domino == null) domino = new Domino(this); domino.nuevaPartida(); }
                else if (k == 2) { if (bingo == null) bingo = new Bingo(this); bingo.empezar(); }
                else if (k == 3) escalera();
                else sudokuNivel();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(9);
            l.addView(c, lp);
        }
        // Música: prender/apagar y volumen
        LinearLayout mu = horizontal();
        mu.setGravity(Gravity.CENTER_VERTICAL);
        mu.setPadding(dp(12), dp(6), dp(12), dp(6));
        mu.setBackground(caja(0x33FFFFFF, 18));
        TextView bm = letra(Musica.prendida(this) ? "🔊" : "🔇", 26, Color.WHITE, false);
        bm.setOnClickListener(v -> {
            boolean on = !Musica.prendida(this);
            getSharedPreferences("doly", 0).edit().putBoolean("musica", on).apply();
            bm.setText(on ? "🔊" : "🔇");
            if (on) Musica.tocar(this, R.raw.musica_menu); else Musica.parar();
        });
        mu.addView(bm);
        android.widget.SeekBar vol = new android.widget.SeekBar(this);
        vol.setMax(100);
        vol.setProgress(Math.round(Musica.volumen(this) * 100));
        vol.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(android.widget.SeekBar s, int p, boolean u) { if (u) Musica.ponerVolumen(JuegosActivity.this, p / 100f); }
            public void onStartTrackingTouch(android.widget.SeekBar s) {}
            public void onStopTrackingTouch(android.widget.SeekBar s) {}
        });
        mu.addView(vol, new LinearLayout.LayoutParams(0, -2, 1f));
        mu.addView(letra("Música", 14, Color.WHITE, true));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(12);
        l.addView(mu, mp);
        int g = pr.getInt("totalGanadas", 0), p = pr.getInt("totalPerdidas", 0);
        TextView st = letra("🏆 Ganadas: " + g + "   ·   😊 Jugadas con alegría: " + (g + p), 14, Color.WHITE, true);
        st.setGravity(Gravity.CENTER);
        st.setPadding(0, dp(10), 0, 0);
        l.addView(st);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFFF8A65, 0xFFEC407A, 0xFF7E57C2}));
        sv.setFillViewport(true);
        sv.addView(l);
        setContentView(sv);
    }

    /** Al terminar cualquier partida: fiesta si ganó, ánimo bonito si ganó el celular. */
    void resultado(String clave, boolean gano, String detalle) {
        pr.edit().putInt(clave + "Jugadas", pr.getInt(clave + "Jugadas", 0) + 1)
                .putInt(clave + "Ganadas", pr.getInt(clave + "Ganadas", 0) + (gano ? 1 : 0))
                .putInt(gano ? "totalGanadas" : "totalPerdidas", pr.getInt(gano ? "totalGanadas" : "totalPerdidas", 0) + 1).apply();
        tono(gano);
        TextView t = letra((gano ? Frases.gano() : Frases.perdio()) + (detalle == null ? "" : "\n\n" + detalle), 19, 0xFF333333, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(20), dp(24), dp(20), dp(10));
        TextView fr = letra("✨ " + Frases.deHoy(), 14, 0xFF7E57C2, false);
        fr.setGravity(Gravity.CENTER);
        fr.setPadding(dp(20), dp(6), dp(20), dp(10));
        LinearLayout box = vertical();
        TextView em = letra(gano ? "🎉🎊🏆🎊🎉" : "🌈😊🎶😊🌈", 36, 0xFF000000, false);
        em.setGravity(Gravity.CENTER);
        em.setPadding(0, dp(18), 0, 0);
        box.addView(em);
        box.addView(t);
        box.addView(fr);
        new android.app.AlertDialog.Builder(this).setView(box)
                .setPositiveButton("▶ Otra partida", (d, w) -> otraPartida(clave))
                .setNegativeButton("🏠 Menú", (d, w) -> menu()).setCancelable(false).show();
    }

    private void otraPartida(String clave) {
        switch (clave) {
            case "par": parques.escogerColor(); break;
            case "dom": domino.nuevaPartida(); break;
            case "bin": bingo.empezar(); break;
            case "esc": escalera(); break;
            default: sudokuNivel();
        }
    }

    /** Sonidito alegre al ganar; uno suave y simpático si gana el celular. */
    void tono(boolean gano) {
        try {
            android.media.ToneGenerator tg = new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 60);
            tg.startTone(gano ? android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD : android.media.ToneGenerator.TONE_PROP_ACK, 600);
            h.postDelayed(tg::release, 900);
        } catch (Exception ignored) {}
    }

    void toastAlegre(String s) { aviso(s); }

    private static String tiempo(long s) {
        if (s <= 0) return "—";
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    // ================= Escalera (serpientes y escaleras) =================

    // casilla de abajo → casilla de arriba (escaleras) y de cabeza → cola (serpientes)
    private static final int[][] SUBE = {{4, 25}, {13, 46}, {33, 49}, {42, 63}, {50, 69}, {62, 81}, {74, 92}};
    private static final int[][] BAJA = {{27, 5}, {40, 3}, {43, 18}, {54, 31}, {66, 45}, {76, 58}, {89, 53}, {99, 41}};
    private int yo, celu, dado = 1;
    private boolean miTurno, terminado;
    private Tablero tablero;
    private TextView tMsg, tDado;
    private Button bTirar;

    private void escalera() {
        enJuego = 1;
        Musica.tocar(this, R.raw.musica_escalera);
        yo = 0; celu = 0; miTurno = true; terminado = false;
        LinearLayout l = vertical();
        l.setBackgroundColor(FONDO);
        l.setPadding(dp(10), dp(10), dp(10), dp(10));
        l.addView(letra("🐍🪜 Escalera", 22, Color.WHITE, true));
        tablero = new Tablero(this);
        l.addView(tablero, new LinearLayout.LayoutParams(-1, getResources().getDisplayMetrics().widthPixels - dp(20)));
        tMsg = letra("", 17, Color.WHITE, true);
        tMsg.setGravity(Gravity.CENTER);
        tMsg.setPadding(0, dp(10), 0, dp(6));
        l.addView(tMsg);
        LinearLayout f = horizontal();
        f.setGravity(Gravity.CENTER);
        tDado = letra("⚀", 56, Color.WHITE, false);
        tDado.setGravity(Gravity.CENTER);
        f.addView(tDado, new LinearLayout.LayoutParams(dp(90), dp(90)));
        bTirar = boton("🎲  Tirar el dado", 0xFFE53958);
        bTirar.setTextSize(19);
        bTirar.setOnClickListener(v -> tirar(true));
        f.addView(bTirar, new LinearLayout.LayoutParams(dp(220), dp(64)));
        l.addView(f);
        Button nuevo = boton("↺ Empezar otra vez", 0xFF546E7A);
        nuevo.setOnClickListener(v -> escalera());
        l.addView(nuevo, ancho(48));
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        sv.setBackgroundColor(FONDO);
        setContentView(sv);
        pintarMsg();
    }

    private void pintarMsg() {
        tMsg.setText("🔵 Usted: casilla " + yo + "      🔴 Celular: casilla " + celu);
        bTirar.setEnabled(miTurno && !terminado);
        bTirar.setAlpha(miTurno && !terminado ? 1f : 0.5f);
    }

    private void tirar(boolean soyYo) {
        if (terminado || soyYo != miTurno) return;
        miTurno = false;
        bTirar.setEnabled(false);
        bTirar.setAlpha(0.5f);
        final int[] vueltas = {0};
        h.post(new Runnable() {
            @Override public void run() {
                dado = 1 + azar.nextInt(6);
                tDado.setText(String.valueOf("⚀⚁⚂⚃⚄⚅".charAt(dado - 1)));
                if (++vueltas[0] < 8) { h.postDelayed(this, 70); return; }
                mover(soyYo);
            }
        });
    }

    private void mover(boolean soyYo) {
        int desde = soyYo ? yo : celu, a = desde + dado;
        String quien = soyYo ? "Usted" : "El celular";
        String nota = quien + " sacó " + dado;
        if (a > 100) { a = desde; nota += " · necesita " + (100 - desde) + " exacto"; }
        int fin = a;
        for (int[] s : SUBE) if (s[0] == a) { fin = s[1]; nota += " · 🪜 ¡sube a " + fin + "!"; }
        for (int[] s : BAJA) if (s[0] == a) { fin = s[1]; nota += " · 🐍 baja a " + fin; }
        if (soyYo) yo = fin; else celu = fin;
        tablero.invalidate();
        toast(nota);
        if (fin == 100) {
            terminado = true;
            final boolean gane = soyYo;
            h.postDelayed(() -> resultado("esc", gane, null), 900);
            tMsg.setText(soyYo ? "🏆 ¡GANÓ USTED! 🎉" : "😅 Ganó el celular. ¡Revancha!");
            return;
        }
        boolean seis = dado == 6;
        if (soyYo && seis) { miTurno = true; toast("🎲 Sacó 6: ¡tire otra vez!"); }
        else if (soyYo || seis) { miTurno = false; h.postDelayed(this::tirarCelu, 1200); }
        else miTurno = true;
        pintarMsg();
    }

    private void tirarCelu() {
        miTurno = false;
        final int[] vueltas = {0};
        h.post(new Runnable() {
            @Override public void run() {
                dado = 1 + azar.nextInt(6);
                tDado.setText(String.valueOf("⚀⚁⚂⚃⚄⚅".charAt(dado - 1)));
                if (++vueltas[0] < 8) { h.postDelayed(this, 70); return; }
                mover(false);
            }
        });
    }

    private void toast(String s) { aviso(s); }

    /** El tablero de 100 casillas en zigzag, con escaleras verdes y serpientes rojas. */
    final class Tablero extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Tablero(Context c) { super(c); }

        private float[] centro(int n) {
            float lado = getWidth() / 10f;
            int fila = (n - 1) / 10, col = (n - 1) % 10;
            if (fila % 2 == 1) col = 9 - col;
            return new float[]{col * lado + lado / 2, getHeight() - (fila * lado + lado / 2)};
        }

        @Override protected void onDraw(Canvas c) {
            float lado = getWidth() / 10f;
            p.setTextSize(lado * 0.28f);
            for (int n = 1; n <= 100; n++) {
                float[] k = centro(n);
                p.setStyle(Paint.Style.FILL);
                p.setColor(n == 100 ? 0xFFFFD54F : ((n + (n - 1) / 10) % 2 == 0 ? 0xFFFFF3E0 : 0xFFFFE0B2));
                c.drawRect(k[0] - lado / 2, k[1] - lado / 2, k[0] + lado / 2, k[1] + lado / 2, p);
                p.setColor(0xFF6D4C41);
                c.drawText(n == 100 ? "🏁" : String.valueOf(n), k[0] - lado * 0.44f, k[1] - lado * 0.18f, p);
            }
            // Escaleras
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int[] s : SUBE) {
                float[] a = centro(s[0]), b = centro(s[1]);
                float dx = b[0] - a[0], dy = b[1] - a[1], len = (float) Math.hypot(dx, dy), nx = -dy / len * lado * 0.16f, ny = dx / len * lado * 0.16f;
                p.setColor(0xFF2E7D32);
                p.setStrokeWidth(lado * 0.07f);
                c.drawLine(a[0] + nx, a[1] + ny, b[0] + nx, b[1] + ny, p);
                c.drawLine(a[0] - nx, a[1] - ny, b[0] - nx, b[1] - ny, p);
                int pel = (int) (len / (lado * 0.35f));
                for (int i = 1; i < pel; i++) {
                    float t = i / (float) pel, x = a[0] + dx * t, y = a[1] + dy * t;
                    c.drawLine(x + nx, y + ny, x - nx, y - ny, p);
                }
            }
            // Serpientes
            p.setStyle(Paint.Style.STROKE);
            for (int[] s : BAJA) {
                float[] a = centro(s[0]), b = centro(s[1]);
                Path pa = new Path();
                pa.moveTo(a[0], a[1]);
                float mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
                pa.quadTo(mx + lado * 1.2f, my - lado * 0.6f, mx, my);
                pa.quadTo(mx - lado * 1.2f, my + lado * 0.6f, b[0], b[1]);
                p.setColor(0xFFC62828);
                p.setStrokeWidth(lado * 0.16f);
                c.drawPath(pa, p);
                p.setColor(0xFFFF7043);
                p.setStrokeWidth(lado * 0.07f);
                c.drawPath(pa, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFB71C1C);
                c.drawCircle(a[0], a[1], lado * 0.17f, p);
                p.setColor(Color.WHITE);
                c.drawCircle(a[0] - lado * 0.06f, a[1] - lado * 0.04f, lado * 0.04f, p);
                c.drawCircle(a[0] + lado * 0.06f, a[1] - lado * 0.04f, lado * 0.04f, p);
                p.setStyle(Paint.Style.STROKE);
            }
            // Fichas
            p.setStyle(Paint.Style.FILL);
            for (int k = 0; k < 2; k++) {
                int casilla = k == 0 ? yo : celu;
                float[] q = casilla == 0 ? new float[]{lado * (k == 0 ? 0.3f : 0.7f), getHeight() + lado * 0.0f - lado * 0.25f} : centro(casilla);
                float ox = k == 0 ? -lado * 0.15f : lado * 0.15f;
                p.setColor(Color.WHITE);
                c.drawCircle(q[0] + ox, q[1] + lado * 0.12f, lado * 0.22f, p);
                p.setColor(k == 0 ? 0xFF1E88E5 : 0xFFE53935);
                c.drawCircle(q[0] + ox, q[1] + lado * 0.12f, lado * 0.17f, p);
            }
        }
    }

    // ================= Sudoku =================

    private int[] sol = new int[81], tab = new int[81];
    private boolean[] fijo = new boolean[81];
    private int sel = -1, errores;
    private long inicio;
    private final TextView[] celdas = new TextView[81];
    private TextView tSud;

    private void sudokuNivel() {
        String[] n = {"😊 Fácil", "🙂 Medio", "😬 Difícil"};
        new android.app.AlertDialog.Builder(this).setTitle("🔢 Sudoku: ¿qué tan difícil?").setItems(n, (d, w) -> sudoku(w)).show();
    }

    private boolean llenar(int[] g, int i) {
        if (i == 81) return true;
        if (g[i] != 0) return llenar(g, i + 1);
        List<Integer> nums = new ArrayList<>();
        for (int v = 1; v <= 9; v++) nums.add(v);
        Collections.shuffle(nums, azar);
        for (int v : nums) if (cabe(g, i, v)) { g[i] = v; if (llenar(g, i + 1)) return true; g[i] = 0; }
        return false;
    }

    private static boolean cabe(int[] g, int i, int v) {
        int f = i / 9, c = i % 9, bf = f / 3 * 3, bc = c / 3 * 3;
        for (int k = 0; k < 9; k++) {
            if (g[f * 9 + k] == v || g[k * 9 + c] == v) return false;
            if (g[(bf + k / 3) * 9 + bc + k % 3] == v) return false;
        }
        return true;
    }

    private void sudoku(int nivel) {
        enJuego = 2;
        Musica.tocar(this, R.raw.musica_sudoku);
        sol = new int[81];
        llenar(sol, 0);
        tab = sol.clone();
        int quitar = nivel == 0 ? 36 : nivel == 1 ? 45 : 52;
        List<Integer> pos = new ArrayList<>();
        for (int i = 0; i < 81; i++) pos.add(i);
        Collections.shuffle(pos, azar);
        for (int i = 0; i < quitar; i++) tab[pos.get(i)] = 0;
        for (int i = 0; i < 81; i++) fijo[i] = tab[i] != 0;
        sel = -1;
        errores = 0;
        inicio = System.currentTimeMillis();

        LinearLayout l = vertical();
        l.setBackgroundColor(FONDO);
        l.setPadding(dp(8), dp(10), dp(8), dp(10));
        tSud = letra("", 17, Color.WHITE, true);
        tSud.setGravity(Gravity.CENTER);
        l.addView(tSud);
        int lado = (getResources().getDisplayMetrics().widthPixels - dp(16)) / 9;
        LinearLayout grilla = vertical();
        grilla.setBackgroundColor(0xFF263238);
        grilla.setPadding(dp(2), dp(2), dp(2), dp(2));
        for (int f = 0; f < 9; f++) {
            LinearLayout fila = horizontal();
            for (int c = 0; c < 9; c++) {
                final int i = f * 9 + c;
                TextView t = letra("", 22, Color.BLACK, true);
                t.setGravity(Gravity.CENTER);
                t.setOnClickListener(v -> { sel = i; pintarSud(); });
                celdas[i] = t;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(lado - dp(1), lado - dp(1));
                lp.setMargins(c % 3 == 0 && c > 0 ? dp(3) : dp(1), f % 3 == 0 && f > 0 ? dp(3) : dp(1), 0, 0);
                fila.addView(t, lp);
            }
            grilla.addView(fila);
        }
        l.addView(grilla);
        LinearLayout num = horizontal();
        num.setPadding(0, dp(12), 0, 0);
        for (int v = 1; v <= 9; v++) {
            final int n = v;
            Button b = boton(String.valueOf(v), 0xFF3949AB);
            b.setTextSize(22);
            b.setPadding(0, 0, 0, 0);
            b.setOnClickListener(x -> poner(n));
            num.addView(b, new LinearLayout.LayoutParams(0, dp(58), 1f) {{ setMargins(dp(2), 0, dp(2), 0); }});
        }
        l.addView(num);
        LinearLayout f2 = horizontal();
        Button bor = boton("⌫ Borrar", 0xFF546E7A);
        bor.setOnClickListener(x -> poner(0));
        Button pista = boton("💡 Pista", 0xFFF9A825);
        pista.setOnClickListener(x -> {
            if (sel < 0 || fijo[sel]) { toast("Toque primero una casilla vacía"); return; }
            tab[sel] = sol[sel]; fijo[sel] = true; pintarSud(); revisarFin();
        });
        Button otro = boton("↺ Otro", 0xFF8D6E63);
        otro.setOnClickListener(x -> sudokuNivel());
        f2.addView(bor, peso(1)); f2.addView(pista, peso(1)); f2.addView(otro, peso(1));
        l.addView(f2, ancho(54));
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        sv.setBackgroundColor(FONDO);
        setContentView(sv);
        pintarSud();
        h.post(new Runnable() {
            @Override public void run() { if (enJuego != 2) return; pintarTitulo(); h.postDelayed(this, 1000); }
        });
    }

    private void pintarTitulo() {
        long s = (System.currentTimeMillis() - inicio) / 1000;
        tSud.setText("🔢 Sudoku   ⏱ " + tiempo(Math.max(1, s)) + "   ❌ " + errores);
    }

    private void poner(int v) {
        if (sel < 0) { toast("Toque primero una casilla"); return; }
        if (fijo[sel]) return;
        tab[sel] = v;
        if (v != 0 && v != sol[sel]) errores++;
        pintarSud();
        revisarFin();
    }

    private void revisarFin() {
        for (int i = 0; i < 81; i++) if (tab[i] != sol[i]) return;
        long s = (System.currentTimeMillis() - inicio) / 1000;
        long mejor = pr.getLong("sudMejor", 0);
        if (mejor == 0 || s < mejor) pr.edit().putLong("sudMejor", s).apply();
        enJuego = 3;
        tSud.setText("🏆 ¡Terminado en " + tiempo(s) + "!" + (mejor == 0 || s < mejor ? "  ¡Récord!" : ""));
        final String det = "Lo terminó en " + tiempo(s) + (mejor == 0 || s < mejor ? " · ¡Nuevo récord!" : "");
        h.postDelayed(() -> resultado("sud", true, det), 700);
    }

    private void pintarSud() {
        int valSel = sel >= 0 ? tab[sel] : 0;
        for (int i = 0; i < 81; i++) {
            TextView t = celdas[i];
            int v = tab[i];
            t.setText(v == 0 ? "" : String.valueOf(v));
            boolean mismaZona = sel >= 0 && (i / 9 == sel / 9 || i % 9 == sel % 9 || (i / 27 == sel / 27 && i % 9 / 3 == sel % 9 / 3));
            int fondo = i == sel ? 0xFFFFD54F : (valSel != 0 && v == valSel) ? 0xFFFFE082 : mismaZona ? 0xFFE3F2FD : Color.WHITE;
            t.setBackgroundColor(fondo);
            t.setTextColor(fijo[i] ? 0xFF212121 : v != 0 && v != sol[i] ? 0xFFD32F2F : 0xFF1565C0);
        }
        if (tSud != null && enJuego == 2) pintarTitulo();
    }
}
