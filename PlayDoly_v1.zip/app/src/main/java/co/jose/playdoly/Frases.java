package co.jose.playdoly;

import java.util.Calendar;
import java.util.Random;

/** Frases originales de Play Doly: una para cada día, y palabras de ánimo al ganar o al perder. */
final class Frases {
    private Frases() {}

    static final String[] DIA = {
            "Cada amanecer es una página en blanco que Dios le regala para escribir algo bonito.",
            "El camino se hace más corto cuando se anda con fe y con una sonrisa.",
            "No hay sueño pequeño cuando se persigue con el corazón entero.",
            "Lo que siembra con amor hoy, lo cosecha con alegría mañana.",
            "La paciencia es la semilla; la paz es el fruto.",
            "Dé gracias por lo que tiene y verá cómo se multiplica.",
            "Cuando el camino se ponga cuesta arriba, mire hacia arriba.",
            "Un corazón agradecido encuentra tesoros donde otros solo ven piedras.",
            "La vida no se mide por los años, sino por las veces que ayudó a otro a sonreír.",
            "Hoy es un buen día para empezar de nuevo, sin miedo y con esperanza.",
            "El que confía camina tranquilo, aunque no vea el final del sendero.",
            "Las caídas no son el final: son el momento de aprender a levantarse.",
            "Su historia todavía no termina; lo mejor puede estar en el próximo capítulo.",
            "Donde hay fe, hay fuerza; donde hay amor, hay camino.",
            "Pequeños pasos todos los días construyen grandes caminos.",
            "No compare su camino con el de nadie; el suyo tiene su propio tiempo.",
            "La alegría compartida se duplica; la tristeza compartida se divide.",
            "Un buen día empieza con un pensamiento bonito y una oración sencilla.",
            "Lo que hoy parece una piedra, mañana puede ser el escalón para subir.",
            "El tiempo de Dios es perfecto, aunque a veces nos parezca lento.",
            "Abrace la vida como viene: con sus soles y con sus lluvias.",
            "La sencillez es la forma más bonita de la grandeza.",
            "Quien sueña despierto construye con las manos lo que vio con el alma.",
            "Hasta el árbol más grande empezó siendo una semilla que creyó.",
            "Hable bonito, piense bonito, y la vida le responderá bonito.",
            "El cansancio pasa; lo que construyó con esfuerzo se queda.",
            "No hay viento contrario para quien sabe hacia dónde quiere ir.",
            "La familia es el primer hogar del corazón.",
            "Agradezca el pan de cada día y la mano que lo comparte.",
            "Las mejores cosas de la vida no se compran: se viven.",
            "Cada error es un maestro que llega sin avisar.",
            "Mire con ojos nuevos lo de siempre y descubrirá milagros escondidos.",
            "La fe no quita las montañas de una vez: le da fuerzas para subirlas.",
            "Hoy regale una palabra amable; no cuesta nada y vale mucho.",
            "El que se levanta temprano con gratitud ya ganó la mitad del día.",
            "Siga adelante: lo que es para usted, nadie se lo quita.",
            "La vida es un juego bonito: se gana compartiendo y se pierde peleando.",
            "Con calma y con fe, todo llega a su tiempo.",
            "Sonría: es la oración más corta y la más fácil de entender.",
            "Lo que hace con amor nunca es tiempo perdido.",
            "Cuando no sepa qué hacer, haga el bien.",
            "Un alma tranquila escucha mejor la voz de Dios.",
            "No espere el momento perfecto: tome el momento y hágalo perfecto.",
            "Los sueños se cumplen a fuerza de constancia, no de suerte.",
            "La humildad abre puertas que el orgullo nunca encuentra.",
            "Viva el hoy: el ayer ya pasó y el mañana está en buenas manos.",
            "Nadie es tan pobre que no pueda dar una sonrisa.",
            "El trabajo honrado es una oración hecha con las manos.",
            "En la quietud de la mañana nacen las mejores ideas.",
            "Cada persona que llega a su vida trae una lección o una bendición.",
            "La alegría no depende de lo que pasa afuera, sino de lo que cuida adentro.",
            "Empiece donde está, use lo que tiene y haga lo que pueda.",
            "El amor es el único tesoro que crece cuando se reparte.",
            "Un día a la vez, una bendición a la vez.",
            "Las raíces fuertes no le temen a las tormentas.",
            "Ponga su corazón en lo que hace y lo que hace tendrá corazón.",
            "Es más fuerte de lo que cree y más querido de lo que imagina.",
            "Deje que la esperanza sea más grande que el miedo.",
            "La gratitud convierte lo que tenemos en suficiente.",
            "El que perdona se libera primero a sí mismo.",
            "Hoy el cielo le dice: siga, que va por buen camino.",
            "Con fe, cada final es el principio de algo mejor.",
            "Las manos que ayudan son más santas que los labios que solo rezan.",
            "Cuide su paz como cuida su casa: con amor todos los días.",
            "La vida le sonríe más cuando usted le sonríe primero.",
            "Sea luz en el camino de alguien hoy.",
            "Dios no le pide que sea perfecto, solo que no deje de caminar.",
            "Cada noche de descanso es una promesa de un nuevo comienzo.",
            "Lo sencillo, hecho con cariño, se vuelve extraordinario.",
            "Bendecido el que juega con alegría y vive con gratitud.",
    };

    static String deHoy() {
        int d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        return DIA[d % DIA.length];
    }

    private static final Random R = new Random();

    static final String[] GANO = {
            "🏆 ¡Qué partidazo! Ganó con toda.",
            "🎉 ¡Ganó! La alegría se le nota hasta en los dedos.",
            "🌟 ¡Victoria bonita! Así se juega.",
            "🥳 ¡Usted es un campeón! El celular le pide la revancha.",
            "👏 ¡Bien jugado! Hoy el día tiene sabor a triunfo.",
    };

    static final String[] PERDIO = {
            "😊 Ganó el celular, pero usted ganó un rato bonito. ¡Otra!",
            "🌈 Perder también es divertido cuando se juega con alegría.",
            "💪 El celular tuvo suerte esta vez. ¡La revancha es suya!",
            "🙌 Lo importante es reírse y seguir jugando. ¡Vamos otra vez!",
            "☀️ Hoy ganó el celular; mañana lo pone a sufrir usted.",
            "🎶 Se perdió la partida, pero no la sonrisa. ¡Eso vale más!",
    };

    static String gano() { return GANO[R.nextInt(GANO.length)]; }
    static String perdio() { return PERDIO[R.nextInt(PERDIO.length)]; }
}
