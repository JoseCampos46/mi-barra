package co.jose.playdoly;

import android.content.Context;
import android.media.MediaPlayer;

/** La música suavecita de fondo: una para cada juego. Se puede apagar y bajar el volumen. */
final class Musica {
    private Musica() {}
    private static MediaPlayer mp;
    private static int sonando;

    static boolean prendida(Context c) { return c.getSharedPreferences("doly", 0).getBoolean("musica", true); }
    static float volumen(Context c) { return c.getSharedPreferences("doly", 0).getFloat("volMusica", 0.5f); }

    static void tocar(Context c, int res) {
        if (!prendida(c)) { parar(); return; }
        if (mp != null && sonando == res) { if (!mp.isPlaying()) mp.start(); return; }
        parar();
        try {
            mp = MediaPlayer.create(c.getApplicationContext(), res);
            if (mp == null) return;
            mp.setLooping(true);
            float v = volumen(c);
            mp.setVolume(v, v);
            mp.start();
            sonando = res;
        } catch (Exception ignored) { mp = null; }
    }

    static void ponerVolumen(Context c, float v) {
        c.getSharedPreferences("doly", 0).edit().putFloat("volMusica", v).apply();
        if (mp != null) mp.setVolume(v, v);
    }

    static void pausar() { try { if (mp != null && mp.isPlaying()) mp.pause(); } catch (Exception ignored) {} }

    static void seguir() { try { if (mp != null && !mp.isPlaying()) mp.start(); } catch (Exception ignored) {} }

    static void parar() {
        try { if (mp != null) { mp.stop(); mp.release(); } } catch (Exception ignored) {}
        mp = null;
        sonando = 0;
    }
}
