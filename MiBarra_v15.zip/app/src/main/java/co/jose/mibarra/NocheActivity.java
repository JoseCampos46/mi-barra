package co.jose.mibarra;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * Reloj de noche: hora grande en color suave sobre negro, también encima de la pantalla de bloqueo.
 * Toque: cambia el color. Toque largo: más o menos brillo. Atrás: salir. Se corre un poquito cada minuto para no marcar la pantalla.
 */
public class NocheActivity extends Activity {
    static final int[] COLORES = {0xFFFF5252, 0xFFFFB74D, 0xFF81C784, 0xFF90CAF9, 0xFFEEEEEE};
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView hora, fecha, extra;
    private LinearLayout caja;
    private int color, brillo;
    private final Random r = new Random();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        android.content.SharedPreferences p = getSharedPreferences("barra", MODE_PRIVATE);
        color = p.getInt("nocheColor", 0);
        brillo = p.getInt("nocheBrillo", 1);
        FrameLayout raiz = new FrameLayout(this);
        raiz.setBackgroundColor(Color.BLACK);
        caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setGravity(Gravity.CENTER_HORIZONTAL);
        hora = texto(96, true);
        fecha = texto(24, false);
        extra = texto(18, false);
        caja.addView(hora); caja.addView(fecha); caja.addView(extra);
        raiz.addView(caja, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        raiz.setOnClickListener(v -> { color = (color + 1) % COLORES.length; p.edit().putInt("nocheColor", color).apply(); pintar(); });
        raiz.setOnLongClickListener(v -> { brillo = (brillo + 1) % 3; p.edit().putInt("nocheBrillo", brillo).apply(); pintar(); return true; });
        setContentView(raiz);
        pintar();
    }

    private TextView texto(float t, boolean negrita) {
        TextView v = new TextView(this);
        v.setTextSize(t);
        v.setGravity(Gravity.CENTER);
        if (negrita) v.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        return v;
    }

    @Override protected void onResume() { super.onResume(); h.post(tic); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tic); }

    private final Runnable tic = new Runnable() {
        @Override public void run() {
            pintar();
            h.postDelayed(this, 60000 - System.currentTimeMillis() % 60000 + 50);
        }
    };

    private void pintar() {
        Locale es = new Locale("es", "CO");
        hora.setText(new SimpleDateFormat("h:mm", es).format(new Date()));
        String f = new SimpleDateFormat("EEEE d 'de' MMMM", es).format(new Date());
        fecha.setText(Character.toUpperCase(f.charAt(0)) + f.substring(1));
        StringBuilder s = new StringBuilder();
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            int lv = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            boolean carga = bat.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            if (lv >= 0) s.append(carga ? "⚡ " : "🔋 ").append(lv * 100 / sc).append(" %");
        }
        AlarmManager am = getSystemService(AlarmManager.class);
        if (am != null && am.getNextAlarmClock() != null)
            s.append("   ⏰ ").append(new SimpleDateFormat("EEE h:mm a", es).format(new Date(am.getNextAlarmClock().getTriggerTime())));
        extra.setText(s);
        int c = COLORES[color];
        float[] alfa = {0.35f, 0.65f, 1f};
        for (TextView t : new TextView[]{hora, fecha, extra}) { t.setTextColor(c); t.setAlpha(alfa[brillo]); }
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = brillo == 0 ? 0.01f : brillo == 1 ? 0.1f : -1f;
        getWindow().setAttributes(lp);
        // se corre un poquito para no marcar la pantalla
        caja.setTranslationX((r.nextFloat() - 0.5f) * 60);
        caja.setTranslationY((r.nextFloat() - 0.5f) * 120);
    }
}
