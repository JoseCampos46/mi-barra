package co.jose.mibarra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Activar el Teclado Mi Barra en 3 pasos, el micrófono y el dictado sin conexión. */
public class TecladoAjustesActivity extends Base {

    @Override protected void onResume() { super.onResume(); pintar(); }

    private boolean activado() {
        InputMethodManager im = getSystemService(InputMethodManager.class);
        for (InputMethodInfo i : im.getEnabledInputMethodList()) if (i.getPackageName().equals(getPackageName())) return true;
        return false;
    }

    private boolean elegido() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return s != null && s.startsWith(getPackageName());
    }

    private void pintar() {
        LinearLayout l = vertical();
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.addView(titulo("⌨ Teclado Mi Barra"));
        TextView t = new TextView(this);
        t.setText("Con sugerencias que aprenden sus palabras, signos a la vista, tildes dejando presionado, ◀ ▶ para mover el cursor y micrófono.");
        t.setTextSize(16);
        t.setPadding(0, dp(6), 0, dp(12));
        l.addView(t);
        boolean a = activado(), e = elegido();
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        Button b1 = boton((a ? "✅" : "1️⃣") + "  Activar el teclado", a ? 0xFF2E7D32 : 0xFF1565C0);
        b1.setOnClickListener(v -> {
            aviso("Prenda «Mi Barra» y acepte el aviso (es el aviso normal de Android para cualquier teclado)");
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        });
        l.addView(b1, ancho(58));
        Button b2 = boton((e ? "✅" : "2️⃣") + "  Escogerlo como teclado del celular", e ? 0xFF2E7D32 : 0xFF1565C0);
        b2.setOnClickListener(v -> getSystemService(InputMethodManager.class).showInputMethodPicker());
        l.addView(b2, ancho(58));
        Button b3 = boton((mic ? "✅" : "3️⃣") + "  Permitir el micrófono 🎤", mic ? 0xFF2E7D32 : 0xFF1565C0);
        b3.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1));
        l.addView(b3, ancho(58));
        Button b4 = boton("4️⃣  Bajar el español para hablar SIN internet", 0xFF6A1B9A);
        b4.setOnClickListener(v -> {
            aviso("Busque «Reconocimiento de voz sin conexión» o «Idiomas» y descargue Español");
            for (String s : new String[]{"android.settings.VOICE_INPUT_SETTINGS", Settings.ACTION_INPUT_METHOD_SETTINGS}) {
                try { startActivity(new Intent(s)); return; } catch (Exception ignored) {}
            }
        });
        l.addView(b4, ancho(58));
        Switch sc = new Switch(this);
        sc.setText("  Preferir dictado sin conexión (no se corta con el Wi‑Fi)");
        sc.setTextSize(15);
        sc.setChecked(getSharedPreferences("barra", MODE_PRIVATE).getBoolean("vozSinConexion", true));
        sc.setOnCheckedChangeListener((c, v) -> getSharedPreferences("barra", MODE_PRIVATE).edit().putBoolean("vozSinConexion", v).apply());
        l.addView(sc);
        TextView p = new TextView(this);
        p.setText("\nPruébelo aquí:");
        p.setTextSize(16);
        l.addView(p);
        EditText prueba = campoTexto("Escriba o hable…", "");
        prueba.setSingleLine(false);
        prueba.setMinLines(3);
        l.addView(prueba);
        Button borrar = boton("🧹  Olvidar las palabras aprendidas", 0xFF8D6E63);
        borrar.setOnClickListener(v -> { new java.io.File(getFilesDir(), "teclado_palabras.txt").delete(); aviso("Listo"); });
        l.addView(borrar, ancho(50));
        TextView n = new TextView(this);
        n.setText("Para volver al teclado de antes: paso 2 y escoja el otro.");
        n.setTextColor(0xFF78909C);
        l.addView(n);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }
}
