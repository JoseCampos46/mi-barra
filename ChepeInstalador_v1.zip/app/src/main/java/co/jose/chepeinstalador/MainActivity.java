package co.jose.chepeinstalador;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Chepe Instalador v1: muestra todas las apps de Jose, qué versión tiene en el celular,
 * cuál hay en GitHub, y las instala o actualiza con un toque. Solo trabaja mientras está abierta.
 */
public class MainActivity extends Activity {

    static final String VERSION = "v1";
    static final String DUENO = "JoseCampos46";

    /** Una app del catálogo. regla = cómo leer la versión instalada para compararla con la de GitHub. */
    static class App {
        String nombre, repo, prefijo, paquete, regla;
        String versionGit, url, fecha; long tamano;
        String versionCel; // null = no instalada
        String estado = ""; // texto mientras baja o instala
        boolean marcada; // ya se encontró en esta revisión
        App(String n, String r, String p, String pk, String rg) { nombre = n; repo = r; prefijo = p; paquete = pk; regla = rg; }
    }

    final List<App> apps = new ArrayList<>();
    final Handler ui = new Handler(Looper.getMainLooper());
    final List<App> cola = new ArrayList<>();
    App instalando = null;
    LinearLayout lista;
    TextView aviso, resumen;
    Button botonTodas;
    LinearLayout bannerPermiso;
    static MainActivity yo;

    void catalogo() {
        apps.clear();
        apps.add(new App("Mi Barra", "mi-barra", "v", "co.jose.mibarra", "punto"));
        apps.add(new App("ChpCad", "mi-inventor", "v", "co.jose.miinventor", "punto"));
        apps.add(new App("Mis Chats", "mi-barra", "mischats-v", "co.jose.mischats", "primero"));
        apps.add(new App("Mi Catálogo", "mi-barra", "micatalogo-v", "co.jose.micatalogo", "punto"));
        apps.add(new App("Mi Control", "mi-barra", "micontrol-v", "co.jose.micontrol", "punto"));
        apps.add(new App("Chepe Video", "mi-barra", "chepevideo-v", "co.jose.chepevideo", "digitos"));
        apps.add(new App("Chepe Estudio", "mi-barra", "chepeestudio-v", "co.jose.chepeestudio", "punto"));
        apps.add(new App("DJ Chepe Gallego", "mi-barra", "djchepe-v", "co.jose.djchepe", "punto"));
        apps.add(new App("Foto Shop", "mi-barra", "fotoshop-v", "co.jose.fotoshop", "punto"));
        apps.add(new App("Play Doly", "mi-barra", "playdoly-v", "co.jose.playdoly", "primero"));
        apps.add(new App("Scanner Chepe Gallego", "mi-barra", "scanner-v", "co.jose.scannerchepe", "primero"));
        apps.add(new App("Mi Salud", "mi-salud", "v", "com.chepegallego.misalud", "ultimo"));
        apps.add(new App("Hablemos English", "hablemos-english", "v", "com.josecampos.hablemos", "ultimo"));
        apps.add(new App("Chepe Instalador", "mi-barra", "chepeinstalador-v", "co.jose.chepeinstalador", "punto"));
    }

    int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        yo = this;
        catalogo();
        getWindow().setStatusBarColor(Color.parseColor("#0D47A1"));

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(Color.WHITE);

        // Barra de arriba: nombre, versión y menú ☰
        LinearLayout barra = new LinearLayout(this);
        barra.setBackgroundColor(Color.parseColor("#0D47A1"));
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setPadding(dp(12), dp(8), dp(4), dp(8));
        TextView titulo = new TextView(this);
        titulo.setText("Chepe Instalador  " + VERSION);
        titulo.setTextColor(Color.WHITE);
        titulo.setTextSize(22);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        barra.addView(titulo, new LinearLayout.LayoutParams(0, -2, 1));
        Button buscar = boton("⟳", Color.parseColor("#1565C0"), Color.WHITE);
        buscar.setTextSize(24);
        buscar.setOnClickListener(v -> buscarEnGitHub());
        barra.addView(buscar, new LinearLayout.LayoutParams(dp(56), dp(52)));
        Button menu = boton("☰", Color.parseColor("#1565C0"), Color.WHITE);
        menu.setTextSize(24);
        menu.setOnClickListener(this::abrirMenu);
        LinearLayout.LayoutParams lm = new LinearLayout.LayoutParams(dp(56), dp(52));
        lm.leftMargin = dp(6);
        barra.addView(menu, lm);
        raiz.addView(barra);

        // Aviso del permiso (solo la primera vez)
        bannerPermiso = new LinearLayout(this);
        bannerPermiso.setOrientation(LinearLayout.VERTICAL);
        bannerPermiso.setBackgroundColor(Color.parseColor("#FFE082"));
        bannerPermiso.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView tp = new TextView(this);
        tp.setText("Primer paso (una sola vez): toque aquí y prenda «Permitir de esta fuente» para que Chepe Instalador pueda instalar sus apps.");
        tp.setTextColor(Color.BLACK);
        tp.setTextSize(17);
        bannerPermiso.addView(tp);
        bannerPermiso.setOnClickListener(v -> abrirPermiso());
        raiz.addView(bannerPermiso);

        // Resumen + Actualizar todas
        LinearLayout fila = new LinearLayout(this);
        fila.setGravity(Gravity.CENTER_VERTICAL);
        fila.setPadding(dp(12), dp(8), dp(12), dp(8));
        resumen = new TextView(this);
        resumen.setTextColor(Color.BLACK);
        resumen.setTextSize(17);
        fila.addView(resumen, new LinearLayout.LayoutParams(0, -2, 1));
        botonTodas = boton("ACTUALIZAR TODAS", Color.parseColor("#1B8F3A"), Color.WHITE);
        botonTodas.setOnClickListener(v -> actualizarTodas());
        fila.addView(botonTodas, new LinearLayout.LayoutParams(-2, dp(52)));
        raiz.addView(fila);

        aviso = new TextView(this);
        aviso.setTextColor(Color.BLACK);
        aviso.setTextSize(15);
        aviso.setPadding(dp(12), 0, dp(12), dp(6));
        raiz.addView(aviso);

        ScrollView sv = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        lista.setPadding(dp(8), 0, dp(8), dp(16));
        sv.addView(lista);
        raiz.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(raiz);

        cargarGuardado();
        leerCelular();
        pintar();
        buscarEnGitHub();
    }

    @Override
    protected void onResume() {
        super.onResume();
        yo = this;
        bannerPermiso.setVisibility(getPackageManager().canRequestPackageInstalls() ? View.GONE : View.VISIBLE);
        leerCelular();
        pintar();
    }

    @Override
    protected void onDestroy() {
        if (yo == this) yo = null;
        super.onDestroy();
    }

    Button boton(String t, int fondo, int letra) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(letra);
        bt.setTextSize(16);
        bt.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(dp(10));
        bt.setBackground(g);
        bt.setPadding(dp(10), 0, dp(10), 0);
        return bt;
    }

    // ---------------- Versiones ----------------

    /** Convierte una versión en números para comparar: "6.7" → [6,7]. */
    static int[] numeros(String v) {
        if (v == null) return new int[0];
        String[] partes = v.replaceAll("[^0-9]+", " ").trim().split(" ");
        if (partes.length == 1 && partes[0].isEmpty()) return new int[0];
        int[] r = new int[partes.length];
        for (int i = 0; i < partes.length; i++) {
            try { r[i] = Integer.parseInt(partes[i]); } catch (Exception e) { r[i] = 0; }
        }
        return r;
    }

    static int comparar(String a, String b) {
        int[] x = numeros(a), y = numeros(b);
        int n = Math.max(x.length, y.length);
        for (int i = 0; i < n; i++) {
            int p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
            if (p != q) return p < q ? -1 : 1;
        }
        return 0;
    }

    /** Pasa el versionName del celular al mismo formato del número de GitHub. */
    static String normalizar(String nombreVersion, String regla) {
        if (nombreVersion == null) return null;
        int[] n = numeros(nombreVersion);
        if (n.length == 0) return nombreVersion;
        switch (regla) {
            case "digitos": return nombreVersion.replaceAll("[^0-9]", "");
            case "primero": return String.valueOf(n[0]);
            case "ultimo": return String.valueOf(n[n.length - 1]);
            default: return nombreVersion.replaceAll("[^0-9.]", "");
        }
    }

    void leerCelular() {
        PackageManager pm = getPackageManager();
        for (App a : apps) {
            try {
                PackageInfo pi = pm.getPackageInfo(a.paquete, 0);
                a.versionCel = normalizar(pi.versionName == null ? "?" : pi.versionName, a.regla);
            } catch (Exception e) {
                a.versionCel = null;
            }
        }
    }

    boolean hayNueva(App a) {
        return a.versionCel != null && a.versionGit != null && comparar(a.versionCel, a.versionGit) < 0;
    }

    // ---------------- GitHub ----------------

    void cargarGuardado() {
        SharedPreferences sp = getSharedPreferences("datos", MODE_PRIVATE);
        for (App a : apps) {
            String k = a.repo + "|" + a.prefijo;
            a.versionGit = sp.getString(k + "|v", null);
            a.url = sp.getString(k + "|u", null);
            a.fecha = sp.getString(k + "|f", "");
            a.tamano = sp.getLong(k + "|t", 0);
        }
        String cuando = sp.getString("cuando", null);
        if (cuando != null) aviso.setText("Última revisión: " + cuando);
    }

    void guardar() {
        SharedPreferences.Editor e = getSharedPreferences("datos", MODE_PRIVATE).edit();
        for (App a : apps) {
            String k = a.repo + "|" + a.prefijo;
            if (a.versionGit != null) {
                e.putString(k + "|v", a.versionGit).putString(k + "|u", a.url)
                        .putString(k + "|f", a.fecha).putLong(k + "|t", a.tamano);
            }
        }
        e.putString("cuando", new java.text.SimpleDateFormat("d MMM, h:mm a", new java.util.Locale("es", "CO")).format(new java.util.Date()));
        e.apply();
    }

    static String leerTexto(String direccion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(direccion).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "ChepeInstalador");
        int code = c.getResponseCode();
        if (code == 403 || code == 429) throw new Exception("espere");
        if (code != 200) throw new Exception("GitHub respondió " + code);
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        } finally { c.disconnect(); }
    }

    /** ¿La etiqueta es de esta app? "v42" con prefijo "v" sí; "micontrol-v2" con prefijo "v" no. */
    static String versionDeEtiqueta(String tag, String prefijo) {
        if (tag == null || !tag.startsWith(prefijo) || tag.length() <= prefijo.length()) return null;
        String resto = tag.substring(prefijo.length());
        if (!Character.isDigit(resto.charAt(0))) return null;
        return resto;
    }

    void buscarEnGitHub() {
        aviso.setText("Buscando versiones nuevas en GitHub…");
        new Thread(() -> {
            String error = null;
            Map<String, List<App>> porRepo = new HashMap<>();
            for (App a : apps) {
                List<App> l = porRepo.get(a.repo);
                if (l == null) { l = new ArrayList<>(); porRepo.put(a.repo, l); }
                l.add(a);
            }
            for (Map.Entry<String, List<App>> ent : porRepo.entrySet()) {
                try {
                    for (int pagina = 1; pagina <= 3; pagina++) {
                        String txt = leerTexto("https://api.github.com/repos/" + DUENO + "/" + ent.getKey()
                                + "/releases?per_page=100&page=" + pagina);
                        JSONArray arr = new JSONArray(txt);
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject r = arr.getJSONObject(i);
                            if (r.optBoolean("draft")) continue;
                            String tag = r.optString("tag_name");
                            JSONArray assets = r.optJSONArray("assets");
                            String url = null; long tam = 0;
                            if (assets != null) for (int j = 0; j < assets.length(); j++) {
                                JSONObject as = assets.getJSONObject(j);
                                if (as.optString("name").toLowerCase().endsWith(".apk")) {
                                    url = as.optString("browser_download_url");
                                    tam = as.optLong("size");
                                    break;
                                }
                            }
                            if (url == null) continue;
                            for (App a : ent.getValue()) {
                                String v = versionDeEtiqueta(tag, a.prefijo);
                                if (v == null) continue;
                                if (!a.marcada || comparar(v, a.versionGit) > 0) {
                                    a.versionGit = v;
                                    a.url = url;
                                    a.tamano = tam;
                                    String f = r.optString("published_at", "");
                                    a.fecha = f.length() >= 10 ? f.substring(0, 10) : "";
                                    a.marcada = true;
                                }
                            }
                        }
                        if (arr.length() < 100) break;
                    }
                } catch (Exception e) {
                    error = "espere".equals(e.getMessage())
                            ? "GitHub pide esperar un rato (muchas consultas). Intente en unos minutos."
                            : "Sin conexión con GitHub. Se muestran los datos de la última revisión.";
                }
            }
            for (App a : apps) a.marcada = false;
            final String err = error;
            ui.post(() -> {
                if (err == null) { guardar(); aviso.setText("Revisado ahora mismo."); }
                else aviso.setText(err);
                leerCelular();
                pintar();
            });
        }).start();
    }

    // ---------------- Pantalla ----------------

    void pintar() {
        lista.removeAllViews();
        List<App> orden = new ArrayList<>();
        for (App a : apps) if (hayNueva(a)) orden.add(a);
        for (App a : apps) if (!orden.contains(a) && a.versionCel != null) orden.add(a);
        for (App a : apps) if (!orden.contains(a)) orden.add(a);
        int nuevas = 0;
        for (App a : apps) if (hayNueva(a)) nuevas++;
        resumen.setText(nuevas == 0 ? "Todas al día ✓" : (nuevas == 1 ? "1 app tiene versión nueva" : nuevas + " apps tienen versión nueva"));
        botonTodas.setVisibility(nuevas >= 2 ? View.VISIBLE : View.GONE);
        for (App a : orden) lista.addView(tarjeta(a));
    }

    View tarjeta(App a) {
        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(hayNueva(a) ? Color.parseColor("#E8F5E9") : Color.parseColor("#F5F5F5"));
        g.setStroke(dp(1), Color.parseColor("#9E9E9E"));
        g.setCornerRadius(dp(12));
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);

        LinearLayout textos = new LinearLayout(this);
        textos.setOrientation(LinearLayout.VERTICAL);
        TextView n = new TextView(this);
        n.setText(a.nombre);
        n.setTextColor(Color.BLACK);
        n.setTextSize(20);
        n.setTypeface(Typeface.DEFAULT_BOLD);
        textos.addView(n);
        TextView d = new TextView(this);
        d.setTextColor(Color.BLACK);
        d.setTextSize(15);
        String cel = a.versionCel == null ? "No instalada" : "En el celular: " + a.versionCel;
        String git = a.versionGit == null ? "En GitHub: —" : "En GitHub: " + a.versionGit
                + (a.tamano > 0 ? "  (" + Math.max(1, Math.round(a.tamano / 1048576.0)) + " MB)" : "");
        d.setText(cel + "\n" + git + (a.estado.isEmpty() ? "" : "\n" + a.estado));
        textos.addView(d);
        t.addView(textos, new LinearLayout.LayoutParams(0, -2, 1));

        Button bt;
        if (a == instalando || cola.contains(a)) {
            bt = boton(a == instalando ? "TRABAJANDO…" : "EN FILA", Color.parseColor("#FFB300"), Color.BLACK);
            bt.setEnabled(false);
        } else if (hayNueva(a)) {
            bt = boton("ACTUALIZAR", Color.parseColor("#1B8F3A"), Color.WHITE);
            bt.setOnClickListener(v -> empezar(a));
        } else if (a.versionCel == null) {
            bt = boton("INSTALAR", Color.parseColor("#1565C0"), Color.WHITE);
            bt.setOnClickListener(v -> empezar(a));
            if (a.url == null) bt.setEnabled(false);
        } else {
            bt = boton("ABRIR", Color.parseColor("#E0E0E0"), Color.BLACK);
            bt.setOnClickListener(v -> abrirApp(a));
        }
        t.addView(bt, new LinearLayout.LayoutParams(dp(132), dp(56)));
        t.setOnLongClickListener(v -> {
            if (a.url == null) return true;
            new AlertDialog.Builder(this).setTitle(a.nombre)
                    .setMessage("¿Instalar otra vez la versión " + a.versionGit + " de GitHub?\n(No se borra nada de lo que tiene guardado.)")
                    .setPositiveButton("Instalar otra vez", (x, y) -> empezar(a))
                    .setNegativeButton("Cancelar", null).show();
            return true;
        });
        return t;
    }

    void abrirApp(App a) {
        if (a.paquete.equals(getPackageName())) { Toast.makeText(this, "Ya está abierta 🙂", Toast.LENGTH_SHORT).show(); return; }
        Intent i = getPackageManager().getLaunchIntentForPackage(a.paquete);
        if (i != null) startActivity(i);
        else Toast.makeText(this, "No se pudo abrir " + a.nombre, Toast.LENGTH_SHORT).show();
    }

    void abrirMenu(View ancla) {
        PopupMenu pm = new PopupMenu(this, ancla);
        pm.getMenu().add(0, 1, 0, "⟳ Buscar versiones nuevas");
        pm.getMenu().add(0, 2, 1, "🔓 Permiso para instalar");
        pm.getMenu().add(0, 3, 2, "🌐 Ver las descargas en GitHub");
        pm.getMenu().add(0, 4, 3, "❓ Ayuda");
        pm.getMenu().add(0, 5, 4, "✕ Cerrar");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: buscarEnGitHub(); break;
                case 2: abrirPermiso(); break;
                case 3: startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/" + DUENO + "/mi-barra/releases"))); break;
                case 4: ayuda(); break;
                case 5: finish(); break;
            }
            return true;
        });
        pm.show();
    }

    void ayuda() {
        new AlertDialog.Builder(this).setTitle("Cómo se usa")
                .setMessage("1. La primera vez, dé el permiso (franja amarilla de arriba).\n"
                        + "2. Al abrir, la app revisa sola en GitHub.\n"
                        + "3. Verde «ACTUALIZAR» = hay versión nueva. Tóquelo.\n"
                        + "4. Android pregunta «¿Actualizar?». Toque «Actualizar».\n"
                        + "5. Gris «ABRIR» = ya está al día.\n\n"
                        + "Deje el dedo sobre una app para instalarla otra vez.\n"
                        + "Actualizar no borra los archivos que usted tiene guardados.\n"
                        + "Esta app no gasta batería: solo trabaja mientras está abierta.")
                .setPositiveButton("Entendido", null).show();
    }

    void abrirPermiso() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    // ---------------- Instalar ----------------

    void actualizarTodas() {
        for (App a : apps) if (hayNueva(a) && a != instalando && !cola.contains(a)) cola.add(a);
        // Chepe Instalador de último, para no cerrarse a mitad del trabajo
        for (App a : new ArrayList<>(cola)) if (a.paquete.equals(getPackageName())) { cola.remove(a); cola.add(a); }
        siguiente();
    }

    void empezar(App a) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this).setTitle("Falta el permiso")
                    .setMessage("Primero prenda «Permitir de esta fuente» para Chepe Instalador. Es una sola vez.")
                    .setPositiveButton("Ir al permiso", (x, y) -> abrirPermiso())
                    .setNegativeButton("Cancelar", null).show();
            return;
        }
        if (a == instalando || cola.contains(a)) return;
        cola.add(a);
        siguiente();
    }

    void siguiente() {
        if (instalando != null) { pintar(); return; }
        if (cola.isEmpty()) { pintar(); return; }
        instalando = cola.remove(0);
        instalando.estado = "Bajando…";
        pintar();
        final App a = instalando;
        new Thread(() -> bajarEInstalar(a)).start();
    }

    void ponerEstado(App a, String s) {
        ui.post(() -> { a.estado = s; pintar(); });
    }

    void bajarEInstalar(App a) {
        PackageInstaller.Session sesion = null;
        try {
            PackageInstaller pi = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams p = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            p.setAppPackageName(a.paquete);
            if (Build.VERSION.SDK_INT >= 31) p.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
            int id = pi.createSession(p);
            sesion = pi.openSession(id);

            HttpURLConnection c = (HttpURLConnection) new URL(a.url).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", "ChepeInstalador");
            if (c.getResponseCode() != 200) throw new Exception("La descarga respondió " + c.getResponseCode());
            long total = c.getContentLengthLong();
            if (total <= 0) total = a.tamano;
            try (InputStream in = c.getInputStream();
                 OutputStream out = sesion.openWrite("app.apk", 0, total > 0 ? total : -1)) {
                byte[] buf = new byte[65536];
                long llevo = 0; int n, ultimo = -1;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    llevo += n;
                    if (total > 0) {
                        int pct = (int) (llevo * 100 / total);
                        if (pct != ultimo && pct % 5 == 0) { ultimo = pct; ponerEstado(a, "Bajando " + pct + " %"); }
                    }
                }
                sesion.fsync(out);
            } finally { c.disconnect(); }

            ponerEstado(a, "Instalando… (Android le va a preguntar)");
            Intent i = new Intent(this, EstadoReceiver.class);
            i.setAction("co.jose.chepeinstalador.ESTADO." + id);
            i.putExtra("paquete", a.paquete);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pend = PendingIntent.getBroadcast(this, id, i, flags);
            sesion.commit(pend.getIntentSender());
            sesion.close();
        } catch (Exception e) {
            if (sesion != null) try { sesion.abandon(); } catch (Exception ignored) { }
            final String m = e.getMessage();
            ui.post(() -> terminar(a, false, "No se pudo: " + (m == null ? "error de descarga" : m)));
        }
    }

    /** Lo llama EstadoReceiver cuando Android termina. */
    static void avisarEstado(String paquete, int estado, String mensaje) {
        MainActivity m = yo;
        if (m == null) return;
        m.ui.post(() -> {
            App a = null;
            for (App x : m.apps) if (x.paquete.equals(paquete)) a = x;
            if (a == null) return;
            if (estado == PackageInstaller.STATUS_SUCCESS) m.terminar(a, true, "✓ Listo, quedó actualizada");
            else if (estado == PackageInstaller.STATUS_FAILURE_ABORTED) m.terminar(a, false, "Cancelada");
            else if (estado == PackageInstaller.STATUS_FAILURE_CONFLICT || estado == PackageInstaller.STATUS_FAILURE_INCOMPATIBLE)
                m.terminar(a, false, "No se pudo: la app del celular tiene otra firma. Desinstálela y toque INSTALAR.");
            else if (estado == PackageInstaller.STATUS_FAILURE_STORAGE)
                m.terminar(a, false, "No se pudo: falta espacio en el celular.");
            else m.terminar(a, false, "No se pudo" + (mensaje == null ? "" : ": " + mensaje));
        });
    }

    void terminar(App a, boolean bien, String texto) {
        a.estado = texto;
        if (instalando == a) instalando = null;
        if (!bien && "Cancelada".equals(texto)) cola.clear();
        leerCelular();
        pintar();
        siguiente();
    }
}
