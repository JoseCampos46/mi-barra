package co.jose.chepeinstalador;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

/** Recibe la respuesta de Android cuando termina (o pide permiso) una instalación. */
public class EstadoReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        int estado = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999);
        String paquete = intent.getStringExtra("paquete");
        if (estado == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirmar = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirmar != null) {
                confirmar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { ctx.startActivity(confirmar); } catch (Exception e) {
                    MainActivity.avisarEstado(paquete, PackageInstaller.STATUS_FAILURE, "No se pudo abrir la confirmación");
                }
            }
            return;
        }
        String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        MainActivity.avisarEstado(paquete, estado, msg);
    }
}
