package co.jose.mischats;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.telecom.Call;
import android.telecom.InCallService;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Maneja todas las llamadas cuando Mis Chats es la app de teléfono principal. */
public class LlamadaService extends InCallService {

    static LlamadaService yo;
    static final List<Call> llamadas = new ArrayList<>();
    static final List<Call> mudas = new ArrayList<>();
    static final Map<Call, Long> inicioMuda = new HashMap<>();
    static Runnable alCambiar;

    private static final String CANAL = "llamadas";
    private static final int AVISO = 7;
    private final Handler h = new Handler(Looper.getMainLooper());

    private final Call.Callback cb = new Call.Callback() {
        @Override
        public void onStateChanged(Call call, int state) {
            avisar();
            cambio();
            if (state == Call.STATE_ACTIVE && Reglas.p(LlamadaService.this).getBoolean("grabarTodas", false) && !Grabador.grabando())
                grabar(call);
        }
    };

    /** Versión 2: pone el altavoz y graba con el micrófono. */
    boolean grabar(Call k) {
        try { setAudioRoute(android.telecom.CallAudioState.ROUTE_SPEAKER); } catch (Exception ignored) {}
        String num = numero(k);
        String nom = Reglas.nombreContacto(this, num);
        return Grabador.empezar(this, nom != null ? nom : num);
    }

    String pararGrabacion() {
        String n = Grabador.parar(this);
        if (n != null) h.post(() -> android.widget.Toast.makeText(this, "✅ Llamada grabada en Descargas/MiBarra/Llamadas", android.widget.Toast.LENGTH_LONG).show());
        return n;
    }

    private final Call.Callback cbMuda = new Call.Callback() {
        @Override
        public void onStateChanged(Call call, int state) {
            cambio();
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        yo = this;
        NotificationChannel ch = new NotificationChannel(CANAL, "Llamadas", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    @Override
    public void onDestroy() {
        if (yo == this) yo = null;
        super.onDestroy();
    }

    static String numero(Call k) {
        try {
            if (k.getDetails().getHandle() == null) return "";
            return k.getDetails().getHandle().getSchemeSpecificPart();
        } catch (Exception e) {
            return "";
        }
    }

    static boolean visible(Call k) {
        return k.getDetails().getHandlePresentation() == TelecomManager.PRESENTATION_ALLOWED;
    }

    @SuppressWarnings("deprecation")
    static int estado(Call k) {
        return k.getState();
    }

    @Override
    public void onCallAdded(Call call) {
        super.onCallAdded(call);
        if (estado(call) == Call.STATE_RINGING) {
            String num = numero(call);
            Reglas.Decision d = Reglas.telefono(this, num, visible(call));
            if (d.muda) {
                hacerMuda(call, d.motivo);
                return;
            }
        }
        llamadas.add(call);
        call.registerCallback(cb);
        avisar();
        abrirPantalla(false);
        cambio();
    }

    /** La llamada sigue entrando (al otro le timbra) pero aquí no suena ni se ve. */
    void hacerMuda(Call call, String motivo) {
        if (!mudas.contains(call)) mudas.add(call);
        inicioMuda.put(call, System.currentTimeMillis());
        llamadas.remove(call);
        if (Grabador.grabando() && principal() == null) pararGrabacion();
        call.unregisterCallback(cb);
        call.registerCallback(cbMuda);
        callarTimbre();
        String num = numero(call);
        String nombre = Reglas.nombreContacto(this, num);
        Reglas.anotar(this, "Teléfono", nombre == null ? "" : nombre, num, motivo);
        avisar();
        cambio();
    }

    /** Si usted cambia de idea, contesta una llamada muda desde Mis Chats. */
    void rescatar(Call call) {
        mudas.remove(call);
        inicioMuda.remove(call);
        call.unregisterCallback(cbMuda);
        if (!llamadas.contains(call)) llamadas.add(call);
        call.registerCallback(cb);
        contestar(call);
        avisar();
        abrirPantalla(false);
        cambio();
    }

    /** Desde la pantalla de llamada: "Mudo siempre". */
    void volverMuda(Call call) {
        hacerMuda(call, "Lo puso en la lista");
    }

    void callarTimbre() {
        try {
            getSystemService(TelecomManager.class).silenceRinger();
        } catch (Exception ignored) {}
    }

    @Override
    public void onCallRemoved(Call call) {
        super.onCallRemoved(call);
        call.unregisterCallback(cb);
        call.unregisterCallback(cbMuda);
        llamadas.remove(call);
        if (mudas.remove(call)) {
            Long ini = inicioMuda.remove(call);
            final String num = numero(call);
            final long desde = ini == null ? System.currentTimeMillis() - 120000 : ini;
            if (Reglas.p(this).getBoolean("ocultarRegistro", true)) {
                h.postDelayed(() -> Reglas.borrarDelRegistroDelCelular(this, num, desde), 3000);
                h.postDelayed(() -> Reglas.borrarDelRegistroDelCelular(this, num, desde), 9000);
            }
        }
        avisar();
        cambio();
    }

    static Call principal() {
        for (Call k : llamadas) if (estado(k) == Call.STATE_RINGING) return k;
        for (Call k : llamadas) if (estado(k) != Call.STATE_DISCONNECTED) return k;
        return null;
    }

    static void contestar(Call k) {
        try { k.answer(VideoProfile.STATE_AUDIO_ONLY); } catch (Exception ignored) {}
    }

    static void colgar(Call k) {
        try {
            if (estado(k) == Call.STATE_RINGING) k.reject(false, null);
            else k.disconnect();
        } catch (Exception ignored) {}
    }

    private void cambio() {
        Runnable r = alCambiar;
        if (r != null) h.post(r);
    }

    void abrirPantalla(boolean contestar) {
        try {
            Intent i = new Intent(this, LlamadaActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            if (contestar) i.putExtra("contestar", true);
            startActivity(i);
        } catch (Exception ignored) {}
    }

    void avisar() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        Call k = principal();
        if (k == null) {
            nm.cancel(AVISO);
            return;
        }
        String num = numero(k);
        String nombre = Reglas.nombreContacto(this, num);
        String titulo = nombre != null ? nombre : (num.isEmpty() ? "Número privado" : Reglas.formato(num));
        boolean entrando = estado(k) == Call.STATE_RINGING;

        Intent abrir = new Intent(this, LlamadaActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent piAbrir = PendingIntent.getActivity(this, 1, abrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent cont = new Intent(this, LlamadaActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("contestar", true);
        PendingIntent piCont = PendingIntent.getActivity(this, 2, cont,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent piColgar = PendingIntent.getBroadcast(this, 3,
                new Intent(this, AccionReceiver.class).setAction(AccionReceiver.COLGAR),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(this, CANAL)
                .setSmallIcon(R.drawable.ic_tel)
                .setContentTitle(titulo)
                .setContentText(entrando ? "Llamada entrante" : "En llamada")
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setColor(0xFF0F6E56)
                .setContentIntent(piAbrir);
        if (entrando) {
            b.setFullScreenIntent(piAbrir, true);
            b.addAction(new Notification.Action.Builder(null, "Colgar", piColgar).build());
            b.addAction(new Notification.Action.Builder(null, "Contestar", piCont).build());
        } else {
            b.setUsesChronometer(true);
            b.addAction(new Notification.Action.Builder(null, "Colgar", piColgar).build());
        }
        try { nm.notify(AVISO, b.build()); } catch (Exception ignored) {}
    }
}
