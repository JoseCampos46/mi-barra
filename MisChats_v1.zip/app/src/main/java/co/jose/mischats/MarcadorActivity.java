package co.jose.mischats;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telecom.Call;
import android.telecom.PhoneAccount;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Pantalla principal: Marcar, Registro, Contactos y Bloqueo. */
public class MarcadorActivity extends Base {

    private static final String[] PESTANAS = {"Marcar", "Registro", "Contactos", "Bloqueo"};
    private int pestana = 0;
    private boolean verMudas = false;
    private LinearLayout raiz, contenido;
    private EditText numero;
    private TextView coincide;
    private EditText buscar;
    private LinearLayout listaContactos;
    private final List<String[]> contactos = new ArrayList<>();
    private final Runnable miCambio = this::pintar;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(VERDE);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        raiz = vertical();
        raiz.setBackgroundColor(FONDO);
        setContentView(raiz);

        numero = new EditText(this);
        numero.setShowSoftInputOnFocus(false);
        numero.setTextSize(34);
        numero.setTextColor(NEGRO);
        numero.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        numero.setGravity(Gravity.CENTER);
        numero.setSingleLine(true);
        numero.setBackground(null);
        numero.setHint("Escriba el número");
        numero.setHintTextColor(0xFF888780);
        numero.setTextSize(30);
        numero.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { mirarCoincidencia(); }
        });
        coincide = texto("", 17, true, VERDE);
        coincide.setGravity(Gravity.CENTER);

        leerIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        leerIntent(i);
        pintar();
    }

    private void leerIntent(Intent i) {
        if (i == null || i.getData() == null) return;
        if ("tel".equals(i.getData().getScheme())) {
            numero.setText(i.getData().getSchemeSpecificPart());
            numero.setSelection(numero.getText().length());
            pestana = 0;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LlamadaService.alCambiar = miCambio;
        pintar();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (LlamadaService.alCambiar == miCambio) LlamadaService.alCambiar = null;
    }

    // ================= Armado general =================

    private void pintar() {
        raiz.removeAllViews();

        if (!LlamadaService.mudas.isEmpty()) {
            Call k = LlamadaService.mudas.get(0);
            String num = LlamadaService.numero(k);
            String nom = Reglas.nombreContacto(this, num);
            LinearLayout f = horizontal();
            f.setBackgroundColor(AMARILLO_CLARO);
            f.setPadding(dp(8), dp(4), dp(4), dp(4));
            f.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = texto("Entrando muda (no le suena): " + (nom != null ? nom : Reglas.formato(num)), 16, true, AMARILLO);
            f.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button c = boton("Contestar", VERDE_VIVO, 0xFFFFFFFF, 15);
            c.setOnClickListener(v -> {
                if (LlamadaService.yo != null) LlamadaService.yo.rescatar(k);
            });
            f.addView(c, new LinearLayout.LayoutParams(dp(110), dp(46)));
            raiz.addView(f, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        if (!esTelefonoPrincipal() || !permisosOk()) {
            TextView t = texto("Falta activar permisos para que funcione. Toque aquí.", 16, true, 0xFFFFFFFF);
            t.setBackgroundColor(ROJO);
            t.setPadding(dp(10), dp(8), dp(10), dp(8));
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                pestana = 3;
                pintar();
            });
            raiz.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        LinearLayout tabs = horizontal();
        tabs.setBackgroundColor(VERDE);
        for (int i = 0; i < PESTANAS.length; i++) {
            final int n = i;
            TextView t = texto(PESTANAS[i], 17, i == pestana, i == pestana ? 0xFFFFFFFF : VERDE_CLARO);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(12), 0, dp(12));
            if (i == pestana) t.setBackgroundColor(VERDE_VIVO);
            t.setOnClickListener(v -> {
                pestana = n;
                pintar();
            });
            tabs.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        raiz.addView(tabs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        contenido = vertical();
        raiz.addView(contenido, relleno());
        switch (pestana) {
            case 0: pintarMarcar(); break;
            case 1: pintarRegistro(); break;
            case 2: pintarContactos(); break;
            default: pintarBloqueo();
        }
    }

    private static void soltar(View v) {
        if (v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    // ================= Marcar =================

    private void pintarMarcar() {
        soltar(numero);
        soltar(coincide);
        contenido.addView(numero, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(70)));
        contenido.addView(coincide, ancho());
        mirarCoincidencia();

        String[][] t = {{"1", ""}, {"2", "ABC"}, {"3", "DEF"}, {"4", "GHI"}, {"5", "JKL"}, {"6", "MNO"},
                {"7", "PQRS"}, {"8", "TUV"}, {"9", "WXYZ"}, {"*", ""}, {"0", "+"}, {"#", ""}};
        LinearLayout tecl = vertical();
        tecl.setPadding(dp(4), 0, dp(4), 0);
        for (int f = 0; f < 4; f++) {
            LinearLayout fila = horizontal();
            for (int c = 0; c < 3; c++) {
                String[] k = t[f * 3 + c];
                Button b = boton(k[1].isEmpty() ? k[0] : k[0] + "\n" + k[1], TARJETA, NEGRO, 26);
                b.setOnClickListener(v -> meter(k[0]));
                if ("0".equals(k[0])) b.setOnLongClickListener(v -> {
                    meter("+");
                    return true;
                });
                fila.addView(b, peso(1));
            }
            tecl.addView(fila, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }
        contenido.addView(tecl, relleno());

        LinearLayout abajo = horizontal();
        abajo.setPadding(dp(4), 0, dp(4), dp(4));
        List<PhoneAccountHandle> sims = sims();
        if (sims.size() >= 2) {
            for (int i = 0; i < sims.size() && i < 2; i++) {
                PhoneAccountHandle ph = sims.get(i);
                Button b = boton("Llamar\nSIM " + (i + 1) + etiqueta(ph), VERDE_VIVO, 0xFFFFFFFF, 17);
                b.setOnClickListener(v -> llamar(numero.getText().toString(), ph));
                abajo.addView(b, peso(1));
            }
        } else {
            Button b = boton("Llamar", VERDE_VIVO, 0xFFFFFFFF, 22);
            b.setOnClickListener(v -> llamar(numero.getText().toString(), sims.isEmpty() ? null : sims.get(0)));
            abajo.addView(b, peso(2));
        }
        Button wa = boton("WhatsApp", VERDE, 0xFFFFFFFF, 15);
        wa.setOnClickListener(v -> abrirWhatsApp(numero.getText().toString()));
        abajo.addView(wa, peso(0.8f));
        Button borrar = boton("⌫", TARJETA, NEGRO, 26);
        borrar.setOnClickListener(v -> borrar());
        borrar.setOnLongClickListener(v -> {
            numero.setText("");
            return true;
        });
        abajo.addView(borrar, peso(0.7f));
        contenido.addView(abajo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78)));
    }

    /** Escribe donde está el cursor (o reemplaza lo seleccionado). */
    private void meter(String s) {
        int a = Math.max(0, numero.getSelectionStart()), b = Math.max(0, numero.getSelectionEnd());
        numero.getText().replace(Math.min(a, b), Math.max(a, b), s);
    }

    private void borrar() {
        int a = Math.max(0, numero.getSelectionStart()), b = Math.max(0, numero.getSelectionEnd());
        if (a != b) numero.getText().replace(Math.min(a, b), Math.max(a, b), "");
        else if (a > 0) numero.getText().delete(a - 1, a);
    }

    private void mirarCoincidencia() {
        if (coincide == null) return;
        String n = numero.getText().toString();
        String nom = Reglas.digitos(n).length() >= 7 ? Reglas.nombreContacto(this, n) : null;
        boolean mudo = false;
        for (Reglas.Entrada e : Reglas.lista(this)) if (Reglas.mismoNumero(e.numero, n)) mudo = true;
        String txt = nom == null ? "" : nom;
        if (mudo) txt = (txt.isEmpty() ? "" : txt + "  ·  ") + "está en mudos";
        coincide.setText(txt);
    }

    private List<PhoneAccountHandle> sims() {
        List<PhoneAccountHandle> l = new ArrayList<>();
        if (!Reglas.puede(this, Manifest.permission.READ_PHONE_STATE)) return l;
        try { l.addAll(getSystemService(TelecomManager.class).getCallCapablePhoneAccounts()); } catch (Exception ignored) {}
        return l;
    }

    private String etiqueta(PhoneAccountHandle ph) {
        try {
            PhoneAccount a = getSystemService(TelecomManager.class).getPhoneAccount(ph);
            if (a != null && a.getLabel() != null) {
                String s = a.getLabel().toString();
                if (s.length() > 10) s = s.substring(0, 10);
                return " · " + s;
            }
        } catch (Exception ignored) {}
        return "";
    }

    private void llamar(String n, PhoneAccountHandle ph) {
        n = n.trim();
        if (Reglas.digitos(n).isEmpty() && !n.contains("*") && !n.contains("#")) {
            aviso("Escriba un número primero");
            return;
        }
        if (!Reglas.puede(this, Manifest.permission.CALL_PHONE)) {
            aviso("Falta el permiso de llamadas. Vaya a Bloqueo > Permisos.");
            return;
        }
        try {
            Bundle ex = new Bundle();
            if (ph != null) ex.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, ph);
            getSystemService(TelecomManager.class).placeCall(Uri.fromParts("tel", n, null), ex);
        } catch (Exception e) {
            aviso("No se pudo llamar: " + e.getMessage());
        }
    }

    private void abrirWhatsApp(String n) {
        String d = Reglas.digitos(n);
        if (d.length() < 7) {
            aviso("Escriba un número primero");
            return;
        }
        if (d.length() == 10) d = "57" + d;
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + d));
        for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            try {
                startActivity(new Intent(i).setPackage(pkg));
                return;
            } catch (Exception ignored) {}
        }
        try { startActivity(i); } catch (Exception e) { aviso("No encontré WhatsApp"); }
    }

    // ================= Registro =================

    private void pintarRegistro() {
        LinearLayout f = horizontal();
        Button todas = boton("Todas las llamadas", verMudas ? TARJETA : VERDE_VIVO, verMudas ? NEGRO : 0xFFFFFFFF, 16);
        todas.setOnClickListener(v -> {
            verMudas = false;
            pintar();
        });
        Button mudas = boton("Mudas (no sonaron)", verMudas ? VERDE_VIVO : TARJETA, verMudas ? 0xFFFFFFFF : NEGRO, 16);
        mudas.setOnClickListener(v -> {
            verMudas = true;
            pintar();
        });
        f.addView(todas, peso(1));
        f.addView(mudas, peso(1));
        contenido.addView(f, alto(56));

        ScrollView sc = new ScrollView(this);
        LinearLayout l = vertical();
        sc.addView(l);
        contenido.addView(sc, relleno());

        if (verMudas) {
            List<Reglas.Muda> m = Reglas.mudas(this);
            if (m.isEmpty()) l.addView(nota("Todavía no ha entrado ninguna llamada muda."));
            for (Reglas.Muda x : m) {
                String nom = x.nombre.isEmpty() ? Reglas.nombreContacto(this, x.numero) : x.nombre;
                String titulo = nom != null && !nom.isEmpty() ? nom : (x.numero.isEmpty() ? "Número privado" : Reglas.formato(x.numero));
                String det = x.via + " · " + Reglas.fecha(x.cuando) + " · " + x.motivo;
                l.addView(fila("✕", AMARILLO, titulo, det, () -> opciones(nom, x.numero)));
            }
            return;
        }

        if (!Reglas.puede(this, Manifest.permission.READ_CALL_LOG)) {
            l.addView(nota("Falta el permiso para ver el registro. Vaya a Bloqueo > Permisos."));
            return;
        }
        boolean ocultar = Reglas.p(this).getBoolean("ocultarRegistro", true);
        try (Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
                        CallLog.Calls.DATE, CallLog.Calls.DURATION},
                null, null, CallLog.Calls.DATE + " DESC")) {
            int n = 0;
            while (c != null && c.moveToNext() && n < 200) {
                String num = c.getString(0) == null ? "" : c.getString(0);
                String nom = c.getString(1);
                int tipo = c.getInt(2);
                long fecha = c.getLong(3);
                long dur = c.getLong(4);
                if (ocultar && Reglas.fueMuda(this, num, fecha)) continue;
                String sim;
                int col;
                switch (tipo) {
                    case CallLog.Calls.INCOMING_TYPE: sim = "↙"; col = VERDE_VIVO; break;
                    case CallLog.Calls.OUTGOING_TYPE: sim = "↗"; col = AZUL; break;
                    case CallLog.Calls.MISSED_TYPE: sim = "↙"; col = ROJO; break;
                    default: sim = "✕"; col = GRIS;
                }
                String titulo = nom != null && !nom.isEmpty() ? nom : (num.isEmpty() ? "Número privado" : Reglas.formato(num));
                String det = Reglas.fecha(fecha) + (dur > 0 ? " · " + (dur / 60) + ":" + String.format("%02d", dur % 60) : "")
                        + (tipo == CallLog.Calls.MISSED_TYPE ? " · perdida" : "");
                final String fn = nom;
                l.addView(fila(sim, col, titulo, det, () -> opciones(fn, num)));
                n++;
            }
            if (n == 0) l.addView(nota("No hay llamadas en el registro."));
        } catch (Exception e) {
            l.addView(nota("No se pudo leer el registro."));
        }
    }

    private TextView nota(String s) {
        TextView t = texto(s, 17, false, GRIS);
        t.setPadding(dp(14), dp(16), dp(14), dp(16));
        return t;
    }

    private View fila(String simbolo, int color, String titulo, String detalle, Runnable alTocar) {
        LinearLayout f = horizontal();
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(10), dp(9), dp(10), dp(9));
        TextView s = texto(simbolo, 24, true, color);
        s.setGravity(Gravity.CENTER);
        f.addView(s, new LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout v = vertical();
        v.addView(texto(titulo, 19, true, NEGRO));
        v.addView(texto(detalle, 14, false, GRIS));
        f.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        f.setOnClickListener(x -> alTocar.run());
        LinearLayout envol = vertical();
        envol.addView(f);
        envol.addView(separador());
        return envol;
    }

    private void opciones(String nombre, String num) {
        String titulo = nombre != null && !nombre.isEmpty() ? nombre : (Reglas.digitos(num).isEmpty() ? "Número privado" : Reglas.formato(num));
        boolean enLista = false;
        for (Reglas.Entrada e : Reglas.lista(this)) if (Reglas.mismoNumero(e.numero, num)) enLista = true;
        final boolean yaEsta = enLista;
        List<String> op = new ArrayList<>();
        op.add("Llamar");
        op.add("Escribir por WhatsApp");
        op.add(yaEsta ? "Quitar de mudos" : "Poner en mudo (teléfono y WhatsApp)");
        op.add("Copiar número");
        op.add("Pasar al marcador");
        new AlertDialog.Builder(this).setTitle(titulo).setItems(op.toArray(new String[0]), (d, w) -> {
            switch (w) {
                case 0:
                    List<PhoneAccountHandle> s = sims();
                    if (s.size() >= 2) {
                        new AlertDialog.Builder(this).setTitle("¿Con cuál SIM?")
                                .setItems(new String[]{"SIM 1" + etiqueta(s.get(0)), "SIM 2" + etiqueta(s.get(1))},
                                        (d2, w2) -> llamar(num, s.get(w2))).show();
                    } else llamar(num, s.isEmpty() ? null : s.get(0));
                    break;
                case 1: abrirWhatsApp(num); break;
                case 2:
                    if (yaEsta) quitar(num);
                    else {
                        Reglas.agregar(this, nombre == null ? "" : nombre, num, true, true);
                        aviso(titulo + " quedó en mudo. No le volverá a sonar.");
                    }
                    pintar();
                    break;
                case 3:
                    getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("número", Reglas.digitos(num)));
                    aviso("Número copiado");
                    break;
                default:
                    numero.setText(Reglas.digitos(num));
                    numero.setSelection(numero.getText().length());
                    pestana = 0;
                    pintar();
            }
        }).show();
    }

    private void quitar(String num) {
        List<Reglas.Entrada> l = Reglas.lista(this);
        List<Reglas.Entrada> q = new ArrayList<>();
        for (Reglas.Entrada e : l) if (!Reglas.mismoNumero(e.numero, num)) q.add(e);
        Reglas.guardarLista(this, q);
        aviso("Quitado de mudos");
    }

    // ================= Contactos =================

    private void pintarContactos() {
        if (!Reglas.puede(this, Manifest.permission.READ_CONTACTS)) {
            contenido.addView(nota("Falta el permiso de contactos. Vaya a Bloqueo > Permisos."));
            return;
        }
        if (contactos.isEmpty()) cargarContactos();
        if (buscar == null) {
            buscar = new EditText(this);
            buscar.setHint("Buscar por nombre o número");
            buscar.setTextSize(19);
            buscar.setTextColor(NEGRO);
            buscar.setSingleLine(true);
            buscar.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
                public void onTextChanged(CharSequence s, int a, int b, int c) {}
                public void afterTextChanged(Editable e) { llenarContactos(); }
            });
        }
        soltar(buscar);
        contenido.addView(buscar, ancho());
        ScrollView sc = new ScrollView(this);
        listaContactos = vertical();
        sc.addView(listaContactos);
        contenido.addView(sc, relleno());
        llenarContactos();
    }

    private void cargarContactos() {
        Set<String> vistos = new HashSet<>();
        try (Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC")) {
            while (c != null && c.moveToNext()) {
                String nom = c.getString(0) == null ? "" : c.getString(0);
                String num = c.getString(1) == null ? "" : c.getString(1);
                String d = Reglas.digitos(num);
                String clave = nom + "|" + (d.length() > 10 ? d.substring(d.length() - 10) : d);
                if (vistos.add(clave)) contactos.add(new String[]{nom, num});
            }
        } catch (Exception ignored) {}
    }

    private void llenarContactos() {
        if (listaContactos == null) return;
        listaContactos.removeAllViews();
        String q = buscar.getText().toString().trim().toLowerCase();
        String qd = Reglas.digitos(q);
        int n = 0;
        for (String[] k : contactos) {
            boolean ok = q.isEmpty() || k[0].toLowerCase().contains(q) || (!qd.isEmpty() && Reglas.digitos(k[1]).contains(qd));
            if (!ok) continue;
            listaContactos.addView(fila("●", VERDE_VIVO, k[0], Reglas.formato(k[1]), () -> opciones(k[0], k[1])));
            if (++n >= 300) break;
        }
        if (n == 0) listaContactos.addView(nota("No encontré contactos con eso."));
    }

    // ================= Bloqueo =================

    private void pintarBloqueo() {
        ScrollView sc = new ScrollView(this);
        LinearLayout l = vertical();
        l.setPadding(dp(6), dp(6), dp(6), dp(10));
        sc.addView(l);
        contenido.addView(sc, relleno());

        List<Reglas.Entrada> lista = Reglas.lista(this);
        LinearLayout met = horizontal();
        met.addView(cifra("Mudas hoy", String.valueOf(Reglas.mudasHoy(this))), peso(1));
        met.addView(cifra("En la lista", lista.size() + (lista.size() == 1 ? " número" : " números")), peso(1));
        l.addView(met, ancho());

        l.addView(subtitulo("Lista de mudos"));
        if (lista.isEmpty()) l.addView(nota("La lista está vacía. Agregue con los botones de abajo."));
        for (Reglas.Entrada e : lista) {
            String det = (e.numero.isEmpty() ? "nombre de WhatsApp" : Reglas.formato(e.numero)) + " · " + e.alcance();
            l.addView(fila("✕", ROJO, e.titulo(), det, () -> editarEntrada(e)));
        }

        LinearLayout b1 = horizontal();
        Button escribir = boton("Escribir número", TARJETA, NEGRO, 16);
        escribir.setOnClickListener(v -> dialogoNuevo(false));
        Button reg = boton("Del registro", TARJETA, NEGRO, 16);
        reg.setOnClickListener(v -> {
            pestana = 1;
            verMudas = false;
            pintar();
            aviso("Toque la llamada y escoja \"Poner en mudo\"");
        });
        b1.addView(escribir, peso(1));
        b1.addView(reg, peso(1));
        l.addView(b1, alto(62));
        LinearLayout b2 = horizontal();
        Button cont = boton("De contactos", TARJETA, NEGRO, 16);
        cont.setOnClickListener(v -> {
            pestana = 2;
            pintar();
            aviso("Toque el contacto y escoja \"Poner en mudo\"");
        });
        Button chat = boton("Nombre de WhatsApp", TARJETA, NEGRO, 16);
        chat.setOnClickListener(v -> dialogoNuevo(true));
        b2.addView(cont, peso(1));
        b2.addView(chat, peso(1));
        l.addView(b2, alto(62));

        l.addView(subtitulo("Reglas generales"));
        l.addView(interruptor("Números ocultos o privados: mudos", "ocultos", false));
        l.addView(interruptor("Números que no tengo guardados: mudos", "desconocidos", false));
        l.addView(interruptor("De noche (10 p. m. a 6 a. m.) solo suenan mis contactos", "noche", false));
        l.addView(interruptor("Borrar las mudas del registro del celular (que no aparezcan)", "ocultarRegistro", true));

        Button ver = boton("Ver quién llamó muda y a qué hora", VERDE, 0xFFFFFFFF, 17);
        ver.setOnClickListener(v -> {
            pestana = 1;
            verMudas = true;
            pintar();
        });
        l.addView(ver, alto(60));

        l.addView(subtitulo("Permisos (actívelos una sola vez)"));
        l.addView(permiso("1. App de teléfono principal",
                "Para que la llamada muda no aparezca en pantalla. Android le pregunta: escoja \"Mis Chats\".",
                esTelefonoPrincipal(), this::pedirTelefonoPrincipal));
        l.addView(permiso("2. Llamadas, contactos y registro",
                "Le salen varias ventanas: a todas toque \"Permitir\".",
                permisosOk(), this::pedirPermisos));
        l.addView(permiso("3. Avisos de WhatsApp",
                "Para callar las llamadas de WhatsApp. Busque \"Mis Chats\" en la lista y actívelo.",
                avisosOk(), () -> abrirAjuste(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        l.addView(permiso("4. No molestar",
                "Para quitar también la vibración de WhatsApp. Busque \"Mis Chats\" y actívelo.",
                noMolestarOk(), () -> abrirAjuste(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));
        TextView xi = texto("En Xiaomi: si deja de funcionar, en Ajustes > Apps > Mis Chats ponga \"Inicio automático\" activado y Ahorro de batería en \"Sin restricciones\".", 14, false, GRIS);
        xi.setPadding(dp(6), dp(8), dp(6), dp(4));
        l.addView(xi);
        TextView guard = texto("La lista y el registro de mudas se guardan en Descargas/MiBarra/MisChats.", 14, false, GRIS);
        guard.setPadding(dp(6), dp(4), dp(6), dp(4));
        l.addView(guard);
    }

    private View cifra(String titulo, String valor) {
        LinearLayout v = vertical();
        v.setBackground(fondo(TARJETA, dp(10)));
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        v.addView(texto(titulo, 14, false, GRIS));
        v.addView(texto(valor, 24, true, NEGRO));
        return v;
    }

    private TextView subtitulo(String s) {
        TextView t = texto(s, 19, true, VERDE_OSCURO);
        t.setPadding(dp(6), dp(14), dp(6), dp(4));
        return t;
    }

    private View interruptor(String texto, String clave, boolean porDefecto) {
        CheckBox c = new CheckBox(this);
        c.setText(texto);
        c.setTextSize(17);
        c.setTextColor(NEGRO);
        c.setPadding(dp(4), dp(8), dp(4), dp(8));
        SharedPreferences sp = Reglas.p(this);
        c.setChecked(sp.getBoolean(clave, porDefecto));
        c.setOnCheckedChangeListener((b, si) -> sp.edit().putBoolean(clave, si).apply());
        return c;
    }

    private View permiso(String titulo, String explica, boolean listo, Runnable activar) {
        LinearLayout f = horizontal();
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout v = vertical();
        v.addView(texto(titulo, 17, true, NEGRO));
        v.addView(texto(explica, 14, false, GRIS));
        f.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (listo) {
            TextView ok = texto("Listo ✓", 16, true, VERDE_VIVO);
            ok.setGravity(Gravity.CENTER);
            f.addView(ok, new LinearLayout.LayoutParams(dp(96), dp(50)));
        } else {
            Button b = boton("Activar", ROJO, 0xFFFFFFFF, 16);
            b.setOnClickListener(x -> activar.run());
            f.addView(b, new LinearLayout.LayoutParams(dp(96), dp(50)));
        }
        LinearLayout envol = vertical();
        envol.addView(f);
        envol.addView(separador());
        return envol;
    }

    private void editarEntrada(Reglas.Entrada e) {
        String[] op = {"Teléfono y WhatsApp", "Solo teléfono", "Solo WhatsApp", "Cambiar nombre", "Quitar de la lista"};
        new AlertDialog.Builder(this).setTitle(e.titulo()).setItems(op, (d, w) -> {
            List<Reglas.Entrada> l = Reglas.lista(this);
            Reglas.Entrada x = null;
            for (Reglas.Entrada y : l) {
                if (y.numero.equals(e.numero) && y.nombre.equals(e.nombre)) x = y;
            }
            if (x == null) return;
            if (w == 0) { x.tel = true; x.wa = true; }
            else if (w == 1) { x.tel = true; x.wa = false; }
            else if (w == 2) { x.tel = false; x.wa = true; }
            else if (w == 3) {
                final Reglas.Entrada z = x;
                EditText et = new EditText(this);
                et.setText(z.nombre);
                et.setTextSize(19);
                new AlertDialog.Builder(this).setTitle("Nombre").setView(et)
                        .setPositiveButton("Guardar", (d2, w2) -> {
                            z.nombre = et.getText().toString().trim();
                            Reglas.guardarLista(this, l);
                            pintar();
                        }).setNegativeButton("Cancelar", null).show();
                return;
            } else l.remove(x);
            Reglas.guardarLista(this, l);
            pintar();
        }).show();
    }

    private void dialogoNuevo(boolean soloWhatsApp) {
        LinearLayout v = vertical();
        v.setPadding(dp(18), dp(8), dp(18), 0);
        EditText nom = new EditText(this);
        nom.setHint(soloWhatsApp ? "Nombre tal cual sale en WhatsApp" : "Nombre (si quiere)");
        nom.setTextSize(19);
        v.addView(nom);
        EditText num = new EditText(this);
        CheckBox tel = new CheckBox(this), wa = new CheckBox(this);
        if (!soloWhatsApp) {
            num.setHint("Número");
            num.setInputType(InputType.TYPE_CLASS_PHONE);
            num.setTextSize(22);
            v.addView(num);
            tel.setText("Callar llamadas de teléfono");
            tel.setTextSize(17);
            tel.setChecked(true);
            v.addView(tel);
            wa.setText("Callar llamadas de WhatsApp");
            wa.setTextSize(17);
            wa.setChecked(true);
            v.addView(wa);
        }
        new AlertDialog.Builder(this).setTitle(soloWhatsApp ? "Mudo por nombre de WhatsApp" : "Agregar a mudos").setView(v)
                .setPositiveButton("Agregar", (d, w) -> {
                    String n = nom.getText().toString();
                    String nu = soloWhatsApp ? "" : num.getText().toString();
                    if (n.trim().isEmpty() && Reglas.digitos(nu).isEmpty()) {
                        aviso("Escriba un número o un nombre");
                        return;
                    }
                    boolean t = !soloWhatsApp && tel.isChecked();
                    boolean wsp = soloWhatsApp || wa.isChecked();
                    if (!t && !wsp) wsp = true;
                    Reglas.agregar(this, n, nu, t, wsp);
                    aviso("Agregado a mudos");
                    pintar();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ================= Permisos =================

    private boolean esTelefonoPrincipal() {
        try {
            RoleManager rm = getSystemService(RoleManager.class);
            return rm != null && rm.isRoleHeld(RoleManager.ROLE_DIALER);
        } catch (Exception e) {
            return false;
        }
    }

    private void pedirTelefonoPrincipal() {
        try {
            RoleManager rm = getSystemService(RoleManager.class);
            startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 10);
        } catch (Exception e) {
            abrirAjuste(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS);
            aviso("Busque \"App de teléfono\" y escoja Mis Chats");
        }
    }

    private String[] permisosNecesarios() {
        List<String> l = new ArrayList<>();
        l.add(Manifest.permission.CALL_PHONE);
        l.add(Manifest.permission.READ_CALL_LOG);
        l.add(Manifest.permission.WRITE_CALL_LOG);
        l.add(Manifest.permission.READ_CONTACTS);
        l.add(Manifest.permission.READ_PHONE_STATE);
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS);
        return l.toArray(new String[0]);
    }

    private boolean permisosOk() {
        for (String p : permisosNecesarios()) if (!Reglas.puede(this, p)) return false;
        return true;
    }

    private void pedirPermisos() {
        requestPermissions(permisosNecesarios(), 11);
    }

    private boolean avisosOk() {
        try {
            return getSystemService(NotificationManager.class)
                    .isNotificationListenerAccessGranted(new ComponentName(this, OyenteWhatsApp.class));
        } catch (Exception e) {
            return false;
        }
    }

    private boolean noMolestarOk() {
        try {
            return getSystemService(NotificationManager.class).isNotificationPolicyAccessGranted();
        } catch (Exception e) {
            return false;
        }
    }

    private void abrirAjuste(String accion) {
        try {
            startActivity(new Intent(accion));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        contactos.clear();
        pintar();
    }

    @Override
    protected void onActivityResult(int code, int res, Intent data) {
        super.onActivityResult(code, res, data);
        pintar();
    }
}
