package co.jose.mischats;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Lista de números mudos, reglas generales y registro de llamadas mudas. */
final class Reglas {

    static final String CARPETA = Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MisChats/";

    static class Entrada {
        String nombre = "";
        String numero = "";
        boolean tel = true;
        boolean wa = true;

        String alcance() {
            if (tel && wa) return "Teléfono y WhatsApp";
            if (tel) return "Solo teléfono";
            return "Solo WhatsApp";
        }

        String titulo() {
            if (!nombre.isEmpty()) return nombre;
            return formato(numero);
        }
    }

    static class Decision {
        boolean muda;
        String motivo = "";
    }

    static class Muda {
        long cuando;
        String via = "", nombre = "", numero = "", motivo = "";
    }

    private Reglas() {}

    static SharedPreferences p(Context c) {
        return c.getSharedPreferences("mischats", Context.MODE_PRIVATE);
    }

    // ---------- Lista ----------

    static List<Entrada> lista(Context c) {
        List<Entrada> l = new ArrayList<>();
        String t = p(c).getString("lista", "");
        for (String linea : t.split("\n")) {
            if (linea.trim().isEmpty()) continue;
            String[] f = linea.split("\t", -1);
            Entrada e = new Entrada();
            e.nombre = f.length > 0 ? f[0] : "";
            e.numero = f.length > 1 ? f[1] : "";
            e.tel = f.length <= 2 || "1".equals(f[2]);
            e.wa = f.length <= 3 || "1".equals(f[3]);
            l.add(e);
        }
        return l;
    }

    static void guardarLista(Context c, List<Entrada> l) {
        StringBuilder b = new StringBuilder();
        StringBuilder respaldo = new StringBuilder("MIS CHATS - Lista de números mudos\n\n");
        for (Entrada e : l) {
            b.append(limpio(e.nombre)).append('\t').append(digitos(e.numero)).append('\t')
                    .append(e.tel ? "1" : "0").append('\t').append(e.wa ? "1" : "0").append('\n');
            respaldo.append(e.titulo()).append(" | ").append(formato(e.numero)).append(" | ")
                    .append(e.alcance()).append('\n');
        }
        p(c).edit().putString("lista", b.toString()).apply();
        escribirDescarga(c, "Lista_mudos.txt", respaldo.toString());
    }

    /** Agrega o actualiza. Devuelve true si era nuevo. */
    static boolean agregar(Context c, String nombre, String numero, boolean tel, boolean wa) {
        List<Entrada> l = lista(c);
        nombre = limpio(nombre);
        numero = digitos(numero);
        for (Entrada e : l) {
            boolean igual = (!numero.isEmpty() && mismoNumero(e.numero, numero))
                    || (numero.isEmpty() && e.numero.isEmpty() && !nombre.isEmpty() && e.nombre.equalsIgnoreCase(nombre));
            if (igual) {
                if (!nombre.isEmpty()) e.nombre = nombre;
                e.tel = tel;
                e.wa = wa;
                guardarLista(c, l);
                return false;
            }
        }
        Entrada e = new Entrada();
        e.nombre = nombre;
        e.numero = numero;
        e.tel = tel;
        e.wa = wa;
        l.add(0, e);
        guardarLista(c, l);
        return true;
    }

    static String limpio(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').trim();
    }

    static String digitos(String s) {
        return s == null ? "" : s.replaceAll("[^0-9]", "");
    }

    static boolean mismoNumero(String a, String b) {
        a = digitos(a);
        b = digitos(b);
        if (a.isEmpty() || b.isEmpty()) return false;
        int k = Math.min(10, Math.min(a.length(), b.length()));
        if (k < 7) return a.equals(b);
        return a.substring(a.length() - k).equals(b.substring(b.length() - k));
    }

    static String formato(String n) {
        String d = digitos(n);
        if (d.length() == 12 && d.startsWith("57")) d = d.substring(2);
        if (d.length() == 10) return d.substring(0, 3) + " " + d.substring(3, 6) + " " + d.substring(6);
        if (d.length() == 7) return d.substring(0, 3) + " " + d.substring(3);
        return n == null ? "" : n;
    }

    // ---------- Contactos ----------

    static boolean puede(Context c, String permiso) {
        return c.checkSelfPermission(permiso) == PackageManager.PERMISSION_GRANTED;
    }

    static String nombreContacto(Context c, String numero) {
        if (digitos(numero).length() < 3 || !puede(c, Manifest.permission.READ_CONTACTS)) return null;
        try {
            Uri u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(numero));
            try (Cursor cur = c.getContentResolver().query(u,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
                if (cur != null && cur.moveToFirst()) return cur.getString(0);
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** Si no hay permiso de contactos, se toma como guardado para no callar a nadie por error. */
    static boolean estaGuardado(Context c, String numero) {
        if (!puede(c, Manifest.permission.READ_CONTACTS)) return true;
        return nombreContacto(c, numero) != null;
    }

    static boolean nocheAhora(Context c) {
        int desde = p(c).getInt("nocheDesde", 22), hasta = p(c).getInt("nocheHasta", 6);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (desde > hasta) return h >= desde || h < hasta;
        return h >= desde && h < hasta;
    }

    // ---------- Decisiones ----------

    static Decision telefono(Context c, String numero, boolean visible) {
        Decision d = new Decision();
        SharedPreferences sp = p(c);
        if (!visible || digitos(numero).isEmpty()) {
            if (sp.getBoolean("ocultos", false)) {
                d.muda = true;
                d.motivo = "Número oculto o privado";
            }
            return d;
        }
        for (Entrada e : lista(c)) {
            if (e.tel && mismoNumero(e.numero, numero)) {
                d.muda = true;
                d.motivo = "Está en la lista";
                return d;
            }
        }
        boolean nuevo = sp.getBoolean("desconocidos", false) || (sp.getBoolean("noche", false) && nocheAhora(c));
        if (nuevo && !estaGuardado(c, numero)) {
            d.muda = true;
            d.motivo = sp.getBoolean("desconocidos", false) ? "No está guardado" : "Horario de noche";
        }
        return d;
    }

    static Decision whatsapp(Context c, String titulo) {
        Decision d = new Decision();
        String t = titulo == null ? "" : titulo.trim();
        if (t.isEmpty()) return d;
        for (Entrada e : lista(c)) {
            if (!e.wa) continue;
            boolean igual = !e.nombre.isEmpty() && e.nombre.equalsIgnoreCase(t);
            if (!igual && !e.numero.isEmpty()) {
                if (mismoNumero(e.numero, t)) igual = true;
                else {
                    String nc = nombreContacto(c, e.numero);
                    if (nc != null && nc.equalsIgnoreCase(t)) igual = true;
                }
            }
            if (igual) {
                d.muda = true;
                d.motivo = "Está en la lista";
                return d;
            }
        }
        boolean pareceNumero = digitos(t).length() >= 7 && t.replaceAll("[0-9+\\-() ]", "").isEmpty();
        SharedPreferences sp = p(c);
        if (pareceNumero && sp.getBoolean("desconocidos", false)) {
            d.muda = true;
            d.motivo = "No está guardado";
        } else if (pareceNumero && sp.getBoolean("noche", false) && nocheAhora(c)) {
            d.muda = true;
            d.motivo = "Horario de noche";
        }
        return d;
    }

    // ---------- Registro de mudas ----------

    static void anotar(Context c, String via, String nombre, String numero, String motivo) {
        String linea = System.currentTimeMillis() + "\t" + limpio(via) + "\t" + limpio(nombre) + "\t"
                + digitos(numero) + "\t" + limpio(motivo);
        String viejo = p(c).getString("mudas", "");
        String[] lineas = viejo.split("\n");
        StringBuilder b = new StringBuilder(linea).append('\n');
        for (int i = 0; i < lineas.length && i < 499; i++) {
            if (!lineas[i].trim().isEmpty()) b.append(lineas[i]).append('\n');
        }
        p(c).edit().putString("mudas", b.toString()).apply();
        respaldarMudas(c);
    }

    static List<Muda> mudas(Context c) {
        List<Muda> l = new ArrayList<>();
        for (String linea : p(c).getString("mudas", "").split("\n")) {
            String[] f = linea.split("\t", -1);
            if (f.length < 5) continue;
            Muda m = new Muda();
            try { m.cuando = Long.parseLong(f[0]); } catch (Exception e) { continue; }
            m.via = f[1];
            m.nombre = f[2];
            m.numero = f[3];
            m.motivo = f[4];
            l.add(m);
        }
        return l;
    }

    static int mudasHoy(Context c) {
        Calendar k = Calendar.getInstance();
        k.set(Calendar.HOUR_OF_DAY, 0);
        k.set(Calendar.MINUTE, 0);
        k.set(Calendar.SECOND, 0);
        long desde = k.getTimeInMillis();
        int n = 0;
        for (Muda m : mudas(c)) if (m.cuando >= desde) n++;
        return n;
    }

    static boolean fueMuda(Context c, String numero, long cuando) {
        for (Muda m : mudas(c)) {
            if (Math.abs(m.cuando - cuando) < 120000 && mismoNumero(m.numero, numero)) return true;
        }
        return false;
    }

    static String fecha(long t) {
        return new SimpleDateFormat("dd/MM/yyyy h:mm a", new Locale("es", "CO")).format(new Date(t));
    }

    static void respaldarMudas(Context c) {
        StringBuilder b = new StringBuilder("MIS CHATS - Llamadas mudas (no sonaron)\n\n");
        for (Muda m : mudas(c)) {
            b.append(fecha(m.cuando)).append(" | ").append(m.via).append(" | ")
                    .append(m.nombre.isEmpty() ? formato(m.numero) : m.nombre);
            if (!m.numero.isEmpty() && !m.nombre.isEmpty()) b.append(" (").append(formato(m.numero)).append(")");
            b.append(" | ").append(m.motivo).append('\n');
        }
        escribirDescarga(c, "Llamadas_mudas.txt", b.toString());
    }

    /** Borra del registro del celular una llamada muda (para que no aparezca en ningún lado). */
    static void borrarDelRegistroDelCelular(Context c, String numero, long desde) {
        if (!puede(c, Manifest.permission.WRITE_CALL_LOG) || !puede(c, Manifest.permission.READ_CALL_LOG)) return;
        try {
            ContentResolver r = c.getContentResolver();
            try (Cursor cur = r.query(CallLog.Calls.CONTENT_URI,
                    new String[]{CallLog.Calls._ID, CallLog.Calls.NUMBER},
                    CallLog.Calls.DATE + ">=?", new String[]{String.valueOf(desde - 10000)}, null)) {
                if (cur == null) return;
                while (cur.moveToNext()) {
                    String n = cur.getString(1);
                    if (mismoNumero(n, numero) || (digitos(numero).isEmpty() && digitos(n).isEmpty())) {
                        r.delete(ContentUris.withAppendedId(CallLog.Calls.CONTENT_URI, cur.getLong(0)), null, null);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    // ---------- Guardar en Descargas/MiBarra/MisChats ----------

    static void escribirDescarga(Context c, String nombre, String texto) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                ContentResolver r = app.getContentResolver();
                Uri col = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri uri = null;
                try (Cursor cur = r.query(col, new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                        new String[]{nombre, CARPETA}, null)) {
                    if (cur != null && cur.moveToFirst()) uri = ContentUris.withAppendedId(col, cur.getLong(0));
                }
                if (uri == null) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, CARPETA);
                    uri = r.insert(col, v);
                }
                if (uri == null) return;
                try (OutputStream o = r.openOutputStream(uri, "wt")) {
                    if (o != null) o.write(texto.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {}
        }).start();
    }
}
