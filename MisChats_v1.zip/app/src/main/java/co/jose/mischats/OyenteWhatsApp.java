package co.jose.mischats;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;
import java.util.Map;

/**
 * Mira los avisos de WhatsApp. Si entra una llamada de alguien de la lista,
 * le quita el timbre y la vibración y esconde el aviso. Al otro le sigue sonando.
 * No gasta batería: Android solo lo despierta cuando llega un aviso.
 */
public class OyenteWhatsApp extends NotificationListenerService {

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<String, Long> calladas = new HashMap<>();
    private final Runnable restaurar = this::devolverSonido;

    static boolean esWhatsApp(String pkg) {
        return "com.whatsapp".equals(pkg) || "com.whatsapp.w4b".equals(pkg);
    }

    @Override
    public void onListenerConnected() {
        devolverSonido();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (!esWhatsApp(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (!esLlamada(n)) return;
            Bundle ex = n.extras;
            CharSequence t = ex == null ? null : ex.getCharSequence(Notification.EXTRA_TITLE);
            String titulo = t == null ? "" : t.toString();
            Reglas.Decision d = Reglas.whatsapp(this, titulo);
            if (!d.muda) return;

            callarSonido();
            try { snoozeNotification(sbn.getKey(), 90000); } catch (Exception ignored) {}
            try { cancelNotification(sbn.getKey()); } catch (Exception ignored) {}

            Long antes = calladas.get(sbn.getKey());
            long ahora = System.currentTimeMillis();
            if (antes == null || ahora - antes > 90000) {
                String numero = Reglas.digitos(titulo).length() >= 7 ? titulo : "";
                Reglas.anotar(this, "WhatsApp", numero.isEmpty() ? titulo : "", numero, d.motivo);
            }
            calladas.put(sbn.getKey(), ahora);
            h.removeCallbacks(restaurar);
            h.postDelayed(restaurar, 75000);
        } catch (Exception ignored) {}
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rm, int razon) {
        if (razon == REASON_SNOOZED || razon == REASON_LISTENER_CANCEL) return;
        if (calladas.containsKey(sbn.getKey())) {
            calladas.remove(sbn.getKey());
            h.removeCallbacks(restaurar);
            h.postDelayed(restaurar, 2500);
        }
    }

    static boolean esLlamada(Notification n) {
        if (Notification.CATEGORY_CALL.equals(n.category)) return true;
        boolean fija = (n.flags & Notification.FLAG_ONGOING_EVENT) != 0;
        if (!fija || n.actions == null || n.actions.length < 2) return false;
        String txt = "";
        if (n.extras != null) {
            CharSequence c = n.extras.getCharSequence(Notification.EXTRA_TEXT);
            if (c != null) txt = c.toString().toLowerCase();
        }
        return txt.contains("llamada") || txt.contains("call");
    }

    private void callarSonido() {
        SharedPreferences sp = Reglas.p(this);
        AudioManager am = getSystemService(AudioManager.class);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (!sp.getBoolean("yoCalle", false)) {
            sp.edit().putBoolean("yoCalle", true).putInt("modoAntes", am.getRingerMode()).apply();
        }
        try {
            if (nm.isNotificationPolicyAccessGranted()) am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
        } catch (Exception ignored) {}
        try { am.adjustStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_MUTE, 0); } catch (Exception ignored) {}
        try { am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0); } catch (Exception ignored) {}
    }

    /** Siempre devuelve el sonido como estaba, para que el celular nunca se quede callado. */
    private void devolverSonido() {
        SharedPreferences sp = Reglas.p(this);
        if (!sp.getBoolean("yoCalle", false)) return;
        AudioManager am = getSystemService(AudioManager.class);
        NotificationManager nm = getSystemService(NotificationManager.class);
        try { am.adjustStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_UNMUTE, 0); } catch (Exception ignored) {}
        try { am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0); } catch (Exception ignored) {}
        try {
            if (nm.isNotificationPolicyAccessGranted()) am.setRingerMode(sp.getInt("modoAntes", AudioManager.RINGER_MODE_NORMAL));
        } catch (Exception ignored) {}
        sp.edit().putBoolean("yoCalle", false).apply();
    }
}
