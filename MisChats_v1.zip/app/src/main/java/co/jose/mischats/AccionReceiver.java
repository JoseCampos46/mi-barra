package co.jose.mischats;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telecom.Call;

/** Botón "Colgar" del aviso de llamada. */
public class AccionReceiver extends BroadcastReceiver {
    static final String COLGAR = "co.jose.mischats.COLGAR";

    @Override
    public void onReceive(Context c, Intent i) {
        if (COLGAR.equals(i.getAction())) {
            Call k = LlamadaService.principal();
            if (k != null) LlamadaService.colgar(k);
        }
    }
}
