package co.jose.mischats;

import android.telecom.Call;
import android.telecom.CallScreeningService;
import android.telecom.TelecomManager;

/** Android le pregunta a esta clase por cada llamada que entra: si es muda, se deja entrar sin timbre. */
public class Filtro extends CallScreeningService {

    @Override
    public void onScreenCall(Call.Details det) {
        CallResponse.Builder b = new CallResponse.Builder();
        try {
            if (det.getCallDirection() == Call.Details.DIRECTION_INCOMING) {
                String num = det.getHandle() == null ? "" : det.getHandle().getSchemeSpecificPart();
                boolean visible = det.getHandlePresentation() == TelecomManager.PRESENTATION_ALLOWED;
                Reglas.Decision d = Reglas.telefono(this, num, visible);
                if (d.muda) {
                    // No se rechaza: al otro le sigue timbrando. Aquí solo se calla el timbre.
                    b.setDisallowCall(false).setSilenceCall(true);
                }
            }
        } catch (Exception ignored) {}
        respondToCall(det, b.build());
    }
}
