package co.jose.scannerchepe;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** Ayudas comunes: colores del estilo "Fresca", letras bonitas, botones y guardar archivos. */
public abstract class Pantalla extends Activity {

    // Colores del estilo C (Fresca)
    static final int AGUA_1 = 0xFFE9FBF7, AGUA_2 = 0xFFC4F1EA, AGUA_3 = 0xFF9FDCF2;
    static final int TINTA = 0xFF0F4C5C, TURQUESA = 0xFF0F7C8C, TURQ_1 = 0xFF0F8C9A, TURQ_2 = 0xFF2BB3C8;
    static final int GRIS_OSCURO = 0xFF263238;
    static final String CARPETA = "ScannerChepe";

    private static Typeface cursiva, normal, negrilla;

    static Typeface cursiva(Context c) {
        if (cursiva == null) cursiva = letra(c, "fonts/dancing.ttf", 700);
        return cursiva;
    }

    static Typeface normal(Context c) {
        if (normal == null) normal = letra(c, "fonts/nunito.ttf", 600);
        return normal;
    }

    static Typeface negrilla(Context c) {
        if (negrilla == null) negrilla = letra(c, "fonts/nunito.ttf", 850);
        return negrilla;
    }

    private static Typeface letra(Context c, String archivo, int peso) {
        try {
            return new Typeface.Builder(c.getAssets(), archivo).setFontVariationSettings("'wght' " + peso).build();
        } catch (Exception e) {
            return peso > 650 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
    }

    void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    int dp(float v) { return dp(this, v); }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    LinearLayout.LayoutParams peso(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    LinearLayout.LayoutParams ancho(int altoDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(altoDp));
        p.topMargin = dp(8);
        return p;
    }

    static GradientDrawable fondo(int radioPx, int... colores) {
        GradientDrawable g = colores.length == 1 ? new GradientDrawable() :
                new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colores);
        if (colores.length == 1) g.setColor(colores[0]);
        g.setCornerRadius(radioPx);
        return g;
    }

    Button boton(String t, int color) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(negrilla(this));
        b.setTextColor(Color.WHITE);
        b.setBackground(fondo(dp(14), color));
        b.setStateListAnimator(null);
        return b;
    }

    /** Botón grande redondeado con el degradado turquesa. */
    Button botonGrande(String t) {
        Button b = boton(t, TURQ_1);
        b.setTextSize(21);
        b.setBackground(fondo(dp(40), TURQ_1, TURQ_2));
        b.setElevation(dp(4));
        return b;
    }

    TextView texto(String t, float sp, int color, Typeface tf) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(tf);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    /** "1,2 MB", "850 KB" */
    static String tamano(long bytes) {
        if (bytes < 0) return "calculando…";
        if (bytes < 1024 * 1024) return Math.max(1, Math.round(bytes / 1024.0)) + " KB";
        return String.format(new Locale("es", "CO"), "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    /** Guarda en el celular: PDF en Descargas/ScannerChepe, imágenes en Imágenes/ScannerChepe. */
    Uri guardar(String nombre, String mime, byte[] datos) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri donde;
        if (mime.startsWith("image/")) {
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + CARPETA);
            donde = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        } else {
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + CARPETA);
            donde = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        }
        Uri u = getContentResolver().insert(donde, v);
        if (u == null) throw new IOException("No se pudo crear el archivo");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null) throw new IOException("No se pudo escribir el archivo");
            o.write(datos);
        }
        ContentValues fin = new ContentValues();
        fin.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContentResolver().update(u, fin, null, null);
        return u;
    }

    /** Manda los archivos: a WhatsApp si se pide (y está instalado), o deja escoger la app. */
    void enviar(boolean whatsapp, String mime, Uri... archivos) {
        ArrayList<Uri> us = new ArrayList<>();
        for (Uri u : archivos) if (u != null) us.add(u);
        if (us.isEmpty()) return;
        Intent i;
        if (us.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, us.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, us);
        }
        i.setType(mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (whatsapp) {
            for (String pq : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
                try {
                    startActivity(new Intent(i).setPackage(pq));
                    return;
                } catch (Exception ignored) {}
            }
            aviso("No encontré WhatsApp; escoja la app");
        }
        startActivity(Intent.createChooser(i, "Enviar con…"));
    }
}
