package co.jose.scannerchepe;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pantalla de bienvenida: estilo "Fresca" con el nombre en letra bonita. */
public class InicioActivity extends Pantalla {

    static final String[] SONIDOS = {"🔊 Sonido: voz y pitos", "🔉 Sonido: solo pitos", "🔇 Sonido: callado"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(AGUA_1);
        getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        pintar();
    }

    private void pintar() {
        SharedPreferences pr = getSharedPreferences("chepe", MODE_PRIVATE);
        LinearLayout raiz = vertical();
        raiz.setGravity(Gravity.CENTER_HORIZONTAL);
        raiz.setPadding(dp(20), dp(26), dp(20), dp(26));

        ImageView ic = new ImageView(this);
        ic.setImageResource(R.mipmap.ic_launcher);
        ic.setElevation(dp(8));
        ic.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(android.view.View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), v.getWidth() * 0.25f);
            }
        });
        ic.setClipToOutline(true);
        LinearLayout.LayoutParams lic = new LinearLayout.LayoutParams(dp(130), dp(130));
        lic.topMargin = dp(10);
        raiz.addView(ic, lic);

        TextView t1 = texto("Scanner", 62, TURQUESA, cursiva(this));
        t1.setPadding(0, dp(18), 0, 0);
        raiz.addView(t1);
        TextView t2 = texto("Chepe Gallego", 58, TINTA, cursiva(this));
        t2.setLineSpacing(0, 0.85f);
        raiz.addView(t2);
        TextView lema = texto("Documentos derechitos, nítidos\ny en tamaño carta", 18, TINTA, normal(this));
        lema.setPadding(0, dp(14), 0, dp(10));
        raiz.addView(lema);

        String[][] filas = {{"🫧 Nivel con sonido", "💡 Luz"}, {"⚡ Disparo solo", "✂️ Esquinas"}, {"📄 PDF · JPG · PNG"}};
        for (String[] f : filas) {
            LinearLayout h = horizontal();
            h.setGravity(Gravity.CENTER);
            for (String s : f) {
                TextView ch = texto(s, 14, TURQUESA, negrilla(this));
                ch.setPadding(dp(12), dp(6), dp(12), dp(6));
                ch.setBackground(fondo(dp(20), 0x220F7C8C));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                h.addView(ch, lp);
            }
            raiz.addView(h);
        }

        Button esc = botonGrande("📸  Escanear");
        esc.setOnClickListener(v -> startActivity(new Intent(this, EscanerActivity.class)));
        LinearLayout.LayoutParams le = new LinearLayout.LayoutParams(dp(300), dp(66));
        le.topMargin = dp(28);
        raiz.addView(esc, le);

        int son = pr.getInt("sonido", 0);
        Button bs = boton(SONIDOS[son], 0x330F7C8C);
        bs.setTextColor(TINTA);
        bs.setOnClickListener(v -> {
            int n = (pr.getInt("sonido", 0) + 1) % 3;
            pr.edit().putInt("sonido", n).apply();
            bs.setText(SONIDOS[n]);
        });
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(dp(300), dp(50));
        lb.topMargin = dp(12);
        raiz.addView(bs, lb);

        TextView ay = texto("Cómo queda bonito:\n1. Ponga la hoja en una mesa con buena luz.\n"
                + "2. Ponga el celular encima, mirando la hoja.\n3. Mueva hasta que la bolita quede en el centro\n"
                + "    y suene el pitico: ¡listo!", 15, TINTA, normal(this));
        ay.setGravity(Gravity.START);
        ay.setPadding(dp(16), dp(14), dp(16), dp(14));
        ay.setBackground(fondo(dp(16), 0x88FFFFFF));
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        la.topMargin = dp(22);
        raiz.addView(ay, la);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{AGUA_1, AGUA_2, AGUA_3}));
        sv.addView(raiz);
        setContentView(sv);
    }
}
