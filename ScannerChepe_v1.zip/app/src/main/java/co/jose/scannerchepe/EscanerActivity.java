package co.jose.scannerchepe;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaActionSound;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Escáner con nivel: la cámara muestra una burbuja; pita más rápido a medida que se endereza,
 * cuando queda derecho el marco se pone verde, suena y habla, y (si quiere) toma la foto solo.
 * Luego se ajustan las 4 esquinas, se endereza, se escoge Color / Gris / Blanco y negro
 * y se guarda o se manda en PDF (tamaño carta), JPG o PNG, mostrando cuánto pesa cada uno.
 */
public class EscanerActivity extends Pantalla implements SensorEventListener {

    private static final float DERECHO = 1.5f; // grados
    private static final float CERCA = 8f;     // desde aquí empiezan los pitos
    private final Handler ui = new Handler(Looper.getMainLooper());

    // Cámara
    private TextureView textura;
    private GuiaView guia;
    private CameraDevice camara;
    private CameraCaptureSession sesion;
    private ImageReader lector;
    private HandlerThread hilo;
    private Handler fondo;
    private CaptureRequest.Builder vista;
    private String idCam;
    private int orientacionSensor = 90;
    private boolean luz, auto, tomando, enCamara;
    private Size tamVista, tamFoto;
    private Button bLuz, bAuto;

    // Nivel y sonido
    private SensorManager sm;
    private final float[] g = new float[3];
    private boolean hayDato, estabaDerecho;
    private long derechoDesde, ultimoPito, ultimaVoz;
    private ToneGenerator tono;
    private MediaActionSound clic;
    private TextToSpeech voz;
    private boolean vozLista;
    private int sonido; // 0 voz y pitos, 1 solo pitos, 2 callado
    private SharedPreferences pr;

    // Páginas
    private final List<File> paginas = new ArrayList<>();
    private Bitmap foto;
    private int filtro = 2; // 0 color, 1 gris, 2 blanco y negro
    private File carpeta;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        sm = getSystemService(SensorManager.class);
        pr = getSharedPreferences("chepe", MODE_PRIVATE);
        auto = pr.getBoolean("escAuto", false);
        filtro = pr.getInt("escFiltro", 2);
        sonido = pr.getInt("sonido", 0);
        try { tono = new ToneGenerator(AudioManager.STREAM_MUSIC, 80); } catch (Exception ignored) {}
        try { clic = new MediaActionSound(); clic.load(MediaActionSound.SHUTTER_CLICK); } catch (Exception ignored) {}
        voz = new TextToSpeech(this, s -> {
            if (s == TextToSpeech.SUCCESS) {
                int r = voz.setLanguage(new Locale("es", "CO"));
                if (r < 0) r = voz.setLanguage(new Locale("es"));
                vozLista = r >= 0;
            }
        });
        carpeta = new File(getCacheDir(), "escaner");
        carpeta.mkdirs();
        File[] viejos = carpeta.listFiles();
        if (viejos != null) for (File f : viejos) f.delete();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 5);
        pantallaCamara();
    }

    private void hablar(String t) {
        if (vozLista && voz != null) voz.speak(t, TextToSpeech.QUEUE_FLUSH, null, "chepe");
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] res) {
        super.onRequestPermissionsResult(r, p, res);
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && enCamara && textura.isAvailable()) abrirCamara();
        else if (res.length > 0 && res[0] != PackageManager.PERMISSION_GRANTED) aviso("Sin permiso de cámara no se puede escanear");
    }

    @Override
    protected void onResume() {
        super.onResume();
        sonido = pr.getInt("sonido", 0);
        Sensor s = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
        if (enCamara && textura != null && textura.isAvailable()) abrirCamara();
    }

    @Override
    protected void onPause() {
        sm.unregisterListener(this);
        cerrarCamara();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (tono != null) tono.release();
        if (clic != null) clic.release();
        if (voz != null) voz.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (!enCamara && foto != null) { foto = null; pantallaCamara(); }
        else if (enCamara && !paginas.isEmpty()) pantallaPaginas();
        else super.onBackPressed();
    }

    // ================= 1. Cámara con nivel =================

    private void pantallaCamara() {
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        enCamara = true;
        tomando = false;
        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(Color.BLACK);

        // Arriba: el nombre bonito y el botón del sonido
        LinearLayout arriba = horizontal();
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        arriba.setPadding(dp(14), dp(4), dp(8), dp(2));
        TextView nombre = texto("Scanner Chepe Gallego", 24, 0xFF9FF0E4, cursiva(this));
        nombre.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        arriba.addView(nombre, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        String[] ic = {"🔊", "🔉", "🔇"};
        Button bSon = boton(ic[sonido], 0xFF37474F);
        bSon.setTextSize(20);
        bSon.setOnClickListener(v -> {
            sonido = (sonido + 1) % 3;
            pr.edit().putInt("sonido", sonido).apply();
            bSon.setText(ic[sonido]);
            aviso(InicioActivity.SONIDOS[sonido]);
        });
        arriba.addView(bSon, new LinearLayout.LayoutParams(dp(56), dp(46)));
        raiz.addView(arriba);

        FrameLayout marco = new FrameLayout(this);
        textura = new TextureView(this);
        marco.addView(textura, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        guia = new GuiaView(this);
        marco.addView(guia, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        raiz.addView(marco, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bot = horizontal();
        bot.setGravity(Gravity.CENTER_VERTICAL);
        bot.setPadding(dp(6), dp(8), dp(6), dp(8));
        bLuz = boton(luz ? "💡 Luz: sí" : "💡 Luz", luz ? TURQ_1 : 0xFF37474F);
        bLuz.setOnClickListener(v -> {
            luz = !luz;
            bLuz.setText(luz ? "💡 Luz: sí" : "💡 Luz");
            bLuz.setBackground(fondo(dp(14), luz ? TURQ_1 : 0xFF37474F));
            repetirVista();
        });
        bot.addView(bLuz, peso(1));
        View disparo = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.WHITE);
        gd.setStroke(dp(5), 0xFF2BB3C8);
        disparo.setBackground(gd);
        disparo.setOnClickListener(v -> tomarFoto());
        LinearLayout.LayoutParams ld = new LinearLayout.LayoutParams(dp(74), dp(74));
        ld.setMargins(dp(10), 0, dp(10), 0);
        bot.addView(disparo, ld);
        bAuto = boton(auto ? "⚡ Sola: sí" : "⚡ Sola: no", auto ? TURQ_1 : 0xFF37474F);
        bAuto.setOnClickListener(v -> {
            auto = !auto;
            bAuto.setText(auto ? "⚡ Sola: sí" : "⚡ Sola: no");
            bAuto.setBackground(fondo(dp(14), auto ? TURQ_1 : 0xFF37474F));
            pr.edit().putBoolean("escAuto", auto).apply();
            aviso(auto ? "La foto se toma sola cuando el celular quede derecho" : "Toque el botón blanco para tomar la foto");
        });
        bot.addView(bAuto, peso(1));
        raiz.addView(bot);
        if (!paginas.isEmpty()) {
            Button ver = boton("📑  Ver " + paginas.size() + (paginas.size() == 1 ? " página" : " páginas") + " y guardar", 0xFF2E7D32);
            ver.setOnClickListener(v -> pantallaPaginas());
            LinearLayout.LayoutParams lv = ancho(52);
            lv.setMargins(dp(8), 0, dp(8), dp(8));
            raiz.addView(ver, lv);
        }
        setContentView(raiz);
        textura.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { abrirCamara(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) {}
        });
        if (textura.isAvailable()) abrirCamara();
    }

    private static Size mejor(Size[] ops, int maxLado, boolean cuatroTercios) {
        Size r = null;
        for (Size s : ops) {
            int largo = Math.max(s.getWidth(), s.getHeight()), corto = Math.min(s.getWidth(), s.getHeight());
            if (largo > maxLado) continue;
            if (cuatroTercios && Math.abs(largo * 3 - corto * 4) > largo / 20) continue;
            if (r == null || (long) s.getWidth() * s.getHeight() > (long) r.getWidth() * r.getHeight()) r = s;
        }
        if (r == null) r = ops[0];
        return r;
    }

    private void abrirCamara() {
        if (camara != null || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            CameraManager cm = getSystemService(CameraManager.class);
            idCam = null;
            CameraCharacteristics ch = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Integer lado = c.get(CameraCharacteristics.LENS_FACING);
                if (lado != null && lado == CameraCharacteristics.LENS_FACING_BACK) { idCam = id; ch = c; break; }
            }
            if (idCam == null) { aviso("No encontré la cámara de atrás"); return; }
            Integer o = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
            orientacionSensor = o == null ? 90 : o;
            StreamConfigurationMap mapa = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            tamVista = mejor(mapa.getOutputSizes(SurfaceTexture.class), 1920, true);
            tamFoto = mejor(mapa.getOutputSizes(ImageFormat.JPEG), 4200, true);
            ajustarTextura();
            hilo = new HandlerThread("camara");
            hilo.start();
            fondo = new Handler(hilo.getLooper());
            lector = ImageReader.newInstance(tamFoto.getWidth(), tamFoto.getHeight(), ImageFormat.JPEG, 2);
            lector.setOnImageAvailableListener(this::fotoLista, fondo);
            cm.openCamera(idCam, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { camara = c; iniciarVista(); }
                @Override public void onDisconnected(CameraDevice c) { c.close(); camara = null; }
                @Override public void onError(CameraDevice c, int e) {
                    c.close(); camara = null;
                    ui.post(() -> aviso("La cámara está ocupada. Cierre otras apps de cámara."));
                }
            }, fondo);
        } catch (Exception e) {
            aviso("No se pudo abrir la cámara: " + e.getMessage());
        }
    }

    /** La vista previa ocupa el ancho y conserva la forma de la foto (sin estirar). */
    private void ajustarTextura() {
        ui.post(() -> {
            View p = (View) textura.getParent();
            int w = p.getWidth(), h = p.getHeight();
            if (w == 0 || tamVista == null) return;
            float forma = (float) Math.max(tamVista.getWidth(), tamVista.getHeight()) / Math.min(tamVista.getWidth(), tamVista.getHeight());
            int alto = Math.round(w * forma), ancho = w;
            if (alto > h) { alto = h; ancho = Math.round(h / forma); }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ancho, alto, Gravity.CENTER);
            textura.setLayoutParams(lp);
            guia.setLayoutParams(new FrameLayout.LayoutParams(ancho, alto, Gravity.CENTER));
        });
    }

    private void iniciarVista() {
        try {
            SurfaceTexture st = textura.getSurfaceTexture();
            if (st == null) return;
            st.setDefaultBufferSize(tamVista.getWidth(), tamVista.getHeight());
            Surface s = new Surface(st);
            vista = camara.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            vista.addTarget(s);
            camara.createCaptureSession(Arrays.asList(s, lector.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession ss) { sesion = ss; repetirVista(); }
                @Override public void onConfigureFailed(CameraCaptureSession ss) { ui.post(() -> aviso("No se pudo iniciar la cámara")); }
            }, fondo);
        } catch (Exception e) {
            ui.post(() -> aviso("Error de cámara: " + e.getMessage()));
        }
    }

    private void repetirVista() {
        if (sesion == null || vista == null) return;
        try {
            vista.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            vista.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            vista.set(CaptureRequest.FLASH_MODE, luz ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            sesion.setRepeatingRequest(vista.build(), null, fondo);
        } catch (Exception ignored) {}
    }

    private void tomarFoto() {
        if (tomando || camara == null || sesion == null) return;
        tomando = true;
        try {
            CaptureRequest.Builder b = camara.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(lector.getSurface());
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            b.set(CaptureRequest.FLASH_MODE, luz ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            b.set(CaptureRequest.JPEG_QUALITY, (byte) 92);
            sesion.capture(b.build(), null, fondo);
            if (sonido < 2 && clic != null) clic.play(MediaActionSound.SHUTTER_CLICK);
            aviso("📸 Tomando…");
        } catch (Exception e) {
            tomando = false;
            aviso("No se pudo tomar la foto");
        }
    }

    private void fotoLista(ImageReader r) {
        Image im = r.acquireLatestImage();
        if (im == null) return;
        byte[] datos;
        try {
            ByteBuffer bb = im.getPlanes()[0].getBuffer();
            datos = new byte[bb.remaining()];
            bb.get(datos);
        } finally { im.close(); }
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(datos, 0, datos.length, op);
        int largo = Math.max(op.outWidth, op.outHeight), muestra = 1;
        while (largo / (muestra * 2) >= 2200) muestra *= 2;
        op = new BitmapFactory.Options();
        op.inSampleSize = muestra;
        Bitmap bm = BitmapFactory.decodeByteArray(datos, 0, datos.length, op);
        if (bm == null) { ui.post(() -> { tomando = false; aviso("La foto salió dañada, tome otra"); }); return; }
        if (orientacionSensor != 0) {
            Matrix m = new Matrix();
            m.postRotate(orientacionSensor);
            Bitmap rot = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            if (rot != bm) bm.recycle();
            bm = rot;
        }
        final Bitmap f = bm;
        ui.post(() -> { foto = f; cerrarCamara(); pantallaRecorte(); });
    }

    private void cerrarCamara() {
        try { if (sesion != null) sesion.close(); } catch (Exception ignored) {}
        sesion = null;
        if (camara != null) { camara.close(); camara = null; }
        if (lector != null) { lector.close(); lector = null; }
        if (hilo != null) { hilo.quitSafely(); hilo = null; fondo = null; }
    }

    // ----- Nivel -----

    @Override
    public void onSensorChanged(SensorEvent e) {
        float a = hayDato ? 0.15f : 1f;
        for (int i = 0; i < 3; i++) g[i] += a * (e.values[i] - g[i]);
        hayDato = true;
        if (!enCamara || guia == null) return;
        double x = Math.toDegrees(Math.atan2(g[0], g[2])), y = Math.toDegrees(Math.atan2(g[1], g[2]));
        boolean boca = g[2] > 3; // celular acostado, cámara mirando hacia la hoja
        boolean derecho = boca && Math.abs(x) < DERECHO && Math.abs(y) < DERECHO;
        guia.auto = auto;
        guia.poner(x, y, derecho, boca);
        long ahora = System.currentTimeMillis();
        double ang = Math.max(Math.abs(x), Math.abs(y));
        // Pitos que se aceleran cuando se va acercando (como el sensor de parqueo)
        if (sonido < 2 && tono != null && boca && !derecho && !tomando && ang < CERCA) {
            long intervalo = (long) (110 + (ang - DERECHO) / (CERCA - DERECHO) * 650);
            if (ahora - ultimoPito > intervalo) { tono.startTone(ToneGenerator.TONE_PROP_BEEP, 35); ultimoPito = ahora; }
        }
        if (derecho && !estabaDerecho) {
            derechoDesde = ahora;
            if (sonido < 2 && tono != null) tono.startTone(ToneGenerator.TONE_PROP_ACK, 160);
            if (sonido == 0 && !tomando && ahora - ultimaVoz > 4000) {
                hablar(auto ? "Listo, quieto" : "Derecho, tome la foto");
                ultimaVoz = ahora;
            }
        }
        estabaDerecho = derecho;
        if (auto && derecho && !tomando && ahora - derechoDesde > 1300) tomarFoto();
    }

    @Override public void onAccuracyChanged(Sensor s, int a) {}

    /** Marco de la hoja + burbuja en el centro. Verde cuando el celular está derecho. */
    static final class GuiaView extends View {
        private double x, y;
        private boolean ok, boca;
        boolean auto;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        GuiaView(Context c) { super(c); }
        void poner(double x, double y, boolean ok, boolean boca) { this.x = x; this.y = y; this.ok = ok; this.boca = boca; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), d = Pantalla.dp(getContext(), 1);
            int color = ok ? 0xFF4CFF4C : 0xFFFFC107;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4 * d);
            p.setColor(color);
            float m = 18 * d, l = 40 * d;
            float[][] esq = {{m, m, 1, 1}, {w - m, m, -1, 1}, {m, h - m, 1, -1}, {w - m, h - m, -1, -1}};
            for (float[] e : esq) {
                c.drawLine(e[0], e[1], e[0] + l * e[2], e[1], p);
                c.drawLine(e[0], e[1], e[0], e[1] + l * e[3], p);
            }
            float cx = w / 2, cy = h / 2, r = 46 * d;
            p.setStrokeWidth(2 * d);
            p.setColor(0xAAFFFFFF);
            c.drawCircle(cx, cy, r, p);
            p.setColor(color);
            c.drawCircle(cx, cy, r * DERECHO / 6f + 10 * d, p);
            double bx = Math.max(-6, Math.min(6, x)), by = Math.max(-6, Math.min(6, y));
            p.setStyle(Paint.Style.FILL);
            p.setColor(ok ? 0xDD4CFF4C : 0xDDFFFFFF);
            c.drawCircle((float) (cx - bx / 6 * r), (float) (cy + by / 6 * r), 9 * d, p);
            p.setColor(0xCC000000);
            c.drawRect(0, h - 40 * d, w, h, p);
            p.setColor(Color.WHITE);
            p.setTextSize(16 * d);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(!boca ? "Acueste el celular encima de la hoja" : ok ? (auto ? "✔ ¡Quieto! Ya la tomo…" : "✔ Derecho: ¡tome la foto!") : "Enderece hasta que la bolita quede en el centro",
                    cx, h - 14 * d, p);
        }
    }

    // ================= 2. Ajustar las 4 esquinas =================

    private RecorteView recorte;

    private void pantallaRecorte() {
        enCamara = false;
        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(0xFF263238);
        TextView ay = new TextView(this);
        ay.setText("Arrastre los 4 círculos a las esquinas de la hoja");
        ay.setTextColor(Color.WHITE);
        ay.setTextSize(16);
        ay.setGravity(Gravity.CENTER);
        ay.setPadding(0, dp(8), 0, dp(4));
        raiz.addView(ay);
        recorte = new RecorteView(this, foto);
        raiz.addView(recorte, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout f1 = horizontal();
        String[] nf = {"🎨 Color", "◐ Gris", "▣ Blanco y negro"};
        Button[] bf = new Button[3];
        for (int i = 0; i < 3; i++) {
            final int k = i;
            bf[i] = boton(nf[i], i == filtro ? TURQ_1 : 0xFF455A64);
            bf[i].setTextSize(13);
            bf[i].setOnClickListener(v -> {
                filtro = k;
                getSharedPreferences("chepe", MODE_PRIVATE).edit().putInt("escFiltro", k).apply();
                for (int j = 0; j < 3; j++) bf[j].setBackground(fondo(dp(14), j == k ? TURQ_1 : 0xFF455A64));
            });
            f1.addView(bf[i], peso(1));
        }
        raiz.addView(f1, ancho(48));
        LinearLayout f2 = horizontal();
        Button otra = boton("↺ Repetir", 0xFF6D4C41);
        otra.setOnClickListener(v -> { foto = null; pantallaCamara(); });
        Button todo = boton("⬚ Toda", 0xFF455A64);
        todo.setOnClickListener(v -> recorte.todaLaFoto());
        Button listo = boton("✔ Listo", 0xFF2E7D32);
        listo.setOnClickListener(v -> procesar());
        f2.addView(otra, peso(1));
        f2.addView(todo, peso(1));
        f2.addView(listo, peso(1.4f));
        raiz.addView(f2, ancho(56));
        setContentView(raiz);
    }

    static final class RecorteView extends View {
        final Bitmap bm;
        final PointF[] p = new PointF[4]; // en pixeles de la foto: arriba-izq, arriba-der, abajo-der, abajo-izq
        private final Matrix m = new Matrix(), inv = new Matrix();
        private final Paint linea = new Paint(Paint.ANTI_ALIAS_FLAG), punto = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int agarrado = -1;

        RecorteView(Context c, Bitmap b) {
            super(c);
            bm = b;
            float w = b.getWidth(), h = b.getHeight(), i = 0.07f;
            p[0] = new PointF(w * i, h * i); p[1] = new PointF(w * (1 - i), h * i);
            p[2] = new PointF(w * (1 - i), h * (1 - i)); p[3] = new PointF(w * i, h * (1 - i));
            linea.setStyle(Paint.Style.STROKE);
            linea.setColor(0xFF4CFF4C);
            linea.setStrokeWidth(Pantalla.dp(c, 3));
        }

        void todaLaFoto() {
            float w = bm.getWidth(), h = bm.getHeight();
            p[0].set(0, 0); p[1].set(w, 0); p[2].set(w, h); p[3].set(0, h);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float pad = Pantalla.dp(getContext(), 20);
            m.setRectToRect(new RectF(0, 0, bm.getWidth(), bm.getHeight()),
                    new RectF(pad, pad, getWidth() - pad, getHeight() - pad), Matrix.ScaleToFit.CENTER);
            m.invert(inv);
            c.drawBitmap(bm, m, null);
            float[] q = new float[8];
            for (int i = 0; i < 4; i++) { q[i * 2] = p[i].x; q[i * 2 + 1] = p[i].y; }
            m.mapPoints(q);
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) % 4;
                c.drawLine(q[i * 2], q[i * 2 + 1], q[j * 2], q[j * 2 + 1], linea);
            }
            float r = Pantalla.dp(getContext(), 16);
            for (int i = 0; i < 4; i++) {
                punto.setColor(i == agarrado ? 0xCCFFEB3B : 0x994CFF4C);
                c.drawCircle(q[i * 2], q[i * 2 + 1], r, punto);
                punto.setColor(Color.WHITE);
                c.drawCircle(q[i * 2], q[i * 2 + 1], r / 4, punto);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float[] t = {e.getX(), e.getY()};
            inv.mapPoints(t);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    float mejor = Float.MAX_VALUE;
                    agarrado = -1;
                    float lim = inv.mapRadius(Pantalla.dp(getContext(), 50));
                    for (int i = 0; i < 4; i++) {
                        float dd = (float) Math.hypot(p[i].x - t[0], p[i].y - t[1]);
                        if (dd < mejor && dd < lim) { mejor = dd; agarrado = i; }
                    }
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_MOVE:
                    if (agarrado >= 0) {
                        p[agarrado].set(Math.max(0, Math.min(bm.getWidth(), t[0])), Math.max(0, Math.min(bm.getHeight(), t[1])));
                        invalidate();
                    }
                    return true;
                default:
                    agarrado = -1;
                    invalidate();
                    return true;
            }
        }
    }

    /** Endereza la hoja (quita la perspectiva) y aplica el filtro. */
    static Bitmap enderezar(Bitmap src, PointF[] p, int filtro) {
        double arriba = Math.hypot(p[1].x - p[0].x, p[1].y - p[0].y), abajo = Math.hypot(p[2].x - p[3].x, p[2].y - p[3].y);
        double izq = Math.hypot(p[3].x - p[0].x, p[3].y - p[0].y), der = Math.hypot(p[2].x - p[1].x, p[2].y - p[1].y);
        double w = Math.max(arriba, abajo), h = Math.max(izq, der);
        double esc = Math.min(1, 2000 / Math.max(w, h));
        int ow = Math.max(10, (int) (w * esc)), oh = Math.max(10, (int) (h * esc));
        Matrix m = new Matrix();
        m.setPolyToPoly(new float[]{p[0].x, p[0].y, p[1].x, p[1].y, p[2].x, p[2].y, p[3].x, p[3].y}, 0,
                new float[]{0, 0, ow, 0, ow, oh, 0, oh}, 0, 4);
        Bitmap out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(Color.WHITE);
        Paint pa = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        if (filtro > 0) {
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(0);
            if (filtro == 2) {
                // Más contraste: el papel queda blanco y la letra negra
                float k = 2.2f, b = -255f * 0.55f;
                ColorMatrix con = new ColorMatrix(new float[]{k, 0, 0, 0, b, 0, k, 0, 0, b, 0, 0, k, 0, b, 0, 0, 0, 1, 0});
                cm.postConcat(con);
            } else {
                float k = 1.25f, b = -255f * 0.1f;
                cm.postConcat(new ColorMatrix(new float[]{k, 0, 0, 0, b, 0, k, 0, 0, b, 0, 0, k, 0, b, 0, 0, 0, 1, 0}));
            }
            pa.setColorFilter(new ColorMatrixColorFilter(cm));
        }
        c.drawBitmap(src, m, pa);
        return out;
    }

    private void procesar() {
        aviso("✔ Enderezando la hoja…");
        final PointF[] pts = recorte.p.clone();
        final Bitmap src = foto;
        new Thread(() -> {
            try {
                Bitmap hoja = enderezar(src, pts, filtro);
                File f = new File(carpeta, "pag_" + System.currentTimeMillis() + ".jpg");
                try (FileOutputStream o = new FileOutputStream(f)) { hoja.compress(Bitmap.CompressFormat.JPEG, 90, o); }
                hoja.recycle();
                ui.post(() -> { paginas.add(f); cambio(); foto = null; src.recycle(); pantallaPaginas(); });
            } catch (Throwable t) {
                ui.post(() -> aviso("No se pudo enderezar: " + t.getMessage()));
            }
        }).start();
    }

    // ================= 3. Páginas: PDF, JPG o PNG con lo que pesa cada uno =================

    private static final int PDF = 0, JPG = 1, PNG = 2;
    private static final String[] MIME = {"application/pdf", "image/jpeg", "image/png"};
    private final TextView[] pesos = new TextView[3];
    private EditText campoNombre;
    private String nombreArchivo;
    private int vuelta;                 // para no pintar tamaños de una pantalla vieja
    private int version;                // sube cada vez que cambian las páginas
    private final String[] claveGuardado = new String[3];
    private final Uri[][] guardados = new Uri[3][];

    private void cambio() { version++; }

    private void pantallaPaginas() {
        enCamara = false;
        cerrarCamara();
        getWindow().setStatusBarColor(AGUA_1);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        final int miVuelta = ++vuelta;
        LinearLayout raiz = vertical();
        raiz.setPadding(dp(14), dp(10), dp(14), dp(20));

        TextView t = texto("Scanner Chepe Gallego", 34, TURQUESA, cursiva(this));
        raiz.addView(t);
        TextView sub = texto("📄 " + paginas.size() + (paginas.size() == 1 ? " página lista" : " páginas listas"), 18, TINTA, negrilla(this));
        sub.setPadding(0, 0, 0, dp(8));
        raiz.addView(sub);

        LinearLayout tiras = horizontal();
        for (int i = 0; i < paginas.size(); i++) {
            final int k = i;
            LinearLayout c = vertical();
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            ImageView iv = new ImageView(this);
            BitmapFactory.Options op = new BitmapFactory.Options();
            op.inSampleSize = 6;
            iv.setImageBitmap(BitmapFactory.decodeFile(paginas.get(i).getAbsolutePath(), op));
            iv.setAdjustViewBounds(true);
            iv.setBackground(fondo(dp(6), Color.WHITE));
            iv.setPadding(dp(3), dp(3), dp(3), dp(3));
            iv.setElevation(dp(3));
            c.addView(iv, new LinearLayout.LayoutParams(dp(140), dp(185)));
            Button q = boton("🗑 Quitar " + (i + 1), 0xFF8D6E63);
            q.setTextSize(12);
            q.setOnClickListener(v -> {
                File f = paginas.remove(k);
                f.delete();
                new File(f.getPath().replace(".jpg", ".png")).delete();
                cambio();
                if (paginas.isEmpty()) pantallaCamara(); else pantallaPaginas();
            });
            LinearLayout.LayoutParams lq = new LinearLayout.LayoutParams(dp(140), dp(40));
            lq.topMargin = dp(4);
            c.addView(q, lq);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            tiras.addView(c, lp);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(tiras);
        raiz.addView(hs);

        Button mas = botonGrande("➕  Escanear otra página");
        mas.setTextSize(18);
        raiz.addView(mas, ancho(58));
        mas.setOnClickListener(v -> pantallaCamara());

        // Nombre del archivo (se corrige poniendo el cursor donde quiera)
        TextView en = texto("Nombre del trabajo:", 15, TINTA, negrilla(this));
        en.setGravity(Gravity.START);
        en.setPadding(dp(4), dp(16), 0, dp(2));
        raiz.addView(en);
        campoNombre = new EditText(this);
        if (nombreArchivo == null) nombreArchivo = "Escaneo " + new SimpleDateFormat("dd-MM-yyyy HH.mm", Locale.US).format(new Date());
        campoNombre.setText(nombreArchivo);
        campoNombre.setTextSize(17);
        campoNombre.setTextColor(TINTA);
        campoNombre.setTypeface(normal(this));
        campoNombre.setSingleLine(true);
        campoNombre.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        campoNombre.setBackground(fondo(dp(12), Color.WHITE));
        campoNombre.setPadding(dp(14), dp(10), dp(14), dp(10));
        raiz.addView(campoNombre, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView como = texto("¿Cómo lo quiere guardar o mandar?", 17, TINTA, negrilla(this));
        como.setPadding(0, dp(18), 0, dp(4));
        raiz.addView(como);
        raiz.addView(tarjeta(PDF, "📄 PDF", "Tamaño carta · todas las páginas en un archivo", 0xFFD32F2F));
        raiz.addView(tarjeta(JPG, "🖼 JPG", "Foto liviana · la más fácil de mandar", TURQ_1));
        raiz.addView(tarjeta(PNG, "✨ PNG", "Máxima nitidez · pesa más", 0xFF6A1B9A));

        Button nuevo = boton("✖  Empezar de nuevo", 0xFF8D6E63);
        nuevo.setOnClickListener(v -> {
            for (File f : paginas) { f.delete(); new File(f.getPath().replace(".jpg", ".png")).delete(); }
            paginas.clear();
            cambio();
            nombreArchivo = null;
            pantallaCamara();
        });
        raiz.addView(nuevo, ancho(50));

        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{AGUA_1, AGUA_2, AGUA_3}));
        sv.addView(raiz);
        setContentView(sv);
        calcularPesos(miVuelta);
    }

    private View tarjeta(int formato, String titulo, String detalle, int color) {
        LinearLayout c = vertical();
        c.setBackground(fondo(dp(18), Color.WHITE));
        c.setElevation(dp(3));
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout fila = horizontal();
        fila.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tx = vertical();
        TextView tt = texto(titulo, 22, color, negrilla(this));
        tt.setGravity(Gravity.START);
        tx.addView(tt);
        TextView dd = texto(detalle, 13, 0xFF546E7A, normal(this));
        dd.setGravity(Gravity.START);
        tx.addView(dd);
        fila.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView pe = texto("⏳ calculando…", 17, Color.WHITE, negrilla(this));
        pe.setBackground(fondo(dp(16), color));
        pe.setPadding(dp(12), dp(6), dp(12), dp(6));
        pesos[formato] = pe;
        fila.addView(pe);
        c.addView(fila);
        LinearLayout bs = horizontal();
        bs.setPadding(0, dp(8), 0, 0);
        Button g = boton("💾 Guardar", color);
        g.setTextSize(14);
        g.setOnClickListener(v -> hacer(formato, 0));
        Button w = boton("💬 WhatsApp", 0xFF25A244);
        w.setTextSize(14);
        w.setOnClickListener(v -> hacer(formato, 1));
        Button o = boton("📤 Otra app", 0xFF546E7A);
        o.setTextSize(14);
        o.setOnClickListener(v -> hacer(formato, 2));
        bs.addView(g, peso(1));
        bs.addView(w, peso(1.1f));
        bs.addView(o, peso(1));
        c.addView(bs);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        c.setLayoutParams(lp);
        return c;
    }

    /** Calcula en segundo plano cuánto pesa cada formato y lo muestra en cada tarjeta. */
    private void calcularPesos(int miVuelta) {
        final List<File> lista = new ArrayList<>(paginas);
        new Thread(() -> {
            try {
                long jpg = 0;
                for (File f : lista) jpg += f.length();
                final long j = jpg;
                ui.post(() -> ponerPeso(miVuelta, JPG, j, lista.size()));
                long pdf = archivoPdf(lista).length();
                ui.post(() -> ponerPeso(miVuelta, PDF, pdf, 1));
                long png = 0;
                for (File f : lista) png += archivoPng(f).length();
                final long p = png;
                ui.post(() -> ponerPeso(miVuelta, PNG, p, lista.size()));
            } catch (Throwable t) {
                ui.post(() -> { for (TextView v : pesos) if (v != null && miVuelta == vuelta) v.setText("—"); });
            }
        }).start();
    }

    private void ponerPeso(int miVuelta, int formato, long bytes, int archivos) {
        if (miVuelta != vuelta || pesos[formato] == null) return;
        pesos[formato].setText(tamano(bytes) + (archivos > 1 ? "\n" + archivos + " archivos" : ""));
    }

    private File pdfHecho;
    private int pdfVersion = -1;

    /** El PDF en tamaño carta (612 x 792 puntos), cada imagen centrada. Se hace una sola vez. */
    private synchronized File archivoPdf(List<File> lista) throws Exception {
        if (pdfHecho != null && pdfVersion == version && pdfHecho.exists()) return pdfHecho;
        int v = version;
        PdfDocument doc = new PdfDocument();
        try {
            for (int i = 0; i < lista.size(); i++) {
                BitmapFactory.Options op = new BitmapFactory.Options();
                op.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(lista.get(i).getAbsolutePath(), op);
                op.inJustDecodeBounds = false;
                op.inSampleSize = Math.max(op.outWidth, op.outHeight) > 2600 ? 2 : 1;
                Bitmap b = BitmapFactory.decodeFile(lista.get(i).getAbsolutePath(), op);
                boolean acostada = b.getWidth() > b.getHeight();
                int pw = acostada ? 792 : 612, ph = acostada ? 612 : 792;
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(pw, ph, i + 1).create());
                Canvas c = pg.getCanvas();
                c.drawColor(Color.WHITE);
                float esc = Math.min((pw - 24f) / b.getWidth(), (ph - 24f) / b.getHeight());
                float w = b.getWidth() * esc, h = b.getHeight() * esc;
                c.drawBitmap(b, null, new RectF((pw - w) / 2, (ph - h) / 2, (pw + w) / 2, (ph + h) / 2),
                        new Paint(Paint.FILTER_BITMAP_FLAG));
                doc.finishPage(pg);
                b.recycle();
            }
            File f = new File(carpeta, "escaneo_" + v + ".pdf");
            try (FileOutputStream o = new FileOutputStream(f)) { doc.writeTo(o); }
            if (pdfHecho != null && !pdfHecho.equals(f)) pdfHecho.delete();
            pdfHecho = f;
            pdfVersion = v;
            return f;
        } finally {
            doc.close();
        }
    }

    /** La misma página en PNG (sin pérdida). Se hace una sola vez por página. */
    private File archivoPng(File jpg) throws Exception {
        File f = new File(jpg.getPath().replace(".jpg", ".png"));
        synchronized (this) {
            if (f.exists() && f.length() > 0) return f;
            Bitmap b = BitmapFactory.decodeFile(jpg.getAbsolutePath());
            File tmp = new File(f.getPath() + ".tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) { b.compress(Bitmap.CompressFormat.PNG, 100, o); }
            b.recycle();
            tmp.renameTo(f);
        }
        return f;
    }

    private static byte[] leer(File f) throws Exception {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream((int) f.length());
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toByteArray();
        }
    }

    private static String limpio(String s) {
        s = s.trim().replaceAll("[\\\\/:*?\"<>|]", "-");
        return s.isEmpty() ? "Escaneo" : s;
    }

    /** accion: 0 guardar, 1 WhatsApp, 2 otra app. Si ya se guardó igualito, no lo repite. */
    private void hacer(int formato, int accion) {
        if (paginas.isEmpty()) { aviso("No hay páginas"); return; }
        nombreArchivo = campoNombre.getText().toString();
        final String nom = limpio(nombreArchivo);
        final String clave = nom + "#" + version;
        if (clave.equals(claveGuardado[formato]) && guardados[formato] != null) {
            if (accion == 0) aviso("Ya está guardado ✔");
            else enviar(accion == 1, MIME[formato], guardados[formato]);
            return;
        }
        aviso(accion == 0 ? "💾 Guardando…" : "📤 Preparando…");
        final List<File> lista = new ArrayList<>(paginas);
        new Thread(() -> {
            try {
                Uri[] us;
                if (formato == PDF) {
                    us = new Uri[]{guardar(nom + ".pdf", MIME[PDF], leer(archivoPdf(lista)))};
                } else {
                    us = new Uri[lista.size()];
                    String ext = formato == JPG ? ".jpg" : ".png";
                    for (int i = 0; i < lista.size(); i++) {
                        File f = formato == JPG ? lista.get(i) : archivoPng(lista.get(i));
                        String n = lista.size() == 1 ? nom + ext : nom + " p" + (i + 1) + ext;
                        us[i] = guardar(n, MIME[formato], leer(f));
                    }
                }
                final Uri[] listo = us;
                ui.post(() -> {
                    claveGuardado[formato] = clave;
                    guardados[formato] = listo;
                    if (accion == 0) aviso(formato == PDF ? "✔ PDF guardado en Descargas/ScannerChepe"
                            : "✔ Guardado en Imágenes/ScannerChepe (aparece en la Galería)");
                    else enviar(accion == 1, MIME[formato], listo);
                });
            } catch (Throwable t) {
                ui.post(() -> aviso("No se pudo guardar: " + t.getMessage()));
            }
        }).start();
    }
}
