package co.jose.mibarra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

/** Pregunta con o sin sonido, pide el permiso de grabar la pantalla (Android lo exige cada vez) y arranca. */
public class GrabarActivity extends Activity {
    private boolean audio;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (b != null) { audio = b.getBoolean("audio"); return; }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("🎥 Grabar la pantalla")
                .setMessage("¿Con sonido o sin sonido?\n\n🔇 Sin sonido ocupa menos espacio.\n\nPara parar: toque el botón rojo ⏹ de arriba a la derecha.")
                .setPositiveButton("🎤 Con sonido", (d, w) -> pedir(true))
                .setNegativeButton("🔇 Sin sonido", (d, w) -> pedir(false))
                .setOnCancelListener(d -> finish())
                .show();
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); o.putBoolean("audio", audio); }

    private void pedir(boolean conAudio) {
        audio = conAudio;
        if (audio && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 3);
            return;
        }
        proyectar();
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] res) {
        super.onRequestPermissionsResult(r, p, res);
        if (res.length == 0 || res[0] != android.content.pm.PackageManager.PERMISSION_GRANTED) audio = false;
        proyectar();
    }

    private void proyectar() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), 1);
    }

    @Override
    protected void onActivityResult(int pedido, int resultado, Intent datos) {
        super.onActivityResult(pedido, resultado, datos);
        if (resultado == RESULT_OK && datos != null) {
            startForegroundService(new Intent(this, GrabarService.class)
                    .putExtra("codigo", resultado).putExtra("datos", datos).putExtra("audio", audio));
        } else {
            Toast.makeText(this, "Grabación cancelada", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}
