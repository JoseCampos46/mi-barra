package co.jose.fotoshop;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * La mesa de trabajo: una hoja carta con capas encima.
 * Un dedo usa la herramienta; dos dedos acercan/alejan la hoja (o, en «Mover», agrandan y giran la capa).
 */
public class Lienzo extends View {

    /** Hoja carta a 150 puntos por pulgada (8,5 × 11 pulgadas). */
    public static final int ANCHO = 1275, ALTO = 1650;

    public static final int MOVER = 0, BORRAR = 1, RESTAURAR = 2, VARITA = 3, LINEA = 4, VER = 5;

    public interface Oyente {
        void cambio();
        void aviso(String s);
    }

    public final List<Capa> capas = new ArrayList<>();
    public int sel = 0;
    public int herramienta = MOVER;
    public float pincelPx = 30;         // grosor del pincel en la pantalla (si acerca la hoja, borra más fino)
    public int color = Color.BLACK;
    public Oyente oyente;

    private final Matrix vista = new Matrix();
    private boolean vistaLista;
    private final Paint pBmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint pHoja = new Paint();
    private final Paint pBorde = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLinea = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLupa = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler h = new Handler(Looper.getMainLooper());

    // ---------------- Deshacer ----------------
    private static class Paso {
        int tipo;          // 0 contenido, 1 capa agregada, 2 capa eliminada
        Capa capa;
        Bitmap bmp, original;
        final Matrix m = new Matrix();
        int indice;
    }

    private final Deque<Paso> pasos = new ArrayDeque<>();
    private static final int MAX_PASOS = 6;

    public Lienzo(Context c) {
        super(c);
        pHoja.setColor(0xFFDDDDDD);
        pBorde.setStyle(Paint.Style.STROKE);
        pBorde.setColor(0xFFFFB300);
        pLinea.setStyle(Paint.Style.STROKE);
        pLinea.setStrokeCap(Paint.Cap.ROUND);
        pLupa.setStyle(Paint.Style.STROKE);
        pLupa.setColor(Color.WHITE);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    public Capa capaSel() {
        if (capas.isEmpty()) return null;
        sel = Math.max(0, Math.min(sel, capas.size() - 1));
        return capas.get(sel);
    }

    // ---------------- Capas ----------------

    public void nuevaHoja() {
        capas.clear();
        Bitmap b = Bitmap.createBitmap(ANCHO, ALTO, Bitmap.Config.ARGB_8888);
        b.eraseColor(Color.WHITE);
        capas.add(new Capa("Hoja", "hoja", b));
        sel = 0;
        pasos.clear();
        ajustarVista();
        avisarCambio();
    }

    /** Agrega una capa encima de todas. Si centrar, la pone en la mitad de la hoja. */
    public void agregar(Capa c, boolean centrar) {
        if (centrar) {
            float esc = Math.min(1f, Math.min(ANCHO * 0.9f / c.bmp.getWidth(), ALTO * 0.9f / c.bmp.getHeight()));
            c.m.setScale(esc, esc);
            c.m.postTranslate((ANCHO - c.bmp.getWidth() * esc) / 2f, (ALTO - c.bmp.getHeight() * esc) / 2f);
        }
        capas.add(c);
        sel = capas.size() - 1;
        Paso p = new Paso();
        p.tipo = 1;
        p.capa = c;
        empujar(p);
        avisarCambio();
    }

    public void eliminar(int i) {
        if (i < 0 || i >= capas.size()) return;
        if (capas.size() == 1) { if (oyente != null) oyente.aviso("Debe quedar al menos una capa"); return; }
        Paso p = new Paso();
        p.tipo = 2;
        p.capa = capas.remove(i);
        p.indice = i;
        empujar(p);
        sel = Math.min(sel, capas.size() - 1);
        avisarCambio();
    }

    public void mover(int i, int haciaArriba) {
        int j = i + haciaArriba;
        if (i < 0 || j < 0 || i >= capas.size() || j >= capas.size()) return;
        Capa a = capas.get(i);
        capas.set(i, capas.get(j));
        capas.set(j, a);
        sel = j;
        avisarCambio();
    }

    /** Cambia lo que se ve de la capa (por ejemplo, después de quitar el fondo). */
    public void reemplazar(Capa c, Bitmap nuevo) {
        guardarPaso(c, false);
        c.bmp = nuevo;
        avisarCambio();
    }

    public void girar90() {
        Capa c = capaSel();
        if (c == null) return;
        guardarPaso(c, false);
        float[] ct = c.centro();
        c.m.postRotate(90, ct[0], ct[1]);
        avisarCambio();
    }

    private void avisarCambio() {
        invalidate();
        if (oyente != null) oyente.cambio();
    }

    // ---------------- Deshacer ----------------

    private void guardarPaso(Capa c, boolean conOriginal) {
        Paso p = new Paso();
        p.tipo = 0;
        p.capa = c;
        p.bmp = c.bmp.copy(Bitmap.Config.ARGB_8888, true);
        if (conOriginal) p.original = c.original.copy(Bitmap.Config.ARGB_8888, true);
        p.m.set(c.m);
        empujar(p);
    }

    private void guardarPasoPosicion(Capa c) {
        Paso p = new Paso();
        p.tipo = 0;
        p.capa = c;
        p.m.set(c.m);
        empujar(p);
    }

    private void empujar(Paso p) {
        pasos.push(p);
        while (pasos.size() > MAX_PASOS) pasos.removeLast();
    }

    public boolean deshacer() {
        Paso p = pasos.poll();
        if (p == null) return false;
        if (p.tipo == 0) {
            if (p.bmp != null) p.capa.bmp = p.bmp;
            if (p.original != null) p.capa.original = p.original;
            p.capa.m.set(p.m);
        } else if (p.tipo == 1) {
            capas.remove(p.capa);
        } else {
            capas.add(Math.min(p.indice, capas.size()), p.capa);
        }
        sel = Math.max(0, Math.min(sel, capas.size() - 1));
        avisarCambio();
        return true;
    }

    public void limpiarPasos() { pasos.clear(); }

    // ---------------- Dibujo ----------------

    @Override
    protected void onSizeChanged(int w, int hh, int ow, int oh) {
        super.onSizeChanged(w, hh, ow, oh);
        ajustarVista();
    }

    /** La hoja completa dentro de la pantalla. */
    public void ajustarVista() {
        if (getWidth() == 0 || getHeight() == 0) return;
        float marg = dp(6);
        float s = Math.min((getWidth() - 2 * marg) / ANCHO, (getHeight() - 2 * marg) / ALTO);
        vista.setScale(s, s);
        vista.postTranslate((getWidth() - ANCHO * s) / 2f, (getHeight() - ALTO * s) / 2f);
        vistaLista = true;
        invalidate();
    }

    private float escalaVista() {
        float[] v = new float[9];
        vista.getValues(v);
        return (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
    }

    private void escena(Canvas c, boolean conMarcas) {
        c.drawRect(0, 0, ANCHO, ALTO, pHoja);
        for (Capa k : capas) {
            if (!k.visible) continue;
            pBmp.setAlpha(Math.round(k.opacidad * 2.55f));
            c.drawBitmap(k.bmp, k.m, pBmp);
        }
        if (!conMarcas) return;
        float sv = escalaVista();
        // borde punteado de la capa escogida mientras se mueve
        Capa s = capaSel();
        if (herramienta == MOVER && s != null && !"hoja".equals(s.tipo)) {
            Path borde = new Path();
            borde.addRect(new RectF(0, 0, s.bmp.getWidth(), s.bmp.getHeight()), Path.Direction.CW);
            borde.transform(s.m);
            pBorde.setStrokeWidth(dp(2) / sv);
            pBorde.setPathEffect(new DashPathEffect(new float[]{dp(8) / sv, dp(5) / sv}, 0));
            c.drawPath(borde, pBorde);
        }
        if (lineaViva) {
            pLinea.setColor(color);
            pLinea.setStrokeWidth(pincelPx / sv);
            c.drawLine(lx0, ly0, lx1, ly1, pLinea);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF2A2F3A);
        if (!vistaLista) ajustarVista();
        c.save();
        c.concat(vista);
        escena(c, true);
        c.restore();
        // Lupa: un círculo que muestra de cerca lo que está debajo del dedo
        if (tocando && !dosDedos && (herramienta == BORRAR || herramienta == RESTAURAR || herramienta == VARITA || herramienta == LINEA)) {
            float r = dp(70);
            boolean izquierda = !(dedoX < r * 2.6f && dedoY < r * 2.6f);
            float cx = izquierda ? r + dp(10) : getWidth() - r - dp(10);
            float cy = r + dp(10);
            Path circ = new Path();
            circ.addCircle(cx, cy, r, Path.Direction.CW);
            c.save();
            c.clipPath(circ);
            c.drawColor(0xFF2A2F3A);
            c.translate(cx, cy);
            c.scale(3f, 3f);
            c.translate(-dedoX, -dedoY);
            c.concat(vista);
            escena(c, true);
            c.restore();
            pLupa.setStrokeWidth(dp(3));
            pLupa.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, pLupa);
            // el tamaño del pincel dentro de la lupa
            pLupa.setStrokeWidth(dp(1.5f));
            pLupa.setColor(herramienta == BORRAR ? 0xFFFF5252 : herramienta == RESTAURAR ? 0xFF69F0AE : 0xFFFFD54A);
            c.drawCircle(cx, cy, herramienta == VARITA ? dp(6) : pincelPx * 3f / 2f, pLupa);
        }
        // el pincel debajo del dedo
        if (tocando && !dosDedos && (herramienta == BORRAR || herramienta == RESTAURAR)) {
            pLupa.setStrokeWidth(dp(1.5f));
            pLupa.setColor(Color.WHITE);
            c.drawCircle(dedoX, dedoY, pincelPx / 2f, pLupa);
        }
    }

    /** Toda la hoja como una sola imagen (para PNG o PDF). */
    public Bitmap componer() {
        Bitmap out = Bitmap.createBitmap(ANCHO, ALTO, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        for (Capa k : capas) {
            if (!k.visible) continue;
            pBmp.setAlpha(Math.round(k.opacidad * 2.55f));
            c.drawBitmap(k.bmp, k.m, pBmp);
        }
        pBmp.setAlpha(255);
        return out;
    }

    // ---------------- Dedos ----------------

    private boolean tocando, dosDedos, pintado, lineaViva;
    private float dedoX, dedoY, antX, antY;
    private float lx0, ly0, lx1, ly1;
    private final Matrix m0 = new Matrix();
    private float d0, a0, mx0, my0;

    private float[] aHoja(float x, float y) {
        Matrix inv = new Matrix();
        vista.invert(inv);
        float[] p = {x, y};
        inv.mapPoints(p);
        return p;
    }

    /** De la pantalla a los puntos de la imagen de la capa. */
    private Matrix pantallaACapa(Capa c) {
        Matrix total = new Matrix(c.m);
        total.postConcat(vista);
        Matrix inv = new Matrix();
        total.invert(inv);
        return inv;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        Capa c = capaSel();
        if (c == null) return true;
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                tocando = true;
                dosDedos = false;
                pintado = false;
                dedoX = antX = x;
                dedoY = antY = y;
                if (herramienta == MOVER) {
                    if ("hoja".equals(c.tipo)) { if (oyente != null) oyente.aviso("Escoja a la derecha la capa que quiere mover"); }
                    else guardarPasoPosicion(c);
                } else if (herramienta == BORRAR || herramienta == RESTAURAR) {
                    if (!c.visible) { if (oyente != null) oyente.aviso("Esa capa está escondida"); }
                    else { guardarPaso(c, false); pintado = true; pintar(c, x, y, x, y); }
                } else if (herramienta == LINEA) {
                    float[] p = aHoja(x, y);
                    lx0 = lx1 = p[0];
                    ly0 = ly1 = p[1];
                    lineaViva = true;
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dosDedos = true;
                    lineaViva = false;
                    d0 = distancia(e);
                    a0 = angulo(e);
                    mx0 = (e.getX(0) + e.getX(1)) / 2f;
                    my0 = (e.getY(0) + e.getY(1)) / 2f;
                    if (herramienta == MOVER && !"hoja".equals(c.tipo)) m0.set(c.m);
                    else m0.set(vista);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dosDedos) {
                    if (e.getPointerCount() < 2) return true;
                    float s = d0 > 0 ? distancia(e) / d0 : 1f;
                    float mx = (e.getX(0) + e.getX(1)) / 2f, my = (e.getY(0) + e.getY(1)) / 2f;
                    if (herramienta == MOVER && !"hoja".equals(c.tipo)) {
                        float[] p0 = aHoja(mx0, my0), p1 = aHoja(mx, my);
                        c.m.set(m0);
                        c.m.postScale(s, s, p0[0], p0[1]);
                        c.m.postRotate(angulo(e) - a0, p0[0], p0[1]);
                        c.m.postTranslate(p1[0] - p0[0], p1[1] - p0[1]);
                    } else {
                        vista.set(m0);
                        vista.postScale(s, s, mx0, my0);
                        vista.postTranslate(mx - mx0, my - my0);
                        limitarVista();
                    }
                    invalidate();
                    return true;
                }
                dedoX = x;
                dedoY = y;
                if (herramienta == MOVER && !"hoja".equals(c.tipo)) {
                    float sv = escalaVista();
                    c.m.postTranslate((x - antX) / sv, (y - antY) / sv);
                } else if (herramienta == VER || (herramienta == MOVER && "hoja".equals(c.tipo))) {
                    vista.postTranslate(x - antX, y - antY);
                } else if (pintado) {
                    pintar(c, antX, antY, x, y);
                } else if (lineaViva) {
                    float[] p = aHoja(x, y);
                    lx1 = p[0];
                    ly1 = p[1];
                }
                antX = x;
                antY = y;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                boolean fueDos = dosDedos;
                tocando = false;
                dosDedos = false;
                if (e.getActionMasked() == MotionEvent.ACTION_UP && !fueDos) {
                    if (herramienta == LINEA && lineaViva) ponerLinea(c);
                    else if (herramienta == VARITA) varita(c, x, y);
                }
                lineaViva = false;
                pintado = false;
                avisarCambio();
                return true;
        }
        return true;
    }

    private void limitarVista() {
        float sv = escalaVista();
        float minimo = Math.min(getWidth() / (float) ANCHO, getHeight() / (float) ALTO) * 0.5f;
        float maximo = minimo * 40f;
        if (sv < minimo) vista.postScale(minimo / sv, minimo / sv, getWidth() / 2f, getHeight() / 2f);
        else if (sv > maximo) vista.postScale(maximo / sv, maximo / sv, getWidth() / 2f, getHeight() / 2f);
    }

    private static float distancia(MotionEvent e) {
        return (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
    }

    private static float angulo(MotionEvent e) {
        return (float) Math.toDegrees(Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
    }

    // ---------------- Herramientas ----------------

    /** Borra o restaura un trazo, de la pantalla a la imagen de la capa. */
    private void pintar(Capa c, float x1, float y1, float x2, float y2) {
        Matrix inv = pantallaACapa(c);
        float[] p = {x1, y1, x2, y2};
        inv.mapPoints(p);
        float grosor = Math.max(1f, inv.mapRadius(pincelPx / 2f) * 2f);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.STROKE);
        pp.setStrokeCap(Paint.Cap.ROUND);
        pp.setStrokeJoin(Paint.Join.ROUND);
        pp.setStrokeWidth(grosor);
        if (herramienta == BORRAR) {
            pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        } else {
            pp.setShader(new BitmapShader(c.original, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        }
        Canvas cv = new Canvas(c.bmp);
        if (p[0] == p[2] && p[1] == p[3]) cv.drawPoint(p[0], p[1], pp);
        else cv.drawLine(p[0], p[1], p[2], p[3], pp);
    }

    /** Línea recta en la capa escogida (también queda en su copia, para que «Restaurar» no la quite). */
    private void ponerLinea(Capa c) {
        if (Math.hypot(lx1 - lx0, ly1 - ly0) < 2) return;
        guardarPaso(c, true);
        Matrix inv = new Matrix();
        c.m.invert(inv);
        float[] p = {lx0, ly0, lx1, ly1};
        inv.mapPoints(p);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.STROKE);
        pp.setStrokeCap(Paint.Cap.ROUND);
        pp.setColor(color);
        pp.setStrokeWidth(Math.max(1f, inv.mapRadius(pincelPx / escalaVista() / 2f) * 2f));
        new Canvas(c.bmp).drawLine(p[0], p[1], p[2], p[3], pp);
        new Canvas(c.original).drawLine(p[0], p[1], p[2], p[3], pp);
    }

    /** «Borrar color»: toca un color y se borra todo lo parecido que esté pegado a ese punto. */
    private void varita(Capa c, float x, float y) {
        Matrix inv = pantallaACapa(c);
        float[] p = {x, y};
        inv.mapPoints(p);
        final int px = (int) p[0], py = (int) p[1];
        final Bitmap b = c.bmp;
        final int w = b.getWidth(), hh = b.getHeight();
        if (px < 0 || py < 0 || px >= w || py >= hh) { if (oyente != null) oyente.aviso("Toque encima de la capa escogida"); return; }
        guardarPaso(c, false);
        if (oyente != null) oyente.aviso("Borrando ese color…");
        new Thread(() -> {
            int[] px2 = new int[w * hh];
            b.getPixels(px2, 0, w, 0, 0, w, hh);
            int obj = px2[py * w + px];
            if (Color.alpha(obj) == 0) return;
            int tol = 46;
            int[] cola = new int[w * hh];
            int ini = 0, fin = 0;
            cola[fin++] = py * w + px;
            px2[py * w + px] = 0;
            while (ini < fin) {
                int k = cola[ini++];
                int kx = k % w, ky = k / w;
                int[] vec = {kx > 0 ? k - 1 : -1, kx < w - 1 ? k + 1 : -1, ky > 0 ? k - w : -1, ky < hh - 1 ? k + w : -1};
                for (int v : vec) {
                    if (v < 0) continue;
                    int col = px2[v];
                    if (Color.alpha(col) == 0) continue;
                    if (Math.abs(Color.red(col) - Color.red(obj)) <= tol && Math.abs(Color.green(col) - Color.green(obj)) <= tol
                            && Math.abs(Color.blue(col) - Color.blue(obj)) <= tol) {
                        px2[v] = 0;
                        cola[fin++] = v;
                    }
                }
            }
            h.post(() -> {
                if (!b.isRecycled() && b.isMutable()) b.setPixels(px2, 0, w, 0, 0, w, hh);
                avisarCambio();
            });
        }, "varita").start();
    }
}
