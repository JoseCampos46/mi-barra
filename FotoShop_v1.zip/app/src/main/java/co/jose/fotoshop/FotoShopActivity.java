package co.jose.fotoshop;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Foto Shop: hoja carta con capas, quitar fondo, borrar y restaurar con lupa, líneas y texto. */
public class FotoShopActivity extends Activity implements Lienzo.Oyente {

    private static final int PEDIR_FOTO = 7;
    private static final String ULTIMO = "_ultimo";

    private final Handler h = new Handler(Looper.getMainLooper());
    private Lienzo lienzo;
    private LinearLayout listaCapas;
    private final List<TextView> botonesHerr = new ArrayList<>();
    private TextView txtPincel;
    private int fotos = 0, textos = 0;
    private boolean guardando, listo;

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF151A26);
        getWindow().setNavigationBarColor(0xFF151A26);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF151A26);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));

        // Arriba: hoja nueva, abrir foto, proyectos, deshacer, guardar
        LinearLayout arriba = new LinearLayout(this);
        arriba.addView(boton("📄\nHoja carta", 0xFF1E88E5, this::preguntarHojaNueva), peso());
        arriba.addView(boton("🖼\nAbrir foto", 0xFF00897B, this::pedirFoto), peso());
        arriba.addView(boton("📂\nProyectos", 0xFF5E35B1, this::abrirProyectos), peso());
        arriba.addView(boton("↩\nDeshacer", 0xFF2B3459, () -> { if (!lienzo.deshacer()) aviso("No hay nada más para deshacer"); }), peso());
        arriba.addView(boton("💾\nGuardar", 0xFF43A047, this::menuGuardar), peso());
        raiz.addView(arriba, new LinearLayout.LayoutParams(-1, dp(56)));

        // Centro: la hoja y, a la derecha, las capas
        LinearLayout centro = new LinearLayout(this);
        lienzo = new Lienzo(this);
        lienzo.oyente = this;
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
        lp.topMargin = dp(4);
        centro.addView(lienzo, lp);
        LinearLayout colCapas = new LinearLayout(this);
        colCapas.setOrientation(LinearLayout.VERTICAL);
        TextView tc = new TextView(this);
        tc.setText("Capas");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setGravity(Gravity.CENTER);
        colCapas.addView(tc);
        ScrollView sv = new ScrollView(this);
        listaCapas = new LinearLayout(this);
        listaCapas.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listaCapas);
        colCapas.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView ayuda = new TextView(this);
        ayuda.setText("Deje el dedo en una capa para más opciones");
        ayuda.setTextColor(0xFF90A4AE);
        ayuda.setTextSize(10);
        ayuda.setGravity(Gravity.CENTER);
        colCapas.addView(ayuda);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(100), -1);
        cp.leftMargin = dp(4);
        cp.topMargin = dp(4);
        centro.addView(colCapas, cp);
        raiz.addView(centro, new LinearLayout.LayoutParams(-1, 0, 1f));

        // Herramientas: dos filas
        String[][] herr = {
                {"✋", "Mover"}, {"🧽", "Borrar"}, {"🖌", "Restaurar"}, {"✂", "Quitar fondo"}, {"🪄", "Borrar color"},
                {"📏", "Línea"}, {"🔤", "Texto"}, {"🎨", "Color"}, {"🔄", "Girar"}, {"🔍", "Lupa"}};
        Runnable[] acc = {
                () -> herramienta(Lienzo.MOVER), () -> herramienta(Lienzo.BORRAR), () -> herramienta(Lienzo.RESTAURAR),
                this::quitarFondo, () -> herramienta(Lienzo.VARITA),
                () -> herramienta(Lienzo.LINEA), this::pedirTexto, this::escogerColor, () -> lienzo.girar90(),
                () -> { if (lienzo.herramienta == Lienzo.VER) lienzo.ajustarVista(); herramienta(Lienzo.VER); }};
        int[] herrDe = {Lienzo.MOVER, Lienzo.BORRAR, Lienzo.RESTAURAR, -1, Lienzo.VARITA, Lienzo.LINEA, -1, -1, -1, Lienzo.VER};
        for (int f = 0; f < 2; f++) {
            LinearLayout fila = new LinearLayout(this);
            for (int k = 0; k < 5; k++) {
                int i = f * 5 + k;
                TextView t = boton(herr[i][0] + "\n" + herr[i][1], 0xFF2B3459, acc[i]);
                t.setTag(herrDe[i]);
                if (i == 3) ((GradientDrawable) t.getBackground()).setColor(0xFFE53935);
                if (herrDe[i] >= 0) botonesHerr.add(t);
                fila.addView(t, peso());
            }
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(52));
            fp.topMargin = dp(3);
            raiz.addView(fila, fp);
        }

        // El grosor del pincel
        LinearLayout filaP = new LinearLayout(this);
        filaP.setGravity(Gravity.CENTER_VERTICAL);
        TextView tp = new TextView(this);
        tp.setText("Pincel");
        tp.setTextColor(Color.WHITE);
        tp.setTextSize(14);
        tp.setPadding(dp(6), 0, dp(6), 0);
        filaP.addView(tp);
        SeekBar pincel = new SeekBar(this);
        pincel.setMax(79);
        pincel.setProgress(29);
        pincel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { lienzo.pincelPx = v + 1; txtPincel.setText((v + 1) + " px"); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        filaP.addView(pincel, new LinearLayout.LayoutParams(0, dp(40), 1f));
        txtPincel = new TextView(this);
        txtPincel.setText("30 px");
        txtPincel.setTextColor(0xFFFFD54A);
        txtPincel.setTextSize(14);
        txtPincel.setMinWidth(dp(54));
        filaP.addView(txtPincel);
        raiz.addView(filaP, new LinearLayout.LayoutParams(-1, dp(42)));

        setContentView(raiz);
        herramienta(Lienzo.MOVER);

        File ult = new File(carpetaProyectos(), ULTIMO);
        if (new File(ult, "capas.txt").exists()) cargarProyecto(ULTIMO, true);
        else lienzo.nuevaHoja();
        recibirCompartido(getIntent());
        listo = true;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        recibirCompartido(i);
    }

    /** Si le comparten una foto desde la galería o WhatsApp, entra como capa nueva. */
    private void recibirCompartido(Intent i) {
        if (i == null || !Intent.ACTION_SEND.equals(i.getAction())) return;
        Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u != null) cargarFoto(u);
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardarProyecto(ULTIMO, true);   // se guarda solo, para no perder el trabajo
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("¿Salir de Foto Shop? El trabajo queda guardado y al volver sigue donde lo dejó.")
                .setPositiveButton("Salir", (d, w) -> finish())
                .setNegativeButton("Seguir", null).show();
    }

    // ---------------- Botones y avisos ----------------

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void herramienta(int k) {
        lienzo.herramienta = k;
        for (TextView t : botonesHerr) {
            GradientDrawable g = (GradientDrawable) t.getBackground();
            boolean es = ((Integer) t.getTag()) == k;
            g.setColor(es ? 0xFFFB8C00 : 0xFF2B3459);
        }
        lienzo.invalidate();
        if (!listo) return;
        if (k == Lienzo.MOVER) aviso("Mover: un dedo arrastra la capa; dos dedos la agrandan y la giran");
        else if (k == Lienzo.VER) aviso("Lupa: dos dedos acercan la hoja, un dedo la corre. Toque otra vez 🔍 para ver la hoja completa");
        else if (k == Lienzo.VARITA) aviso("Toque un color de la capa escogida y se borra todo lo parecido");
    }

    @Override public void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    /** Cada vez que cambia algo se redibuja la lista de capas (la de arriba primero). */
    @Override
    public void cambio() {
        listaCapas.removeAllViews();
        for (int i = lienzo.capas.size() - 1; i >= 0; i--) {
            final int idx = i;
            Capa c = lienzo.capas.get(i);
            TextView t = new TextView(this);
            t.setText(c.icono() + " " + c.nombre + "\n" + (c.visible ? "opac. " + c.opacidad + " %" : "🙈 escondida"));
            t.setTextColor(Color.WHITE);
            t.setTextSize(12);
            t.setPadding(dp(6), dp(6), dp(4), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(idx == lienzo.sel ? 0xFF3949AB : 0xFF2B3459);
            g.setCornerRadius(dp(8));
            if (idx == lienzo.sel) g.setStroke(dp(2), 0xFFFFD54A);
            t.setBackground(g);
            t.setOnClickListener(v -> { lienzo.sel = idx; cambio(); lienzo.invalidate(); });
            t.setOnLongClickListener(v -> { lienzo.sel = idx; cambio(); opcionesCapa(idx); return true; });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(4);
            listaCapas.addView(t, p);
        }
    }

    private void opcionesCapa(int i) {
        Capa c = lienzo.capas.get(i);
        String[] ops = {"Opacidad (" + c.opacidad + " %)", c.visible ? "🙈 Esconder" : "👁 Mostrar", "⬆ Subir", "⬇ Bajar", "✏ Cambiar nombre", "🗑 Eliminar capa"};
        new AlertDialog.Builder(this).setTitle(c.icono() + " " + c.nombre).setItems(ops, (d, w) -> {
            switch (w) {
                case 0: opacidad(c); break;
                case 1: c.visible = !c.visible; cambio(); lienzo.invalidate(); break;
                case 2: lienzo.mover(i, 1); break;
                case 3: lienzo.mover(i, -1); break;
                case 4: renombrar(c); break;
                case 5: lienzo.eliminar(i); break;
            }
        }).show();
    }

    private void opacidad(Capa c) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(10), dp(20), 0);
        TextView v = new TextView(this);
        v.setText(c.opacidad + " %");
        v.setTextSize(20);
        v.setGravity(Gravity.CENTER);
        l.addView(v);
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(c.opacidad);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { c.opacidad = Math.max(5, p); v.setText(c.opacidad + " %"); lienzo.invalidate(); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
        new AlertDialog.Builder(this).setTitle("Opacidad de " + c.nombre).setView(l)
                .setPositiveButton("Listo", (d, w) -> cambio()).show();
    }

    private void renombrar(Capa c) {
        EditText e = new EditText(this);
        e.setText(c.nombre);
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Nombre de la capa").setView(e)
                .setPositiveButton("Listo", (d, w) -> { String n = e.getText().toString().trim(); if (!n.isEmpty()) c.nombre = n; cambio(); })
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Hoja y fotos ----------------

    private void preguntarHojaNueva() {
        if (lienzo.capas.size() <= 1) { lienzo.nuevaHoja(); fotos = 0; textos = 0; return; }
        new AlertDialog.Builder(this).setMessage("¿Empezar una hoja carta nueva? Lo que no haya guardado como proyecto se pierde.")
                .setPositiveButton("Hoja nueva", (d, w) -> { lienzo.nuevaHoja(); fotos = 0; textos = 0; })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirFoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*");
        try { startActivityForResult(Intent.createChooser(i, "Escoja la foto"), PEDIR_FOTO); }
        catch (Exception e) { aviso("No se pudo abrir la galería"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == PEDIR_FOTO && res == RESULT_OK && d != null && d.getData() != null) cargarFoto(d.getData());
    }

    /** Abre la foto (máximo 2048 puntos de lado, para que el celular no se ahogue), derecha y como capa nueva. */
    private void cargarFoto(Uri u) {
        aviso("Abriendo la foto…");
        new Thread(() -> {
            try {
                ContentResolver cr = getContentResolver();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = cr.openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
                int lado = Math.max(o.outWidth, o.outHeight), muestra = 1;
                while (lado / muestra > 2048) muestra *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = muestra;
                Bitmap b;
                try (InputStream in = cr.openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
                if (b == null) throw new Exception("sin imagen");
                int giro = 0;
                try (InputStream in = cr.openInputStream(u)) {
                    int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    giro = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                } catch (Exception ignored) {}
                if (giro != 0) {
                    Matrix mm = new Matrix();
                    mm.postRotate(giro);
                    b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mm, true);
                }
                final Bitmap fin = b.copy(Bitmap.Config.ARGB_8888, true);
                h.post(() -> {
                    fotos++;
                    lienzo.agregar(new Capa("Foto " + fotos, "foto", fin), true);
                    herramienta(Lienzo.MOVER);
                });
            } catch (Throwable t) {
                h.post(() -> aviso("No se pudo abrir esa foto"));
            }
        }, "foto").start();
    }

    // ---------------- Quitar fondo (programa de Google) ----------------

    private void quitarFondo() {
        Capa c = lienzo.capaSel();
        if (c == null || "hoja".equals(c.tipo)) { aviso("Escoja a la derecha la capa de la foto"); return; }
        aviso("✂ Quitando el fondo… espere unos segundos");
        try {
            SubjectSegmenter seg = SubjectSegmentation.getClient(
                    new SubjectSegmenterOptions.Builder().enableForegroundBitmap().build());
            seg.process(InputImage.fromBitmap(c.original, 0))
                    .addOnSuccessListener(r -> {
                        Bitmap fg = r.getForegroundBitmap();
                        if (fg == null) { aviso("No encontré una persona u objeto claro en la foto"); return; }
                        Bitmap nuevo = fg.copy(Bitmap.Config.ARGB_8888, true);
                        if (nuevo.getWidth() != c.original.getWidth() || nuevo.getHeight() != c.original.getHeight())
                            nuevo = Bitmap.createScaledBitmap(nuevo, c.original.getWidth(), c.original.getHeight(), true);
                        lienzo.reemplazar(c, nuevo);
                        aviso("✔ Fondo quitado. Si quitó de más, use 🖌 Restaurar");
                        seg.close();
                    })
                    .addOnFailureListener(e -> {
                        new AlertDialog.Builder(this)
                                .setMessage("La primera vez el celular necesita internet para bajar el programa de Google que quita el fondo (es una sola vez). "
                                        + "Conéctese y vuelva a tocar ✂ en un minuto.\n\nMientras tanto puede usar 🪄 Borrar color.")
                                .setPositiveButton("Entendido", null).show();
                        seg.close();
                    });
        } catch (Throwable t) {
            aviso("Este celular no pudo quitar el fondo; use 🪄 Borrar color");
        }
    }

    // ---------------- Texto y color ----------------

    private void pedirTexto() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(8), dp(18), 0);
        EditText e = new EditText(this);
        e.setHint("Escriba aquí");
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        l.addView(e);
        TextView tt = new TextView(this);
        tt.setText("Tamaño: 60");
        l.addView(tt);
        SeekBar s = new SeekBar(this);
        s.setMax(200);
        s.setProgress(60);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { tt.setText("Tamaño: " + Math.max(14, p)); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(44)));
        new AlertDialog.Builder(this).setTitle("🔤 Texto (sale en el color escogido en 🎨)").setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String txt = e.getText().toString();
                    if (txt.trim().isEmpty()) return;
                    textos++;
                    Capa c = new Capa("Texto " + textos, "texto", imagenTexto(txt, Math.max(14, s.getProgress())));
                    lienzo.agregar(c, true);
                    herramienta(Lienzo.MOVER);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private Bitmap imagenTexto(String txt, int tam) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(tam);
        p.setColor(lienzo.color);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        String[] lineas = txt.split("\n");
        int ancho = 1;
        Rect r = new Rect();
        for (String s : lineas) { p.getTextBounds(s.isEmpty() ? " " : s, 0, Math.max(1, s.length()), r); ancho = Math.max(ancho, Math.round(p.measureText(s))); }
        Paint.FontMetrics fm = p.getFontMetrics();
        float altoLinea = fm.descent - fm.ascent;
        int pad = tam / 4;
        Bitmap b = Bitmap.createBitmap(ancho + pad * 2, Math.round(altoLinea * lineas.length) + pad * 2, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        for (int i = 0; i < lineas.length; i++) c.drawText(lineas[i], pad, pad - fm.ascent + i * altoLinea, p);
        return b;
    }

    private void escogerColor() {
        final int[] colores = {Color.BLACK, Color.WHITE, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
                0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA, 0xFFD81B60, 0xFF6D4C41};
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(10), dp(14), dp(4));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int f = 0; f < 3; f++) {
            LinearLayout fila = new LinearLayout(this);
            for (int k = 0; k < 4; k++) {
                final int col = colores[f * 4 + k];
                View v = new View(this);
                GradientDrawable g = new GradientDrawable();
                g.setColor(col);
                g.setCornerRadius(dp(10));
                g.setStroke(dp(col == lienzo.color ? 4 : 1), col == lienzo.color ? 0xFFFFB300 : 0xFF888888);
                v.setBackground(g);
                v.setOnClickListener(x -> { lienzo.color = col; if (dlg[0] != null) dlg[0].dismiss(); aviso("Color listo para 📏 Línea y 🔤 Texto"); });
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(52), 1f);
                p.setMargins(dp(4), dp(4), dp(4), dp(4));
                fila.addView(v, p);
            }
            l.addView(fila);
        }
        dlg[0] = new AlertDialog.Builder(this).setTitle("🎨 Color").setView(l).show();
    }

    // ---------------- Guardar ----------------

    private void menuGuardar() {
        String[] ops = {"💾 Guardar proyecto (para seguir después con las capas)", "🖼 Imagen PNG tamaño carta",
                "📄 PDF tamaño carta", "✂ Solo la capa escogida (recorte sin fondo, PNG)", "📲 Compartir por WhatsApp"};
        new AlertDialog.Builder(this).setTitle("Guardar").setItems(ops, (d, w) -> {
            switch (w) {
                case 0: pedirNombreProyecto(); break;
                case 1: exportarPng(lienzo.componer(), "Hoja", false); break;
                case 2: exportarPdf(); break;
                case 3: {
                    Capa c = lienzo.capaSel();
                    if (c != null) exportarPng(c.bmp, c.nombre, false);
                    break;
                }
                case 4: exportarPng(lienzo.componer(), "Hoja", true); break;
            }
        }).show();
    }

    private String fecha() { return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()); }

    private Uri nuevoArchivo(String nombre, String tipo) {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, tipo);
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FotoShop");
        return getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
    }

    private void exportarPng(Bitmap b, String base, boolean compartir) {
        aviso("Guardando…");
        new Thread(() -> {
            try {
                String nom = "FotoShop_" + base.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_" + fecha() + ".png";
                Uri u = nuevoArchivo(nom, "image/png");
                try (OutputStream o = getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.PNG, 100, o); }
                h.post(() -> {
                    aviso("✔ Guardado en Descargas/FotoShop");
                    if (compartir) compartir(u, "image/png");
                });
            } catch (Throwable t) { h.post(() -> aviso("No se pudo guardar")); }
        }, "png").start();
    }

    private void exportarPdf() {
        aviso("Haciendo el PDF…");
        Bitmap hoja = lienzo.componer();
        new Thread(() -> {
            try {
                PdfDocument pdf = new PdfDocument();
                PdfDocument.Page pg = pdf.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create()); // carta en puntos
                Canvas c = pg.getCanvas();
                c.drawColor(Color.WHITE);
                c.drawBitmap(hoja, null, new Rect(0, 0, 612, 792), new Paint(Paint.FILTER_BITMAP_FLAG));
                pdf.finishPage(pg);
                Uri u = nuevoArchivo("FotoShop_Hoja_" + fecha() + ".pdf", "application/pdf");
                try (OutputStream o = getContentResolver().openOutputStream(u)) { pdf.writeTo(o); }
                pdf.close();
                h.post(() -> aviso("✔ PDF guardado en Descargas/FotoShop"));
            } catch (Throwable t) { h.post(() -> aviso("No se pudo hacer el PDF")); }
        }, "pdf").start();
    }

    private void compartir(Uri u, String tipo) {
        Intent i = new Intent(Intent.ACTION_SEND).setType(tipo).putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) {
            try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {}
        }
    }

    // ---------------- Proyectos (para seguir después) ----------------

    private File carpetaProyectos() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private void pedirNombreProyecto() {
        EditText e = new EditText(this);
        e.setText("Proyecto " + new SimpleDateFormat("dd-MM HH.mm", Locale.US).format(new Date()));
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty() || n.startsWith("_")) n = "Proyecto";
                    guardarProyecto(n, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Guarda cada capa (lo que se ve y su copia completa) y su posición. */
    private void guardarProyecto(String nombre, boolean callado) {
        if (guardando || lienzo == null || lienzo.capas.isEmpty()) return;
        guardando = true;
        final List<Capa> copia = new ArrayList<>(lienzo.capas);
        final int sel = lienzo.sel;
        new Thread(() -> {
            try {
                File dir = new File(carpetaProyectos(), nombre);
                File tmp = new File(carpetaProyectos(), nombre + ".tmp");
                borrarCarpeta(tmp);
                tmp.mkdirs();
                StringBuilder sb = new StringBuilder();
                sb.append("sel|").append(sel).append('\n');
                for (int i = 0; i < copia.size(); i++) {
                    Capa c = copia.get(i);
                    try (FileOutputStream o = new FileOutputStream(new File(tmp, "capa" + i + ".png"))) { c.bmp.compress(Bitmap.CompressFormat.PNG, 100, o); }
                    try (FileOutputStream o = new FileOutputStream(new File(tmp, "orig" + i + ".png"))) { c.original.compress(Bitmap.CompressFormat.PNG, 100, o); }
                    float[] v = new float[9];
                    c.m.getValues(v);
                    sb.append(c.nombre.replace("|", " ")).append('|').append(c.tipo).append('|').append(c.opacidad).append('|').append(c.visible);
                    for (float x : v) sb.append('|').append(x);
                    sb.append('\n');
                }
                try (FileWriter w = new FileWriter(new File(tmp, "capas.txt"))) { w.write(sb.toString()); }
                borrarCarpeta(dir);
                tmp.renameTo(dir);
                if (!callado) h.post(() -> aviso("✔ Proyecto «" + nombre + "» guardado"));
            } catch (Throwable t) {
                if (!callado) h.post(() -> aviso("No se pudo guardar el proyecto"));
            } finally { guardando = false; }
        }, "proyecto").start();
    }

    private void borrarCarpeta(File f) {
        if (f == null || !f.exists()) return;
        File[] hijos = f.listFiles();
        if (hijos != null) for (File x : hijos) x.delete();
        f.delete();
    }

    private void abrirProyectos() {
        File[] dirs = carpetaProyectos().listFiles(f -> f.isDirectory() && !f.getName().endsWith(".tmp"));
        if (dirs == null || dirs.length == 0) { aviso("Todavía no hay proyectos guardados"); return; }
        Arrays.sort(dirs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        String[] nombres = new String[dirs.length];
        for (int i = 0; i < dirs.length; i++) nombres[i] = ULTIMO.equals(dirs[i].getName()) ? "⏱ Último trabajo (automático)" : "📁 " + dirs[i].getName();
        new AlertDialog.Builder(this).setTitle("📂 Proyectos").setItems(nombres, (d, w) -> {
            String n = dirs[w].getName();
            new AlertDialog.Builder(this).setTitle(nombres[w])
                    .setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                        if (w2 == 0) cargarProyecto(n, false);
                        else new AlertDialog.Builder(this).setMessage("¿Borrar «" + n + "» para siempre?")
                                .setPositiveButton("Borrar", (d3, w3) -> { borrarCarpeta(dirs[w]); aviso("Borrado"); })
                                .setNegativeButton("Cancelar", null).show();
                    }).show();
        }).show();
    }

    private void cargarProyecto(String nombre, boolean callado) {
        File dir = new File(carpetaProyectos(), nombre);
        new Thread(() -> {
            try {
                List<Capa> nuevas = new ArrayList<>();
                int sel = 0;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inMutable = true;
                try (BufferedReader r = new BufferedReader(new FileReader(new File(dir, "capas.txt")))) {
                    String ln;
                    int i = 0;
                    while ((ln = r.readLine()) != null) {
                        String[] p = ln.split("\\|");
                        if (p[0].equals("sel")) { sel = Integer.parseInt(p[1]); continue; }
                        Bitmap b = BitmapFactory.decodeFile(new File(dir, "capa" + i + ".png").getPath(), o);
                        Bitmap or = BitmapFactory.decodeFile(new File(dir, "orig" + i + ".png").getPath(), o);
                        i++;
                        if (b == null) continue;
                        Capa c = new Capa(p[0], p[1], b);
                        if (or != null) c.original = or;
                        c.opacidad = Integer.parseInt(p[2]);
                        c.visible = Boolean.parseBoolean(p[3]);
                        float[] v = new float[9];
                        for (int k = 0; k < 9; k++) v[k] = Float.parseFloat(p[4 + k]);
                        c.m.setValues(v);
                        nuevas.add(c);
                    }
                }
                if (nuevas.isEmpty()) throw new Exception("vacío");
                final int s = sel;
                h.post(() -> {
                    lienzo.capas.clear();
                    lienzo.capas.addAll(nuevas);
                    lienzo.sel = Math.min(s, nuevas.size() - 1);
                    lienzo.limpiarPasos();
                    fotos = 0; textos = 0;
                    for (Capa c : nuevas) { if ("foto".equals(c.tipo)) fotos++; if ("texto".equals(c.tipo)) textos++; }
                    lienzo.ajustarVista();
                    cambio();
                    if (!callado) aviso("✔ Proyecto abierto");
                });
            } catch (Throwable t) {
                h.post(() -> { if (lienzo.capas.isEmpty()) lienzo.nuevaHoja(); if (!callado) aviso("No se pudo abrir ese proyecto"); });
            }
        }, "abrir").start();
    }
}
