package co.jose.fotoshop;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;

/** Una capa: su imagen, una copia sin borrar (para restaurar), su posición sobre la hoja y su opacidad. */
public class Capa {
    public String nombre;
    public String tipo;          // hoja, foto, texto
    public Bitmap bmp;           // lo que se ve (con lo borrado)
    public Bitmap original;      // la imagen completa, para «Restaurar»
    public final Matrix m = new Matrix(); // de la capa a la hoja
    public int opacidad = 100;
    public boolean visible = true;

    public Capa(String nombre, String tipo, Bitmap bmp) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.bmp = bmp;
        this.original = bmp.copy(Bitmap.Config.ARGB_8888, true);
    }

    /** El centro de la capa, en medidas de la hoja. */
    public float[] centro() {
        RectF r = new RectF(0, 0, bmp.getWidth(), bmp.getHeight());
        m.mapRect(r);
        return new float[]{r.centerX(), r.centerY()};
    }

    public String icono() {
        return "hoja".equals(tipo) ? "📄" : "texto".equals(tipo) ? "🔤" : "🖼";
    }
}
