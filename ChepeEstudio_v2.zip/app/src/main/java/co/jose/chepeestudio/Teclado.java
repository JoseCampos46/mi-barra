package co.jose.chepeestudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;

/**
 * Teclado de piano para varios dedos a la vez. Se puede deslizar el dedo de tecla en tecla.
 * Mientras más abajo toque la tecla, más fuerte suena.
 * Si "acordes solos" está prendido, la primera octava de la izquierda es para los acordes (se ve en morado).
 */
public class Teclado extends View {

    public interface Oyente {
        void tecla(int nota, int fuerza, boolean abajo);
    }

    public Oyente oyente;
    public int primera = 48;          // nota de la primera tecla blanca de la izquierda (Do)
    public int blancas = 15;          // cuántas teclas blancas se ven
    public int corte = -1;            // notas por debajo de esto son de acordes (-1 = apagado)
    private final boolean[] prendida = new boolean[128];
    private final SparseIntArray dedos = new SparseIntArray();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private static final int[] BL = {0, 2, 4, 5, 7, 9, 11};
    private static final String[] NOM = {"Do", "Re", "Mi", "Fa", "Sol", "La", "Si"};

    public Teclado(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
    }

    /** Número de la nota de la tecla blanca i (contando desde la primera). */
    private int blanca(int i) {
        int base = primera - primera % 12;
        int idx = indexBlanca(primera) + i;
        return base + (idx / 7) * 12 + BL[idx % 7];
    }

    private static int indexBlanca(int nota) {
        int pc = nota % 12;
        for (int i = 0; i < 7; i++) if (BL[i] >= pc) return i;
        return 6;
    }

    private static boolean esNegra(int n) {
        int pc = n % 12;
        return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10;
    }

    public void prender(int nota, boolean on) {
        if (nota >= 0 && nota < 128) { prendida[nota] = on; postInvalidateOnAnimation(); }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float kw = w / blancas, bh = h * 0.6f, bw = kw * 0.62f;
        p.setTextSize(Math.min(13 * dp, kw * 0.32f));
        for (int i = 0; i < blancas; i++) {
            int n = blanca(i);
            float x = i * kw;
            boolean ac = corte >= 0 && n < corte;
            p.setStyle(Paint.Style.FILL);
            p.setColor(prendida[n] ? 0xFF5DCAA5 : ac ? 0xFFCECBF6 : 0xFFFFFFFF);
            c.drawRect(x + 1, 0, x + kw - 1, h, p);
            p.setColor(0xFF000000);
            if (n % 12 == 0 || kw > 40 * dp) {
                String t = NOM[indexBlanca(n)] + (n % 12 == 0 ? (n / 12 - 1) : "");
                float tw = p.measureText(t);
                c.drawText(t, x + (kw - tw) / 2, h - 8 * dp, p);
            }
        }
        for (int i = 0; i < blancas; i++) {
            int n = blanca(i) + 1;
            if (!esNegra(n) || i == blancas - 1) continue;
            float x = (i + 1) * kw - bw / 2;
            boolean ac = corte >= 0 && n < corte;
            p.setColor(prendida[n] ? 0xFF1D9E75 : ac ? 0xFF3C3489 : 0xFF111111);
            c.drawRoundRect(x, 0, x + bw, bh, 3 * dp, 3 * dp, p);
        }
    }

    /** Qué nota hay bajo el dedo y con qué fuerza. */
    private int notaEn(float x, float y) {
        float w = getWidth(), h = getHeight();
        float kw = w / blancas, bh = h * 0.6f, bw = kw * 0.62f;
        int i = (int) Math.max(0, Math.min(blancas - 1, x / kw));
        if (y < bh) {
            // ¿negra a la derecha o a la izquierda?
            float rx = (i + 1) * kw;
            int nr = blanca(i) + 1;
            if (esNegra(nr) && i < blancas - 1 && x > rx - bw / 2) return nr;
            float lx = i * kw;
            int nl = blanca(i) - 1;
            if (i > 0 && esNegra(nl) && x < lx + bw / 2) return nl;
        }
        return blanca(i);
    }

    private int fuerza(float y) {
        float f = Math.max(0f, Math.min(1f, y / getHeight()));
        return Math.round(55 + 72 * f);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex();
            int n = notaEn(e.getX(i), e.getY(i));
            dedos.put(e.getPointerId(i), n);
            tocar(n, fuerza(e.getY(i)), true);
            getParent().requestDisallowInterceptTouchEvent(true);
        } else if (a == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                int old = dedos.get(id, -1);
                int n = notaEn(e.getX(i), e.getY(i));
                if (old != n) {
                    if (old >= 0) tocar(old, 0, false);
                    dedos.put(id, n);
                    tocar(n, fuerza(e.getY(i)), true);
                }
            }
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) {
            int i = e.getActionIndex();
            int id = e.getPointerId(i);
            int old = dedos.get(id, -1);
            if (old >= 0) tocar(old, 0, false);
            dedos.delete(id);
        } else if (a == MotionEvent.ACTION_CANCEL) {
            for (int i = 0; i < dedos.size(); i++) tocar(dedos.valueAt(i), 0, false);
            dedos.clear();
        }
        return true;
    }

    private void tocar(int n, int f, boolean abajo) {
        // si dos dedos están en la misma tecla, no la apaga hasta soltar los dos
        if (!abajo) {
            for (int i = 0; i < dedos.size(); i++) if (dedos.valueAt(i) == n && dedos.keyAt(i) >= 0) {
                int count = 0;
                for (int j = 0; j < dedos.size(); j++) if (dedos.valueAt(j) == n) count++;
                if (count > 1) return;
            }
        }
        prender(n, abajo);
        if (oyente != null) oyente.tecla(n, f, abajo);
    }
}
