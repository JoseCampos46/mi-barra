package co.jose.chepeestudio;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/**
 * Una pista de karaoke (MP3, M4A, MP4...). Se lee por pedazos (no se carga entera en memoria)
 * y suena por el mismo motor de Chepe Estudio, así queda dentro de la grabación.
 * "Quitar voz A": resta lo que suena en el centro (donde casi siempre va la voz) y deja los bajos.
 */
public final class Pista {

    private static final int SR = Motor.SR;
    private static final int CAP = SR * 2 * 4; // 4 segundos estéreo

    public final Uri uri;
    public final String nombre;
    public long durMs;
    public boolean tieneVideo;

    public volatile boolean sinVoz;
    public volatile float vol = 0.9f;
    public volatile boolean tocando;
    public volatile boolean terminada;
    public volatile String error;

    private final Context ctx;
    private final float[] ring = new float[CAP];
    private volatile long w, r;
    private volatile boolean listo = true, fin;
    private volatile int gen;
    private Thread hilo;
    private volatile long baseMs, consumidos;

    // filtro de bajos para "sin voz"
    private float lb0, lb1, lb2, la1, la2, lx1, lx2, ly1, ly2;

    public Pista(Context c, Uri u, String n) throws Exception {
        ctx = c.getApplicationContext();
        uri = u;
        nombre = n;
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(ctx, u, null);
        boolean audio = false;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat f = ex.getTrackFormat(i);
            String m = f.getString(MediaFormat.KEY_MIME);
            if (m == null) continue;
            if (m.startsWith("video/")) tieneVideo = true;
            if (m.startsWith("audio/")) {
                audio = true;
                if (f.containsKey(MediaFormat.KEY_DURATION)) durMs = Math.max(durMs, f.getLong(MediaFormat.KEY_DURATION) / 1000);
            }
        }
        ex.release();
        if (!audio) throw new Exception("ese archivo no tiene sonido");
        double w0 = 2 * Math.PI * 170 / SR, cs = Math.cos(w0), al = Math.sin(w0) / (2 * 0.707), a0 = 1 + al;
        lb0 = (float) ((1 - cs) / 2 / a0); lb1 = (float) ((1 - cs) / a0); lb2 = lb0;
        la1 = (float) (-2 * cs / a0); la2 = (float) ((1 - al) / a0);
        arrancarDesde(0);
    }

    public long posMs() { return baseMs + consumidos * 1000 / SR; }

    /** Ir a un punto de la canción (en milisegundos). */
    public void ir(long ms) {
        ms = Math.max(0, durMs > 0 ? Math.min(ms, durMs - 500) : ms);
        arrancarDesde(ms);
    }

    public void soltar() {
        gen++;
        tocando = false;
    }

    private synchronized void arrancarDesde(long ms) {
        listo = false;
        gen++;
        Thread viejo = hilo;
        if (viejo != null) try { viejo.join(800); } catch (InterruptedException ignored) {}
        w = 0;
        r = 0;
        fin = false;
        terminada = false;
        consumidos = 0;
        baseMs = ms;
        lx1 = lx2 = ly1 = ly2 = 0;
        final int g = gen;
        final long desde = ms;
        hilo = new Thread(() -> leer(g, desde), "pista");
        hilo.start();
        listo = true;
    }

    // ------------------------------------------------ hilo que lee el archivo

    private float prevL, prevR;
    private double frac;
    private float[] tmp = new float[8192 * 2];

    private void leer(int g, long desdeMs) {
        MediaExtractor ex = null;
        MediaCodec dec = null;
        try {
            ex = new MediaExtractor();
            ex.setDataSource(ctx, uri, null);
            int tr = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { tr = i; fmt = f; break; }
            }
            if (tr < 0) throw new Exception("sin sonido");
            ex.selectTrack(tr);
            long desdeUs = desdeMs * 1000;
            if (desdeUs > 0) ex.seekTo(desdeUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            dec.configure(fmt, null, null, 0);
            dec.start();
            int srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int chs = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            prevL = prevR = 0;
            frac = 0;
            boolean inEos = false;
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            while (g == gen) {
                if (!inEos) {
                    int ii = dec.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int n = ib == null ? -1 : ex.readSampleData(ib, 0);
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inEos = true;
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = dec.dequeueOutputBuffer(bi, 5000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    chs = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                } else if (oi >= 0) {
                    ByteBuffer ob = dec.getOutputBuffer(oi);
                    if (ob != null && bi.size > 0 && bi.presentationTimeUs + 30000 >= desdeUs) {
                        ob.position(bi.offset);
                        ob.limit(bi.offset + bi.size);
                        ShortBuffer sb = ob.slice().order(ByteOrder.nativeOrder()).asShortBuffer();
                        int frames = sb.remaining() / Math.max(1, chs);
                        if (tmp.length < frames * 2) tmp = new float[frames * 2];
                        for (int i = 0; i < frames; i++) {
                            float L = sb.get(i * chs) / 32768f;
                            float R = chs > 1 ? sb.get(i * chs + 1) / 32768f : L;
                            tmp[i * 2] = L;
                            tmp[i * 2 + 1] = R;
                        }
                        dec.releaseOutputBuffer(oi, false);
                        empujar(g, tmp, frames, srcRate);
                    } else {
                        dec.releaseOutputBuffer(oi, false);
                    }
                    if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
        } catch (Throwable t) {
            if (g == gen) error = t.getMessage();
        } finally {
            if (g == gen) fin = true;
            try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) {}
            try { if (ex != null) ex.release(); } catch (Exception ignored) {}
        }
    }

    /** Cambia a 44.100 Hz si hace falta y mete al tanque. */
    private void empujar(int g, float[] s, int m, int srcRate) {
        double paso = srcRate / (double) SR;
        double t = frac;
        while (t < m && g == gen) {
            int i = (int) t;
            float k = (float) (t - i);
            float aL = i == 0 ? prevL : s[(i - 1) * 2], aR = i == 0 ? prevR : s[(i - 1) * 2 + 1];
            float bL = s[i * 2], bR = s[i * 2 + 1];
            // espera si el tanque está lleno
            while (CAP - (w - r) < 2 && g == gen) { try { Thread.sleep(8); } catch (InterruptedException ignored) {} }
            if (g != gen) return;
            int p = (int) (w % CAP);
            ring[p] = aL + (bL - aL) * k;
            ring[p + 1] = aR + (bR - aR) * k;
            w += 2;
            t += paso;
        }
        frac = t - m;
        prevL = s[(m - 1) * 2];
        prevR = s[(m - 1) * 2 + 1];
    }

    // ------------------------------------------------ dentro del hilo de sonido

    public void mezclar(float[] mix, int n) {
        if (!tocando || !listo) return;
        long disp = (w - r) / 2;
        int k = (int) Math.min(n, disp);
        float v = vol;
        boolean sv = sinVoz;
        for (int i = 0; i < k; i++) {
            int p = (int) (r % CAP);
            float L = ring[p], R = ring[p + 1];
            r += 2;
            if (sv) {
                float mid = (L + R) * 0.5f;
                float y = lb0 * mid + lb1 * lx1 + lb2 * lx2 - la1 * ly1 - la2 * ly2;
                lx2 = lx1; lx1 = mid; ly2 = ly1; ly1 = y;
                float side = (L - R) * 0.8f;
                L = R = side + y;
            }
            mix[i * 2] += L * v;
            mix[i * 2 + 1] += R * v;
        }
        consumidos += k;
        if (k < n && fin && w - r < 2) { tocando = false; terminada = true; }
    }
}
