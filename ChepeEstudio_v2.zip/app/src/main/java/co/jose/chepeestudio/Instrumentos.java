package co.jose.chepeestudio;

/** Los 128 instrumentos del banco, con su nombre en español y agrupados por familia. */
public final class Instrumentos {

    public static final String[] NOMBRES = {
            "Piano de cola", "Piano brillante", "Piano eléctrico de cola", "Piano de cantina", "Piano eléctrico Rhodes", "Piano eléctrico FM", "Clavecín", "Clavinet",
            "Celesta", "Glockenspiel", "Caja de música", "Vibráfono", "Marimba", "Xilófono", "Campanas tubulares", "Dulcémele",
            "Órgano Hammond", "Órgano de percusión", "Órgano de rock", "Órgano de iglesia", "Armonio", "Acordeón", "Armónica", "Bandoneón",
            "Guitarra española", "Guitarra acústica", "Guitarra eléctrica jazz", "Guitarra eléctrica limpia", "Guitarra apagada", "Guitarra con saturación", "Guitarra distorsionada", "Armónicos de guitarra",
            "Bajo acústico", "Bajo eléctrico (dedos)", "Bajo eléctrico (púa)", "Bajo sin trastes", "Bajo slap 1", "Bajo slap 2", "Bajo sintetizado 1", "Bajo sintetizado 2",
            "Violín", "Viola", "Violonchelo", "Contrabajo", "Cuerdas en trémolo", "Cuerdas pellizcadas", "Arpa", "Timbales de orquesta",
            "Orquesta de cuerdas", "Cuerdas suaves", "Cuerdas sintetizadas 1", "Cuerdas sintetizadas 2", "Coro \"Aah\"", "Voces \"Ooh\"", "Voz sintetizada", "Golpe de orquesta",
            "Trompeta", "Trombón", "Tuba", "Trompeta con sordina", "Corno francés", "Sección de metales", "Metales sintetizados 1", "Metales sintetizados 2",
            "Saxo soprano", "Saxo alto", "Saxo tenor", "Saxo barítono", "Oboe", "Corno inglés", "Fagot", "Clarinete",
            "Flautín", "Flauta", "Flauta dulce", "Flauta de pan", "Botella soplada", "Shakuhachi", "Silbido", "Ocarina",
            "Sinte cuadrado", "Sinte sierra", "Sinte calíope", "Sinte chiff", "Sinte charango", "Sinte voz", "Sinte quintas", "Sinte bajo + melodía",
            "Fondo new age", "Fondo cálido", "Fondo polisintetizador", "Fondo coro", "Fondo arco", "Fondo metálico", "Fondo halo", "Fondo barrido",
            "Efecto lluvia", "Efecto banda sonora", "Efecto cristal", "Efecto atmósfera", "Efecto brillo", "Efecto duendes", "Efecto ecos", "Efecto ciencia ficción",
            "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba", "Gaita", "Violín country", "Shanai",
            "Campanita", "Agogó", "Tambores metálicos", "Bloque de madera", "Taiko", "Tom melódico", "Tambor sintetizado", "Platillo al revés",
            "Ruido de traste", "Respiración", "Olas del mar", "Pájaros", "Teléfono", "Helicóptero", "Aplausos", "Disparo",
    };

    public static final String[] FAMILIAS = {"Pianos", "Campanas", "Órganos y acordeón", "Guitarras", "Bajos", "Cuerdas", "Orquesta y coros",
            "Metales", "Saxos y maderas", "Flautas", "Sintetizadores", "Fondos", "Efectos", "Del mundo", "Percusión", "Sonidos"};

    /** Los más usados en la música nuestra, para tenerlos a la mano. */
    public static final int[] FAVORITOS = {0, 21, 16, 24, 65, 56, 40, 48, 73, 33, 4, 61};

    private Instrumentos() {}
}
