package co.jose.chepeestudio;

import android.annotation.SuppressLint;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

/**
 * El micrófono para cantar. Solo está prendido mientras usted lo tiene en "Sí" (no gasta batería si no).
 * La voz lleva un toque de eco/reverberación para que suene más profesional.
 * La voz va a la grabación (no al parlante, para que no pite).
 */
public final class Microfono implements Runnable {

    private static final int SR = Motor.SR, CAP = SR * 2; // 2 segundos
    private static final int PRELLENO = 2048;

    public volatile float ganancia = 1.0f;
    public volatile boolean eco = true;

    private final float[] ring = new float[CAP];
    private volatile long w, r;
    private volatile boolean corre = true, lleno;
    private Thread hilo;
    private AudioRecord ar;

    // reverberación sencilla (tipo Freeverb, en mono)
    private final float[][] comb = {new float[1116], new float[1188], new float[1277], new float[1356]};
    private final int[] ci = new int[4];
    private final float[] cstore = new float[4];
    private final float[][] ap = {new float[556], new float[441]};
    private final int[] ai = new int[2];

    @SuppressLint("MissingPermission")
    public Microfono() throws Exception {
        int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int src = MediaRecorder.AudioSource.VOICE_PERFORMANCE;
        try {
            ar = new AudioRecord(src, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192));
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) { ar.release(); ar = null; }
        } catch (Exception e) { ar = null; }
        if (ar == null)
            ar = new AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192));
        if (ar.getState() != AudioRecord.STATE_INITIALIZED) throw new Exception("el micrófono no está disponible");
        ar.startRecording();
        hilo = new Thread(this, "microfono");
        hilo.setPriority(Thread.MAX_PRIORITY);
        hilo.start();
    }

    public void apagar() {
        corre = false;
        try { if (hilo != null) hilo.join(500); } catch (InterruptedException ignored) {}
        try { ar.stop(); } catch (Exception ignored) {}
        try { ar.release(); } catch (Exception ignored) {}
    }

    @Override
    public void run() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] b = new short[512];
        while (corre) {
            int n = ar.read(b, 0, b.length);
            if (n <= 0) continue;
            float g = ganancia;
            boolean e = eco;
            for (int i = 0; i < n; i++) {
                float x = b[i] / 32768f * g;
                if (e) x = x + reverb(x) * 0.28f;
                if (CAP - (w - r) < 1) r++; // si nadie lo lee, bota lo más viejo
                ring[(int) (w % CAP)] = x;
                w++;
            }
            // que no se acumule atraso: máximo ~0,2 s guardados
            if (w - r > PRELLENO * 4) r = w - PRELLENO;
        }
    }

    private float reverb(float x) {
        float in = x * 0.3f, out = 0;
        for (int k = 0; k < 4; k++) {
            float[] c = comb[k];
            float y = c[ci[k]];
            cstore[k] = y * 0.8f + cstore[k] * 0.2f;
            c[ci[k]] = in + cstore[k] * 0.78f;
            ci[k] = (ci[k] + 1) % c.length;
            out += y;
        }
        for (int k = 0; k < 2; k++) {
            float[] a = ap[k];
            float bo = a[ai[k]];
            a[ai[k]] = out + bo * 0.5f;
            out = bo - out;
            ai[k] = (ai[k] + 1) % a.length;
        }
        return out;
    }

    /** Toma n muestras (mono). Si todavía no hay suficiente, entrega silencio. */
    public void leer(float[] dst, int n) {
        long disp = w - r;
        if (!lleno) {
            if (disp >= PRELLENO) lleno = true;
            else { java.util.Arrays.fill(dst, 0, n, 0f); return; }
        }
        int k = (int) Math.min(n, disp);
        for (int i = 0; i < k; i++) { dst[i] = ring[(int) (r % CAP)]; r++; }
        if (k < n) { java.util.Arrays.fill(dst, k, n, 0f); lleno = false; }
    }
}
