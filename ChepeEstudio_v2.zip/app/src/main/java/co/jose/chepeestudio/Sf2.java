package co.jose.chepeestudio;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Lee un banco de sonidos SoundFont (.sf2): instrumentos reales grabados nota por nota.
 * Para cada nota tocada entrega las "zonas" (pedazos de sonido) que hay que hacer sonar.
 */
public final class Sf2 {

    /** Un pedazo de sonido listo para tocar. */
    public static final class Zone {
        public int keyLo = 0, keyHi = 127, velLo = 0, velHi = 127;
        public int start, end, loopStart, loopEnd, sampleRate = 44100;
        public int rootKey = 60, loopMode;
        public float tuneCents, scaleTuning = 100f, attenuation, pan; // pan -500..500
        public float delay, attack, hold, decay, sustainDb, release; // segundos / dB
        public float filterHz = 20000;
        public int exclusive;
    }

    public static final class Preset {
        public String name;
        public int bank, program;
        public final List<Zone> zones = new ArrayList<>();
    }

    public final ShortBuffer smpl;
    public final HashMap<Integer, Preset> presets = new HashMap<>();

    // ---------------- lectura

    private static final int G_START = 0, G_END = 1, G_LSTART = 2, G_LEND = 3, G_START_C = 4, G_FILTER_FC = 8,
            G_END_C = 12, G_PAN = 17, G_DELAY = 33, G_ATTACK = 34, G_HOLD = 35, G_DECAY = 36, G_SUSTAIN = 37,
            G_RELEASE = 38, G_INSTRUMENT = 41, G_KEYRANGE = 43, G_VELRANGE = 44, G_LSTART_C = 45, G_ATTEN = 48,
            G_LEND_C = 50, G_COARSE = 51, G_FINE = 52, G_SAMPLE = 53, G_MODES = 54, G_SCALE = 56, G_EXCL = 57,
            G_ROOT = 58;

    private static final class Raw {
        String name;
        int a, b, c, d, e, f, g, h; // campos genéricos
    }

    private ByteBuffer bb;
    private int smplOff, smplLen;
    private int[][] pbag, ibag; // [i] = {genNdx}
    private int[][] pgen, igen; // [i] = {oper, amount(raw u16)}
    private Raw[] phdr, inst, shdr;

    public Sf2(ByteBuffer data) throws Exception {
        bb = data.order(ByteOrder.LITTLE_ENDIAN);
        if (tag(0) != fourcc("RIFF") || tag(8) != fourcc("sfbk")) throw new Exception("no es un banco SF2");
        int end = Math.min(bb.limit(), 8 + bb.getInt(4));
        int p = 12;
        while (p + 8 <= end) {
            int id = tag(p), len = bb.getInt(p + 4);
            if (id == fourcc("LIST")) {
                int type = tag(p + 8);
                if (type == fourcc("sdta")) readSdta(p + 12, p + 8 + len);
                else if (type == fourcc("pdta")) readPdta(p + 12, p + 8 + len);
            }
            p += 8 + len + (len & 1);
        }
        ByteBuffer s = bb.duplicate().order(ByteOrder.LITTLE_ENDIAN);
        s.position(smplOff);
        s.limit(smplOff + smplLen);
        smpl = s.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
        build();
        bb = null;
        pbag = ibag = pgen = igen = null;
        phdr = inst = shdr = null;
    }

    private static int fourcc(String s) {
        return (s.charAt(0) & 0xff) | (s.charAt(1) & 0xff) << 8 | (s.charAt(2) & 0xff) << 16 | (s.charAt(3) & 0xff) << 24;
    }

    private int tag(int p) { return bb.getInt(p); }

    private int u16(int p) { return bb.getShort(p) & 0xffff; }

    private String str(int p, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            int c = bb.get(p + i) & 0xff;
            if (c == 0) break;
            sb.append((char) c);
        }
        return sb.toString().trim();
    }

    private void readSdta(int p, int end) {
        while (p + 8 <= end) {
            int id = tag(p), len = bb.getInt(p + 4);
            if (id == fourcc("smpl")) { smplOff = p + 8; smplLen = len; }
            p += 8 + len + (len & 1);
        }
    }

    private void readPdta(int p, int end) {
        while (p + 8 <= end) {
            int id = tag(p), len = bb.getInt(p + 4), d = p + 8;
            if (id == fourcc("phdr")) {
                int n = len / 38;
                phdr = new Raw[n];
                for (int i = 0; i < n; i++) {
                    int q = d + i * 38;
                    Raw r = new Raw();
                    r.name = str(q, 20);
                    r.a = u16(q + 20); // preset
                    r.b = u16(q + 22); // bank
                    r.c = u16(q + 24); // bag
                    phdr[i] = r;
                }
            } else if (id == fourcc("pbag")) pbag = bags(d, len);
            else if (id == fourcc("pgen")) pgen = gens(d, len);
            else if (id == fourcc("inst")) {
                int n = len / 22;
                inst = new Raw[n];
                for (int i = 0; i < n; i++) {
                    int q = d + i * 22;
                    Raw r = new Raw();
                    r.name = str(q, 20);
                    r.a = u16(q + 20);
                    inst[i] = r;
                }
            } else if (id == fourcc("ibag")) ibag = bags(d, len);
            else if (id == fourcc("igen")) igen = gens(d, len);
            else if (id == fourcc("shdr")) {
                int n = len / 46;
                shdr = new Raw[n];
                for (int i = 0; i < n; i++) {
                    int q = d + i * 46;
                    Raw r = new Raw();
                    r.name = str(q, 20);
                    r.a = bb.getInt(q + 20); // start
                    r.b = bb.getInt(q + 24); // end
                    r.c = bb.getInt(q + 28); // loop start
                    r.d = bb.getInt(q + 32); // loop end
                    r.e = bb.getInt(q + 36); // sample rate
                    r.f = bb.get(q + 40) & 0xff; // original pitch
                    r.g = bb.get(q + 41); // pitch correction (con signo)
                    r.h = u16(q + 44); // tipo
                    shdr[i] = r;
                }
            }
            p += 8 + len + (len & 1);
        }
    }

    private int[][] bags(int d, int len) {
        int n = len / 4;
        int[][] r = new int[n][1];
        for (int i = 0; i < n; i++) r[i][0] = u16(d + i * 4);
        return r;
    }

    private int[][] gens(int d, int len) {
        int n = len / 4;
        int[][] r = new int[n][2];
        for (int i = 0; i < n; i++) { r[i][0] = u16(d + i * 4); r[i][1] = u16(d + i * 4 + 2); }
        return r;
    }

    // ---------------- armar los instrumentos

    /** Generadores de una zona: valor por operador (null = no está). */
    private static Integer[] zoneGens(int[][] gens, int from, int to) {
        Integer[] g = new Integer[64];
        for (int i = from; i < to && i < gens.length; i++) {
            int op = gens[i][0];
            if (op < 64) g[op] = gens[i][1];
        }
        return g;
    }

    private static int s16(Integer v) { return v == null ? 0 : (short) (int) v; }

    private static int lo(Integer v) { return v & 0xff; }

    private static int hi(Integer v) { return (v >> 8) & 0xff; }

    private static float secs(int tc) { return tc <= -12000 ? 0f : (float) Math.pow(2, tc / 1200.0); }

    private void build() {
        if (phdr == null || inst == null || shdr == null) return;
        for (int pi = 0; pi + 1 < phdr.length; pi++) {
            Raw ph = phdr[pi];
            Preset pr = new Preset();
            pr.name = ph.name;
            pr.program = ph.a;
            pr.bank = ph.b;
            int b0 = ph.c, b1 = phdr[pi + 1].c;
            Integer[] pGlobal = null;
            for (int b = b0; b < b1 && b + 1 < pbag.length; b++) {
                Integer[] pg = zoneGens(pgen, pbag[b][0], pbag[b + 1][0]);
                if (pg[G_INSTRUMENT] == null) { if (b == b0) pGlobal = pg; continue; }
                Integer[] pz = merge(pGlobal, pg);
                int ii = pg[G_INSTRUMENT];
                if (ii < 0 || ii + 1 >= inst.length) continue;
                addInstrument(pr, ii, pz);
            }
            if (!pr.zones.isEmpty()) presets.put(pr.bank * 128 + pr.program, pr);
        }
    }

    private static Integer[] merge(Integer[] global, Integer[] local) {
        Integer[] r = new Integer[64];
        if (global != null) System.arraycopy(global, 0, r, 0, 64);
        for (int i = 0; i < 64; i++) if (local[i] != null) r[i] = local[i];
        return r;
    }

    private void addInstrument(Preset pr, int ii, Integer[] pz) {
        int b0 = inst[ii].a, b1 = inst[ii + 1].a;
        Integer[] iGlobal = null;
        for (int b = b0; b < b1 && b + 1 < ibag.length; b++) {
            Integer[] ig = zoneGens(igen, ibag[b][0], ibag[b + 1][0]);
            if (ig[G_SAMPLE] == null) { if (b == b0) iGlobal = ig; continue; }
            Integer[] g = merge(iGlobal, ig);
            int si = g[G_SAMPLE];
            if (si < 0 || si >= shdr.length) continue;
            Raw sh = shdr[si];
            if ((sh.h & 0x8000) != 0) continue; // sonido en ROM: no existe
            Zone z = new Zone();
            // rangos: el del instrumento cruzado con el del preset
            int kl = g[G_KEYRANGE] != null ? lo(g[G_KEYRANGE]) : 0, kh = g[G_KEYRANGE] != null ? hi(g[G_KEYRANGE]) : 127;
            int vl = g[G_VELRANGE] != null ? lo(g[G_VELRANGE]) : 0, vh = g[G_VELRANGE] != null ? hi(g[G_VELRANGE]) : 127;
            if (pz[G_KEYRANGE] != null) { kl = Math.max(kl, lo(pz[G_KEYRANGE])); kh = Math.min(kh, hi(pz[G_KEYRANGE])); }
            if (pz[G_VELRANGE] != null) { vl = Math.max(vl, lo(pz[G_VELRANGE])); vh = Math.min(vh, hi(pz[G_VELRANGE])); }
            if (kl > kh || vl > vh) continue;
            z.keyLo = kl; z.keyHi = kh; z.velLo = vl; z.velHi = vh;
            z.start = sh.a + s16(g[G_START]) + s16(g[G_START_C]) * 32768;
            z.end = sh.b + s16(g[G_END]) + s16(g[G_END_C]) * 32768;
            z.loopStart = sh.c + s16(g[G_LSTART]) + s16(g[G_LSTART_C]) * 32768;
            z.loopEnd = sh.d + s16(g[G_LEND]) + s16(g[G_LEND_C]) * 32768;
            int total = smpl.limit();
            z.start = clamp(z.start, 0, total - 1);
            z.end = clamp(z.end, z.start + 1, total);
            z.loopStart = clamp(z.loopStart, z.start, z.end - 1);
            z.loopEnd = clamp(z.loopEnd, z.loopStart + 1, z.end);
            z.sampleRate = sh.e > 0 ? sh.e : 44100;
            int root = g[G_ROOT] != null ? s16(g[G_ROOT]) : -1;
            z.rootKey = root >= 0 && root <= 127 ? root : (sh.f <= 127 ? sh.f : 60);
            z.tuneCents = (s16(g[G_COARSE]) + s16(pz[G_COARSE])) * 100f + s16(g[G_FINE]) + s16(pz[G_FINE]) + sh.g;
            z.scaleTuning = g[G_SCALE] != null ? s16(g[G_SCALE]) : 100;
            z.attenuation = (s16(g[G_ATTEN]) + s16(pz[G_ATTEN])) / 10f; // dB
            z.pan = Math.max(-500, Math.min(500, s16(g[G_PAN]) + s16(pz[G_PAN])));
            z.loopMode = g[G_MODES] != null ? (g[G_MODES] & 3) : 0;
            z.exclusive = g[G_EXCL] != null ? s16(g[G_EXCL]) : 0;
            z.delay = secs(tc(g, pz, G_DELAY));
            z.attack = secs(tc(g, pz, G_ATTACK));
            z.hold = secs(tc(g, pz, G_HOLD));
            z.decay = secs(tc(g, pz, G_DECAY));
            z.release = Math.max(0.01f, secs(tc(g, pz, G_RELEASE)));
            z.sustainDb = Math.max(0, Math.min(144, (s16(g[G_SUSTAIN]) + s16(pz[G_SUSTAIN])) / 10f));
            int fc = g[G_FILTER_FC] != null ? s16(g[G_FILTER_FC]) : 13500;
            fc += s16(pz[G_FILTER_FC]);
            z.filterHz = fc >= 13500 ? 20000 : (float) (8.176 * Math.pow(2, fc / 1200.0));
            pr.zones.add(z);
        }
    }

    /** Tiempos del volumen: el del instrumento (o -12000) más lo que agregue el preset. */
    private static int tc(Integer[] g, Integer[] pz, int op) {
        int v = g[op] != null ? s16(g[op]) : -12000;
        return v + s16(pz[op]);
    }

    private static int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }

    // ---------------- buscar

    public Preset preset(int bank, int program) {
        Preset p = presets.get(bank * 128 + program);
        if (p == null && bank == 128) p = presets.get(128 * 128);
        if (p == null) p = presets.get(program);
        if (p == null) p = presets.get(0);
        return p;
    }
}
