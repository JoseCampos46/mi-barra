package co.jose.chepeestudio;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/** Guarda lo que se toca como archivo MIDI (.mid), para corregir notas después en el Estudio. */
public final class Midi {

    private static final int PPQ = 480;
    private final List<long[]> ev = new ArrayList<>(); // {muestra, status, d1, d2}
    private final int tempo;

    public Midi(int tempo) { this.tempo = Math.max(30, tempo); }

    public synchronized void add(long sample, int st, int d1, int d2) {
        int t = st & 0xF0;
        if (t != 0x80 && t != 0x90 && t != 0xC0 && t != 0xB0) return;
        if (t == 0xC0 && d2 == 128) { /* batería: el canal 10 ya la indica */ }
        ev.add(new long[]{sample, st, d1, d2});
    }

    public synchronized boolean empty() { return ev.isEmpty(); }

    public synchronized void save(File f) throws Exception {
        ByteArrayOutputStream tr = new ByteArrayOutputStream();
        int usPerQ = 60_000_000 / tempo;
        vlq(tr, 0);
        tr.write(new byte[]{(byte) 0xFF, 0x51, 0x03, (byte) (usPerQ >> 16), (byte) (usPerQ >> 8), (byte) usPerQ}, 0, 6);
        double ticksPerSample = PPQ * tempo / 60.0 / Motor.SR;
        long last = 0;
        for (long[] e : ev) {
            long tick = Math.round(e[0] * ticksPerSample);
            if (tick < last) tick = last;
            vlq(tr, tick - last);
            last = tick;
            int st = (int) e[1];
            tr.write(st);
            tr.write((int) e[2] & 0x7F);
            if ((st & 0xF0) != 0xC0) tr.write((int) e[3] & 0x7F);
        }
        vlq(tr, 0);
        tr.write(new byte[]{(byte) 0xFF, 0x2F, 0x00}, 0, 3);
        byte[] body = tr.toByteArray();
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write(new byte[]{'M', 'T', 'h', 'd', 0, 0, 0, 6, 0, 0, 0, 1, (byte) (PPQ >> 8), (byte) PPQ});
            o.write(new byte[]{'M', 'T', 'r', 'k'});
            o.write(new byte[]{(byte) (body.length >> 24), (byte) (body.length >> 16), (byte) (body.length >> 8), (byte) body.length});
            o.write(body);
        }
    }

    private static void vlq(ByteArrayOutputStream o, long v) {
        int buf = (int) (v & 0x7F);
        while ((v >>= 7) > 0) { buf <<= 8; buf |= (int) ((v & 0x7F) | 0x80); }
        while (true) {
            o.write(buf & 0xFF);
            if ((buf & 0x80) != 0) buf >>= 8; else break;
        }
    }
}
