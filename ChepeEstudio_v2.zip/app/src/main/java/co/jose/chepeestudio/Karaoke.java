package co.jose.chepeestudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Karaoke de Chepe Estudio: el video de la pista grande a la izquierda (para leer bien la letra)
 * y los controles a la derecha. La pista suena por el motor, así queda en la grabación M4A.
 */
public final class Karaoke {

    public interface AlTeclado { void ver(boolean si); }

    static final int ABRIR = 501, PERMISO_MIC = 502;
    static final int GRIS = 0xFF2A2A2A, VERDE = 0xFF0F6E56, ROSA = 0xFF993556, MORADO = 0xFF534AB7, AZUL = 0xFF185FA5;

    public AlTeclado alTeclado;

    private final Activity a;
    private final Motor motor;
    private final Handler ui;
    private final SharedPreferences prefs;

    private LinearLayout raiz;
    private FrameLayout marco;
    private TextureView tex;
    private Surface surface;
    private TextView letrero, bPlay, bSinVoz, bMic, bTeclado, lTiempo, lAjuste;
    private SeekBar sbPos;
    private boolean arrastrando, tecladoVisible = true;

    private Pista pista;
    private MediaPlayer mp;
    private boolean mpListo;
    private Microfono mic;
    private float volPista = 0.9f;
    private int ajusteMs;

    public Karaoke(Activity act, Motor m, Handler h) {
        a = act;
        motor = m;
        ui = h;
        prefs = act.getSharedPreferences("karaoke", 0);
        ajusteMs = prefs.getInt("ajuste", 200);
        motor.retrasoVoz = ajusteMs * Motor.SR / 1000;
    }

    // ------------------------------------------------------------ pantalla

    private int dp(float v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable fondo(int c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(dp(8));
        return g;
    }

    private TextView boton(LinearLayout padre, String s, int c, Runnable r) {
        TextView t = tv(s, 14, Color.WHITE);
        t.setBackground(fondo(c));
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(42));
        lp.setMargins(0, dp(3), 0, dp(3));
        padre.addView(t, lp);
        return t;
    }

    private TextView botonFila(LinearLayout fila, String s, int c, Runnable r) {
        TextView t = tv(s, 14, Color.WHITE);
        t.setBackground(fondo(c));
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        fila.addView(t, lp);
        return t;
    }

    private LinearLayout fila(LinearLayout padre) {
        LinearLayout f = new LinearLayout(a);
        f.setOrientation(LinearLayout.HORIZONTAL);
        f.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(3), 0, dp(3));
        padre.addView(f, lp);
        return f;
    }

    private interface Val { void v(int x); }

    private SeekBar barra(LinearLayout padre, String nombre, int max, int valor, Val v) {
        padre.addView(tv(nombre, 13, 0xFFFAC775));
        SeekBar s = new SeekBar(a);
        s.setMax(max);
        s.setProgress(valor);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int x, boolean u) { if (u) v.v(x); }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) {}
        });
        padre.addView(s, new LinearLayout.LayoutParams(-1, dp(34)));
        return s;
    }

    public View vista() {
        raiz = new LinearLayout(a);
        raiz.setOrientation(LinearLayout.HORIZONTAL);
        raiz.setBackgroundColor(0xFF151515);

        // izquierda: el video grande
        marco = new FrameLayout(a);
        marco.setBackgroundColor(Color.BLACK);
        tex = new TextureView(a);
        tex.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                surface = new Surface(st);
                if (mp != null) try { mp.setSurface(surface); } catch (Exception ignored) {}
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (mp != null) try { mp.setSurface(null); } catch (Exception ignored) {}
                if (surface != null) surface.release();
                surface = null;
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {}
        });
        marco.addView(tex, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        letrero = tv("🎤 Karaoke\n\nToque  📂 Abrir pista", 22, Color.WHITE);
        letrero.setGravity(Gravity.CENTER);
        marco.addView(letrero, new FrameLayout.LayoutParams(-1, -1));
        marco.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> { if (r - l != or - ol || b - t != ob - ot) ui.post(this::ajustarVideo); });
        raiz.addView(marco, new LinearLayout.LayoutParams(0, -1, 1f));

        // derecha: los controles
        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(2), dp(6), dp(6));
        sv.addView(col);
        raiz.addView(sv, new LinearLayout.LayoutParams(dp(230), -1));

        boton(col, "📂 Abrir pista", AZUL, this::abrir);
        LinearLayout f1 = fila(col);
        botonFila(f1, "⏪ 10 s", GRIS, () -> saltar(-10000));
        bPlay = botonFila(f1, "▶ Tocar", VERDE, this::tocar);
        botonFila(f1, "10 s ⏩", GRIS, () -> saltar(10000));
        lTiempo = tv("0:00 / 0:00", 15, Color.WHITE);
        lTiempo.setGravity(Gravity.CENTER);
        col.addView(lTiempo, new LinearLayout.LayoutParams(-1, -2));
        sbPos = new SeekBar(a);
        sbPos.setMax(1000);
        sbPos.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int x, boolean u) {
                if (u && pista != null) lTiempo.setText(hora(pista.durMs * x / 1000) + " / " + hora(pista.durMs));
            }
            @Override public void onStartTrackingTouch(SeekBar b) { arrastrando = true; }
            @Override public void onStopTrackingTouch(SeekBar b) {
                arrastrando = false;
                if (pista != null) irA(pista.durMs * b.getProgress() / 1000);
            }
        });
        col.addView(sbPos, new LinearLayout.LayoutParams(-1, dp(36)));

        bSinVoz = boton(col, "🗣 Quitar voz A: No", GRIS, this::sinVoz);
        boton(col, "🌐 Quitar voz B (IA, internet)", MORADO, this::quitarVozIA);
        bMic = boton(col, "🎙 Micrófono: No", GRIS, this::microfono);
        barra(col, "Volumen de la pista", 100, 90, x -> { volPista = x / 100f; if (pista != null) pista.vol = volPista; });
        barra(col, "Volumen de su voz (en la grabación)", 200, 100, x -> motor.volVoz = x / 100f);
        col.addView(tv("Si en la grabación su voz queda atrasada, súbale:", 12, Color.LTGRAY));
        LinearLayout f2 = fila(col);
        botonFila(f2, "−", GRIS, () -> ajuste(-20));
        lAjuste = tv(ajusteMs + " ms", 15, Color.WHITE);
        lAjuste.setGravity(Gravity.CENTER);
        f2.addView(lAjuste, new LinearLayout.LayoutParams(0, dp(42), 1.3f));
        botonFila(f2, "+", GRIS, () -> ajuste(20));
        bTeclado = boton(col, "🎹 Teclado: Sí", GRIS, this::teclado);
        return raiz;
    }

    // ------------------------------------------------------------ abrir pista

    public void alAbrir() {
        if (!prefs.getBoolean("carpeta", false)) {
            new Thread(() -> {
                try {
                    File f = new File(a.getCacheDir(), "leeme.txt");
                    try (FileOutputStream o = new FileOutputStream(f)) {
                        o.write(("Ponga en esta carpeta las pistas de karaoke (MP4, MP3, M4A).\n" +
                                "Chepe Estudio las abre con el botón \"Abrir pista\".\n").getBytes("UTF-8"));
                    }
                    Store.saveFile(a, f, "Pistas", "LEEME - ponga aqui sus pistas.txt", "text/plain");
                    f.delete();
                    prefs.edit().putBoolean("carpeta", true).apply();
                } catch (Exception ignored) {}
            }).start();
        }
        ui.removeCallbacks(sincro);
        ui.post(sincro);
    }

    private List<String[]> recientes() {
        List<String[]> l = new ArrayList<>();
        for (String s : prefs.getString("recientes", "").split("\n")) {
            String[] p = s.split("\t");
            if (p.length == 2) l.add(p);
        }
        return l;
    }

    private void guardarReciente(Uri u, String nombre) {
        List<String[]> l = recientes();
        StringBuilder sb = new StringBuilder(u + "\t" + nombre);
        int n = 1;
        for (String[] p : l) {
            if (p[0].equals(u.toString()) || n >= 12) continue;
            sb.append('\n').append(p[0]).append('\t').append(p[1]);
            n++;
        }
        prefs.edit().putString("recientes", sb.toString()).apply();
    }

    private void abrir() {
        List<String[]> l = recientes();
        if (l.isEmpty()) { buscar(); return; }
        String[] items = new String[l.size() + 1];
        items[0] = "📂 Buscar en el celular…";
        for (int i = 0; i < l.size(); i++) items[i + 1] = "🎵 " + l.get(i)[1];
        new AlertDialog.Builder(a).setTitle("Abrir pista")
                .setItems(items, (d, w) -> {
                    if (w == 0) buscar();
                    else cargar(Uri.parse(l.get(w - 1)[0]), l.get(w - 1)[1]);
                }).show();
    }

    private void buscar() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        try {
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:Download/" + Store.BASE + "/Pistas"));
        } catch (Exception ignored) {}
        try { a.startActivityForResult(i, ABRIR); }
        catch (Exception e) { toast("No pude abrir el buscador de archivos"); }
    }

    public void resultado(int req, int res, Intent data) {
        if (req != ABRIR || res != Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try { a.getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) {}
        String nombre = "Pista";
        try (Cursor c = a.getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) nombre = c.getString(0);
        } catch (Exception ignored) {}
        cargar(u, nombre);
    }

    private void cargar(Uri u, String nombre) {
        letrero.setVisibility(View.VISIBLE);
        letrero.setText("Cargando…\n" + nombre);
        new Thread(() -> {
            Pista p = null;
            String err = null;
            try { p = new Pista(a, u, nombre); } catch (Exception e) { err = e.getMessage(); }
            final Pista fp = p;
            final String fe = err;
            ui.post(() -> {
                if (fp == null) {
                    letrero.setText("No pude abrir la pista\n" + nombre + "\n(" + fe + ")");
                    return;
                }
                soltarPista();
                pista = fp;
                pista.vol = volPista;
                pista.sinVoz = bSinVoz.getText().toString().endsWith("Sí");
                motor.pista = pista;
                guardarReciente(u, nombre);
                bPlay.setText("▶ Tocar");
                if (pista.tieneVideo) prepararVideo(u);
                else letrero.setText("🎵 " + nombre);
                actualizar();
            });
        }).start();
    }

    private void prepararVideo(Uri u) {
        try {
            mp = new MediaPlayer();
            mpListo = false;
            mp.setDataSource(a, u);
            mp.setVolume(0f, 0f); // el sonido sale por Chepe Estudio
            if (surface != null) mp.setSurface(surface);
            mp.setOnPreparedListener(m -> {
                mpListo = true;
                letrero.setVisibility(View.GONE);
                ajustarVideo();
                try { m.seekTo((int) pista.posMs()); } catch (Exception ignored) {}
            });
            mp.setOnVideoSizeChangedListener((m, w, h) -> ajustarVideo());
            mp.setOnErrorListener((m, w, x) -> { letrero.setVisibility(View.VISIBLE); letrero.setText("🎵 " + pista.nombre + "\n(el video no se puede mostrar, la música sí suena)"); return true; });
            mp.prepareAsync();
        } catch (Exception e) {
            letrero.setText("🎵 " + pista.nombre);
        }
    }

    /** El video lo más grande posible sin deformarlo. */
    private void ajustarVideo() {
        if (mp == null || !mpListo) return;
        int vw = mp.getVideoWidth(), vh = mp.getVideoHeight();
        int cw = marco.getWidth(), ch = marco.getHeight();
        if (vw <= 0 || vh <= 0 || cw <= 0 || ch <= 0) return;
        float s = Math.min(cw / (float) vw, ch / (float) vh);
        tex.setLayoutParams(new FrameLayout.LayoutParams(Math.round(vw * s), Math.round(vh * s), Gravity.CENTER));
    }

    // ------------------------------------------------------------ tocar

    private void tocar() {
        if (pista == null) { abrir(); return; }
        motor.setActive(true);
        if (pista.terminada) irA(0);
        pista.tocando = !pista.tocando;
        bPlay.setText(pista.tocando ? "⏸ Pausa" : "▶ Tocar");
        actualizar();
    }

    private void saltar(long ms) { if (pista != null) irA(pista.posMs() + ms); }

    private void irA(long ms) {
        if (pista == null) return;
        pista.ir(ms);
        if (mp != null && mpListo) try { mp.seekTo((int) pista.posMs()); } catch (Exception ignored) {}
        actualizar();
    }

    private final Runnable sincro = new Runnable() {
        @Override
        public void run() {
            actualizar();
            ui.postDelayed(this, 250);
        }
    };

    private String hora(long ms) {
        long s = Math.max(0, ms) / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private void actualizar() {
        Pista p = pista;
        if (p == null || raiz == null) return;
        long pos = p.posMs();
        if (!arrastrando) {
            lTiempo.setText(hora(pos) + " / " + hora(p.durMs));
            if (p.durMs > 0) sbPos.setProgress((int) (pos * 1000 / p.durMs));
        }
        if (p.error != null) { toast("Problema con la pista: " + p.error); p.error = null; }
        if (p.terminada && bPlay.getText().toString().startsWith("⏸")) bPlay.setText("▶ Tocar");
        if (!p.tieneVideo) letrero.setText("🎵 " + p.nombre + "\n\n" + hora(pos) + " / " + hora(p.durMs));
        if (mp != null && mpListo) {
            try {
                long objetivo = Math.max(0, pos - 120); // lo que ya sonó por el parlante
                if (p.tocando) {
                    if (!mp.isPlaying()) { mp.seekTo((int) objetivo); mp.start(); }
                    else if (Math.abs(mp.getCurrentPosition() - objetivo) > 350) mp.seekTo((int) objetivo);
                } else if (mp.isPlaying()) mp.pause();
            } catch (Exception ignored) {}
        }
    }

    // ------------------------------------------------------------ quitar la voz

    private void sinVoz() {
        boolean on = !bSinVoz.getText().toString().endsWith("Sí");
        bSinVoz.setText(on ? "🗣 Quitar voz A: Sí" : "🗣 Quitar voz A: No");
        bSinVoz.setBackground(fondo(on ? ROSA : GRIS));
        if (pista != null) pista.sinVoz = on;
        if (on) toast("Voz quitada (forma rápida). Si se oye un eco de la voz, use la forma B con IA.");
    }

    private void quitarVozIA() {
        String pasos = "Para que quede excelente, una página gratuita con inteligencia artificial separa la voz:\n\n" +
                "1. Toque una de las páginas de abajo.\n" +
                "2. Suba la canción (botón de subir o \"Browse my files\").\n" +
                "3. Espere uno o dos minutos.\n" +
                "4. Descargue la pista SIN voz (en inglés dice \"Music\" o \"Instrumental\"; la voz sola dice \"Vocal\").\n" +
                "5. Vuelva a Chepe Estudio y toque  📂 Abrir pista: el archivo queda en Descargas.\n\n" +
                "Necesita internet. Si quiere, después la pasa a la carpeta Pistas.";
        new AlertDialog.Builder(a).setTitle("Quitar voz B (con IA)").setMessage(pasos)
                .setPositiveButton("Página 1", (d, w) -> web("https://vocalremover.org/"))
                .setNeutralButton("Página 2", (d, w) -> web("https://freetts.com/vocal-remover"))
                .setNegativeButton("Cerrar", null).show();
    }

    private void web(String url) {
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("No hay navegador para abrir la página"); }
    }

    // ------------------------------------------------------------ micrófono

    public boolean micPrendido() { return mic != null; }

    private void microfono() {
        if (mic != null) { apagarMic(); return; }
        if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISO_MIC);
            return;
        }
        prenderMic();
    }

    public void permiso(int req, int[] g) {
        if (req != PERMISO_MIC) return;
        if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) prenderMic();
        else toast("Sin permiso del micrófono no se puede grabar su voz");
    }

    private void prenderMic() {
        try {
            mic = new Microfono();
            motor.mic = mic;
            bMic.setText("🎙 Micrófono: Sí");
            bMic.setBackground(fondo(VERDE));
            toast("🎙 Listo. Use audífonos con micrófono para que la pista no se meta en su voz. Toque ⏺ Grabar arriba.");
        } catch (Exception e) {
            mic = null;
            toast("No pude prender el micrófono: " + e.getMessage());
        }
    }

    private void apagarMic() {
        motor.mic = null;
        if (mic != null) mic.apagar();
        mic = null;
        bMic.setText("🎙 Micrófono: No");
        bMic.setBackground(fondo(GRIS));
    }

    private void ajuste(int d) {
        ajusteMs = Math.max(0, Math.min(800, ajusteMs + d));
        lAjuste.setText(ajusteMs + " ms");
        motor.retrasoVoz = ajusteMs * Motor.SR / 1000;
        prefs.edit().putInt("ajuste", ajusteMs).apply();
    }

    private void teclado() {
        tecladoVisible = !tecladoVisible;
        bTeclado.setText(tecladoVisible ? "🎹 Teclado: Sí" : "🎹 Teclado: No (video grande)");
        if (alTeclado != null) alTeclado.ver(tecladoVisible);
        ui.postDelayed(this::ajustarVideo, 150);
    }

    // ------------------------------------------------------------ vida de la app

    public void enPausa() {
        if (pista != null && pista.tocando) { pista.tocando = false; bPlay.setText("▶ Tocar"); }
        if (mp != null) try { if (mp.isPlaying()) mp.pause(); } catch (Exception ignored) {}
        if (mic != null && !motor.isRecording()) apagarMic();
        ui.removeCallbacks(sincro);
    }

    public void enVuelta() {
        if (raiz != null && raiz.getVisibility() == View.VISIBLE && raiz.isShown()) { ui.removeCallbacks(sincro); ui.post(sincro); }
    }

    private void soltarPista() {
        motor.pista = null;
        if (pista != null) pista.soltar();
        pista = null;
        if (mp != null) try { mp.release(); } catch (Exception ignored) {}
        mp = null;
        mpListo = false;
        tex.setLayoutParams(new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
    }

    public void soltar() {
        ui.removeCallbacks(sincro);
        soltarPista();
        if (mic != null) apagarMic();
    }

    private void toast(String s) { Toast.makeText(a, s, Toast.LENGTH_LONG).show(); }
}
