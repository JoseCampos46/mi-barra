package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/**
 * Versión 5: la cinta como en InShot.
 * - La RAYA BLANCA queda fija en el centro; con el dedo se corre la cinta por debajo.
 * - Dos dedos: acercar o alejar.
 * - Varias filas (pistas): 0 = video (gris, con fotitos), 1 = sonidos (morado), 2 = textos (amarillo).
 * - Tocar un pedazo lo escoge: marco blanco y agarraderas [ ] en las puntas para alargar o recortar.
 */
public class CintaView extends View {

    /** De dónde salen los pedazos de cada fila. Tiempos en milisegundos de la cinta. */
    public interface Fuente {
        int filas();
        int cuantos(int fila);
        long ini(int fila, int i);
        long fin(int fila, int i);
        String nombre(int fila, int i);
        Bitmap foto(int fila, int i);
        long total();
    }

    public interface Oyente {
        void onMover(long ms);
        void onEscoger(int fila, int i);
        /** Arrastró una agarradera: inicio = true la de la izquierda. Devuelve el tiempo que quedó. */
        void onAgarradera(int fila, int i, boolean inicio, long ms);
        void onSoltar();
    }

    public Fuente fuente;
    public Oyente oyente;
    public long posMs;
    public int selFila = -1, selIdx = -1;

    private float msPorPx = 40f;
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    // toque
    private float x0, y0, lastX;
    private boolean movio, pinch, arrastrandoCinta;
    private int agarrada; // 0 nada, 1 inicio, 2 fin
    private float pd0, mp0;

    private static final int[] FONDO = {0xFF607D8B, 0xFF7E57C2, 0xFFF9A825};
    private static final int[] FONDO_SEL = {0xFF78909C, 0xFF9575CD, 0xFFFBC02D};

    public CintaView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private float alto(int fila) { return fila == 0 ? 54 * dp : 30 * dp; }

    private float arriba(int fila) {
        float y = 18 * dp;
        for (int f = 0; f < fila; f++) y += alto(f) + 6 * dp;
        return y;
    }

    public int altoTotal(int filas) {
        float y = 18 * dp;
        for (int f = 0; f < filas; f++) y += alto(f) + 6 * dp;
        return Math.round(y + 4 * dp);
    }

    private float x(long ms) { return getWidth() / 2f + (ms - posMs) / msPorPx; }

    /** Que todo el video quepa en la pantalla al abrirlo. */
    public void ajustar() {
        if (fuente == null || getWidth() <= 0) return;
        long t = Math.max(1000, fuente.total());
        msPorPx = Math.max(2f, t / (getWidth() * 0.9f));
        invalidate();
    }

    public void acercar() { msPorPx = Math.max(1f, msPorPx / 2f); invalidate(); }

    public void alejar() { msPorPx = Math.min(20000f, msPorPx * 2f); invalidate(); }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (ow == 0) ajustar();
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF1B1B1B);
        if (fuente == null) return;
        int filas = fuente.filas();
        float W = getWidth();
        // reglita de tiempo arriba
        p.setColor(0xFFB0BEC5);
        p.setTextSize(10 * dp);
        long paso = pasoRegla();
        long t0 = Math.max(0, (long) ((posMs - W / 2f * msPorPx) / paso) * paso);
        for (long t = t0; x(t) < W; t += paso) {
            float xx = x(t);
            c.drawRect(xx, 12 * dp, xx + dp, 16 * dp, p);
            c.drawText(TimelineView.fmt(t).replace(".0", ""), xx + 2 * dp, 10 * dp, p);
        }
        for (int f = 0; f < filas; f++) {
            float top = arriba(f), bot = top + alto(f);
            int n = fuente.cuantos(f);
            for (int i = 0; i < n; i++) {
                float a = x(fuente.ini(f, i)), b = x(fuente.fin(f, i));
                if (b < 0 || a > W) continue;
                boolean sel = f == selFila && i == selIdx;
                p.setStyle(Paint.Style.FILL);
                p.setColor(sel ? FONDO_SEL[Math.min(2, f)] : FONDO[Math.min(2, f)]);
                dst.set(a + dp, top, b - dp, bot);
                c.drawRoundRect(dst, 5 * dp, 5 * dp, p);
                Bitmap fo = f == 0 ? fuente.foto(f, i) : null;
                if (fo != null && !fo.isRecycled()) {
                    // fotitos repetidas a lo largo del pedazo
                    float lado = bot - top;
                    c.save();
                    c.clipRect(Math.max(0, a + dp), top, Math.min(W, b - dp), bot);
                    src.set(0, 0, fo.getWidth(), fo.getHeight());
                    for (float xx = a; xx < b && xx < W; xx += lado) {
                        if (xx + lado < 0) continue;
                        dst.set(xx, top, xx + lado, bot);
                        c.drawBitmap(fo, src, dst, null);
                    }
                    c.restore();
                }
                String nm = fuente.nombre(f, i);
                if (nm != null && b - a > 30 * dp) {
                    p.setTextSize(11 * dp);
                    p.setColor(f == 2 ? Color.BLACK : Color.WHITE);
                    if (f == 0) { p.setColor(0x99000000); c.drawRect(Math.max(a, 0) + 2 * dp, top + 2 * dp, Math.max(a, 0) + 6 * dp + p.measureText(nm), top + 16 * dp, p); p.setColor(Color.WHITE); }
                    c.save();
                    c.clipRect(a, top, b, bot);
                    c.drawText(nm, Math.max(a, 0) + 4 * dp, f == 0 ? top + 13 * dp : top + (bot - top) / 2f + 4 * dp, p);
                    c.restore();
                }
                if (sel) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(3 * dp);
                    p.setColor(Color.WHITE);
                    dst.set(a + dp, top, b - dp, bot);
                    c.drawRoundRect(dst, 5 * dp, 5 * dp, p);
                    agarradera(c, a, top, bot, true);
                    agarradera(c, b, top, bot, false);
                }
            }
        }
        // la raya blanca fija en el centro
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.BLACK);
        c.drawRect(W / 2f - 2.5f * dp, 12 * dp, W / 2f + 2.5f * dp, getHeight(), p);
        p.setColor(Color.WHITE);
        c.drawRect(W / 2f - 1.3f * dp, 12 * dp, W / 2f + 1.3f * dp, getHeight(), p);
        p.setTextSize(11 * dp);
        String tt = TimelineView.fmt(posMs);
        float tw = p.measureText(tt);
        p.setColor(Color.WHITE);
        c.drawRoundRect(W / 2f - tw / 2f - 4 * dp, 0, W / 2f + tw / 2f + 4 * dp, 13 * dp, 3 * dp, 3 * dp, p);
        p.setColor(Color.BLACK);
        c.drawText(tt, W / 2f - tw / 2f, 10.5f * dp, p);
    }

    private long pasoRegla() {
        long[] pasos = {500, 1000, 2000, 5000, 10000, 30000, 60000, 120000, 300000, 600000};
        for (long s : pasos) if (s / msPorPx > 60 * dp) return s;
        return 1200000;
    }

    private void agarradera(Canvas c, float xx, float top, float bot, boolean izq) {
        float w = 14 * dp;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        dst.set(izq ? xx - w + 2 * dp : xx - 2 * dp, top - 2 * dp, izq ? xx + 2 * dp : xx + w - 2 * dp, bot + 2 * dp);
        c.drawRoundRect(dst, 4 * dp, 4 * dp, p);
        p.setColor(Color.BLACK);
        p.setTextSize(14 * dp);
        String s = izq ? "[" : "]";
        c.drawText(s, dst.centerX() - p.measureText(s) / 2f, dst.centerY() + 5 * dp, p);
    }

    private int filaEn(float yy) {
        if (fuente == null) return -1;
        for (int f = 0; f < fuente.filas(); f++) if (yy >= arriba(f) - 4 * dp && yy <= arriba(f) + alto(f) + 4 * dp) return f;
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (fuente == null) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                x0 = lastX = e.getX(); y0 = e.getY();
                movio = false; pinch = false; arrastrandoCinta = false; agarrada = 0;
                // ¿agarró una agarradera del pedazo escogido?
                if (selFila >= 0 && selIdx >= 0 && selIdx < fuente.cuantos(selFila) && filaEn(y0) == selFila) {
                    float a = x(fuente.ini(selFila, selIdx)), b = x(fuente.fin(selFila, selIdx));
                    float tol = 22 * dp;
                    if (Math.abs(x0 - a) < tol && Math.abs(x0 - a) <= Math.abs(x0 - b)) agarrada = 1;
                    else if (Math.abs(x0 - b) < tol) agarrada = 2;
                }
                break;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    pinch = true;
                    agarrada = 0;
                    pd0 = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
                    mp0 = msPorPx;
                }
                break;
            case MotionEvent.ACTION_MOVE: {
                float xx = e.getX();
                if (Math.abs(xx - x0) > 8 * dp) movio = true;
                if (pinch && e.getPointerCount() >= 2) {
                    float d = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
                    msPorPx = Math.max(1f, Math.min(20000f, mp0 * pd0 / d));
                    invalidate();
                } else if (agarrada != 0 && movio) {
                    long ms = Math.max(0, posMs + (long) ((xx - getWidth() / 2f) * msPorPx));
                    if (oyente != null) oyente.onAgarradera(selFila, selIdx, agarrada == 1, ms);
                    invalidate();
                } else if (!pinch && movio) {
                    arrastrandoCinta = true;
                    posMs = Math.max(0, Math.min(fuente.total(), posMs - (long) ((xx - lastX) * msPorPx)));
                    if (oyente != null) oyente.onMover(posMs);
                    invalidate();
                }
                lastX = xx;
                break;
            }
            case MotionEvent.ACTION_UP: {
                if (!movio && !pinch) escogerEn(e.getX(), e.getY());
                if ((agarrada != 0 || arrastrandoCinta) && oyente != null) oyente.onSoltar();
                agarrada = 0; pinch = false; arrastrandoCinta = false;
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                agarrada = 0; pinch = false; arrastrandoCinta = false;
                break;
        }
        return true;
    }

    private void escogerEn(float xx, float yy) {
        int f = filaEn(yy);
        int esc = -1;
        if (f >= 0) {
            long ms = posMs + (long) ((xx - getWidth() / 2f) * msPorPx);
            for (int i = fuente.cuantos(f) - 1; i >= 0; i--)
                if (ms >= fuente.ini(f, i) && ms <= fuente.fin(f, i)) { esc = i; break; }
        }
        if (esc < 0) { selFila = -1; selIdx = -1; } else { selFila = f; selIdx = esc; }
        if (oyente != null) oyente.onEscoger(selFila, selIdx);
        invalidate();
    }

    public String info() { return String.format(Locale.US, "%.0f", msPorPx); }
}
