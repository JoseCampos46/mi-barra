package co.jose.mibarra;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

/** Calculadora de obra: básica con quebrados, mm ↔ pulgadas, concreto y ladrillo/farol. */
public class CalculadoraActivity extends VentanaActivity {

    private FrameLayout contenido;
    private final Button[] pestanas = new Button[4];
    private static final double MEDIO_CUNETE = 9.5;   // litros
    private static final double FACTOR_CONCRETO = 1.54; // volumen seco / volumen húmedo
    private static final double FACTOR_MORTERO = 1.30;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout raiz = vertical();
        raiz.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout tabs = horizontal();
        String[] nombres = {"Básica", "mm ↔ pulg", "Concreto", "Ladrillo"};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            Button t = new Button(this);
            t.setText(nombres[i]);
            t.setAllCaps(false);
            t.setTextSize(13);
            t.setOnClickListener(v -> mostrar(k));
            pestanas[i] = t;
            tabs.addView(t, peso(1));
        }
        raiz.addView(tabs);
        contenido = new FrameLayout(this);
        raiz.addView(contenido, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(raiz);
        mostrar(getIntent().getIntExtra("pestana", getSharedPreferences("barra", MODE_PRIVATE).getInt("pestanaCalc", 0)));
    }

    private void mostrar(int k) {
        getSharedPreferences("barra", MODE_PRIVATE).edit().putInt("pestanaCalc", k).apply();
        for (int i = 0; i < 4; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == k ? 0xFF1565C0 : 0xFFCFD8DC);
            g.setCornerRadius(dp(8));
            pestanas[i].setBackground(g);
            pestanas[i].setTextColor(i == k ? Color.WHITE : 0xFF263238);
        }
        contenido.removeAllViews();
        View v;
        if (k == 0) v = basica();
        else if (k == 1) v = conversor();
        else if (k == 2) v = concreto();
        else v = ladrillo();
        contenido.addView(v);
    }

    // =====================================================================
    // 1. BÁSICA (con quebrados exactos y paréntesis)
    // =====================================================================

    private String expr = "";
    private TextView tvExpr, tvRes;

    private View basica() {
        LinearLayout l = vertical();
        tvExpr = new TextView(this);
        tvExpr.setTextSize(30);
        tvExpr.setGravity(Gravity.END);
        tvExpr.setMinLines(2);
        tvExpr.setTextColor(0xFF111111);
        tvExpr.setPadding(dp(8), dp(12), dp(8), 0);
        tvRes = new TextView(this);
        tvRes.setTextSize(22);
        tvRes.setGravity(Gravity.END);
        tvRes.setTextColor(0xFF1565C0);
        tvRes.setMinLines(2);
        tvRes.setPadding(dp(8), 0, dp(8), dp(8));
        l.addView(tvExpr);
        l.addView(tvRes);
        String[][] filas = {
                {"C", "(", ")", "⌫"},
                {"7", "8", "9", "÷"},
                {"4", "5", "6", "×"},
                {"1", "2", "3", "−"},
                {"0", ",", "%", "+"},
        };
        for (String[] f : filas) {
            LinearLayout r = horizontal();
            for (String s : f) r.addView(tecla(s), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f) {{
                setMargins(dp(3), dp(3), dp(3), dp(3));
            }});
            l.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }
        LinearLayout r = horizontal();
        LinearLayout.LayoutParams pi = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        pi.setMargins(dp(3), dp(3), dp(3), dp(3));
        r.addView(tecla("="), pi);
        l.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView ayuda = new TextView(this);
        ayuda.setText("Quebrados: 3÷4 da 3/4 exacto. Para 1 ½ escriba 1+1÷2. "
                + "200+10% = 220 · 200×10% = 20");
        ayuda.setTextSize(13);
        ayuda.setPadding(dp(6), dp(4), dp(6), 0);
        l.addView(ayuda);
        actualizarBasica();
        return l;
    }

    private Button tecla(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(24);
        b.setAllCaps(false);
        int color = "=".equals(s) ? 0xFF2E7D32 : ("C".equals(s) ? 0xFFC62828
                : ("÷×−+%()⌫".contains(s) ? 0xFF455A64 : 0xFFECEFF1));
        b.setTextColor((color == 0xFFECEFF1) ? 0xFF111111 : Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(12));
        b.setBackground(g);
        b.setOnClickListener(v -> pulsar(s));
        return b;
    }

    private void pulsar(String s) {
        switch (s) {
            case "C": expr = ""; break;
            case "⌫": if (!expr.isEmpty()) expr = expr.substring(0, expr.length() - 1); break;
            case "=":
                try {
                    Fr r = new Calc(expr).evaluar();
                    expr = r.paraExpresion();
                } catch (Exception e) {
                    tvRes.setText("Revise la operación");
                    return;
                }
                break;
            default: expr += s;
        }
        actualizarBasica();
    }

    private void actualizarBasica() {
        tvExpr.setText(expr.isEmpty() ? "0" : expr);
        if (expr.isEmpty()) { tvRes.setText(""); return; }
        try {
            Fr r = new Calc(expr).evaluar();
            String q = r.quebrado();
            tvRes.setText("= " + r.decimal() + (q.isEmpty() ? "" : "\n= " + q));
        } catch (Exception e) {
            tvRes.setText("");
        }
    }

    /** Fracción exacta. */
    static final class Fr {
        final BigInteger n, d;

        Fr(BigInteger n, BigInteger d) {
            if (d.signum() == 0) throw new ArithmeticException("división por cero");
            if (d.signum() < 0) { n = n.negate(); d = d.negate(); }
            BigInteger g = n.gcd(d);
            if (g.signum() == 0) g = BigInteger.ONE;
            this.n = n.divide(g);
            this.d = d.divide(g);
        }

        static Fr de(long v) { return new Fr(BigInteger.valueOf(v), BigInteger.ONE); }
        Fr mas(Fr o) { return new Fr(n.multiply(o.d).add(o.n.multiply(d)), d.multiply(o.d)); }
        Fr menos(Fr o) { return mas(o.neg()); }
        Fr por(Fr o) { return new Fr(n.multiply(o.n), d.multiply(o.d)); }
        Fr entre(Fr o) { return new Fr(n.multiply(o.d), d.multiply(o.n)); }
        Fr neg() { return new Fr(n.negate(), d); }

        String decimal() {
            BigDecimal v = new BigDecimal(n).divide(new BigDecimal(d), 10, RoundingMode.HALF_UP).stripTrailingZeros();
            String s = v.toPlainString();
            boolean negativo = s.startsWith("-");
            if (negativo) s = s.substring(1);
            String ent = s, dec = "";
            int p = s.indexOf('.');
            if (p >= 0) { ent = s.substring(0, p); dec = s.substring(p + 1); }
            StringBuilder g = new StringBuilder();
            for (int i = 0; i < ent.length(); i++) {
                if (i > 0 && (ent.length() - i) % 3 == 0) g.append('.');
                g.append(ent.charAt(i));
            }
            return (negativo ? "−" : "") + g + (dec.isEmpty() ? "" : "," + dec);
        }

        /** Como quebrado mixto (1 3/4). Vacío si es entero o el denominador es enorme. */
        String quebrado() {
            if (d.equals(BigInteger.ONE) || d.compareTo(BigInteger.valueOf(100000)) > 0) return "";
            BigInteger an = n.abs();
            BigInteger[] qr = an.divideAndRemainder(d);
            String signo = n.signum() < 0 ? "−" : "";
            if (qr[0].signum() == 0) return signo + qr[1] + "/" + d;
            return signo + qr[0] + " " + qr[1] + "/" + d;
        }

        /** Para seguir calculando con el resultado sin perder exactitud. */
        String paraExpresion() {
            BigInteger x = d;
            while (x.mod(BigInteger.valueOf(2)).signum() == 0) x = x.divide(BigInteger.valueOf(2));
            while (x.mod(BigInteger.valueOf(5)).signum() == 0) x = x.divide(BigInteger.valueOf(5));
            if (x.equals(BigInteger.ONE)) {
                String s = new BigDecimal(n).divide(new BigDecimal(d)).stripTrailingZeros().toPlainString();
                return s.replace('.', ',').replace("-", "−");
            }
            return "(" + (n.signum() < 0 ? "−" : "") + n.abs() + "÷" + d + ")";
        }
    }

    /** Lee y resuelve la operación respetando paréntesis y prioridad. */
    static final class Calc {
        private final String s;
        private int i;

        private static final class Val {
            final Fr v; final boolean pct;
            Val(Fr v, boolean pct) { this.v = v; this.pct = pct; }
        }

        Calc(String s) { this.s = s.replace(" ", ""); }

        Fr evaluar() {
            Val v = suma();
            if (i != s.length()) throw new IllegalArgumentException("sobra algo");
            return v.v;
        }

        private char ver() { return i < s.length() ? s.charAt(i) : 0; }

        private Val suma() {
            Val a = producto();
            while (true) {
                char c = ver();
                if (c == '+' || c == '−' || c == '-') {
                    i++;
                    Val b = producto();
                    Fr x = b.pct ? a.v.por(b.v) : b.v; // 200 + 10% = 220
                    a = new Val(c == '+' ? a.v.mas(x) : a.v.menos(x), false);
                } else return a;
            }
        }

        private Val producto() {
            Val a = unario();
            while (true) {
                char c = ver();
                if (c == '×' || c == '*') { i++; a = new Val(a.v.por(unario().v), false); }
                else if (c == '÷' || c == '/') { i++; a = new Val(a.v.entre(unario().v), false); }
                else if (c == '(' || Character.isDigit(c)) { a = new Val(a.v.por(unario().v), false); } // 2(3) = 6
                else return a;
            }
        }

        private Val unario() {
            char c = ver();
            if (c == '−' || c == '-') { i++; Val v = unario(); return new Val(v.v.neg(), v.pct); }
            if (c == '+') { i++; return unario(); }
            Val v = primario();
            while (ver() == '%') { i++; v = new Val(v.v.entre(Fr.de(100)), true); }
            return v;
        }

        private Val primario() {
            char c = ver();
            if (c == '(') {
                i++;
                Val v = suma();
                if (ver() == ')') i++; // si falta cerrar, se cierra solo
                return new Val(v.v, false);
            }
            int ini = i;
            while (Character.isDigit(ver()) || ver() == ',' || ver() == '.') i++;
            if (ini == i) throw new IllegalArgumentException("falta un número");
            String num = s.substring(ini, i).replace('.', ',');
            int coma = num.indexOf(',');
            if (coma < 0) return new Val(new Fr(new BigInteger(num), BigInteger.ONE), false);
            String ent = num.substring(0, coma), dec = num.substring(coma + 1).replace(",", "");
            if (ent.isEmpty()) ent = "0";
            BigInteger den = BigInteger.TEN.pow(dec.length());
            return new Val(new Fr(new BigInteger(ent + dec), den), false);
        }
    }

    // =====================================================================
    // 2. CONVERSOR mm ↔ pulgadas fraccionarias
    // =====================================================================

    private boolean ocupado;

    private View conversor() {
        LinearLayout l = vertical();
        l.setPadding(dp(8), dp(8), dp(8), dp(8));
        l.addView(titulo("Milímetros"));
        EditText mm = numero("Escriba milímetros");
        l.addView(mm);
        l.addView(titulo("Pulgadas"));
        EditText pul = new EditText(this);
        pul.setHint("Ej: 3 5/8   ó   7/16   ó   2");
        pul.setTextSize(22);
        pul.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        l.addView(pul);
        TextView res = resultado();
        l.addView(res);

        mm.addTextChangedListener(alCambiar(() -> {
            if (ocupado) return;
            double v = leer(mm);
            ocupado = true;
            if (mm.getText().toString().trim().isEmpty()) { pul.setText(""); res.setText(""); }
            else {
                double in = v / 25.4;
                pul.setText(pulgadas(in, 128).replace("≈ ", ""));
                res.setText(tablaPulgadas(in));
            }
            ocupado = false;
        }));
        pul.addTextChangedListener(alCambiar(() -> {
            if (ocupado) return;
            double in = leerPulgadas(pul.getText().toString());
            ocupado = true;
            if (Double.isNaN(in)) { mm.setText(""); res.setText(pul.getText().length() > 0 ? "Escriba así: 3 5/8" : ""); }
            else {
                double v = in * 25.4;
                mm.setText(dec(v, 2));
                res.setText("= " + dec(v, 2) + " mm\n= " + dec(v / 10, 2) + " cm\n\n" + tablaPulgadas(in));
            }
            ocupado = false;
        }));
        return desplazable(l);
    }

    private String tablaPulgadas(double in) {
        return "Exacta (1/128):  " + pulgadas(in, 128) + "\n"
                + "En 64avos:  " + pulgadas(in, 64) + "\n"
                + "En 32avos:  " + pulgadas(in, 32) + "\n"
                + "En 16avos:  " + pulgadas(in, 16) + "\n"
                + "En decimal:  " + dec(in, 4) + "\"\n\n"
                + "≈ quiere decir que es la medida comercial más cercana.";
    }

    /** Pulgadas en quebrado redondeado a la fracción pedida (128, 64, 32, 16). */
    static String pulgadas(double in, int den) {
        boolean neg = in < 0;
        double a = Math.abs(in);
        long n = Math.round(a * den);
        boolean exacto = Math.abs(a * den - n) < 1e-6;
        long ent = n / den, num = n % den;
        long d = den;
        while (num > 0 && num % 2 == 0) { num /= 2; d /= 2; }
        String s;
        if (num == 0) s = ent + "\"";
        else if (ent == 0) s = num + "/" + d + "\"";
        else s = ent + " " + num + "/" + d + "\"";
        return (exacto ? "" : "≈ ") + (neg ? "−" : "") + s;
    }

    static double leerPulgadas(String t) {
        t = t.replace("\"", "").replace("-", " ").replace(',', '.').trim();
        if (t.isEmpty()) return Double.NaN;
        try {
            String[] p = t.split("\\s+");
            double total = 0;
            for (String x : p) {
                if (x.contains("/")) {
                    String[] f = x.split("/");
                    total += Double.parseDouble(f[0]) / Double.parseDouble(f[1]);
                } else total += Double.parseDouble(x);
            }
            return Double.isInfinite(total) ? Double.NaN : total;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    // =====================================================================
    // 3. CONCRETO
    // =====================================================================

    private static final String[] MEZCLAS = {"1:2:2", "1:2:3", "1:2:4", "1:3:6"};
    private int mezcla = 1;
    private boolean enMetros = false;

    private View concreto() {
        LinearLayout l = vertical();
        l.setPadding(dp(8), dp(8), dp(8), dp(8));
        TextView ayuda = new TextView(this);
        ayuda.setText("Columna: ancho × fondo × alto.  Zapata: largo × ancho × profundidad.");
        ayuda.setTextSize(14);
        l.addView(ayuda);
        Button unidad = new Button(this);
        unidad.setAllCaps(false);
        unidad.setText(enMetros ? "Medidas en: metros (toque para cambiar)" : "Medidas en: centímetros (toque para cambiar)");
        l.addView(unidad);
        EditText a = fila(l, "Ancho", "");
        EditText f = fila(l, "Fondo / largo", "");
        EditText h = fila(l, "Alto / profundidad", "");
        EditText n = fila(l, "Cuántas (columnas o zapatas)", "1");
        Button bm = new Button(this);
        bm.setAllCaps(false);
        l.addView(bm);
        EditText desp = fila(l, "Desperdicio %", "5");
        EditText lb = fila(l, "Litros por bulto de cemento", "36");
        TextView res = resultado();
        l.addView(res);

        Runnable calc = () -> {
            double k = enMetros ? 1 : 0.01;
            double vol = leer(a) * k * leer(f) * k * leer(h) * k * Math.max(1, leer(n));
            bm.setText("Mezcla " + MEZCLAS[mezcla] + "  (cemento : arena : grava) — toque para cambiar");
            if (vol <= 0) { res.setText("Escriba las medidas."); return; }
            double volD = vol * (1 + leer(desp) / 100);
            int[] p = partes(MEZCLAS[mezcla]);
            int suma = p[0] + p[1] + p[2];
            double litrosCemento = volD * FACTOR_CONCRETO * p[0] / suma * 1000;
            double litrosBulto = leer(lb) > 0 ? leer(lb) : 36;
            long cuartos = (long) Math.ceil(litrosCemento / litrosBulto * 4 - 1e-9);
            long mArena = cuartos * p[1] / p[0], mGrava = cuartos * p[2] / p[0];
            long medAgua = (long) Math.ceil(cuartos * 12.5 * 0.5 / MEDIO_CUNETE - 1e-9);
            res.setText("Volumen: " + dec(vol, 3) + " m³  (con desperdicio " + dec(volD, 3) + " m³)\n\n"
                    + "🟫 CEMENTO: " + bultos(cuartos) + "  (" + dec(cuartos * 12.5, 1) + " kg)\n"
                    + "      = " + cunetes(cuartos) + "\n\n"
                    + "🟨 ARENA: " + cunetes(mArena) + "\n"
                    + "      = " + dec(mArena * MEDIO_CUNETE / 1000, 2) + " m³\n\n"
                    + "⬜ GRAVA: " + cunetes(mGrava) + "\n"
                    + "      = " + dec(mGrava * MEDIO_CUNETE / 1000, 2) + " m³\n\n"
                    + "💧 AGUA aprox.: " + cunetes(medAgua) + "\n\n"
                    + "CÓMO MEDIR CADA MEZCLA\n"
                    + "• Con ½ bulto: 1 cuñete de cemento, " + p[1] + " de arena, " + p[2] + " de grava.\n"
                    + "• Con ¼ bulto: 1 medio cuñete de cemento, " + p[1] + " de arena, " + p[2] + " de grava (medios cuñetes).\n\n"
                    + "Cuñete = balde de 19 L · medio cuñete = 9,5 L. ¼ de bulto ≈ 1 medio cuñete.");
        };
        unidad.setOnClickListener(v -> {
            enMetros = !enMetros;
            unidad.setText(enMetros ? "Medidas en: metros (toque para cambiar)" : "Medidas en: centímetros (toque para cambiar)");
            calc.run();
        });
        bm.setOnClickListener(v -> { mezcla = (mezcla + 1) % MEZCLAS.length; calc.run(); });
        for (EditText e : new EditText[]{a, f, h, n, desp, lb}) e.addTextChangedListener(alCambiar(calc));
        calc.run();
        return desplazable(l);
    }

    // =====================================================================
    // 4. LADRILLO / FAROL
    // =====================================================================

    private static final String[] PEGAS = {"1:3", "1:4", "1:5", "1:6"};
    private int pega = 1;

    private View ladrillo() {
        LinearLayout l = vertical();
        l.setPadding(dp(8), dp(8), dp(8), dp(8));
        l.addView(titulo("Pared (metros)"));
        EditText pl = fila(l, "Largo de la pared", "");
        EditText ph = fila(l, "Alto de la pared", "");
        l.addView(titulo("Farol o ladrillo (cm), como se ve en la pared"));
        EditText ul = fila(l, "Largo", "30");
        EditText ua = fila(l, "Alto", "20");
        EditText ug = fila(l, "Grueso (ancho del muro)", "10");
        EditText uj = fila(l, "Grueso del mortero de pega", "1,5");
        l.addView(titulo("Ventanas (metros)"));
        EditText va = fila(l, "Ancho", "");
        EditText vh = fila(l, "Alto", "");
        EditText vn = fila(l, "Cantidad", "0");
        l.addView(titulo("Puertas (metros)"));
        EditText da = fila(l, "Ancho", "");
        EditText dh = fila(l, "Alto", "");
        EditText dn = fila(l, "Cantidad", "0");
        Button bp = new Button(this);
        bp.setAllCaps(false);
        l.addView(bp);
        EditText dl = fila(l, "Desperdicio de farol %", "5");
        EditText dm = fila(l, "Desperdicio de mortero %", "10");
        EditText lb = fila(l, "Litros por bulto de cemento", "36");
        TextView res = resultado();
        l.addView(res);

        Runnable calc = () -> {
            bp.setText("Mortero de pega " + PEGAS[pega] + "  (cemento : arena) — toque para cambiar");
            double area = leer(pl) * leer(ph)
                    - leer(va) * leer(vh) * leer(vn)
                    - leer(da) * leer(dh) * leer(dn);
            double L = leer(ul) / 100, A = leer(ua) / 100, G = leer(ug) / 100, J = leer(uj) / 100;
            if (area <= 0 || L <= 0 || A <= 0) { res.setText("Escriba las medidas de la pared y del farol."); return; }
            double porM2 = 1 / ((L + J) * (A + J));
            long piezas = (long) Math.ceil(area * porM2 * (1 + leer(dl) / 100) - 1e-9);
            double mortero = area * (1 - (L * A) * porM2) * G * (1 + leer(dm) / 100);
            int r = partes(PEGAS[pega])[1];
            double litrosCemento = mortero * FACTOR_MORTERO / (1 + r) * 1000;
            double litrosBulto = leer(lb) > 0 ? leer(lb) : 36;
            long cuartos = (long) Math.ceil(litrosCemento / litrosBulto * 4 - 1e-9);
            long mArena = cuartos * r;
            res.setText("Área para pegar: " + dec(area, 2) + " m²  (" + dec(porM2, 1) + " piezas por m²)\n\n"
                    + "🧱 FAROLES / LADRILLOS: " + piezas + "\n\n"
                    + "Mortero: " + dec(mortero, 3) + " m³\n\n"
                    + "🟫 CEMENTO: " + bultos(cuartos) + "  (" + dec(cuartos * 12.5, 1) + " kg)\n"
                    + "      = " + cunetes(cuartos) + "\n\n"
                    + "🟨 ARENA: " + cunetes(mArena) + "\n"
                    + "      = " + dec(mArena * MEDIO_CUNETE / 1000, 2) + " m³\n\n"
                    + "CÓMO MEDIR CADA MEZCLA\n"
                    + "• Con ½ bulto: 1 cuñete de cemento y " + r + " cuñetes de arena.\n"
                    + "• Con ¼ bulto: 1 medio cuñete de cemento y " + r + " medios cuñetes de arena.");
        };
        bp.setOnClickListener(v -> { pega = (pega + 1) % PEGAS.length; calc.run(); });
        for (EditText e : new EditText[]{pl, ph, ul, ua, ug, uj, va, vh, vn, da, dh, dn, dl, dm, lb})
            e.addTextChangedListener(alCambiar(calc));
        calc.run();
        return desplazable(l);
    }

    // =====================================================================
    // Ayudas
    // =====================================================================

    static int[] partes(String m) {
        String[] p = m.split(":");
        int[] r = new int[p.length];
        for (int i = 0; i < p.length; i++) r[i] = Integer.parseInt(p[i]);
        return r;
    }

    /** Cuartos de bulto → "2 ¾ bultos". */
    static String bultos(long cuartos) {
        long ent = cuartos / 4, r = cuartos % 4;
        String fr = r == 1 ? "¼" : r == 2 ? "½" : r == 3 ? "¾" : "";
        if (ent == 0 && fr.isEmpty()) return "0 bultos";
        if (ent == 0) return fr + " de bulto";
        return ent + (fr.isEmpty() ? "" : " " + fr) + (ent == 1 && fr.isEmpty() ? " bulto" : " bultos");
    }

    /** Medios cuñetes → "5 cuñetes y 1 medio cuñete". */
    static String cunetes(long medios) {
        long ent = medios / 2, r = medios % 2;
        if (ent == 0 && r == 0) return "0 cuñetes";
        if (ent == 0) return "1 medio cuñete";
        String s = ent + (ent == 1 ? " cuñete" : " cuñetes");
        return r == 1 ? s + " y 1 medio cuñete" : s;
    }

    static String dec(double v, int d) {
        return new BigDecimal(v).setScale(d, RoundingMode.HALF_UP).stripTrailingZeros()
                .toPlainString().replace('.', ',');
    }

    private double leer(EditText e) {
        String s = e.getText().toString().trim().replace(',', '.');
        if (s.isEmpty()) return 0;
        try { return Double.parseDouble(s); } catch (Exception x) { return 0; }
    }

    private TextWatcher alCambiar(Runnable r) {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { r.run(); }
        };
    }

    private EditText numero(String pista) {
        EditText e = new EditText(this);
        e.setHint(pista);
        e.setTextSize(20);
        e.setSingleLine(true);
        e.setKeyListener(DigitsKeyListener.getInstance("0123456789.,"));
        e.setRawInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private EditText fila(LinearLayout padre, String etiqueta, String valor) {
        LinearLayout r = horizontal();
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextSize(16);
        r.addView(t, peso(1.4f));
        EditText e = numero("");
        e.setText(valor);
        e.setGravity(Gravity.END);
        r.addView(e, peso(1));
        padre.addView(r);
        return e;
    }

    private TextView titulo(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(12), 0, dp(2));
        return v;
    }

    private TextView resultado() {
        TextView v = new TextView(this);
        v.setTextSize(17);
        v.setTextColor(0xFF111111);
        v.setTextIsSelectable(true);
        int p = dp(12);
        v.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFF8E1);
        g.setCornerRadius(dp(10));
        v.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        v.setLayoutParams(lp);
        return v;
    }

    private ScrollView desplazable(View v) {
        ScrollView sv = new ScrollView(this);
        sv.addView(v);
        return sv;
    }

    private int dp(float v) { return Util.dp(this, v); }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout.LayoutParams peso(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }
}
