package co.jose.chptronic;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Guarda los datos de la app y los archivos en Descargas/MiBarra/ChpTronic/<carpeta>. */
final class Almacen {

    private Almacen() {}

    static final String CARPETA = Environment.DIRECTORY_DOWNLOADS + "/MiBarra/ChpTronic/";

    private static JSONObject datos;

    // ---------- Datos internos (casos, bodega, biblioteca, casas, respuestas) ----------

    static JSONObject datos(Context c) {
        if (datos != null) return datos;
        try {
            File f = new File(c.getFilesDir(), "datos.json");
            if (f.exists()) {
                try (InputStream in = new FileInputStream(f)) {
                    datos = new JSONObject(new String(leer(in), StandardCharsets.UTF_8));
                }
            }
        } catch (Exception ignored) { }
        if (datos == null) datos = new JSONObject();
        return datos;
    }

    static JSONArray lista(Context c, String nombre) {
        JSONObject d = datos(c);
        JSONArray a = d.optJSONArray(nombre);
        if (a == null) {
            a = new JSONArray();
            try { d.put(nombre, a); } catch (Exception ignored) { }
        }
        return a;
    }

    static void guardar(Context c) {
        try {
            File f = new File(c.getFilesDir(), "datos.json");
            File t = new File(c.getFilesDir(), "datos.tmp");
            try (OutputStream o = new FileOutputStream(t)) {
                o.write(datos(c).toString().getBytes(StandardCharsets.UTF_8));
            }
            if (!t.renameTo(f)) {
                try (OutputStream o = new FileOutputStream(f)) {
                    o.write(datos(c).toString().getBytes(StandardCharsets.UTF_8));
                }
            }
        } catch (Exception ignored) { }
    }

    static void quitar(JSONArray a, int i) {
        a.remove(i);
    }

    // ---------- Archivos en Descargas ----------

    static String limpio(String s) {
        String x = s == null ? "" : s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", "_").trim();
        return x.isEmpty() ? "archivo" : x;
    }

    static String ruta(String sub) {
        String r = CARPETA;
        if (sub != null && !sub.isEmpty()) r += sub + "/";
        return r;
    }

    /** Crea un archivo nuevo en Descargas/MiBarra/ChpTronic/<sub>. */
    static Uri crear(Context c, String sub, String nombre, String mime) {
        ContentResolver r = c.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, limpio(nombre));
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, ruta(sub));
        return r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
    }

    /** Copia un archivo escogido por el usuario a nuestra carpeta. */
    static Uri copiar(Context c, Uri origen, String sub, String nombre, String mime) {
        try {
            Uri destino = crear(c, sub, nombre, mime == null ? "application/octet-stream" : mime);
            if (destino == null) return null;
            try (InputStream in = c.getContentResolver().openInputStream(origen);
                 OutputStream o = c.getContentResolver().openOutputStream(destino)) {
                if (in == null || o == null) return null;
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) o.write(b, 0, n);
            }
            return destino;
        } catch (Exception e) {
            return null;
        }
    }

    static String nombreDe(Context c, Uri u) {
        try (Cursor k = c.getContentResolver().query(u, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
            if (k != null && k.moveToFirst()) return k.getString(0);
        } catch (Exception ignored) { }
        String s = u.getLastPathSegment();
        return s == null ? "archivo" : s;
    }

    static byte[] leer(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return b.toByteArray();
    }

    static String leerTexto(Context c, Uri u) {
        try (InputStream in = c.getContentResolver().openInputStream(u)) {
            if (in == null) return null;
            return new String(leer(in), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    /** Archivos de una subcarpeta: {uri, nombre, tamaño}. */
    static List<Object[]> archivos(Context c, String sub) {
        List<Object[]> r = new ArrayList<>();
        String rp = ruta(sub);
        try (Cursor k = c.getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE},
                MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", new String[]{rp + "%"}, null)) {
            while (k != null && k.moveToNext()) {
                Uri u = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, String.valueOf(k.getLong(0)));
                r.add(new Object[]{u, k.getString(1), k.getLong(2)});
            }
        } catch (Exception ignored) { }
        return r;
    }

    static String tamano(long b) {
        if (b < 1024) return b + " bytes";
        if (b < 1024 * 1024) return Math.round(b / 1024.0) + " KB";
        return String.format(java.util.Locale.US, "%.1f MB", b / (1024.0 * 1024.0));
    }
}
