package co.jose.chptronic;

/** Inventos de ejemplo y guías de Casa inteligente (Alexa). */
final class Guias {

    private Guias() {}

    // ======================= Mis Inventos (plantillas) =======================
    // Cada invento: {nombre, idea, componentes "cantidad|nombre" separados por \n, pasos separados por \n, avisos}

    static final String[][] INVENTOS = {
            {"Detector de paso en la puerta (sensor PIR)",
                    "Cuando una persona pasa por la puerta suena un pito y prende un LED. Funciona con 5 V (cargador de celular) o con 4 pilas AA. Sin peligro: no toca los 110 V.",
                    "1|Sensor de movimiento PIR HC-SR501\n"
                            + "1|Zumbador (buzzer) activo de 5 V\n"
                            + "1|Transistor NPN 2N2222 (o BC547)\n"
                            + "1|Resistencia de 1 kΩ (café, negro, rojo)\n"
                            + "1|LED rojo de 5 mm\n"
                            + "1|Resistencia de 330 Ω (naranja, naranja, café)\n"
                            + "1|Plaqueta perforada (baquelita universal) pequeña\n"
                            + "1|Cargador de celular de 5 V con cable USB viejo (o portapilas de 4 AA)\n"
                            + "1|Cable delgado de colores (rojo, negro, amarillo)\n"
                            + "1|Estaño y cautín",
                    "Pruebe el sensor solo: conecte VCC al + (5 V) y GND al −. Espere 1 minuto quieto: el sensor se está calentando y puede dar falsas alarmas al principio.\n"
                            + "Laboratorio, prueba Pila o batería: perilla en V⎓ 20, negro en GND del sensor y rojo en la pata OUT. Sin movimiento debe marcar casi 0; al pasar la mano debe marcar unos 3,3. Si pasa eso, el sensor está bueno.\n"
                            + "Ajuste los dos tornillitos naranjas del sensor: uno es la distancia (Sx) y el otro es cuánto tiempo pita (Tx); vienen marcados en la plaqueta. Empiece con el tiempo al mínimo y la distancia en la mitad.\n"
                            + "Ponga el puente amarillo del sensor en la posición H (pita mientras haya movimiento).\n"
                            + "Transistor 2N2222 mirando la cara plana, patas abajo: izquierda Emisor, centro Base, derecha Colector (en el BC547: izquierda Colector, centro Base, derecha Emisor; revise la hoja de la tienda).\n"
                            + "OUT del sensor → resistencia de 1 kΩ → Base del transistor.\n"
                            + "Emisor del transistor → − (GND).\n"
                            + "Zumbador: su pata + (la larga, o la marcada +) va al + de 5 V; su pata − va al Colector del transistor.\n"
                            + "LED: pata larga al + de 5 V a través de la resistencia de 330 Ω; pata corta al Colector (prende junto con el pito).\n"
                            + "Antes de conectar la corriente, revise todo con la prueba Cable de corriente (continuidad) y que no haya estaño uniendo puntos vecinos.\n"
                            + "Conecte y pase la mano: debe pitar y prender el LED.\n"
                            + "Instálelo a unos 2 metros de alto, mirando hacia el paso de la puerta, lejos de la luz del sol directa y de ventiladores o calentadores (lo engañan).",
                    "Si más adelante quiere que prenda un bombillo de 110 V, se agrega un MÓDULO RELÉ de 5 V de un canal (ya trae su transistor y su diodo). Esa parte sí lleva 110 V: la armamos juntos con el botón Claude, con caja cerrada y fusible."},
            {"Alarma del carro con aviso al celular",
                    "Si alguien golpea o hala un espejo o una puerta, suena una sirena en el carro y le llega un mensaje y una llamada al celular. Funciona en cualquier parte porque usa un chip (SIM) de celular.",
                    "1|Plaquita ESP32 (el cerebro, se programa)\n"
                            + "1|Módulo 4G con SIM (tipo A7670 o SIM7600) — NO 2G\n"
                            + "1|SIM de prepago con saldo para mensajes y llamadas\n"
                            + "2|Sensor de vibración SW-420 (uno por lado, cerca de cada espejo)\n"
                            + "1|Sirena de 12 V para carro\n"
                            + "1|Módulo relé de 5 V de un canal\n"
                            + "1|Convertidor de 12 V a 5 V (tipo LM2596 o mini-560)\n"
                            + "1|Portafusible derivador (add-a-fuse) del tamaño de los fusibles de su carro\n"
                            + "1|Fusible de 2 A para la alarma\n"
                            + "1|Fusible de 10 A en línea para la sirena\n"
                            + "1|Caja plástica pequeña\n"
                            + "1|Cable automotriz y terminales",
                    "Mándeme por el botón Claude: modelo y año de la camioneta y foto de la caja de fusibles. Con eso le digo de qué fusible tomar la corriente.\n"
                            + "Pruebe todo primero en la mesa, con una batería de 12 V o una fuente, antes de llevarlo al carro.\n"
                            + "Conecte el convertidor a 12 V y, ANTES de conectarle nada, mida su salida (prueba Pila o batería, V⎓ 20). Ajuste el tornillito hasta que marque 5,0.\n"
                            + "Yo le preparo el programa del ESP32 con su número de celular; usted solo lo carga con el cable USB siguiendo mis pasos.\n"
                            + "Pruebe: golpecito al sensor → debe sonar la sirena y llegarle el mensaje.\n"
                            + "Mida el consumo en reposo: multímetro en A 200m, en serie con el + (cable rojo en VΩmA). Debe dar lo más bajo posible; si pasa de 50 mA, me avisa, porque descargaría la batería en pocos días.\n"
                            + "En el carro: tome la corriente con el portafusible derivador, nunca cortando cables de fábrica. Tierra a un tornillo del chasis.\n"
                            + "Esconda la caja y la sirena donde no se vean fácil.",
                    "Cada cable que llegue a la batería del carro va con su fusible, cerca de la batería. Nunca corte cables de fábrica en un carro moderno: puede dañar la electrónica y la garantía."}
    };

    // ======================= Casa inteligente (Alexa) =======================
    // {título, pasos separados por \n, aviso}

    static final String[][] ALEXA = {
            {"Lo que debe comprar",
                    "Enchufe inteligente Wi‑Fi: en la caja debe decir \"Compatible con Alexa\" (Works with Alexa) y \"2.4 GHz\".\n"
                            + "Que el enchufe aguante lo que va a conectar: mire los amperios de la caja (por ejemplo 10 A) y los vatios de la sirena o el bombillo.\n"
                            + "Sirena de 110 V para exterior, para la calle.\n"
                            + "Bombillos inteligentes (opcional) para prender luces por voz.\n"
                            + "Cada enchufe y bombillo se instala con la app que trae la caja, y luego esa app se enlaza con la app de Alexa (Más → Skills → buscar la marca → Habilitar).",
                    "La sirena va en un enchufe inteligente. Si la sirena es de 12 V, necesita un adaptador de 12 V enchufado al enchufe inteligente."},
            {"Alarma con frase secreta",
                    "Abra la app Amazon Alexa en el celular.\n"
                            + "Toque \"Más\" (abajo a la derecha) y luego \"Rutinas\".\n"
                            + "Toque el \"+\" para crear una rutina nueva.\n"
                            + "Nombre: \"Alarma\".\n"
                            + "\"Cuando esto suceda\" → \"Voz\" → escriba su frase secreta, por ejemplo \"llegó la tía\".\n"
                            + "\"Agregar acción\" → \"Hogar inteligente\" → escoja el enchufe de la sirena → Encender.\n"
                            + "Agregue otra acción: \"Hogar inteligente\" → todas las luces → Encender.\n"
                            + "Agregue otra acción: \"Mensajes\" → \"Enviar notificación\" → escriba \"¡Alarma en la casa!\" (le llega al celular).\n"
                            + "Si su app le muestra la acción de anuncio o de llamada, agréguela para avisar a un familiar que tenga Alexa.\n"
                            + "Guarde y pruebe diciendo: \"Alexa, llegó la tía\".\n"
                            + "Haga otra rutina \"Alexa, ya se fue la tía\" que APAGUE la sirena.",
                    "No use la palabra \"ladrón\": el ladrón la oye. Alexa NO llama al 123: a la policía llame usted desde el celular. Sin luz o sin internet Alexa no funciona."},
            {"Me voy de la casa",
                    "Más → Rutinas → +.\n"
                            + "Voz: \"me voy\".\n"
                            + "Acciones: apagar todos los enchufes y luces, menos una luz de la sala.\n"
                            + "Acción \"Alexa dice\": \"Revise que la estufa y las puertas queden cerradas\".",
                    ""},
            {"Buenas noches",
                    "Más → Rutinas → +.\n"
                            + "Voz: \"buenas noches\".\n"
                            + "Acciones: apagar las luces, dejar la del patio prendida.\n"
                            + "Acción \"Alexa dice\": \"¿Cerró la puerta y el gas?\".",
                    ""},
            {"Simular que hay alguien (cuando viaja)",
                    "Más → Rutinas → +.\n"
                            + "\"Cuando esto suceda\" → \"Programación\" → todos los días a las 7:00 p. m.\n"
                            + "Acción: prender la luz de la sala.\n"
                            + "Haga otra rutina a las 10:30 p. m. que la apague y prenda la de la pieza; y otra a las 11:15 p. m. que apague todo.\n"
                            + "Cambie las horas de vez en cuando para que no se note la costumbre.",
                    ""}
    };
}
