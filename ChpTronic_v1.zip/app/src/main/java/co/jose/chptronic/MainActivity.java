package co.jose.chptronic;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * ChpTronic: taller de electrónica y electricidad de Chepe.
 * Una sola pantalla que cambia de contenido; el botón atrás devuelve a la anterior.
 */
public class MainActivity extends Pantalla {

    static final String VERSION = "v1.0";

    static final int NEGRO = 0xFF111111, GRIS = 0xFF555555, FONDO = 0xFFF3F2EE, BLANCO = 0xFFFFFFFF;
    static final int AZUL = 0xFF1E5BB8, VERDE = 0xFF1E7D3A, ROJO = 0xFFC62828, NARANJA = 0xFFD9730D,
            MORADO = 0xFF5B3FB0, TURQ = 0xFF0F7C8C, CAFE = 0xFF6D4C1F, ROSA = 0xFFAD2F68, GRIS_OSC = 0xFF3D3D3D;

    private static final int R_FOTO = 11, R_ARCHIVO = 12, R_ESCANER = 13, R_DICTAR = 14, R_IMPORTAR = 15;

    private final Deque<Runnable> pila = new ArrayDeque<>();
    private LinearLayout c; // contenido de la pantalla actual
    private SharedPreferences pr;

    private Consumer<List<Uri>> alRecibir;
    private Consumer<String> alImportar;
    private EditText dictarEn;
    private Uri fotoPendiente;

    // ======================= Arranque =======================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pr = getSharedPreferences("chptronic", MODE_PRIVATE);
        getWindow().setStatusBarColor(0xFF12172A);
        ir(this::inicio);
        recordarCopia();
    }

    @Override
    protected void onPause() {
        Almacen.guardar(this);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        atras();
    }

    private void ir(Runnable pantalla) {
        Almacen.guardar(this);
        pila.push(pantalla);
        pantalla.run();
    }

    private void atras() {
        Almacen.guardar(this);
        if (pila.size() > 1) {
            pila.pop();
            pila.peek().run();
        } else {
            finish();
        }
    }

    private void refrescar() {
        Almacen.guardar(this);
        if (!pila.isEmpty()) pila.peek().run();
    }

    // ======================= Piezas de pantalla =======================

    /** Prepara una pantalla nueva con su barra de arriba. */
    private void nueva(String titulo, boolean conAtras) {
        LinearLayout raiz = vertical();
        raiz.setBackgroundColor(FONDO);

        LinearLayout barra = horizontal();
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackgroundColor(0xFF12172A);
        barra.setPadding(dp(4), dp(4), dp(8), dp(4));
        TextView izq = txt(conAtras ? "←" : "☰", 28, BLANCO, true);
        izq.setGravity(Gravity.CENTER);
        izq.setOnClickListener(v -> { if (conAtras) atras(); else menu(); });
        barra.addView(izq, new LinearLayout.LayoutParams(dp(52), dp(52)));
        TextView t = txt(titulo, 20, BLANCO, true);
        t.setSingleLine(true);
        barra.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView ver = txt(VERSION, 14, 0xFF12172A, true);
        ver.setBackground(fondo(dp(8), 0xFFFFD54F));
        ver.setPadding(dp(8), dp(3), dp(8), dp(3));
        barra.addView(ver);
        if (conAtras) {
            TextView m = txt("☰", 24, BLANCO, true);
            m.setGravity(Gravity.CENTER);
            m.setOnClickListener(v -> menu());
            barra.addView(m, new LinearLayout.LayoutParams(dp(44), dp(52)));
        }
        raiz.addView(barra);

        ScrollView sv = new ScrollView(this);
        c = vertical();
        c.setPadding(dp(10), dp(8), dp(10), dp(24));
        sv.addView(c);
        raiz.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(raiz);
    }

    private TextView txt(String s, float sp, int color, boolean negrita) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(negrita ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setLineSpacing(0, 1.1f);
        return v;
    }

    private void parrafo(String s) {
        TextView t = txt(s, 16, NEGRO, false);
        t.setPadding(dp(4), dp(4), dp(4), dp(4));
        c.addView(t);
    }

    private void titulo(String s) {
        TextView t = txt(s, 19, NEGRO, true);
        t.setPadding(dp(4), dp(14), dp(4), dp(4));
        c.addView(t);
    }

    private void avisoRojo(String s) {
        if (s == null || s.isEmpty()) return;
        TextView t = txt("⚠ " + s.replace("⚠ ", ""), 16, 0xFF7A0000, true);
        t.setBackground(fondoBorde(0xFFFFE3E3, ROJO));
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = anchoTotal();
        lp.topMargin = dp(8);
        c.addView(t, lp);
    }

    private void cajaInfo(String s, int fondoColor, int borde) {
        TextView t = txt(s, 16, NEGRO, false);
        t.setBackground(fondoBorde(fondoColor, borde));
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = anchoTotal();
        lp.topMargin = dp(8);
        c.addView(t, lp);
    }

    private GradientDrawable fondoBorde(int color, int borde) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(2), borde);
        return g;
    }

    private LinearLayout.LayoutParams anchoTotal() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    /** Botón ancho de color. */
    private TextView btn(String s, int color, Runnable r) {
        TextView b = txt(s, 17, BLANCO, true);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        b.setBackground(fondo(dp(12), color));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = anchoTotal();
        lp.topMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private void boton(String s, int color, Runnable r) { c.addView(btn(s, color, r)); }

    /** Dos botones lado a lado. */
    private void fila(TextView a, TextView b) {
        LinearLayout f = horizontal();
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
        la.setMargins(0, dp(6), dp(3), 0);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lb.setMargins(dp(3), dp(6), 0, 0);
        a.setLayoutParams(la);
        f.addView(a);
        if (b != null) { b.setLayoutParams(lb); f.addView(b); }
        else f.addView(new View(this), lb);
        c.addView(f);
    }

    /** Cuadros grandes de 2 en 2. */
    private void cuadros(Object[][] items) {
        for (int i = 0; i < items.length; i += 2) {
            TextView a = cuadro(items[i]);
            TextView b = i + 1 < items.length ? cuadro(items[i + 1]) : null;
            fila(a, b);
        }
    }

    private TextView cuadro(Object[] it) {
        TextView t = txt(it[0] + "\n" + it[1], 16, BLANCO, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(14), dp(6), dp(14));
        t.setBackground(fondo(dp(14), (Integer) it[2]));
        Runnable r = (Runnable) it[3];
        t.setOnClickListener(v -> r.run());
        return t;
    }

    /** Campo de texto que guarda solo mientras escribe; se corrige poniendo el cursor donde sea. */
    private EditText campo(String etiqueta, String valor, boolean varias, Consumer<String> alCambiar) {
        TextView e = txt(etiqueta, 14, GRIS, true);
        e.setPadding(dp(4), dp(8), dp(4), 0);
        c.addView(e);
        EditText t = new EditText(this);
        t.setText(valor);
        t.setTextSize(17);
        t.setTextColor(NEGRO);
        t.setBackground(fondoBorde(BLANCO, 0xFF9E9E9E));
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (varias) {
            t.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            t.setMinLines(3);
            t.setGravity(Gravity.TOP | Gravity.START);
        } else {
            t.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        t.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void afterTextChanged(Editable s) { alCambiar.accept(s.toString()); }
        });
        c.addView(t, anchoTotal());
        return t;
    }

    private void poner(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception ignored) { }
    }

    private static String hoy() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private static String ahora() {
        return new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
    }

    private void confirmar(String pregunta, Runnable si) {
        new AlertDialog.Builder(this).setMessage(pregunta)
                .setPositiveButton("Sí", (d, w) -> si.run())
                .setNegativeButton("No", null).show();
    }

    // ======================= Menú ☰ =======================

    private void menu() {
        String[] op = {"📏 Mi multímetro DT830D", "📁 Dónde se guardan mis archivos", "☁ Copia de seguridad en Google Drive",
                "🗺 Lo que viene en v2, v3 y v4", "ℹ Acerca de ChpTronic " + VERSION};
        new AlertDialog.Builder(this).setTitle("Menú").setItems(op, (d, w) -> {
            if (w == 0) ir(this::laboratorio);
            else if (w == 1) mensaje("Dónde se guardan", "Todo queda en el celular, en la carpeta:\n\nDescargas / MiBarra / ChpTronic\n\nAdentro hay una carpeta para cada cosa: Biblioteca, Fotos, Escaneos, Claude/Enviados, etc.\n\nSi usted mueve una carpeta a la nube, la app la vuelve a crear cuando la necesite.");
            else if (w == 2) mensaje("Copia de seguridad", "1. Abra la app \"Archivos\" (o \"Gestor de archivos\").\n2. Entre a Descargas → MiBarra.\n3. Deje oprimida la carpeta ChpTronic.\n4. Toque \"Compartir\" o \"Copiar a\" y escoja Google Drive.\n\nHágalo una vez al mes: la app se lo recuerda.");
            else if (w == 3) mensaje("Lo que viene", "v2: nevera, lavadora, microondas, aire acondicionado, televisores, controles, sonido, carro y moto, soldadores, relojes digitales, cargadores y UPS, apuntar antena (aire, satélite libre, Claro, Movistar, DIRECTV, Tigo).\n\nv3: celulares, tabletas, portátiles, PC, router, impresoras, cámaras, timbres.\n\nv4: relojería de cuerda y paneles solares.");
            else mensaje("ChpTronic " + VERSION, "Taller de electrónica y electricidad de Chepe Gallego.\n\nTodo lo que escriba, escanee y fotografíe queda en su celular. Para consultarme, use el botón Claude: arma un paquete que usted sube a un chat dentro del proyecto ChpTronic.");
        }).show();
    }

    private void mensaje(String t, String s) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(s).setPositiveButton("Entendido", null).show();
    }

    private void recordarCopia() {
        long ultima = pr.getLong("copia", 0);
        long ahora = System.currentTimeMillis();
        if (ultima == 0) { pr.edit().putLong("copia", ahora).apply(); return; }
        if (ahora - ultima > 30L * 24 * 3600 * 1000) {
            new AlertDialog.Builder(this).setTitle("☁ Copia de su biblioteca")
                    .setMessage("Ya pasó un mes. ¿Hace la copia de la carpeta ChpTronic en Google Drive para no perder su trabajo?")
                    .setPositiveButton("Ver cómo", (d, w) -> mensaje("Copia de seguridad", "1. Abra la app \"Archivos\".\n2. Descargas → MiBarra.\n3. Deje oprimida la carpeta ChpTronic.\n4. Compartir o \"Copiar a\" → Google Drive."))
                    .setNegativeButton("Después", null).show();
            pr.edit().putLong("copia", ahora).apply();
        }
    }

    // ======================= Inicio =======================

    private void inicio() {
        nueva("ChpTronic", false);
        String garantias = garantiasPorVencer();
        if (!garantias.isEmpty()) cajaInfo(garantias, 0xFFFFF4D6, NARANJA);
        cuadros(new Object[][]{
                {"🔧", "Reparar aparatos", AZUL, (Runnable) () -> ir(this::aparatos)},
                {"🧪", "Laboratorio", VERDE, (Runnable) () -> ir(this::laboratorio)},
                {"📚", "Biblioteca", MORADO, (Runnable) () -> ir(() -> biblioteca(""))},
                {"⚡", "Electricidad casa", NARANJA, (Runnable) () -> ir(this::electricidad)},
                {"💡", "Mis Inventos", ROSA, (Runnable) () -> ir(this::inventos)},
                {"🏠", "Casa inteligente", TURQ, (Runnable) () -> ir(this::casaInteligente)},
                {"🛒", "Mis Aparatos", CAFE, (Runnable) () -> ir(this::misAparatos)},
                {"📦", "Bodega de piezas", GRIS_OSC, (Runnable) () -> ir(this::bodega)},
                {"👥", "Clientes y casos", 0xFF2E5E4E, (Runnable) () -> ir(this::casos)},
                {"📄", "Escanear", 0xFF455A64, (Runnable) () -> escanearALaBiblioteca()},
        });
        TextView claude = btn("✉  Claude — escribirle una consulta", 0xFFC15F3C, () -> ir(() -> claude("", "", null)));
        claude.setGravity(Gravity.CENTER);
        claude.setTextSize(19);
        c.addView(claude);
    }

    private void escanearALaBiblioteca() {
        escanear("Biblioteca/Escaneos", us -> {
            JSONObject d = new JSONObject();
            poner(d, "categoria", "Otros");
            poner(d, "titulo", "Escaneo " + hoy());
            poner(d, "notas", "");
            poner(d, "aparato", "");
            poner(d, "fecha", hoy());
            JSONArray a = new JSONArray();
            for (Uri u : us) a.put(u.toString());
            poner(d, "archivos", a);
            JSONArray lista = Almacen.lista(this, "biblioteca");
            lista.put(d);
            Almacen.guardar(this);
            aviso("Guardado en la Biblioteca. Póngale nombre y categoría.");
            int i = lista.length() - 1;
            ir(() -> documento(i));
        });
    }

    // ======================= Aparatos =======================

    private void aparatos() {
        nueva("Reparar aparatos", true);
        String grupo = "";
        for (Datos.Aparato a : Datos.APARATOS) {
            if (!a.grupo.equals(grupo)) {
                grupo = a.grupo;
                titulo(grupo.equals("Próximamente") ? "Próximamente (en gris)" : grupo);
            }
            if (a.version == 1) {
                boton(a.icono + "  " + a.nombre, AZUL, () -> ir(() -> aparato(a)));
            } else {
                boton(a.nombre + "  ·  v" + a.version, 0xFFBDBDBD, () -> aviso(a.nombre + " viene en la versión " + a.version));
            }
        }
    }

    private void aparato(Datos.Aparato a) {
        nueva(a.icono + " " + a.nombre, true);
        avisoRojo(a.aviso);

        int docs = docsDe(a);
        boton("📚  En su biblioteca: " + docs + (docs == 1 ? " documento" : " documentos"), MORADO, () -> ir(() -> biblioteca(a.nombre.split(" ")[0])));

        titulo("Partes que tiene por dentro");
        for (String[] p : a.partes) {
            TextView t = txt("• " + p[0] + ": ", 16, NEGRO, true);
            t.append(p[1]);
            t.setTypeface(Typeface.DEFAULT);
            t.setPadding(dp(4), dp(3), dp(4), dp(3));
            c.addView(t);
        }

        titulo("Fallas más comunes (toque una)");
        for (Datos.Falla f : a.fallas) boton("❓  " + f.titulo, NARANJA, () -> ir(() -> falla(a, f)));

        titulo("Buscar ayuda");
        fila(btn("▶ YouTube", 0xFFD32F2F, () -> abrirWeb("https://www.youtube.com/results?search_query=" + Uri.encode(a.youtube))),
                btn("🔎 Google", AZUL, () -> abrirWeb("https://www.google.com/search?q=" + Uri.encode(a.youtube))));
        fila(btn("👥 Nuevo caso", 0xFF2E5E4E, () -> nuevoCaso(a.nombre)),
                btn("✉ Claude", 0xFFC15F3C, () -> ir(() -> claude(a.nombre + ": ", "Aparato: " + a.nombre + "\nMarca y modelo: \nQué le pasa: \nLo que ya medí: \n", null))));
    }

    private void falla(Datos.Aparato a, Datos.Falla f) {
        nueva(a.nombre, true);
        titulo("❓ " + f.titulo);
        avisoRojo(a.aviso);
        titulo("Paso a paso");
        for (int i = 0; i < f.pasos.length; i++) {
            TextView t = txt((i + 1) + ".  " + f.pasos[i], 17, NEGRO, false);
            t.setPadding(dp(6), dp(6), dp(6), dp(6));
            c.addView(t);
        }
        if (f.pruebas.length > 0) {
            titulo("Pruebas con su multímetro");
            for (String id : f.pruebas) {
                Datos.Prueba p = Datos.prueba(id);
                boton("🧪  " + p.nombre, VERDE, () -> ir(() -> prueba(p, -1)));
            }
        }
        boton("▶  Ver videos de esta falla", 0xFFD32F2F, () -> abrirWeb("https://www.youtube.com/results?search_query=" + Uri.encode("reparar " + a.nombre + " " + f.titulo)));
    }

    private void abrirWeb(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { aviso("No se pudo abrir el navegador"); }
    }

    // ======================= Laboratorio =======================

    private void laboratorio() {
        nueva("🧪 Laboratorio", true);
        cajaInfo("Su multímetro: DT830D.\nCable ROJO casi siempre en VΩmA y NEGRO en COM.\nEl hueco de 10A solo para medir corriente fuerte; después devuelva el rojo a VΩmA.", 0xFFE8F5E9, VERDE);
        titulo("Escoja la prueba");
        for (Datos.Prueba p : Datos.PRUEBAS) boton("🧪  " + p.nombre, VERDE, () -> ir(() -> prueba(p, -1)));
    }

    private void prueba(Datos.Prueba p, int casoIdx) {
        nueva("🧪 " + p.nombre, true);
        avisoRojo(p.aviso);
        Multimetro m = new Multimetro(this);
        m.poner(p.perilla, p.cables);
        c.addView(m, anchoTotal());
        TextView pos = txt("Perilla: " + p.perillaTxt + "   ·   " + cablesTxt(p.cables), 17, ROJO, true);
        pos.setGravity(Gravity.CENTER);
        c.addView(pos);

        titulo("Paso a paso");
        for (int i = 0; i < p.pasos.length; i++) {
            TextView t = txt((i + 1) + ".  " + p.pasos[i], 17, NEGRO, false);
            t.setPadding(dp(6), dp(5), dp(6), dp(5));
            c.addView(t);
        }

        titulo("Resultado");
        TextView res = txt("", 19, NEGRO, true);
        res.setPadding(dp(12), dp(10), dp(12), dp(10));
        final String[] ultimo = {""};
        Consumer<String[]> mostrar = r -> {
            // r = {texto, "bueno"|"malo"|"revisar"}
            int fondoC = "bueno".equals(r[1]) ? 0xFFDFF5E1 : "malo".equals(r[1]) ? 0xFFFFE0E0 : 0xFFFFF4D6;
            int bordeC = "bueno".equals(r[1]) ? VERDE : "malo".equals(r[1]) ? ROJO : NARANJA;
            res.setText(r[0]);
            res.setBackground(fondoBorde(fondoC, bordeC));
            ultimo[0] = p.nombre + ": " + r[0];
        };

        if (p.tipo.equals("condensador")) {
            opciones(mostrar, new String[][]{
                    {"El número sube poco a poco y termina en 1", "✔ BUENO: el condensador carga (no está en corto ni abierto).", "bueno"},
                    {"Se queda en 0 o casi 0", "✖ DAÑADO: está en corto. Cámbielo.", "malo"},
                    {"Marca 1 de una vez y no se mueve", "⚠ Si es de más de 1 µF: está ABIERTO (seco), cámbielo. Si es muy pequeño (nF), es normal: mídalo con un probador.", "revisar"}});
        } else if (p.tipo.equals("serie")) {
            opciones(mostrar, new String[][]{
                    {"El bombillo brilla FUERTE", "✖ CORTO: el aparato tiene un corto. NO lo conecte directo al toma.", "malo"},
                    {"El bombillo queda APAGADO", "⚠ ABIERTO: no pasa corriente. Revise cable, interruptor, fusible y fusible térmico.", "revisar"},
                    {"Brilla suave o parpadea", "✔ NORMAL: el aparato consume y no hay corto. Ya lo puede probar directo.", "bueno"}});
        } else if (p.tipo.equals("led")) {
            opciones(mostrar, new String[][]{
                    {"Prende suave", "✔ BUENO: el LED funciona.", "bueno"},
                    {"No prende de ninguna forma", "⚠ Pruebe al revés. Si tampoco, y tiene puntico negro: DAÑADO. Si no, puede necesitar más voltaje.", "revisar"}});
        } else {
            EditText vatios = null, nominal = null;
            if (p.tipo.equals("resistencia")) {
                vatios = numero("Vatios del aparato (de la placa, ej. 1000)");
            } else if (p.tipo.equals("voltajeDC")) {
                nominal = numero("Voltaje que dice la pila o batería (ej. 1.5, 9, 12)");
            }
            EditText lect = numero("Lo que marca su multímetro");
            final EditText fv = vatios, fn = nominal;
            fila(btn("✔ Evaluar", VERDE, () -> {
                        double x = leerNum(lect);
                        if (Double.isNaN(x)) { aviso("Escriba la lectura"); return; }
                        m.lectura(lect.getText().toString());
                        mostrar.accept(evaluar(p.tipo, x, false, fv == null ? Double.NaN : leerNum(fv), fn == null ? Double.NaN : leerNum(fn)));
                    }),
                    btn("Marca 1 (fuera de rango)", GRIS_OSC, () -> {
                        m.lectura("1   ");
                        mostrar.accept(evaluar(p.tipo, 0, true, fv == null ? Double.NaN : leerNum(fv), fn == null ? Double.NaN : leerNum(fn)));
                    }));
        }
        c.addView(res, anchoTotal());

        fila(btn("👥 Guardar en un caso", 0xFF2E5E4E, () -> {
                    if (ultimo[0].isEmpty()) { aviso("Primero haga la prueba"); return; }
                    guardarMedicion(casoIdx, ultimo[0]);
                }),
                btn("▶ Video", 0xFFD32F2F, () -> abrirWeb("https://www.youtube.com/results?search_query=" + Uri.encode("como probar " + p.nombre + " con multimetro"))));
    }

    private String cablesTxt(String cables) {
        if ("nada".equals(cables)) return "Sin multímetro";
        if ("10A".equals(cables)) return "Rojo en 10A, negro en COM";
        return "Rojo VΩmA, negro COM";
    }

    private void opciones(Consumer<String[]> mostrar, String[][] ops) {
        TextView q = txt("¿Qué vio?", 16, GRIS, true);
        q.setPadding(dp(4), dp(4), dp(4), dp(2));
        c.addView(q);
        for (String[] o : ops) boton(o[0], AZUL, () -> mostrar.accept(new String[]{o[1], o[2]}));
    }

    private EditText numero(String etiqueta) {
        EditText e = campo(etiqueta, "", false, s -> { });
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        return e;
    }

    private double leerNum(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(',', '.')); }
        catch (Exception ex) { return Double.NaN; }
    }

    /** Devuelve {texto, "bueno"|"malo"|"revisar"}. fuera = el multímetro marca 1 a la izquierda. */
    static String[] evaluar(String tipo, double x, boolean fuera, double vatios, double nominal) {
        switch (tipo) {
            case "continuidad":
                if (fuera) return new String[]{"✖ ABIERTO: no pasa corriente. Está dañado (o el punto que midió no es el correcto).", "malo"};
                if (x <= 2) return new String[]{"✔ BUENO: pasa la corriente (" + x + " Ω).", "bueno"};
                return new String[]{"⚠ " + x + " Ω es mucho para esta pieza: contactos sucios o quemados. Límpielos o cámbiela.", "revisar"};
            case "motor":
                if (fuera) return new String[]{"✖ ABIERTO: revise carbones (gastados o pegados), cable e interruptor. Si todo está bien, la bobina está abierta.", "malo"};
                if (x < 0.5) return new String[]{"✖ CORTO: la bobina o la armadura está en corto.", "malo"};
                if (x <= 100) return new String[]{"✔ BUENO: el motor tiene camino (" + x + " Ω). Si no gira, revise lo mecánico.", "bueno"};
                return new String[]{"⚠ " + x + " Ω es alto: carbones gastados o colector sucio.", "revisar"};
            case "resistencia": {
                if (fuera) return new String[]{"✖ ABIERTA: la resistencia está partida. Cámbiela.", "malo"};
                if (x < 0.5) return new String[]{"✖ CORTO: algo está pegado. Revise que no toque la carcasa.", "malo"};
                if (Double.isNaN(vatios) || vatios <= 0) return new String[]{"✔ Tiene continuidad (" + x + " Ω). Escriba los vatios para saber si el valor es el correcto.", "revisar"};
                double esperado = 120.0 * 120.0 / vatios;
                String e = String.format(Locale.US, "%.1f", esperado);
                if (x >= esperado * 0.75 && x <= esperado * 1.3) return new String[]{"✔ BUENA: marca " + x + " Ω y debería marcar unos " + e + " Ω.", "bueno"};
                return new String[]{"⚠ Marca " + x + " Ω pero debería marcar unos " + e + " Ω (a 120 V). Revise los vatios o la resistencia.", "revisar"};
            }
            case "diodo":
                if (fuera) return new String[]{"⚠ Marca 1: o está al revés, o está abierto. Voltee las puntas: si al revés marca entre 400 y 800, está bueno.", "revisar"};
                if (x >= 300 && x <= 900) return new String[]{"✔ BUENO en directo (" + x + "). Verifique que al revés marque 1.", "bueno"};
                if (x < 100) return new String[]{"✖ CORTO: el diodo está dañado.", "malo"};
                return new String[]{"⚠ Valor raro (" + x + "). Suéltelo del circuito y repita.", "revisar"};
            case "voltajeAC":
                if (fuera) return new String[]{"⚠ Fuera de rango: revise la perilla (V~ 750) y los cables.", "revisar"};
                if (x >= 105 && x <= 132) return new String[]{"✔ BUENO: el toma tiene " + x + " V.", "bueno"};
                if (x < 5) return new String[]{"✖ SIN CORRIENTE: revise el breaker de ese circuito.", "malo"};
                if (x < 105) return new String[]{"⚠ Voltaje BAJO (" + x + " V): puede dañar motores y neveras.", "revisar"};
                if (x > 200) return new String[]{"⚠ Ese toma es de 220 V. ¡No conecte aparatos de 110 V!", "malo"};
                return new String[]{"⚠ Voltaje ALTO (" + x + " V).", "revisar"};
            case "voltajeDC": {
                if (fuera) return new String[]{"⚠ Fuera de rango: suba la perilla a V⎓ 200.", "revisar"};
                double v = Math.abs(x);
                if (Double.isNaN(nominal) || nominal <= 0) return new String[]{"Marca " + v + " V. Escriba el voltaje de la pila para evaluarla.", "revisar"};
                double pct = v / nominal * 100;
                if (x < 0) return new String[]{"Las puntas están al revés (salió negativo). Marca " + v + " V.", "revisar"};
                if (pct >= 90) return new String[]{"✔ BUENA: " + v + " V de " + nominal + " V.", "bueno"};
                if (pct >= 75) return new String[]{"⚠ A MEDIA CARGA: " + v + " V de " + nominal + " V.", "revisar"};
                return new String[]{"✖ DESCARGADA o mala: " + v + " V de " + nominal + " V.", "malo"};
            }
            default:
                return new String[]{"Lectura: " + x, "revisar"};
        }
    }

    private void guardarMedicion(int casoIdx, String texto) {
        JSONArray casos = Almacen.lista(this, "casos");
        if (casoIdx >= 0 && casoIdx < casos.length()) {
            agregarMedicion(casos.optJSONObject(casoIdx), texto);
            return;
        }
        if (casos.length() == 0) { aviso("Primero cree un caso en Clientes y casos"); return; }
        String[] nombres = new String[casos.length()];
        for (int i = 0; i < casos.length(); i++) nombres[i] = nombreCaso(casos.optJSONObject(i));
        new AlertDialog.Builder(this).setTitle("¿En cuál caso?").setItems(nombres, (d, w) -> agregarMedicion(casos.optJSONObject(w), texto)).show();
    }

    private void agregarMedicion(JSONObject caso, String texto) {
        JSONArray m = caso.optJSONArray("mediciones");
        if (m == null) { m = new JSONArray(); poner(caso, "mediciones", m); }
        m.put(hoy() + " · " + texto);
        Almacen.guardar(this);
        aviso("✔ Guardado en el caso");
    }

    // ======================= Electricidad =======================

    private void electricidad() {
        nueva("⚡ Electricidad de la casa", true);
        cajaInfo("Cree la casa, luego sus circuitos (uno por breaker) y anote lo que va conectado en cada uno. La app le dice el breaker y el cable.", 0xFFFFF4D6, NARANJA);
        JSONArray casas = Almacen.lista(this, "casas");
        for (int i = 0; i < casas.length(); i++) {
            int k = i;
            boton("🏠  " + casas.optJSONObject(i).optString("nombre"), NARANJA, () -> ir(() -> casa(k)));
        }
        boton("➕  Nueva casa", VERDE, () -> pedirTexto("Nombre de la casa (ej. Casa señora Dolly)", "", s -> {
            JSONObject o = new JSONObject();
            poner(o, "nombre", s);
            poner(o, "circuitos", new JSONArray());
            poner(o, "archivos", new JSONArray());
            casas.put(o);
            refrescar();
        }));
    }

    private void casa(int i) {
        JSONObject casa = Almacen.lista(this, "casas").optJSONObject(i);
        nueva("🏠 " + casa.optString("nombre"), true);
        JSONArray cir = casa.optJSONArray("circuitos");
        double total = 0;
        for (int k = 0; k < cir.length(); k++) total += vatiosDe(cir.optJSONObject(k));
        cajaInfo("Total de la casa: " + Math.round(total) + " W", 0xFFE3F2FD, AZUL);
        titulo("Circuitos (uno por cada breaker)");
        for (int k = 0; k < cir.length(); k++) {
            JSONObject o = cir.optJSONObject(k);
            int kk = k;
            double w = vatiosDe(o);
            boton("🔌  " + o.optString("nombre") + "  ·  " + Math.round(w) + " W", AZUL, () -> ir(() -> circuito(i, kk)));
        }
        boton("➕  Nuevo circuito", VERDE, () -> pedirTexto("Nombre del circuito (ej. Cocina, Ducha, Alcobas)", "", s -> {
            JSONObject o = new JSONObject();
            poner(o, "nombre", s);
            poner(o, "voltaje", 120);
            poner(o, "cargas", new JSONArray());
            cir.put(o);
            refrescar();
        }));
        titulo("Plano eléctrico de la casa");
        archivos(casa, "Biblioteca/Casas/" + Almacen.limpio(casa.optString("nombre")));
        boton("🗑  Borrar esta casa", ROJO, () -> confirmar("¿Borrar la casa " + casa.optString("nombre") + "?", () -> {
            Almacen.quitar(Almacen.lista(this, "casas"), i);
            atras();
        }));
    }

    private double vatiosDe(JSONObject circuito) {
        double t = 0;
        JSONArray cg = circuito.optJSONArray("cargas");
        if (cg != null) for (int j = 0; j < cg.length(); j++) t += cg.optJSONObject(j).optDouble("w", 0) * cg.optJSONObject(j).optInt("cant", 1);
        return t;
    }

    private void circuito(int ci, int k) {
        JSONObject casa = Almacen.lista(this, "casas").optJSONObject(ci);
        JSONObject cir = casa.optJSONArray("circuitos").optJSONObject(k);
        nueva("🔌 " + cir.optString("nombre"), true);
        int volt = cir.optInt("voltaje", 120);
        fila(btn((volt == 120 ? "● " : "○ ") + "120 V", volt == 120 ? AZUL : 0xFF9E9E9E, () -> { poner(cir, "voltaje", 120); refrescar(); }),
                btn((volt == 220 ? "● " : "○ ") + "220 V", volt == 220 ? AZUL : 0xFF9E9E9E, () -> { poner(cir, "voltaje", 220); refrescar(); }));

        JSONArray cg = cir.optJSONArray("cargas");
        titulo("Lo que va conectado");
        boolean hayNevera = false, hayDucha = false;
        for (int j = 0; j < cg.length(); j++) {
            JSONObject o = cg.optJSONObject(j);
            int jj = j;
            String n = o.optString("n");
            if (n.toLowerCase(Locale.ROOT).contains("nevera")) hayNevera = true;
            if (n.toLowerCase(Locale.ROOT).contains("ducha")) hayDucha = true;
            LinearLayout f = horizontal();
            f.setGravity(Gravity.CENTER_VERTICAL);
            TextView nom = txt(o.optInt("cant", 1) + " × " + n, 16, NEGRO, true);
            f.addView(nom, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            EditText w = new EditText(this);
            w.setText(String.valueOf(Math.round(o.optDouble("w", 0))));
            w.setInputType(InputType.TYPE_CLASS_NUMBER);
            w.setTextSize(17);
            w.setTextColor(NEGRO);
            w.setBackground(fondoBorde(BLANCO, 0xFF9E9E9E));
            w.setPadding(dp(8), dp(6), dp(8), dp(6));
            w.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
                @Override public void onTextChanged(CharSequence s, int a, int b, int d) {}
                @Override public void afterTextChanged(Editable s) {
                    try { poner(o, "w", Double.parseDouble(s.toString())); } catch (Exception ignored) { }
                }
            });
            f.addView(w, new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
            f.addView(txt(" W ", 16, NEGRO, true));
            TextView x = txt("✖", 22, ROJO, true);
            x.setPadding(dp(10), dp(4), dp(6), dp(4));
            x.setOnClickListener(v -> { Almacen.quitar(cg, jj); refrescar(); });
            f.addView(x);
            f.setPadding(0, dp(4), 0, dp(4));
            c.addView(f);
        }
        boton("➕  Agregar aparato", VERDE, () -> {
            String[] nombres = new String[Datos.CARGAS.length];
            for (int j = 0; j < nombres.length; j++) nombres[j] = Datos.CARGAS[j][0] + "  (" + Datos.CARGAS[j][1] + " W)";
            new AlertDialog.Builder(this).setTitle("¿Qué aparato?").setItems(nombres, (d, w) -> pedirTexto("¿Cuántos?", "1", s -> {
                JSONObject o = new JSONObject();
                poner(o, "n", Datos.CARGAS[w][0]);
                poner(o, "w", Double.parseDouble(Datos.CARGAS[w][1]));
                int cant = 1;
                try { cant = Math.max(1, Integer.parseInt(s.trim())); } catch (Exception ignored) { }
                poner(o, "cant", cant);
                cg.put(o);
                refrescar();
            })).show();
        });
        boton("🔄  Recalcular", AZUL, this::refrescar);

        double vat = vatiosDe(cir);
        double amp = vat / volt;
        String[] bc = Datos.breakerYCable(amp);
        titulo("Resultado");
        cajaInfo(String.format(Locale.US, "Total: %d W\nCorriente: %.1f A a %d V\n\nBreaker: %s A\nCable de cobre: %s",
                Math.round(vat), amp, volt, bc[0], bc[1]), 0xFFE3F2FD, AZUL);
        if (amp > 0 && !bc[0].startsWith("más")) {
            double uso = amp / Double.parseDouble(bc[0]) * 100;
            cajaInfo(String.format(Locale.US, "El circuito usa el %.0f %% del breaker (lo sano es no pasar del 80 %%).", uso),
                    uso > 80 ? 0xFFFFE0E0 : 0xFFDFF5E1, uso > 80 ? ROJO : VERDE);
        }
        if (hayNevera && cg.length() > 1) avisoRojo("La nevera va mejor en su PROPIO circuito: al arrancar el motor jala varias veces su consumo y puede disparar el breaker de los demás aparatos.");
        if (hayDucha) avisoRojo("La ducha eléctrica necesita su propio circuito, cable grueso y polo a tierra. Nunca la comparta con otros aparatos.");
        avisoRojo("Esto es una guía para calcular. Si el cable que ya existe es más delgado que el recomendado, NO ponga un breaker más grande: se recalienta el cable. Cambie el cable.");
    }

    // ======================= Biblioteca =======================

    static final String[] CATEGORIAS = {"Aparatos", "Carros y motos", "Casas", "Inventos", "Otros"};

    private void biblioteca(String filtroInicial) {
        nueva("📚 Biblioteca", true);
        JSONArray lista = Almacen.lista(this, "biblioteca");
        LinearLayout resultados = vertical();
        EditText buscar = campo("🔎 Buscar (ej. Hyundai fusibles, licuadora Oster)", filtroInicial, false, s -> { });
        fila(btn("📄 Escanear", 0xFF455A64, this::escanearALaBiblioteca),
                btn("➕ Nuevo documento", VERDE, () -> {
                    JSONObject d = new JSONObject();
                    poner(d, "categoria", "Aparatos");
                    poner(d, "titulo", filtroInicial.isEmpty() ? "Documento nuevo" : filtroInicial);
                    poner(d, "notas", "");
                    poner(d, "aparato", "");
                    poner(d, "fecha", hoy());
                    poner(d, "archivos", new JSONArray());
                    lista.put(d);
                    int i = lista.length() - 1;
                    ir(() -> documento(i));
                }));
        c.addView(resultados);
        Runnable pintar = () -> {
            resultados.removeAllViews();
            String q = buscar.getText().toString().toLowerCase(Locale.ROOT).trim();
            for (String cat : CATEGORIAS) {
                boolean titulo = false;
                for (int i = 0; i < lista.length(); i++) {
                    JSONObject d = lista.optJSONObject(i);
                    if (!cat.equals(d.optString("categoria", "Otros"))) continue;
                    String todo = (d.optString("titulo") + " " + d.optString("notas") + " " + d.optString("aparato") + " " + cat).toLowerCase(Locale.ROOT);
                    if (!q.isEmpty()) {
                        boolean ok = true;
                        for (String palabra : q.split("\\s+")) if (!todo.contains(palabra)) { ok = false; break; }
                        if (!ok) continue;
                    }
                    if (!titulo) {
                        TextView t = txt(cat, 18, NEGRO, true);
                        t.setPadding(dp(4), dp(12), dp(4), dp(2));
                        resultados.addView(t);
                        titulo = true;
                    }
                    int ii = i;
                    JSONArray ar = d.optJSONArray("archivos");
                    resultados.addView(btn("📄  " + d.optString("titulo") + "  (" + (ar == null ? 0 : ar.length()) + ")", MORADO, () -> ir(() -> documento(ii))));
                }
            }
            if (resultados.getChildCount() == 0) {
                TextView t = txt(lista.length() == 0 ? "La biblioteca está vacía. Escanee un manual, un plano o un diagrama para empezar." : "No encontré nada con esa búsqueda.", 16, GRIS, false);
                t.setPadding(dp(4), dp(12), dp(4), dp(4));
                resultados.addView(t);
            }
        };
        buscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void afterTextChanged(Editable s) { pintar.run(); }
        });
        pintar.run();
    }

    private void documento(int i) {
        JSONObject d = Almacen.lista(this, "biblioteca").optJSONObject(i);
        nueva("📄 Documento", true);
        campo("Nombre (ej. Licuadora Oster 465 — diagrama)", d.optString("titulo"), false, s -> poner(d, "titulo", s));
        String cat = d.optString("categoria", "Otros");
        TextView e = txt("Categoría", 14, GRIS, true);
        e.setPadding(dp(4), dp(8), dp(4), 0);
        c.addView(e);
        for (int k = 0; k < CATEGORIAS.length; k += 2) {
            String a = CATEGORIAS[k];
            String b = k + 1 < CATEGORIAS.length ? CATEGORIAS[k + 1] : null;
            fila(btn((a.equals(cat) ? "● " : "○ ") + a, a.equals(cat) ? MORADO : 0xFF9E9E9E, () -> { poner(d, "categoria", a); refrescar(); }),
                    b == null ? null : btn((b.equals(cat) ? "● " : "○ ") + b, b.equals(cat) ? MORADO : 0xFF9E9E9E, () -> { poner(d, "categoria", b); refrescar(); }));
        }
        campo("Notas (marca, modelo, lo importante)", d.optString("notas"), true, s -> poner(d, "notas", s));
        titulo("Archivos");
        archivos(d, "Biblioteca/" + Almacen.limpio(d.optString("categoria", "Otros")));
        fila(btn("🔎 Buscar manual", AZUL, () -> abrirWeb("https://www.google.com/search?q=" + Uri.encode(d.optString("titulo") + " manual pdf"))),
                btn("✉ Claude", 0xFFC15F3C, () -> ir(() -> claude(d.optString("titulo"), "Le mando este documento de mi biblioteca. Por favor:\n", d.optJSONArray("archivos")))));
        boton("🗑  Borrar este documento", ROJO, () -> confirmar("¿Borrar \"" + d.optString("titulo") + "\" de la biblioteca? (los archivos quedan en la carpeta)", () -> {
            Almacen.quitar(Almacen.lista(this, "biblioteca"), i);
            atras();
        }));
    }

    private int docsDe(Datos.Aparato a) {
        JSONArray l = Almacen.lista(this, "biblioteca");
        String n = a.nombre.toLowerCase(Locale.ROOT);
        String primera = n.split(" ")[0];
        int k = 0;
        for (int i = 0; i < l.length(); i++) {
            String t = (l.optJSONObject(i).optString("titulo") + " " + l.optJSONObject(i).optString("notas")).toLowerCase(Locale.ROOT);
            if (t.contains(primera)) k++;
        }
        return k;
    }

    // ======================= Archivos adjuntos (comunes) =======================

    /** Muestra los archivos de un registro con botones para agregar (escáner, foto, archivo). */
    private void archivos(JSONObject dueno, String carpeta) {
        JSONArray a = dueno.optJSONArray("archivos");
        if (a == null) { a = new JSONArray(); poner(dueno, "archivos", a); }
        final JSONArray lista = a;
        for (int i = 0; i < lista.length(); i++) {
            Uri u = Uri.parse(lista.optString(i));
            int ii = i;
            LinearLayout f = horizontal();
            f.setGravity(Gravity.CENTER_VERTICAL);
            f.setBackground(fondoBorde(BLANCO, 0xFFBDBDBD));
            f.setPadding(dp(6), dp(6), dp(6), dp(6));
            ImageView mini = new ImageView(this);
            try {
                Bitmap bm = getContentResolver().loadThumbnail(u, new Size(dp(56), dp(56)), null);
                mini.setImageBitmap(bm);
            } catch (Exception e) {
                mini.setImageDrawable(null);
                mini.setBackgroundColor(0xFFE0E0E0);
            }
            f.addView(mini, new LinearLayout.LayoutParams(dp(56), dp(56)));
            TextView n = txt("  " + Almacen.nombreDe(this, u), 15, NEGRO, false);
            n.setOnClickListener(v -> abrirArchivo(u));
            f.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            TextView x = txt("✖", 22, ROJO, true);
            x.setPadding(dp(10), 0, dp(6), 0);
            x.setOnClickListener(v -> confirmar("¿Quitar este archivo de aquí? (sigue en la carpeta del celular)", () -> { Almacen.quitar(lista, ii); refrescar(); }));
            f.addView(x);
            LinearLayout.LayoutParams lp = anchoTotal();
            lp.topMargin = dp(4);
            c.addView(f, lp);
        }
        Consumer<List<Uri>> agregar = us -> {
            for (Uri u : us) lista.put(u.toString());
            Almacen.guardar(this);
            refrescar();
        };
        fila(btn("📄 Escanear", 0xFF455A64, () -> escanear(carpeta, agregar)),
                btn("📷 Foto", 0xFF455A64, () -> tomarFoto(carpeta, agregar)));
        boton("📎 Adjuntar archivo (PDF, foto, audio…)", 0xFF455A64, () -> escogerArchivos(carpeta, agregar));
    }

    private void abrirArchivo(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            String mime = getContentResolver().getType(u);
            i.setDataAndType(u, mime == null ? "*/*" : mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            aviso("No hay una app para abrir este archivo");
        }
    }

    private void escanear(String carpeta, Consumer<List<Uri>> listo) {
        alRecibir = listo;
        startActivityForResult(new Intent(this, EscanerActivity.class).putExtra("carpeta", carpeta), R_ESCANER);
    }

    private String carpetaPendiente = "Fotos";

    private void tomarFoto(String carpeta, Consumer<List<Uri>> listo) {
        try {
            fotoPendiente = Almacen.crear(this, carpeta, "Foto_" + ahora() + ".jpg", "image/jpeg");
            if (fotoPendiente == null) { aviso("No se pudo crear la foto"); return; }
            alRecibir = listo;
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, fotoPendiente);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, R_FOTO);
        } catch (Exception e) {
            aviso("No se pudo abrir la cámara");
        }
    }

    private void escogerArchivos(String carpeta, Consumer<List<Uri>> listo) {
        carpetaPendiente = carpeta;
        alRecibir = listo;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, R_ARCHIVO); } catch (Exception e) { aviso("No se pudo abrir el selector de archivos"); }
    }

    private void dictar(EditText en) {
        dictarEn = en;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hable ahora");
        try { startActivityForResult(i, R_DICTAR); } catch (Exception e) { aviso("Este celular no tiene dictado por voz"); }
    }

    private void importarTexto(Consumer<String> listo) {
        alImportar = listo;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, R_IMPORTAR); } catch (Exception e) { aviso("No se pudo abrir el selector de archivos"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == R_DICTAR) {
            if (res == RESULT_OK && data != null && dictarEn != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) {
                    int pos = Math.max(0, dictarEn.getSelectionStart());
                    String antes = dictarEn.getText().toString();
                    String nuevo = r.get(0);
                    if (pos > 0 && antes.charAt(pos - 1) != ' ' && antes.charAt(pos - 1) != '\n') nuevo = " " + nuevo;
                    dictarEn.getText().insert(pos, nuevo);
                }
            }
            return;
        }
        if (req == R_IMPORTAR) {
            if (res == RESULT_OK && data != null && data.getData() != null && alImportar != null) {
                String s = Almacen.leerTexto(this, data.getData());
                if (s == null) aviso("No se pudo leer el archivo");
                else alImportar.accept(s);
            }
            return;
        }
        Consumer<List<Uri>> cb = alRecibir;
        alRecibir = null;
        if (cb == null) return;
        List<Uri> us = new ArrayList<>();
        if (req == R_FOTO) {
            if (res == RESULT_OK && fotoPendiente != null) us.add(fotoPendiente);
            else if (fotoPendiente != null) { try { getContentResolver().delete(fotoPendiente, null, null); } catch (Exception ignored) { } }
            fotoPendiente = null;
        } else if (req == R_ESCANER) {
            if (res == RESULT_OK && data != null) {
                ArrayList<String> l = data.getStringArrayListExtra("uris");
                if (l != null) for (String s : l) us.add(Uri.parse(s));
            }
        } else if (req == R_ARCHIVO) {
            if (res == RESULT_OK && data != null) {
                List<Uri> elegidos = new ArrayList<>();
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) elegidos.add(data.getClipData().getItemAt(i).getUri());
                } else if (data.getData() != null) {
                    elegidos.add(data.getData());
                }
                for (Uri o : elegidos) {
                    Uri copia = Almacen.copiar(this, o, carpetaPendiente, Almacen.nombreDe(this, o), getContentResolver().getType(o));
                    if (copia != null) us.add(copia);
                }
                if (us.size() < elegidos.size()) aviso("Algunos archivos no se pudieron copiar");
            }
        }
        if (!us.isEmpty()) cb.accept(us);
    }

    // ======================= Clientes y casos =======================

    static final String[] ESTADOS = {"Recibido", "En revisión", "Esperando repuesto", "Reparado", "Entregado", "No tuvo arreglo"};

    private String nombreCaso(JSONObject o) {
        return o.optString("aparato") + " " + o.optString("cliente") + "  ·  " + o.optString("estado", "Recibido");
    }

    private void casos() {
        nueva("👥 Clientes y casos", true);
        JSONArray l = Almacen.lista(this, "casos");
        boton("➕  Nuevo caso", VERDE, () -> nuevoCaso(""));
        for (int i = l.length() - 1; i >= 0; i--) {
            JSONObject o = l.optJSONObject(i);
            int ii = i;
            String est = o.optString("estado", "Recibido");
            int color = est.equals("Entregado") ? 0xFF9E9E9E : est.equals("Reparado") ? VERDE : 0xFF2E5E4E;
            boton("🔧  " + nombreCaso(o), color, () -> ir(() -> caso(ii)));
        }
    }

    private void nuevoCaso(String aparato) {
        JSONObject o = new JSONObject();
        poner(o, "cliente", "");
        poner(o, "aparato", aparato);
        poner(o, "marca", "");
        poner(o, "falla", "");
        poner(o, "notas", "");
        poner(o, "estado", "Recibido");
        poner(o, "fecha", hoy());
        poner(o, "mediciones", new JSONArray());
        poner(o, "archivos", new JSONArray());
        poner(o, "respuestas", new JSONArray());
        JSONArray l = Almacen.lista(this, "casos");
        l.put(o);
        Almacen.guardar(this);
        int i = l.length() - 1;
        ir(() -> caso(i));
    }

    private void caso(int i) {
        JSONObject o = Almacen.lista(this, "casos").optJSONObject(i);
        nueva("🔧 Caso", true);
        campo("Aparato (ej. Televisor)", o.optString("aparato"), false, s -> poner(o, "aparato", s));
        campo("Cliente (ej. señora Dolly)", o.optString("cliente"), false, s -> poner(o, "cliente", s));
        campo("Marca y modelo", o.optString("marca"), false, s -> poner(o, "marca", s));
        campo("Qué le pasa", o.optString("falla"), true, s -> poner(o, "falla", s));
        campo("Notas de lo que hice", o.optString("notas"), true, s -> poner(o, "notas", s));
        boton("📌  Estado: " + o.optString("estado", "Recibido") + "  (tocar para cambiar)", NARANJA, () ->
                new AlertDialog.Builder(this).setTitle("Estado").setItems(ESTADOS, (d, w) -> { poner(o, "estado", ESTADOS[w]); refrescar(); }).show());

        titulo("Mediciones guardadas");
        JSONArray m = o.optJSONArray("mediciones");
        if (m == null || m.length() == 0) parrafo("Todavía no hay. Haga una prueba en el laboratorio y toque \"Guardar en un caso\".");
        else for (int k = 0; k < m.length(); k++) parrafo("• " + m.optString(k));
        boton("🧪  Ir al laboratorio para este caso", VERDE, () -> {
            String[] n = new String[Datos.PRUEBAS.size()];
            for (int k = 0; k < n.length; k++) n[k] = Datos.PRUEBAS.get(k).nombre;
            new AlertDialog.Builder(this).setTitle("¿Qué prueba?").setItems(n, (d, w) -> ir(() -> prueba(Datos.PRUEBAS.get(w), i))).show();
        });

        titulo("Fotos y archivos");
        archivos(o, "Casos/" + Almacen.limpio(o.optString("aparato") + " " + o.optString("cliente")));

        titulo("Respuestas de Claude");
        JSONArray r = o.optJSONArray("respuestas");
        if (r == null) { r = new JSONArray(); poner(o, "respuestas", r); }
        for (int k = 0; k < r.length(); k++) cajaInfo(r.optString(k), 0xFFFFF3EC, 0xFFC15F3C);
        final JSONArray rr = r;
        fila(btn("✉ Consultar a Claude", 0xFFC15F3C, () -> ir(() -> claude(
                        o.optString("aparato") + " " + o.optString("cliente"),
                        "Aparato: " + o.optString("aparato") + "\nMarca y modelo: " + o.optString("marca") + "\nQué le pasa: " + o.optString("falla")
                                + "\nLo que hice: " + o.optString("notas") + "\nMediciones:\n" + textoLista(o.optJSONArray("mediciones")) + "\nMi pregunta: ",
                        o.optJSONArray("archivos")))),
                btn("📥 Importar respuesta", 0xFF8D4A2B, () -> importarTexto(s -> {
                    rr.put(hoy() + "\n" + s);
                    Almacen.guardar(this);
                    refrescar();
                })));
        boton("🗑  Borrar este caso", ROJO, () -> confirmar("¿Borrar este caso?", () -> {
            Almacen.quitar(Almacen.lista(this, "casos"), i);
            atras();
        }));
    }

    private String textoLista(JSONArray a) {
        if (a == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.length(); i++) b.append("- ").append(a.optString(i)).append('\n');
        return b.toString();
    }

    // ======================= Bodega de piezas =======================

    private void bodega() {
        nueva("📦 Bodega de piezas", true);
        JSONArray l = Almacen.lista(this, "bodega");
        LinearLayout res = vertical();
        EditText buscar = campo("🔎 Buscar pieza (ej. condensador 2 µF)", "", false, s -> { });
        boton("➕  Nueva pieza", VERDE, () -> {
            JSONObject o = new JSONObject();
            poner(o, "nombre", "");
            poner(o, "valor", "");
            poner(o, "origen", "");
            poner(o, "cantidad", "1");
            poner(o, "notas", "");
            poner(o, "archivos", new JSONArray());
            l.put(o);
            int i = l.length() - 1;
            ir(() -> pieza(i));
        });
        c.addView(res);
        Runnable pintar = () -> {
            res.removeAllViews();
            String q = buscar.getText().toString().toLowerCase(Locale.ROOT).trim();
            for (int i = l.length() - 1; i >= 0; i--) {
                JSONObject o = l.optJSONObject(i);
                String todo = (o.optString("nombre") + " " + o.optString("valor") + " " + o.optString("origen") + " " + o.optString("notas")).toLowerCase(Locale.ROOT);
                if (!q.isEmpty() && !todo.contains(q)) continue;
                int ii = i;
                res.addView(btn("🔩  " + o.optString("nombre") + " " + o.optString("valor") + "  ×" + o.optString("cantidad", "1")
                        + (o.optString("origen").isEmpty() ? "" : "\n     de: " + o.optString("origen")), GRIS_OSC, () -> ir(() -> pieza(ii))));
            }
        };
        buscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void afterTextChanged(Editable s) { pintar.run(); }
        });
        pintar.run();
    }

    private void pieza(int i) {
        JSONObject o = Almacen.lista(this, "bodega").optJSONObject(i);
        nueva("🔩 Pieza", true);
        campo("Qué es (ej. Condensador, Motor, Transistor)", o.optString("nombre"), false, s -> poner(o, "nombre", s));
        campo("Valor o referencia (ej. 2 µF 250 V, 2N2222)", o.optString("valor"), false, s -> poner(o, "valor", s));
        campo("De qué aparato salió (ej. Ventilador Samurai)", o.optString("origen"), false, s -> poner(o, "origen", s));
        EditText cant = campo("Cantidad", o.optString("cantidad", "1"), false, s -> poner(o, "cantidad", s));
        cant.setInputType(InputType.TYPE_CLASS_NUMBER);
        campo("Notas (si está buena, dónde la guardé)", o.optString("notas"), true, s -> poner(o, "notas", s));
        titulo("Fotos");
        archivos(o, "Bodega");
        boton("🗑  Borrar esta pieza", ROJO, () -> confirmar("¿Borrar esta pieza de la bodega?", () -> {
            Almacen.quitar(Almacen.lista(this, "bodega"), i);
            atras();
        }));
    }

    /** ¿Hay en la bodega una pieza parecida? Devuelve su texto o null. */
    private String enBodega(String componente) {
        JSONArray l = Almacen.lista(this, "bodega");
        String c0 = componente.toLowerCase(Locale.ROOT);
        for (int i = 0; i < l.length(); i++) {
            JSONObject o = l.optJSONObject(i);
            String n = o.optString("nombre").toLowerCase(Locale.ROOT).trim();
            String v = o.optString("valor").toLowerCase(Locale.ROOT).trim();
            if (n.length() < 3) continue;
            if (c0.contains(n) && (v.isEmpty() || c0.contains(v))) return o.optString("nombre") + " " + o.optString("valor");
        }
        return null;
    }

    // ======================= Mis Inventos =======================

    static final String[] ESTADOS_INV = {"💭 En idea", "🛒 Comprando", "🔧 Armando", "🧪 Probando", "✅ Funcionando"};

    private void inventos() {
        nueva("💡 Mis Inventos", true);
        JSONArray l = Almacen.lista(this, "inventos");
        if (!pr.getBoolean("inventosCargados", false)) {
            for (String[] t : Guias.INVENTOS) l.put(inventoDePlantilla(t));
            pr.edit().putBoolean("inventosCargados", true).apply();
            Almacen.guardar(this);
        }
        cajaInfo("Escriba su idea, la app le da los componentes, el armado paso a paso y las pruebas con su multímetro. Si algo no funciona, me manda fotos con el botón Claude.", 0xFFFCE4EC, ROSA);
        for (int i = 0; i < l.length(); i++) {
            JSONObject o = l.optJSONObject(i);
            int ii = i;
            boton("💡  " + o.optString("nombre") + "\n     " + o.optString("estado", ESTADOS_INV[0]), ROSA, () -> ir(() -> invento(ii)));
        }
        boton("➕  Nuevo invento (mi idea)", VERDE, () -> pedirTexto("¿Cómo se llama su invento?", "", s -> {
            JSONObject o = new JSONObject();
            poner(o, "nombre", s);
            poner(o, "idea", "");
            poner(o, "estado", ESTADOS_INV[0]);
            poner(o, "componentes", new JSONArray());
            poner(o, "pasos", new JSONArray());
            poner(o, "avisos", "");
            poner(o, "notas", "");
            poner(o, "archivos", new JSONArray());
            l.put(o);
            int i = l.length() - 1;
            ir(() -> invento(i));
        }));
    }

    private JSONObject inventoDePlantilla(String[] t) {
        JSONObject o = new JSONObject();
        poner(o, "nombre", t[0]);
        poner(o, "idea", t[1]);
        JSONArray comp = new JSONArray();
        for (String linea : t[2].split("\n")) {
            String[] p = linea.split("\\|", 2);
            JSONObject x = new JSONObject();
            poner(x, "cant", p[0]);
            poner(x, "n", p.length > 1 ? p[1] : p[0]);
            poner(x, "listo", false);
            comp.put(x);
        }
        poner(o, "componentes", comp);
        JSONArray pasos = new JSONArray();
        for (String s : t[3].split("\n")) {
            JSONObject x = new JSONObject();
            poner(x, "t", s);
            poner(x, "hecho", false);
            pasos.put(x);
        }
        poner(o, "pasos", pasos);
        poner(o, "avisos", t[4]);
        poner(o, "estado", ESTADOS_INV[0]);
        poner(o, "notas", "");
        poner(o, "archivos", new JSONArray());
        return o;
    }

    private void invento(int i) {
        JSONObject o = Almacen.lista(this, "inventos").optJSONObject(i);
        nueva("💡 Invento", true);
        campo("Nombre", o.optString("nombre"), false, s -> poner(o, "nombre", s));
        campo("La idea: qué debe hacer", o.optString("idea"), true, s -> poner(o, "idea", s));
        boton("📌  Estado: " + o.optString("estado", ESTADOS_INV[0]) + "  (tocar para cambiar)", NARANJA, () ->
                new AlertDialog.Builder(this).setTitle("Estado").setItems(ESTADOS_INV, (d, w) -> { poner(o, "estado", ESTADOS_INV[w]); refrescar(); }).show());
        avisoRojo(o.optString("avisos"));

        titulo("🛒 Componentes (toque para marcar \"ya lo tengo\")");
        JSONArray comp = o.optJSONArray("componentes");
        if (comp == null || comp.length() == 0) parrafo("Todavía no hay lista. Toque \"Consultar a Claude\" con su idea y yo le mando la lista de componentes.");
        else for (int k = 0; k < comp.length(); k++) {
            JSONObject x = comp.optJSONObject(k);
            boolean listo = x.optBoolean("listo");
            String bod = listo ? null : enBodega(x.optString("n"));
            String s = (listo ? "✅ " : "⬜ ") + x.optString("cant") + " × " + x.optString("n") + (bod != null ? "\n     📦 En su bodega hay: " + bod : "");
            c.addView(btn(s, listo ? VERDE : bod != null ? 0xFF6A8F2A : GRIS_OSC, () -> { poner(x, "listo", !listo); refrescar(); }));
        }

        titulo("🔧 Armado paso a paso (toque cuando lo haga)");
        JSONArray pasos = o.optJSONArray("pasos");
        if (pasos != null) for (int k = 0; k < pasos.length(); k++) {
            JSONObject x = pasos.optJSONObject(k);
            boolean hecho = x.optBoolean("hecho");
            TextView t = txt((hecho ? "✅ " : (k + 1) + ". ") + x.optString("t"), 17, hecho ? GRIS : NEGRO, false);
            t.setPadding(dp(8), dp(8), dp(8), dp(8));
            t.setBackground(fondoBorde(hecho ? 0xFFEFEFEF : BLANCO, hecho ? 0xFFBDBDBD : 0xFF757575));
            t.setOnClickListener(v -> { poner(x, "hecho", !hecho); refrescar(); });
            LinearLayout.LayoutParams lp = anchoTotal();
            lp.topMargin = dp(5);
            c.addView(t, lp);
        }
        boton("🧪  Ir al laboratorio", VERDE, () -> ir(this::laboratorio));

        campo("Mis notas del invento", o.optString("notas"), true, s -> poner(o, "notas", s));
        titulo("Fotos, planos y diagramas");
        archivos(o, "Inventos/" + Almacen.limpio(o.optString("nombre")));
        fila(btn("✉ Consultar a Claude", 0xFFC15F3C, () -> ir(() -> claude("Invento: " + o.optString("nombre"),
                        "Invento: " + o.optString("nombre") + "\nLa idea: " + o.optString("idea") + "\nEstado: " + o.optString("estado") + "\nMis notas: " + o.optString("notas") + "\nMi pregunta: ",
                        o.optJSONArray("archivos")))),
                btn("📥 Importar respuesta", 0xFF8D4A2B, () -> importarTexto(s -> {
                    poner(o, "notas", o.optString("notas") + "\n\n— Claude (" + hoy() + "):\n" + s);
                    Almacen.guardar(this);
                    refrescar();
                })));
        boton("🗑  Borrar este invento", ROJO, () -> confirmar("¿Borrar este invento?", () -> {
            Almacen.quitar(Almacen.lista(this, "inventos"), i);
            atras();
        }));
    }

    // ======================= Casa inteligente =======================

    private void casaInteligente() {
        nueva("🏠 Casa inteligente", true);
        cajaInfo("Guías para sacarle provecho a su Alexa con rutinas: una frase suya dispara varias cosas a la vez.", 0xFFE0F2F1, TURQ);
        for (String[] g : Guias.ALEXA) boton("🗣  " + g[0], TURQ, () -> ir(() -> guiaAlexa(g)));
        boton("▶  Videos de rutinas de Alexa", 0xFFD32F2F, () -> abrirWeb("https://www.youtube.com/results?search_query=" + Uri.encode("como crear rutinas alexa en español enchufe inteligente")));
        boton("✉  Preguntarle a Claude", 0xFFC15F3C, () -> ir(() -> claude("Casa inteligente", "Tengo Alexa y quiero que: ", null)));
    }

    private void guiaAlexa(String[] g) {
        nueva("🗣 " + g[0], true);
        avisoRojo(g[2]);
        String[] pasos = g[1].split("\n");
        for (int i = 0; i < pasos.length; i++) {
            TextView t = txt((i + 1) + ".  " + pasos[i], 17, NEGRO, false);
            t.setPadding(dp(6), dp(7), dp(6), dp(7));
            c.addView(t);
        }
    }

    // ======================= Mis Aparatos (lo que compro) =======================

    private void misAparatos() {
        nueva("🛒 Mis Aparatos", true);
        cajaInfo("Registre lo que compra: escanee la factura y el manual, y mándemelos con el botón Claude. Le devuelvo la guía en español.", 0xFFF3E9DC, CAFE);
        JSONArray l = Almacen.lista(this, "misaparatos");
        boton("➕  Registrar un aparato nuevo", VERDE, () -> {
            JSONObject o = new JSONObject();
            for (String k : new String[]{"nombre", "marca", "modelo", "tienda", "guia", "notas"}) poner(o, k, "");
            poner(o, "compra", hoy());
            poner(o, "garantia", "");
            poner(o, "archivos", new JSONArray());
            l.put(o);
            int i = l.length() - 1;
            ir(() -> miAparato(i));
        });
        for (int i = l.length() - 1; i >= 0; i--) {
            JSONObject o = l.optJSONObject(i);
            int ii = i;
            String g = estadoGarantia(o.optString("garantia"));
            boton("🛒  " + o.optString("nombre") + " " + o.optString("marca") + " " + o.optString("modelo") + (g.isEmpty() ? "" : "\n     " + g), CAFE, () -> ir(() -> miAparato(ii)));
        }
    }

    private void miAparato(int i) {
        JSONObject o = Almacen.lista(this, "misaparatos").optJSONObject(i);
        nueva("🛒 Mi aparato", true);
        campo("Qué es (ej. Lavadora)", o.optString("nombre"), false, s -> poner(o, "nombre", s));
        campo("Marca", o.optString("marca"), false, s -> poner(o, "marca", s));
        campo("Modelo / referencia", o.optString("modelo"), false, s -> poner(o, "modelo", s));
        campo("Dónde lo compré", o.optString("tienda"), false, s -> poner(o, "tienda", s));
        campo("Fecha de compra (año-mes-día)", o.optString("compra"), false, s -> poner(o, "compra", s));
        campo("Garantía hasta (año-mes-día, ej. 2027-11-22)", o.optString("garantia"), false, s -> poner(o, "garantia", s));
        String g = estadoGarantia(o.optString("garantia"));
        if (!g.isEmpty()) cajaInfo(g, 0xFFFFF4D6, NARANJA);
        titulo("Factura, manual y catálogo");
        archivos(o, "Biblioteca/Aparatos/" + Almacen.limpio(o.optString("nombre") + " " + o.optString("marca")));
        String q = o.optString("marca") + " " + o.optString("modelo");
        fila(btn("🔎 Buscar manual", AZUL, () -> abrirWeb("https://www.google.com/search?q=" + Uri.encode(q + " manual de usuario pdf"))),
                btn("▶ Videos", 0xFFD32F2F, () -> abrirWeb("https://www.youtube.com/results?search_query=" + Uri.encode(q + " como usar"))));
        titulo("Guía de Claude");
        if (o.optString("guia").isEmpty()) parrafo("Todavía no hay guía. Mándeme el manual con el botón Claude y luego importe mi respuesta.");
        else cajaInfo(o.optString("guia"), 0xFFFFF3EC, 0xFFC15F3C);
        fila(btn("✉ Pedir guía a Claude", 0xFFC15F3C, () -> ir(() -> claude("Guía: " + o.optString("nombre") + " " + q,
                        "Compré: " + o.optString("nombre") + "\nMarca y modelo: " + q + "\nLe mando el manual escaneado. Por favor hágame la guía en español: cómo se usa paso a paso, mantenimiento, qué no hacer y avisos de seguridad.\n",
                        o.optJSONArray("archivos")))),
                btn("📥 Importar guía", 0xFF8D4A2B, () -> importarTexto(s -> {
                    poner(o, "guia", s);
                    Almacen.guardar(this);
                    refrescar();
                })));
        campo("Mis notas", o.optString("notas"), true, s -> poner(o, "notas", s));
        boton("🗑  Borrar este aparato", ROJO, () -> confirmar("¿Borrar este aparato de la lista?", () -> {
            Almacen.quitar(Almacen.lista(this, "misaparatos"), i);
            atras();
        }));
    }

    /** "⚠ La garantía vence en 12 días", "Garantía vencida", o "" */
    private String estadoGarantia(String fecha) {
        if (fecha == null || fecha.trim().length() < 8) return "";
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(fecha.trim());
            if (d == null) return "";
            long dias = (d.getTime() - System.currentTimeMillis()) / (24L * 3600 * 1000);
            if (dias < 0) return "Garantía vencida";
            if (dias <= 30) return "⚠ La garantía vence en " + dias + " días";
            return "Garantía hasta " + fecha.trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String garantiasPorVencer() {
        JSONArray l = Almacen.lista(this, "misaparatos");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.length(); i++) {
            String g = estadoGarantia(l.optJSONObject(i).optString("garantia"));
            if (g.startsWith("⚠")) b.append(g).append(": ").append(l.optJSONObject(i).optString("nombre")).append('\n');
        }
        return b.toString().trim();
    }

    // ======================= Botón Claude (cuaderno tipo correo) =======================

    private void claude(String asuntoIni, String mensajeIni, JSONArray adjuntosIni) {
        nueva("✉ Escribirle a Claude", true);
        JSONObject borrador = Almacen.datos(this).optJSONObject("borrador");
        boolean nuevo = borrador == null || !asuntoIni.isEmpty() || !mensajeIni.isEmpty() || adjuntosIni != null;
        if (borrador == null || (nuevo && !borrador.optString("asuntoIni").equals(asuntoIni))) {
            borrador = new JSONObject();
            poner(borrador, "asuntoIni", asuntoIni);
            poner(borrador, "asunto", asuntoIni);
            poner(borrador, "mensaje", mensajeIni);
            JSONArray a = new JSONArray();
            if (adjuntosIni != null) for (int i = 0; i < adjuntosIni.length(); i++) a.put(adjuntosIni.optString(i));
            poner(borrador, "archivos", a);
            poner(Almacen.datos(this), "borrador", borrador);
        }
        final JSONObject b = borrador;
        cajaInfo("Para: Claude  ·  proyecto ChpTronic\n\nLa app junta todo en un paquete. Usted lo sube a un chat nuevo dentro del proyecto ChpTronic en la app de Claude.", 0xFFFFF3EC, 0xFFC15F3C);
        campo("Asunto", b.optString("asunto"), false, s -> poner(b, "asunto", s));
        EditText msg = campo("Mensaje", b.optString("mensaje"), true, s -> poner(b, "mensaje", s));
        msg.setMinLines(6);
        boton("🎤  Dictar en el mensaje", AZUL, () -> dictar(msg));
        titulo("Adjuntos");
        archivos(b, "Claude/Adjuntos");

        titulo("Enviar");
        boton("📦  Crear paquete y enviar a Claude", 0xFFC15F3C, () -> enviarAClaude(b, true));
        boton("📤  Enviar archivos sueltos (si el .zip no entra)", 0xFF8D4A2B, () -> enviarAClaude(b, false));
        fila(btn("🧹 Nuevo mensaje", GRIS_OSC, () -> confirmar("¿Borrar este borrador y empezar uno nuevo?", () -> {
                    Almacen.datos(this).remove("borrador");
                    poner(Almacen.datos(this), "borrador", null);
                    refrescar();
                })),
                btn("📥 Importar respuesta", 0xFF8D4A2B, () -> importarTexto(s -> {
                    JSONArray r = Almacen.lista(this, "respuestas");
                    r.put(hoy() + " · " + b.optString("asunto") + "\n" + s);
                    Almacen.guardar(this);
                    aviso("✔ Respuesta guardada");
                    refrescar();
                })));

        JSONArray r = Almacen.lista(this, "respuestas");
        if (r.length() > 0) {
            titulo("Respuestas de Claude guardadas");
            for (int i = r.length() - 1; i >= 0 && i >= r.length() - 5; i--) cajaInfo(r.optString(i), 0xFFFFF3EC, 0xFFC15F3C);
        }
        titulo("Espacio");
        boton("🗑  Liberar espacio (paquetes ya enviados)", GRIS_OSC, this::liberarEspacio);
    }

    private void enviarAClaude(JSONObject b, boolean comprimido) {
        String asunto = b.optString("asunto").trim();
        if (asunto.isEmpty()) asunto = "Consulta";
        String texto = "PARA: Claude (proyecto ChpTronic)\nDE: Chepe Gallego · ChpTronic " + VERSION + "\nFECHA: " + hoy()
                + "\nASUNTO: " + asunto + "\n\n" + b.optString("mensaje")
                + "\n\n(Al final, por favor entrégueme la respuesta también como archivo .txt para importarla en ChpTronic.)\n";
        JSONArray adj = b.optJSONArray("archivos");
        String base = "ChpTronic_" + Almacen.limpio(asunto).replace(' ', '-') + "_" + ahora();
        try {
            Uri txtUri = Almacen.crear(this, "Claude/Enviados", base + ".txt", "text/plain");
            if (txtUri == null) throw new Exception("sin archivo");
            try (OutputStream o = getContentResolver().openOutputStream(txtUri)) {
                if (o != null) o.write(texto.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            ArrayList<Uri> enviar = new ArrayList<>();
            if (comprimido) {
                Uri zip = Almacen.crear(this, "Claude/Enviados", base + ".zip", "application/zip");
                if (zip == null) throw new Exception("sin zip");
                try (OutputStream o = getContentResolver().openOutputStream(zip); ZipOutputStream z = new ZipOutputStream(o)) {
                    z.putNextEntry(new ZipEntry("mensaje.txt"));
                    z.write(texto.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    z.closeEntry();
                    if (adj != null) for (int i = 0; i < adj.length(); i++) {
                        Uri u = Uri.parse(adj.optString(i));
                        try (InputStream in = getContentResolver().openInputStream(u)) {
                            if (in == null) continue;
                            z.putNextEntry(new ZipEntry((i + 1) + "_" + Almacen.limpio(Almacen.nombreDe(this, u))));
                            byte[] buf = new byte[16384];
                            int n;
                            while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                            z.closeEntry();
                        } catch (Exception ignored) { }
                    }
                }
                getContentResolver().delete(txtUri, null, null);
                enviar.add(zip);
            } else {
                enviar.add(txtUri);
                if (adj != null) for (int i = 0; i < adj.length(); i++) enviar.add(Uri.parse(adj.optString(i)));
            }
            Intent i;
            if (enviar.size() == 1) {
                i = new Intent(Intent.ACTION_SEND);
                i.putExtra(Intent.EXTRA_STREAM, enviar.get(0));
                i.setType(comprimido ? "application/zip" : "text/plain");
            } else {
                i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, enviar);
                i.setType("*/*");
            }
            i.putExtra(Intent.EXTRA_TEXT, texto);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            aviso("Escoja \"Claude\" en la lista");
            startActivity(Intent.createChooser(i, "Enviar a Claude"));
        } catch (Exception e) {
            aviso("No se pudo armar el paquete: " + e.getMessage());
        }
    }

    private void liberarEspacio() {
        List<Object[]> l = Almacen.archivos(this, "Claude/Enviados");
        long total = 0;
        for (Object[] o : l) total += (Long) o[2];
        if (l.isEmpty()) { aviso("No hay paquetes enviados"); return; }
        final List<Object[]> lista = l;
        confirmar("Hay " + l.size() + " paquetes enviados que ocupan " + Almacen.tamano(total)
                + ".\n¿Borrarlos? (Claude ya los tiene en los chats; sus casos, notas y respuestas NO se borran)", () -> {
            int k = 0;
            for (Object[] o : lista) {
                try { k += getContentResolver().delete((Uri) o[0], null, null); } catch (Exception ignored) { }
            }
            aviso("✔ Borrados " + k + " paquetes");
        });
    }

    // ======================= Pedir un texto =======================

    private void pedirTexto(String pregunta, String inicial, Consumer<String> listo) {
        EditText e = new EditText(this);
        e.setText(inicial);
        e.setTextSize(18);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setSelection(e.getText().length());
        LinearLayout box = vertical();
        box.setPadding(dp(18), dp(6), dp(18), 0);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle(pregunta).setView(box)
                .setPositiveButton("Listo", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) aviso("Escriba algo");
                    else listo.accept(s);
                })
                .setNegativeButton("Cancelar", null).show();
    }
}
