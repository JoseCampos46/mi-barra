package co.jose.chptronic;

import java.util.ArrayList;
import java.util.List;

/** Todo el conocimiento del taller: aparatos, fallas, pasos y pruebas del laboratorio. */
final class Datos {

    private Datos() {}

    // ======================= Pruebas del laboratorio =======================

    static final class Prueba {
        final String id, nombre, perillaTxt, cables, tipo, aviso;
        final int perilla;
        final String[] pasos;
        Prueba(String id, String nombre, int perilla, String perillaTxt, String cables, String tipo, String aviso, String... pasos) {
            this.id = id; this.nombre = nombre; this.perilla = perilla; this.perillaTxt = perillaTxt;
            this.cables = cables; this.tipo = tipo; this.aviso = aviso; this.pasos = pasos;
        }
    }

    /** Posiciones de la perilla del DT830D (dibujo aproximado). */
    static final String[] PERILLA = {
            "OFF", "V⎓ 200m", "V⎓ 2000m", "V⎓ 20", "V⎓ 200", "V⎓ 1000",
            "V~ 750", "V~ 200", "A 200µ", "A 2000µ", "A 20m", "A 200m", "A 10A",
            "hFE", "Diodo", "Ω 200", "Ω 2000", "Ω 20k", "Ω 200k", "Ω 2000k"
    };

    static final String DESCONECTADO = "Aparato DESCONECTADO del toma antes de medir. Nunca mida resistencia con el aparato enchufado: daña el multímetro y es peligroso.";

    static final List<Prueba> PRUEBAS = new ArrayList<>();
    static {
        PRUEBAS.add(new Prueba("fusible", "Fusible", 15, "Ω 200", "normal", "continuidad", DESCONECTADO,
                "Desenchufe el aparato y saque el fusible si se puede.",
                "Ponga la perilla en Ω 200.",
                "Cable rojo en VΩmA y negro en COM.",
                "Junte las dos puntas: debe marcar casi 0. Ese es el 'cero' de sus cables.",
                "Ponga una punta en cada extremo del fusible.",
                "Escriba lo que marca. Si marca 1 a la izquierda, toque el botón 'Marca 1 (fuera de rango)'."));
        PRUEBAS.add(new Prueba("fusibletermico", "Fusible térmico", 15, "Ω 200", "normal", "continuidad", DESCONECTADO + " El fusible térmico va pegado a la resistencia y se corta cuando el aparato se recalienta.",
                "Desenchufe el aparato y destápelo.",
                "Busque el fusible térmico: una pieza pequeña con funda (casi siempre blanca) junto a la resistencia o al termostato.",
                "Perilla en Ω 200, rojo en VΩmA, negro en COM.",
                "Una punta en cada patita del fusible térmico.",
                "Si está abierto, cámbielo por uno de la MISMA temperatura (viene escrita, ej. 216 °C) y mismo amperaje. Se une con conector de presión (ponchado), no con estaño, porque el calor del cautín lo daña."));
        PRUEBAS.add(new Prueba("cable", "Cable de corriente", 15, "Ω 200", "normal", "continuidad", DESCONECTADO,
                "Desenchufe y abra el aparato donde llega el cable.",
                "Perilla en Ω 200, rojo en VΩmA, negro en COM.",
                "Una punta en una pata del enchufe y la otra en el extremo del MISMO hilo adentro.",
                "Mueva y doble el cable mientras mide, sobre todo cerca del enchufe y de la entrada al aparato: si el número salta, hay un hilo roto.",
                "Repita con la otra pata."));
        PRUEBAS.add(new Prueba("resistencia", "Resistencia de calentar", 15, "Ω 200", "normal", "resistencia", DESCONECTADO,
                "Desenchufe y destape el aparato.",
                "Busque los vatios en la placa del aparato (ej. 1000 W) y escríbalos abajo: la app calcula cuánto debe marcar.",
                "Suelte un cable de la resistencia para que no mida por otro camino.",
                "Perilla en Ω 200, rojo en VΩmA, negro en COM.",
                "Una punta en cada terminal de la resistencia y escriba la lectura."));
        PRUEBAS.add(new Prueba("termostato", "Termostato", 15, "Ω 200", "normal", "continuidad", DESCONECTADO,
                "Desenchufe y deje enfriar el aparato del todo.",
                "Perilla en Ω 200, rojo en VΩmA, negro en COM.",
                "Ponga la perilla del termostato en lo más alto (si tiene).",
                "Mida entre sus dos terminales: frío debe estar CERRADO (casi 0).",
                "Si marca 1 (fuera de rango) estando frío, el termostato está pegado abierto o con contactos quemados."));
        PRUEBAS.add(new Prueba("interruptor", "Interruptor / botón", 15, "Ω 200", "normal", "continuidad", DESCONECTADO,
                "Desenchufe y destape.",
                "Perilla en Ω 200, rojo en VΩmA, negro en COM.",
                "Ponga las puntas en las dos patas del interruptor.",
                "Apagado debe marcar 1 (abierto). Prendido debe marcar casi 0.",
                "Escriba la lectura con el interruptor PRENDIDO. Si chisporrotea o calienta, aunque mida bien, cámbielo."));
        PRUEBAS.add(new Prueba("motor", "Motor con carbones", 15, "Ω 200", "normal", "motor", DESCONECTADO,
                "Desenchufe el aparato.",
                "Perilla en Ω 200, rojo en VΩmA, negro en COM.",
                "Mida entre las dos patas del enchufe con el interruptor del aparato PRENDIDO.",
                "Gire el eje o el vaso despacio con la mano mientras mide: el número debe moverse poco.",
                "Si marca 1 (fuera de rango), revise primero los carbones: se cambian cuando quedan de menos de un tercio de su largo nuevo (más o menos 6 mm)."));
        PRUEBAS.add(new Prueba("condensador", "Condensador", 19, "Ω 2000k", "normal", "condensador", "⚠ PELIGRO: los condensadores guardan corriente aunque el aparato esté desenchufado. Descárguelo antes de tocarlo: una resistencia de unos 10 kΩ (5 W) entre sus patas por unos segundos, con pinza aislada. Nunca con un destornillador: chispea y daña la pista.",
                "Desenchufe y DESCARGUE el condensador (ver aviso rojo).",
                "Suéltelo del circuito, por lo menos una pata.",
                "Perilla en Ω 2000k, rojo en VΩmA, negro en COM.",
                "Toque sus patas: mire qué hace el número durante unos segundos.",
                "Su DT830D no mide microfaradios: esta prueba solo dice si está en corto o abierto. Para medir el valor necesita un probador (LCR-T4).",
                "Si está hinchado, reventado o con líquido, está dañado aunque mida bien."));
        PRUEBAS.add(new Prueba("diodo", "Diodo", 14, "Diodo", "normal", "diodo", DESCONECTADO,
                "Desenchufe. Suelte una pata del diodo si se puede.",
                "Perilla en la posición del diodo (símbolo ▶|).",
                "Rojo en VΩmA, negro en COM.",
                "Rojo en el lado SIN raya y negro en el lado CON raya: debe marcar entre 400 y 800.",
                "Al revés debe marcar 1 (fuera de rango). Escriba la lectura de la primera forma."));
        PRUEBAS.add(new Prueba("led", "LED", 14, "Diodo", "normal", "led", DESCONECTADO,
                "Desenchufe el bombillo y ábralo con cuidado (la tapa plástica sale haciendo palanca).",
                "Perilla en Diodo, rojo en VΩmA, negro en COM.",
                "Rojo en el + del LED y negro en el −.",
                "Un LED bueno prende de forma suave. Algunos LED de bombillo necesitan más voltaje del que da el multímetro: si no prende, pruébelo con la pila de prueba de LED.",
                "Un LED quemado muchas veces tiene un puntico negro encima."));
        PRUEBAS.add(new Prueba("tomacorriente", "Voltaje del toma (110 V)", 6, "V~ 750", "normal", "voltajeAC", "⚠ PELIGRO: aquí se mide CON corriente. Coja las puntas solo por la parte plástica, una mano a la vez, y nunca toque las puntas de metal. Antes de medir, revise que el cable rojo NO esté en el hueco de 10A.",
                "Revise que el cable rojo esté en VΩmA (NO en 10A).",
                "Perilla en V~ 750 (voltaje alterno). Se usa 750 por seguridad, por si el toma fuera de 220 V.",
                "Meta una punta en cada hueco del toma.",
                "Debe marcar entre 110 y 127. Escriba la lectura."));
        PRUEBAS.add(new Prueba("pila", "Pila o batería", 3, "V⎓ 20", "normal", "voltajeDC", "Rojo en el + y negro en el −. Si el número sale con un menos (−) delante, las puntas están al revés.",
                "Perilla en V⎓ 20 (voltaje directo).",
                "Rojo en VΩmA, negro en COM.",
                "Rojo en el + y negro en el −.",
                "Escriba el voltaje que dice la pila (ej. 1.5, 9 o 12) y la lectura."));
        PRUEBAS.add(new Prueba("serie", "Bombillo en serie", 0, "Multímetro apagado", "nada", "serie", "⚠ PELIGRO: esta prueba se hace CON corriente. Use un bombillo INCANDESCENTE (de los viejos, de filamento) de 60 a 100 W en un portalámparas con cable. Nunca use bombillo LED: no sirve para esta prueba.",
                "Arme el probador: un cable del enchufe va directo al aparato; el otro pasa primero por el bombillo.",
                "Conecte el aparato al probador y el probador al toma.",
                "Prenda el aparato y mire el bombillo.",
                "Toque abajo lo que vio."));
    }

    static Prueba prueba(String id) {
        for (Prueba p : PRUEBAS) if (p.id.equals(id)) return p;
        return PRUEBAS.get(0);
    }

    // ======================= Aparatos =======================

    static final class Falla {
        final String titulo;
        final String[] pasos;
        final String[] pruebas;
        Falla(String titulo, String[] pruebas, String... pasos) { this.titulo = titulo; this.pruebas = pruebas; this.pasos = pasos; }
    }

    static final class Aparato {
        final String id, nombre, icono, grupo, aviso, youtube;
        final int version;
        final String[][] partes;
        final Falla[] fallas;
        Aparato(String id, String nombre, String icono, String grupo, int version, String aviso, String youtube, String[][] partes, Falla... fallas) {
            this.id = id; this.nombre = nombre; this.icono = icono; this.grupo = grupo; this.version = version;
            this.aviso = aviso; this.youtube = youtube; this.partes = partes; this.fallas = fallas;
        }
    }

    static String[] p(String... ids) { return ids; }
    static String[][] partes(String... nd) {
        String[][] r = new String[nd.length / 2][];
        for (int i = 0; i < r.length; i++) r[i] = new String[]{nd[i * 2], nd[i * 2 + 1]};
        return r;
    }

    static final String CALOR = "Desenchufe y deje enfriar antes de abrir. Las resistencias y las placas quedan calientes mucho rato.";

    static final List<Aparato> APARATOS = new ArrayList<>();
    static {
        // ---------------- Cocina ----------------
        APARATOS.add(new Aparato("licuadora", "Licuadora", "🥤", "Cocina", 1,
                "Desenchufe antes de meter la mano. Las cuchillas cortan aunque estén quietas.",
                "reparar licuadora no prende carbones",
                partes("Motor universal", "Tiene bobinas, colector (la parte de cobre que gira) y dos carbones que rozan el colector.",
                        "Carbones", "Bloquecitos de grafito con resorte. Se gastan con el uso.",
                        "Interruptor / botones", "Escogen la velocidad. Se ensucian o se queman.",
                        "Fusible térmico", "Protege el motor si se recalienta. Va pegado a la bobina.",
                        "Acople", "La pieza de caucho o plástico que une el motor con las cuchillas."),
                new Falla("No prende", p("cable", "interruptor", "motor", "fusibletermico"),
                        "Pruebe el toma con otro aparato.",
                        "Mida el cable de corriente.",
                        "Mida el interruptor en cada velocidad.",
                        "Mida el motor por el enchufe (prueba Motor con carbones).",
                        "Si el motor marca abierto, saque los carbones y mire el largo.",
                        "Mida el fusible térmico de la bobina."),
                new Falla("Huele a quemado o echa chispas", p("motor"),
                        "Desenchufe de inmediato.",
                        "Revise los carbones: si están muy cortos o partidos, cámbielos.",
                        "Mire el colector: si tiene rayas profundas o placas levantadas, el motor necesita rectificación.",
                        "Si la bobina se ve negra o huele fuerte a barniz quemado, la bobina está dañada."),
                new Falla("Suena pero no gira la cuchilla", p(),
                        "Desenchufe.",
                        "Revise el acople de abajo del vaso y el de arriba del motor: si están lisos o rotos, cámbielos.",
                        "Revise que las cuchillas giren libres con la mano.")));

        APARATOS.add(new Aparato("plancha", "Plancha de ropa", "👕", "Cocina", 1, CALOR,
                "reparar plancha de ropa no calienta",
                partes("Resistencia", "Va dentro de la suela. Es la que calienta.",
                        "Termostato", "La perilla de temperatura. Abre y cierra el paso de corriente.",
                        "Fusible térmico", "Se corta si la plancha se recalienta.",
                        "Cable", "Se parte por dentro de tanto moverlo, cerca de la plancha."),
                new Falla("No calienta", p("cable", "fusibletermico", "termostato", "resistencia"),
                        "Revise el cable, moviéndolo mientras mide: es la falla más común.",
                        "Mida el fusible térmico.",
                        "Mida el termostato en frío y con la perilla en lo más alto.",
                        "Mida la resistencia de la suela."),
                new Falla("Calienta demasiado o se quema la ropa", p("termostato"),
                        "El termostato está pegado: sus contactos no abren.",
                        "Cámbielo, o limpie los contactos con una lija muy fina si están solo sucios.")));

        APARATOS.add(new Aparato("freidora", "Freidora de aire", "🍟", "Cocina", 1, CALOR,
                "reparar freidora de aire no calienta",
                partes("Resistencia", "Va arriba, en espiral, detrás de una rejilla.",
                        "Ventilador y motor", "Mueve el aire caliente.",
                        "Termostato y fusible térmico", "Cuidan la temperatura.",
                        "Microinterruptor del cajón", "Si el cajón no está bien metido, no prende.",
                        "Tarjeta electrónica", "En las digitales, maneja la pantalla y los tiempos."),
                new Falla("No prende nada", p("cable", "fusibletermico", "interruptor"),
                        "Revise que el cajón cierre bien: tiene un microinterruptor.",
                        "Mida el cable.",
                        "Mida el fusible térmico (es la falla más común).",
                        "Mida el microinterruptor del cajón."),
                new Falla("Prende pero no calienta", p("resistencia", "termostato"),
                        "Mida la resistencia de arriba.",
                        "Mida el termostato.",
                        "Si es digital y todo mide bien, la falla puede estar en el relé de la tarjeta.")));

        APARATOS.add(new Aparato("sanduchera", "Sanduchera", "🥪", "Cocina", 1, CALOR,
                "reparar sanduchera no calienta",
                partes("Resistencias", "Una en cada tapa, bajo las placas.",
                        "Termostato", "Prende y apaga el bombillito verde.",
                        "Fusible térmico", "Protege si se recalienta.",
                        "Bisagra y cables", "Los cables pasan por la bisagra y se parten con el uso."),
                new Falla("No calienta", p("cable", "fusibletermico", "termostato", "resistencia"),
                        "Revise los cables que pasan por la bisagra.",
                        "Mida el fusible térmico.",
                        "Mida el termostato.",
                        "Mida cada resistencia por separado."),
                new Falla("Calienta solo una tapa", p("resistencia"),
                        "Mida la resistencia de la tapa fría.",
                        "Revise el cable de la bisagra hacia esa tapa.")));

        APARATOS.add(new Aparato("arrocera", "Olla arrocera", "🍚", "Cocina", 1, CALOR,
                "reparar olla arrocera no calienta",
                partes("Plato calentador", "La resistencia va dentro del plato del fondo.",
                        "Termostato magnético", "El botón que salta cuando el arroz está listo.",
                        "Fusible térmico", "Se corta si se recalienta (por ejemplo, prendida sin agua).",
                        "Resistencia de mantener caliente", "Una pequeña que mantiene el arroz tibio."),
                new Falla("No calienta", p("cable", "fusibletermico", "resistencia"),
                        "Mida el cable.",
                        "Mida el fusible térmico.",
                        "Mida el plato calentador."),
                new Falla("Se salta antes de tiempo o quema el arroz", p(),
                        "Limpie el plato del fondo y el fondo de la olla: una mugre o un golpe hacen mal contacto.",
                        "Revise que la olla no esté torcida.",
                        "Si sigue, el termostato magnético está débil: cámbielo.")));

        APARATOS.add(new Aparato("cafetera", "Cafetera", "☕", "Cocina", 1, CALOR,
                "reparar cafetera de goteo no calienta",
                partes("Resistencia", "Va en el fondo, pegada a un tubo por donde sube el agua.",
                        "Termostato y fusible térmico", "Cuidan la temperatura.",
                        "Válvula de retención", "Una bolita en la manguera que no deja devolver el agua.",
                        "Interruptor", "Con bombillito."),
                new Falla("No calienta", p("cable", "interruptor", "fusibletermico", "resistencia"),
                        "Mida cable e interruptor.",
                        "Mida el fusible térmico.",
                        "Mida la resistencia."),
                new Falla("Calienta pero no pasa el agua", p(),
                        "Haga una descalcificación: llene con mitad vinagre y mitad agua y pase el ciclo dos veces, luego dos veces con agua sola.",
                        "Revise que la bolita de la válvula no esté pegada.")));

        // ---------------- Hogar ----------------
        APARATOS.add(new Aparato("bombilloled", "Bombillos y lámparas LED", "💡", "Hogar", 1,
                "Apague el interruptor de la pared y espere unos minutos: el driver tiene un condensador que guarda corriente.",
                "reparar bombillo LED redondo de techo",
                partes("LEDs", "Van en una placa de aluminio, en serie. Si uno se quema, se apagan todos.",
                        "Driver", "La tarjetica que convierte los 110 V en el voltaje de los LEDs.",
                        "Condensador del driver", "El cilindro; si se hincha, el bombillo parpadea.",
                        "Fusible o resistencia fusible", "En la entrada del driver."),
                new Falla("No prende", p("led", "fusible", "condensador"),
                        "Abra el bombillo.",
                        "Busque LEDs con puntico negro y mídalos con la prueba LED.",
                        "Un LED quemado se puede cambiar por uno igual; de emergencia se puede puentear con un alambre: el bombillo queda un poco más brillante y dura menos.",
                        "Si todos los LEDs están buenos, mida el fusible de entrada del driver.",
                        "Revise si el condensador del driver está hinchado."),
                new Falla("Parpadea o prende muy débil", p("condensador", "led"),
                        "Revise el condensador del driver: si está hinchado, cámbielo por uno del mismo valor (µF) y voltaje igual o mayor.",
                        "Busque un LED con puntico negro: a veces hace contacto a ratos.")));

        APARATOS.add(new Aparato("ventilador", "Ventilador", "🌀", "Hogar", 1,
                "Desenchufe antes de quitar la rejilla. El condensador de arranque puede guardar corriente: descárguelo.",
                "reparar ventilador gira lento condensador",
                partes("Motor de inducción", "Sin carbones: tiene bobinas fijas y un rotor.",
                        "Condensador de arranque", "Cilindro o caja pequeña (1 a 2 µF). Ayuda a arrancar el motor.",
                        "Selector de velocidad", "Botones que escogen qué bobina usar.",
                        "Bujes", "Donde gira el eje. Se secan y frenan el motor."),
                new Falla("Zumba pero no gira, o gira muy lento", p("condensador"),
                        "Desenchufe y empuje las aspas con la mano: si están duras, el problema son los bujes. Límpielos y póngales unas gotas de aceite de máquina.",
                        "Si giran libres, cambie el condensador de arranque por uno del mismo valor (µF).",
                        "Esta es la falla más común de los ventiladores."),
                new Falla("No prende", p("cable", "interruptor", "fusibletermico"),
                        "Mida el cable.",
                        "Mida el selector de velocidades.",
                        "Muchos motores tienen un fusible térmico escondido dentro de la bobina.")));

        APARATOS.add(new Aparato("secador", "Secador de pelo", "💨", "Hogar", 1,
                "Desenchufe y deje enfriar. Nunca lo pruebe destapado cerca de agua.",
                "reparar secador de pelo no calienta",
                partes("Resistencia", "En espiral sobre una mica, a la salida del aire.",
                        "Motor pequeño DC", "Mueve el ventilador. Se alimenta por un puente de diodos.",
                        "Puente de diodos", "Cuatro diodos que cambian la corriente para el motor.",
                        "Protector térmico", "Corta si se tapa la entrada de aire."),
                new Falla("Sopla pero no calienta", p("resistencia", "interruptor"),
                        "Revise la espiral de la resistencia: si se ve partida, cámbiela.",
                        "Mida el selector de calor."),
                new Falla("No sopla", p("diodo", "cable"),
                        "Limpie la entrada de aire: el pelo se enreda en el eje.",
                        "Mida los diodos del puente.",
                        "Mida el cable.")));

        APARATOS.add(new Aparato("planchapelo", "Plancha de pelo", "💇", "Hogar", 1, CALOR,
                "reparar plancha de pelo no calienta",
                partes("Placas con resistencia", "Cerámicas o de titanio, con la resistencia debajo.",
                        "Tarjeta electrónica", "Controla la temperatura en las que tienen pantalla.",
                        "Cable giratorio", "Se parte por dentro en la unión que gira."),
                new Falla("No calienta", p("cable", "resistencia"),
                        "Mida el cable moviendo la parte giratoria.",
                        "Mida cada placa.",
                        "Si tiene tarjeta, revise el fusible de la tarjeta.")));

        APARATOS.add(new Aparato("ducha", "Ducha eléctrica", "🚿", "Hogar", 1,
                "⚠ PELIGRO: agua y electricidad. Baje el breaker de la ducha antes de destaparla, no solo el interruptor. La ducha necesita su propio circuito, cable grueso y polo a tierra.",
                "reparar ducha electrica no calienta resistencia",
                partes("Resistencia", "Va dentro de la cámara del agua.",
                        "Diafragma", "La membrana que se empuja con el agua y cierra el contacto.",
                        "Contactos", "Se ponen negros por las chispas."),
                new Falla("No calienta", p("resistencia"),
                        "Baje el breaker.",
                        "Revise si la resistencia está partida (se ve a simple vista).",
                        "Revise que el diafragma no esté roto: si no se empuja, no cierra el contacto.",
                        "Limpie los contactos si están negros."),
                new Falla("Se dispara el breaker", p(),
                        "Revise el calibre del cable y el breaker en la sección Electricidad.",
                        "Revise si la resistencia toca la carcasa (fuga a tierra): en ese caso, cámbiela YA.")));

        // ---------------- Herramientas ----------------
        APARATOS.add(new Aparato("taladro", "Taladro", "🔩", "Herramientas", 1,
                "Desenchufe y quite la broca antes de abrir.",
                "reparar taladro cambiar carbones",
                partes("Motor universal", "Con carbones y colector, igual que la licuadora.",
                        "Carbones", "Se cambian por la tapa de atrás o abriendo la carcasa.",
                        "Gatillo", "Controla la velocidad. Tiene un pequeño circuito.",
                        "Caja de engranajes", "Necesita grasa."),
                new Falla("No arranca", p("cable", "interruptor", "motor"),
                        "Mida el cable.",
                        "Mida el gatillo apretado.",
                        "Revise los carbones.",
                        "Mida el motor."),
                new Falla("Chispea mucho por las rejillas", p(),
                        "Carbones gastados o colector sucio: cambie carbones y limpie el colector con lija fina 600.",
                        "Si chispea en anillo todo alrededor, la armadura está en corto.")));

        APARATOS.add(new Aparato("pulidora", "Pulidora", "⚙", "Herramientas", 1,
                "⚠ Desenchufe y quite el disco antes de abrir. Nunca la pruebe sin la guarda puesta.",
                "reparar pulidora cambiar carbones",
                partes("Motor universal", "Con carbones y colector.",
                        "Carbones", "Muchas los tienen por fuera, con tapitas.",
                        "Interruptor", "Se llena de polvo del metal.",
                        "Cabeza de engranajes", "Necesita grasa; si suena a piedras, los piñones están mal."),
                new Falla("No arranca", p("cable", "interruptor", "motor"),
                        "Sople el polvo del interruptor y mídalo.",
                        "Revise los carbones.",
                        "Mida el motor."),
                new Falla("Suena feo en la cabeza", p(),
                        "Abra la cabeza, saque la grasa vieja y revise los dientes de los piñones.",
                        "Engrase con grasa para engranajes.")));

        APARATOS.add(new Aparato("ruteadora", "Ruteadora", "🪚", "Herramientas", 1,
                "Desenchufe y quite la fresa antes de abrir.",
                "reparar ruteadora router madera carbones",
                partes("Motor universal", "Con carbones y colector, gira muy rápido.",
                        "Control de velocidad", "Una tarjetica con un triac en las que tienen perilla.",
                        "Rodamientos", "Si suenan, se cambian."),
                new Falla("No arranca", p("cable", "interruptor", "motor"),
                        "Mida cable e interruptor.",
                        "Revise los carbones.",
                        "Mida el motor."),
                new Falla("No cambia de velocidad", p(),
                        "La falla está en la tarjeta del control de velocidad (casi siempre el triac).",
                        "Mándeme fotos de la tarjeta por el botón Claude.")));

        APARATOS.add(new Aparato("cautin", "Cautín", "🖊", "Herramientas", 1, CALOR,
                "reparar cautin no calienta resistencia",
                partes("Resistencia", "Un tubito de cerámica o mica alrededor de la punta.",
                        "Punta", "Se gasta y se pone negra; se limpia y se estaña.",
                        "Cable", "Se parte por la entrada al mango."),
                new Falla("No calienta", p("cable", "resistencia"),
                        "Mida el cable moviéndolo.",
                        "Mida la resistencia (un cautín de 40 W debe marcar unos 360 Ω: use Ω 2000)."),
                new Falla("Calienta pero no pega el estaño", p(),
                        "La punta está oxidada: límpiela caliente en una esponja húmeda o virutilla de bronce y póngale estaño de una vez.",
                        "Nunca la lime: se le quita la capa protectora.")));

        APARATOS.add(new Aparato("pistolasoldar", "Pistola de soldar (estaño)", "🔫", "Herramientas", 1, CALOR,
                "reparar pistola de soldar estaño transformador",
                partes("Transformador", "Baja el voltaje y da mucha corriente a la punta.",
                        "Punta de cobre", "Es un alambre grueso; se calienta por la corriente que pasa.",
                        "Tornillos de la punta", "Si se aflojan, la punta no calienta."),
                new Falla("Prende el bombillito pero no calienta", p(),
                        "Apriete los tornillos de la punta: es la falla más común.",
                        "Limpie con lija las puntas donde entran.",
                        "Cambie la punta si está muy delgada."),
                new Falla("No prende nada", p("cable", "interruptor"),
                        "Mida cable y gatillo.",
                        "Mida la bobina primaria del transformador (Ω 200): abierta = dañada.")));

        // ---------------- Próximas versiones (en gris) ----------------
        String[] v2 = {"Nevera", "Lavadora", "Microondas", "Aire acondicionado", "Televisores", "Controles remotos", "Radio y sonido", "Parlantes y audífonos", "Carro 12 V", "Moto", "Soldadores MIG, TIG y electrodo", "Relojes digitales", "Cargadores y UPS", "Apuntar antena"};
        String[] v3 = {"Celulares", "Tabletas", "Portátiles", "PC de escritorio", "Router y módem", "Impresoras", "Cámaras de seguridad", "Timbres"};
        String[] v4 = {"Relojería de cuerda", "Paneles solares"};
        for (String n : v2) APARATOS.add(new Aparato("v2_" + n, n, "", "Próximamente", 2, "", "", new String[0][]));
        for (String n : v3) APARATOS.add(new Aparato("v3_" + n, n, "", "Próximamente", 3, "", "", new String[0][]));
        for (String n : v4) APARATOS.add(new Aparato("v4_" + n, n, "", "Próximamente", 4, "", "", new String[0][]));
    }

    static Aparato aparato(String id) {
        for (Aparato a : APARATOS) if (a.id.equals(id)) return a;
        return null;
    }

    // ======================= Electricidad =======================

    /** Aparatos típicos de una casa con sus vatios aproximados (se pueden corregir). */
    static final String[][] CARGAS = {
            {"Nevera", "200"}, {"Televisor LED", "100"}, {"Licuadora", "600"}, {"Plancha de ropa", "1200"},
            {"Microondas", "1200"}, {"Freidora de aire", "1500"}, {"Ducha eléctrica", "3500"}, {"Lavadora", "500"},
            {"Bombillo LED", "10"}, {"Ventilador", "60"}, {"Computador", "300"}, {"Olla arrocera", "700"},
            {"Cafetera", "900"}, {"Secador de pelo", "1500"}, {"Aire acondicionado 12000 BTU", "1200"},
            {"Sanduchera", "750"}, {"Taladro", "600"}, {"Pulidora", "900"}, {"Otro", "100"}
    };

    /** Breaker y cable de cobre (THHN) según la corriente. Devuelve {breaker A, cable}. */
    static String[] breakerYCable(double amperios) {
        double necesario = amperios / 0.8; // la carga no debe pasar del 80 % del breaker
        if (necesario <= 15) return new String[]{"15", "14 AWG"};
        if (necesario <= 20) return new String[]{"20", "12 AWG"};
        if (necesario <= 30) return new String[]{"30", "10 AWG"};
        if (necesario <= 40) return new String[]{"40", "8 AWG"};
        if (necesario <= 50) return new String[]{"50", "6 AWG"};
        return new String[]{"más de 50", "consultar"};
    }
}
