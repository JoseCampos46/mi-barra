package co.jose.chptronic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Dibujo del multímetro DT830D con la perilla y los cables marcados para cada prueba. */
class Multimetro extends View {

    private int posicion;
    private String cables = "normal";
    private String pantalla = "000";
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    Multimetro(Context c) { super(c); }

    void poner(int posicion, String cables) {
        this.posicion = posicion;
        this.cables = cables;
        invalidate();
    }

    void lectura(String s) { pantalla = (s == null || s.isEmpty()) ? "000" : s; invalidate(); }

    @Override
    protected void onMeasure(int w, int h) {
        int ancho = MeasureSpec.getSize(w);
        setMeasuredDimension(ancho, (int) (ancho * 1.05f));
    }

    @Override
    protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight();
        float d = getResources().getDisplayMetrics().density;
        // Cuerpo amarillo
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF5B82E);
        RectF cuerpo = new RectF(W * 0.06f, H * 0.01f, W * 0.94f, H * 0.99f);
        c.drawRoundRect(cuerpo, 18 * d, 18 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * d);
        p.setColor(0xFF6B4A00);
        c.drawRoundRect(cuerpo, 18 * d, 18 * d, p);

        // Pantalla
        RectF pant = new RectF(W * 0.18f, H * 0.03f, W * 0.82f, H * 0.12f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFC9CDB8);
        c.drawRoundRect(pant, 6 * d, 6 * d, p);
        p.setColor(Color.BLACK);
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(H * 0.07f);
        c.drawText(pantalla, W / 2, H * 0.105f, p);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(11 * d);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText("DT830D", W * 0.10f, H * 0.97f, p);

        // Perilla y posiciones alrededor
        float cx = W / 2, cy = H * 0.44f, r = W * 0.15f, rt = W * 0.30f;
        int n = Datos.PERILLA.length;
        p.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < n; i++) {
            double ang = Math.toRadians(-90 + i * (360.0 / n));
            float x = cx + (float) (Math.cos(ang) * rt);
            float y = cy + (float) (Math.sin(ang) * rt);
            boolean sel = i == posicion;
            p.setTextSize((sel ? 13 : 10) * d);
            p.setTypeface(sel ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            if (sel) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFE02424);
                float tw = p.measureText(Datos.PERILLA[i]) / 2 + 5 * d;
                c.drawRoundRect(new RectF(x - tw, y - 12 * d, x + tw, y + 5 * d), 5 * d, 5 * d, p);
                p.setColor(Color.WHITE);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF3A2A00);
            }
            c.drawText(Datos.PERILLA[i], x, y, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFE89B12);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFF6B4A00);
        c.drawCircle(cx, cy, r, p);
        double a = Math.toRadians(-90 + posicion * (360.0 / n));
        p.setStrokeWidth(10 * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFF222222);
        c.drawLine(cx, cy, cx + (float) (Math.cos(a) * r * 0.95f), cy + (float) (Math.sin(a) * r * 0.95f), p);
        p.setStrokeWidth(2 * d);

        // Huecos de los cables
        float hx = W * 0.80f;
        float[] hy = {H * 0.80f, H * 0.87f, H * 0.94f};
        String[] nom = {"10A", "VΩmA", "COM"};
        for (int i = 0; i < 3; i++) {
            boolean rojo = ("normal".equals(cables) && i == 1) || ("10A".equals(cables) && i == 0);
            boolean negro = !"nada".equals(cables) && i == 2;
            p.setStyle(Paint.Style.FILL);
            p.setColor(rojo ? 0xFFE02424 : negro ? 0xFF111111 : 0xFF8A7A55);
            c.drawCircle(hx, hy[i], (rojo || negro ? 9 : 6) * d, p);
            p.setColor(rojo ? 0xFFB00000 : 0xFF3A2A00);
            p.setTextSize(12 * d);
            p.setTypeface(rojo || negro ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setTextAlign(Paint.Align.RIGHT);
            String extra = rojo ? "cable rojo → " : negro ? "cable negro → " : "";
            c.drawText(extra + nom[i], hx - 14 * d, hy[i] + 4 * d, p);
        }
    }
}
