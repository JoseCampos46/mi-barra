package co.jose.mibarra;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.io.File;
import java.util.Locale;

/**
 * Versión 29: la voz de Mi Voz. Usa Acapela (Antonio) si está instalada; si no, la voz del celular.
 * Tono y velocidad graduables, y «acento latino»: cambia por dentro la z y la c suave por s
 * para que Antonio no diga «th».
 */
final class VozLocutor {

    static final String ACAPELA = "com.acapelagroup.android.tts";

    interface Listo { void listo(boolean bien); }

    private TextToSpeech tts;
    private boolean lista;
    private final SharedPreferences p;
    private Runnable alTerminar;

    VozLocutor(Context c, Listo cb) {
        p = c.getSharedPreferences("mivoz", Context.MODE_PRIVATE);
        boolean hayAcapela;
        try { c.getPackageManager().getPackageInfo(ACAPELA, 0); hayAcapela = true; } catch (Exception e) { hayAcapela = false; }
        TextToSpeech.OnInitListener init = s -> {
            lista = s == TextToSpeech.SUCCESS;
            if (lista) {
                tts.setLanguage(new Locale("es", "ES"));
                ajustar();
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { Runnable r = alTerminar; alTerminar = null; if (r != null) r.run(); }
                    @Override public void onError(String id) { Runnable r = alTerminar; alTerminar = null; if (r != null) r.run(); }
                });
            }
            if (cb != null) cb.listo(lista);
        };
        tts = hayAcapela ? new TextToSpeech(c.getApplicationContext(), init, ACAPELA) : new TextToSpeech(c.getApplicationContext(), init);
    }

    float tono() { return p.getInt("tono", 85) / 100f; }
    float velocidad() { return p.getInt("vel", 92) / 100f; }
    boolean latino() { return p.getBoolean("latino", true); }

    void guardar(int tono, int vel, boolean latino) {
        p.edit().putInt("tono", tono).putInt("vel", vel).putBoolean("latino", latino).apply();
        ajustar();
    }

    private void ajustar() {
        if (!lista) return;
        tts.setPitch(Math.max(0.5f, tono()));
        tts.setSpeechRate(Math.max(0.5f, velocidad()));
    }

    /** Lo que de verdad se le pasa a la voz: sin símbolos, con «pesos», y con acento latino si está prendido. */
    String preparar(String t) {
        String s = t.replace("*", "").replace("•", "").replace("×", " a ").replace("=", ", son ")
                .replaceAll("\\$\\s?([\\d.]+)", "$1 pesos").replace("_", " ");
        if (latino()) {
            s = s.replaceAll("z", "s").replaceAll("Z", "S")
                    .replaceAll("c([eéií])", "s$1").replaceAll("C([eEéÉiIíÍ])", "S$1");
        }
        return s;
    }

    boolean lista() { return lista; }

    void hablar(String texto) {
        if (!lista) return;
        tts.stop();
        tts.speak(preparar(texto), TextToSpeech.QUEUE_FLUSH, null, "leer");
    }

    void callar() { if (tts != null) tts.stop(); }

    /** Graba el escrito en un archivo de audio; avisa cuando termina. */
    void aArchivo(String texto, File f, Runnable listo) {
        if (!lista) { listo.run(); return; }
        alTerminar = listo;
        Bundle b = new Bundle();
        int r = tts.synthesizeToFile(preparar(texto), b, f, "archivo");
        if (r != TextToSpeech.SUCCESS) { alTerminar = null; listo.run(); }
    }

    void cerrar() { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {} }
}
