package co.jose.mibarra;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Versión 29: Radio reloj tipo Sony (solo acostado). Reemplaza al reloj de noche.
 * Hora grande en rojo, batería, temperatura, alarma con radio o con música propia, dormir y luz suave.
 */
public class RadioRelojActivity extends Activity {

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Locale es = new Locale("es", "CO");
    private SharedPreferences p;
    private TextView tHora, tFecha, tAlarma, tBat, tTemp, tSonando;
    private int bateria = -1;
    private boolean cargando;
    private Runnable dormirFin;

    private int dp(float v) { return Util.dp(this, v); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("radioreloj", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setShowWhenLocked(true);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        LinearLayout raiz = new LinearLayout(this);
        raiz.setBackgroundColor(0xFF111111);
        raiz.setPadding(dp(12), dp(10), dp(12), dp(10));

        // Izquierda: la pantalla negra con la hora roja
        FrameLayout pant = new FrameLayout(this);
        pant.setBackground(Comun.fondo(this, Color.BLACK, 18));
        LinearLayout centro = new LinearLayout(this);
        centro.setOrientation(LinearLayout.VERTICAL);
        centro.setGravity(Gravity.CENTER);
        tHora = texto(96, 0xFFFF3B30);
        tHora.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        tHora.setIncludeFontPadding(false);
        centro.addView(tHora);
        tFecha = texto(18, 0xFFFF8A80);
        centro.addView(tFecha);
        tAlarma = texto(17, 0xFFFFD54F);
        tAlarma.setPadding(0, dp(6), 0, 0);
        centro.addView(tAlarma);
        tSonando = texto(15, 0xFF9CCC65);
        centro.addView(tSonando);
        pant.addView(centro, new FrameLayout.LayoutParams(-1, -1));
        tBat = texto(18, 0xFF9CCC65);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        bl.setMargins(dp(14), dp(8), 0, 0);
        pant.addView(tBat, bl);
        tTemp = texto(18, 0xFF81D4FA);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        tl.setMargins(0, dp(8), dp(14), 0);
        pant.addView(tTemp, tl);
        raiz.addView(pant, new LinearLayout.LayoutParams(0, -1, 1.6f));

        // Derecha: los botones
        LinearLayout der = new LinearLayout(this);
        der.setOrientation(LinearLayout.VERTICAL);
        der.setPadding(dp(10), 0, 0, 0);
        fila(der, "📻 Radio", () -> { pararTodo(); SonidoService.radioFavorita(this); tSonando.setText("📻 Radio"); },
                "🎵 Música", this::escogerMusica);
        fila(der, "🎧 Mi carpeta", () -> { pararTodo(); SonidoService.miCarpeta(this); tSonando.setText("🎧 Mi carpeta"); },
                "⏹ Parar", () -> { pararTodo(); tSonando.setText(""); });
        fila(der, "💤 Dormir", this::dormir, "⏰ Alarma", this::alarma);
        LinearLayout fl = new LinearLayout(this);
        fl.setGravity(Gravity.CENTER_VERTICAL);
        fl.setBackground(Comun.fondo(this, 0xFF2A2A2A, 10));
        fl.setPadding(dp(8), 0, dp(4), 0);
        fl.addView(texto(16, Color.WHITE, "🔅"));
        SeekBar luz = new SeekBar(this);
        luz.setMax(100);
        luz.setProgress(p.getInt("luz", 15));
        luz.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { if (u) { p.edit().putInt("luz", v).apply(); ponerLuz(); } }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        fl.addView(luz, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, 0, 1f);
        fp.topMargin = dp(6);
        der.addView(fl, fp);
        raiz.addView(der, new LinearLayout.LayoutParams(0, -1, 1f));
        setContentView(raiz);
        ponerLuz();
        registerReceiver(bat, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        despertarSiToca(getIntent());
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); despertarSiToca(i); }

    @Override protected void onResume() { super.onResume(); h.post(tic); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tic); }
    @Override protected void onDestroy() { try { unregisterReceiver(bat); } catch (Exception ignored) {} super.onDestroy(); }

    private final BroadcastReceiver bat = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            bateria = lv < 0 ? -1 : lv * 100 / sc;
            cargando = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            pintarBat();
        }
    };

    private void pintarBat() {
        if (bateria < 0) { tBat.setText(""); return; }
        tBat.setText((cargando ? "⚡ " : "🔋 ") + bateria + " %");
        tBat.setTextColor(bateria <= 20 ? 0xFFFF5252 : bateria <= 50 ? 0xFFFFD54F : 0xFF9CCC65);
    }

    private final Runnable tic = new Runnable() {
        @Override public void run() {
            Date d = new Date();
            tHora.setText(new SimpleDateFormat("h:mm", es).format(d));
            String a = new SimpleDateFormat("a", es).format(d).replace("a.m.", "a. m.").replace("p.m.", "p. m.");
            String f = new SimpleDateFormat("EEE d MMM", es).format(d).replace(".", "");
            tFecha.setText(a + " · " + f);
            long al = p.getLong("alarma", 0);
            tAlarma.setText(al > System.currentTimeMillis()
                    ? "⏰ " + new SimpleDateFormat("h:mm a", es).format(new Date(al)).replace("a.m.", "a. m.").replace("p.m.", "p. m.")
                    + " · " + (p.getInt("sonido", 0) == 3 ? "📻 Radio" : Melodias.NOMBRES[p.getInt("sonido", 0)])
                    : "⏰ Sin alarma");
            // Temperatura: la última que sacó la pantalla de inicio (se actualiza cuando hay internet)
            String cl = getSharedPreferences("inicio", MODE_PRIVATE).getString("clima", "");
            Matcher m = Pattern.compile("(-?\\d+)°").matcher(cl);
            tTemp.setText(m.find() ? "🌡 " + m.group(1) + " °C" : "");
            h.postDelayed(this, 60000 - System.currentTimeMillis() % 60000 + 50);
        }
    };

    private TextView texto(float t, int c) { return texto(t, c, ""); }

    private TextView texto(float t, int c, String s) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(t);
        v.setTextColor(c);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private void fila(LinearLayout l, String a, Runnable ra, String b, Runnable rb) {
        LinearLayout f = new LinearLayout(this);
        for (int i = 0; i < 2; i++) {
            TextView t = texto(17, Color.WHITE, i == 0 ? a : b);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setBackground(Comun.fondo(this, 0xFF2A2A2A, 10));
            Runnable r = i == 0 ? ra : rb;
            t.setOnClickListener(v -> r.run());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
            lp.setMargins(i == 0 ? 0 : dp(6), 0, 0, 0);
            f.addView(t, lp);
        }
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, 0, 1f);
        fp.topMargin = l.getChildCount() == 0 ? 0 : dp(6);
        l.addView(f, fp);
    }

    /** Luz de la pantalla: muy suave por defecto; él la gradúa. */
    private void ponerLuz() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = Math.max(0.01f, p.getInt("luz", 15) / 100f);
        getWindow().setAttributes(lp);
    }

    private void pararTodo() {
        Melodias.parar();
        SonidoService.parar(this);
        if (dormirFin != null) { h.removeCallbacks(dormirFin); dormirFin = null; }
    }

    private void escogerMusica() {
        new AlertDialog.Builder(this).setTitle("🎵 Música de Mi Barra").setItems(Melodias.NOMBRES, (d, w) -> {
            pararTodo();
            Melodias.tocar(w, false);
            tSonando.setText(Melodias.NOMBRES[w]);
        }).show();
    }

    private void dormir() {
        String[] ops = {"15 minutos", "30 minutos", "60 minutos"};
        int[] min = {15, 30, 60};
        new AlertDialog.Builder(this).setTitle("💤 Apagar el sonido en…").setItems(ops, (d, w) -> {
            SonidoService.dormir(this, min[w]);
            if (dormirFin != null) h.removeCallbacks(dormirFin);
            dormirFin = () -> { Melodias.parar(); tSonando.setText(""); };
            h.postDelayed(dormirFin, min[w] * 60000L);
            Toast.makeText(this, "💤 Se apaga en " + ops[w], Toast.LENGTH_SHORT).show();
        }).show();
    }

    /** Alarma: escoge la hora y con qué suena (música propia o radio). */
    private void alarma() {
        String[] ops = {"⏰ Poner alarma", "🔕 Quitar alarma"};
        new AlertDialog.Builder(this).setTitle("⏰ Alarma").setItems(ops, (d, w) -> {
            if (w == 1) { quitarAlarma(); return; }
            Calendar c = Calendar.getInstance();
            new TimePickerDialog(this, (tp, hh, mm) -> {
                String[] son = {Melodias.NOMBRES[0], Melodias.NOMBRES[1], Melodias.NOMBRES[2], "📻 Radio (emisora favorita)"};
                new AlertDialog.Builder(this).setTitle("¿Con qué suena?").setItems(son, (d2, s) -> {
                    p.edit().putInt("sonido", s).apply();
                    ponerAlarma(hh, mm);
                }).show();
            }, p.getInt("hh", 5), p.getInt("mm", 30), false).show();
        }).show();
    }

    private PendingIntent pi() {
        return PendingIntent.getActivity(this, 2929, new Intent(this, RadioRelojActivity.class).putExtra("despertar", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void ponerAlarma(int hh, int mm) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hh);
        c.set(Calendar.MINUTE, mm);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_MONTH, 1);
        try {
            AlarmManager am = getSystemService(AlarmManager.class);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(c.getTimeInMillis(), pi()), pi());
            p.edit().putLong("alarma", c.getTimeInMillis()).putInt("hh", hh).putInt("mm", mm).apply();
            Toast.makeText(this, "⏰ Alarma lista", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo poner la alarma", Toast.LENGTH_LONG).show();
        }
        h.post(tic);
    }

    private void quitarAlarma() {
        try { getSystemService(AlarmManager.class).cancel(pi()); } catch (Exception ignored) {}
        p.edit().putLong("alarma", 0).apply();
        h.post(tic);
    }

    /** Llegó la hora: prende la pantalla y suena (la música empieza bajito y va subiendo). Mañana a la misma hora otra vez. */
    private void despertarSiToca(Intent i) {
        if (i == null || !i.getBooleanExtra("despertar", false)) return;
        i.removeExtra("despertar");
        setTurnScreenOn(true);
        pararTodo();
        int s = p.getInt("sonido", 0);
        if (s == 3) { SonidoService.radioFavorita(this); tSonando.setText("📻 Radio"); }
        else { Melodias.tocar(s, true); tSonando.setText(Melodias.NOMBRES[s]); }
        ponerAlarma(p.getInt("hh", 5), p.getInt("mm", 30));
        new AlertDialog.Builder(this).setTitle("⏰ ¡Buenos días!").setCancelable(false)
                .setPositiveButton("⏹ Apagar", (d, w) -> { pararTodo(); tSonando.setText(""); })
                .setNegativeButton("💤 10 minutos más", (d, w) -> {
                    pararTodo();
                    tSonando.setText("💤 Suena otra vez en 10 min");
                    h.postDelayed(() -> { Melodias.tocar(s == 3 ? 0 : s, true); tSonando.setText("⏰"); }, 600000);
                }).show();
    }
}
