package co.jose.chepevideo;

import androidx.media3.common.Format;
import androidx.media3.transformer.Codec;
import androidx.media3.transformer.ExportException;

/** Pide al codificador de sonido un tamaño (kbps) más pequeño, para que el M4A pese poco. */
public final class AudioRate implements Codec.EncoderFactory {

    private final Codec.EncoderFactory base;
    private final int bitrate;

    public AudioRate(Codec.EncoderFactory base, int bitrate) {
        this.base = base;
        this.bitrate = bitrate;
    }

    @Override
    public Codec createForAudioEncoding(Format format) throws ExportException {
        return base.createForAudioEncoding(format.buildUpon().setAverageBitrate(bitrate).build());
    }

    @Override
    public Codec createForVideoEncoding(Format format) throws ExportException {
        return base.createForVideoEncoding(format);
    }
}
