package co.jose.chepevideo;

import androidx.media3.effect.RgbMatrix;

/** Oscurece al entrar y al salir (desvanecer). El tiempo se cuenta desde el primer cuadro de este video. */
public final class TransFade implements RgbMatrix {

    private final boolean fadeIn, fadeOut;
    private final long durUs, tUs;
    private long first = -1;

    public TransFade(boolean fadeIn, boolean fadeOut, long durMs, long transMs) {
        this.fadeIn = fadeIn;
        this.fadeOut = fadeOut;
        this.durUs = durMs * 1000L;
        this.tUs = transMs * 1000L;
    }

    @Override
    public float[] getMatrix(long presentationTimeUs, boolean useHdr) {
        if (first < 0) first = presentationTimeUs;
        long rel = presentationTimeUs - first;
        float k = 1f;
        if (tUs > 0) {
            if (fadeIn && rel < tUs) k = Math.min(k, rel / (float) tUs);
            if (fadeOut && rel > durUs - tUs) k = Math.min(k, Math.max(0f, (durUs - rel) / (float) tUs));
        }
        k = Math.max(0f, Math.min(1f, k));
        return new float[]{
                k, 0, 0, 0,
                0, k, 0, 0,
                0, 0, k, 0,
                0, 0, 0, 1};
    }

    /** Nunca se salta: el brillo depende del tiempo. */
    public boolean isNoOp(int inputWidth, int inputHeight) { return false; }
}
