package co.jose.chepevideo;

import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.BaseAudioProcessor;

import java.nio.ByteBuffer;

/**
 * Sube o baja el volumen, hace entrada y salida suave y, si se pide, deja el sonido en un solo canal (mono).
 * fadeInMs / fadeOutMs = 0 para no hacer entrada o salida suave. totalMs = duración total (para saber cuándo salir).
 */
public final class Gain extends BaseAudioProcessor {

    private final float gain;
    private final long fadeInMs, fadeOutMs, totalMs;
    private final boolean mono;
    private long frames;

    public Gain(float gain, long fadeInMs, long fadeOutMs, long totalMs, boolean mono) {
        this.gain = gain;
        this.fadeInMs = fadeInMs;
        this.fadeOutMs = fadeOutMs;
        this.totalMs = totalMs;
        this.mono = mono;
    }

    @Override
    protected AudioFormat onConfigure(AudioFormat in) throws UnhandledAudioFormatException {
        if (in.encoding != C.ENCODING_PCM_16BIT) throw new UnhandledAudioFormatException(in);
        if (mono && in.channelCount > 1) return new AudioFormat(in.sampleRate, 1, C.ENCODING_PCM_16BIT);
        return in;
    }

    private float gainAt(long frame, int rate) {
        float g = gain;
        if (rate <= 0) return g;
        double ms = frame * 1000.0 / rate;
        if (fadeInMs > 0 && ms < fadeInMs) g *= (float) (ms / fadeInMs);
        if (fadeOutMs > 0 && totalMs > 0 && ms > totalMs - fadeOutMs)
            g *= (float) Math.max(0.0, (totalMs - ms) / fadeOutMs);
        return g;
    }

    @Override
    public void queueInput(ByteBuffer in) {
        int inCh = Math.max(1, inputAudioFormat.channelCount);
        int outCh = Math.max(1, outputAudioFormat.channelCount);
        int rate = inputAudioFormat.sampleRate;
        int n = in.remaining() / (2 * inCh);
        if (n <= 0) { in.position(in.limit()); return; }
        ByteBuffer out = replaceOutputBuffer(n * 2 * outCh);
        int pos = in.position();
        for (int f = 0; f < n; f++) {
            float g = gainAt(frames + f, rate);
            if (outCh == inCh) {
                for (int ch = 0; ch < inCh; ch++) {
                    int i = pos + (f * inCh + ch) * 2;
                    int v = (short) ((in.get(i) & 0xFF) | (in.get(i + 1) << 8));
                    put(out, v * g);
                }
            } else {
                float sum = 0;
                for (int ch = 0; ch < inCh; ch++) {
                    int i = pos + (f * inCh + ch) * 2;
                    sum += (short) ((in.get(i) & 0xFF) | (in.get(i + 1) << 8));
                }
                put(out, sum / inCh * g);
            }
        }
        frames += n;
        in.position(pos + n * 2 * inCh);
        if (in.hasRemaining()) in.position(in.limit());
        out.flip();
    }

    private static void put(ByteBuffer out, float v) {
        int s = Math.round(v);
        if (s > 32767) s = 32767; else if (s < -32768) s = -32768;
        out.put((byte) (s & 0xFF));
        out.put((byte) ((s >> 8) & 0xFF));
    }

    @Override
    protected void onReset() { frames = 0; }
}
