package co.jose.chepevideo;

import android.graphics.Matrix;

import androidx.media3.effect.MatrixTransformation;

/**
 * Movimiento de entrada y de salida de cada video cuando se unen.
 * Tipos: 0 corte, 1 desvanecer, 2 zoom, 3 deslizar, 4 giro.
 * El tiempo se cuenta desde el primer cuadro de este video.
 */
public final class TransMotion implements MatrixTransformation {

    private final int inType, outType;
    private final long durUs, tUs;
    private final float aspect;
    private long first = -1;

    public TransMotion(int inType, int outType, long durMs, long transMs, float aspectWH) {
        this.inType = inType;
        this.outType = outType;
        this.durUs = durMs * 1000L;
        this.tUs = transMs * 1000L;
        this.aspect = aspectWH <= 0 ? 1f : aspectWH;
    }

    public static boolean moves(int type) { return type >= 2; }

    private static float smooth(float p) { p = Math.max(0f, Math.min(1f, p)); return p * p * (3f - 2f * p); }

    /** amount 1 = totalmente afuera, 0 = en su puesto. */
    private void apply(Matrix m, int type, float amount, boolean entering) {
        if (amount <= 0f) return;
        switch (type) {
            case 2: {
                float s = entering ? 1f + 0.6f * amount : 1f + 0.6f * amount;
                m.postScale(s, s);
                break;
            }
            case 3: {
                float dx = entering ? 2f * amount : -2f * amount;
                m.postTranslate(dx, 0f);
                break;
            }
            case 4: {
                float s = 1f - 0.85f * amount;
                float deg = (entering ? 1f : -1f) * 180f * amount;
                m.postScale(aspect, 1f);
                m.postRotate(deg);
                m.postScale(s / aspect, s);
                break;
            }
        }
    }

    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        if (first < 0) first = presentationTimeUs;
        long rel = presentationTimeUs - first;
        Matrix m = new Matrix();
        if (tUs <= 0) return m;
        if (rel < tUs && moves(inType)) {
            apply(m, inType, 1f - smooth(rel / (float) tUs), true);
        } else if (rel > durUs - tUs && moves(outType)) {
            apply(m, outType, smooth((rel - (durUs - tUs)) / (float) tUs), false);
        }
        return m;
    }

    /** Nunca se salta: el movimiento depende del tiempo. */
    public boolean isNoOp(int inputWidth, int inputHeight) { return false; }
}
