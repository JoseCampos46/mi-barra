package co.jose.chepevideo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.provider.OpenableColumns;
import android.view.WindowManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SonicAudioProcessor;
import androidx.media3.effect.Crop;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.google.android.gms.tasks.Tasks;
import com.google.common.collect.ImmutableList;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    static final int TEAL_L = 0xFFE1F5EE, TEAL_D = 0xFF0F6E56, TEAL_T = 0xFF085041;
    static final int AMB_L = 0xFFFAEEDA, AMB_T = 0xFF633806, AMB_B = 0xFFBA7517;
    static final int REQ_VIDEO = 1, REQ_IMAGE = 2, REQ_LAYER = 3, REQ_BG_IMG = 4, REQ_BG_VID = 5,
            REQ_JOIN = 6, REQ_MUSIC = 7, REQ_MIC = 12, REQ_NOTIF = 13;
    static final String[] TRANS = {"✂ Corte", "🌑 Desvanecer", "🔍 Zoom", "➡ Deslizar", "🌀 Giro"};
    static final String[] FORMATS = {"Como el primero", "Vertical", "Horizontal", "Cuadrado"};
    static final long TRANS_MS = 600;

    private ExoPlayer player;
    private PlayerView playerView;
    private OverlayView overlay;
    private TimelineView timeline;
    private ZoomFrame videoFrame;
    private long lastTapT;
    private LinearLayout topBar, ctxBox, ctxRow, thumbRow, timelineRow, panel;
    private HorizontalScrollView ctxScroll;
    private ScrollView gridScroll;
    private TextView titleView, statusView, openBtn, playBtn;
    private GridLayout grid;
    private final ImageView[] thumbs = new ImageView[5];
    private final EnumMap<Mode, TextView> modeBtns = new EnumMap<>(Mode.class);
    private final Mode[] order = {Mode.OPEN, Mode.JOIN, Mode.CUT, Mode.SPEED, Mode.MUTE,
            Mode.PHOTO, Mode.SUBS, Mode.TEXT, Mode.IMAGE, Mode.CROP,
            Mode.BG, Mode.LAYER, Mode.MUSIC, Mode.AUDIO, Mode.EXPORT};

    private boolean landscape, menuVisible = true, exporting, previewBusy, subsBusy;
    private boolean photoCarta = true, bgGreen, layerGreen;
    private Mode mode = Mode.NONE;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private Compositor previewComp;
    private Seg imgSeg;
    private MediaMetadataRetriever thumbRet;
    private Uri thumbUri;
    private long lastThumbPos = -1;
    private Runnable pendingMic;

    private ExoPlayer musicPlayer;
    private boolean screenOn, askedNotif;
    private int savedVol = -1;
    private Runnable jobCleanup;
    private SharedPreferences prefs;

    private SpeechRecognizer micRec;
    private boolean micActive;
    private long micSegStart;

    // ------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("chepevideo", MODE_PRIVATE);
        player = new ExoPlayer.Builder(this).build();
        player.setSeekParameters(SeekParameters.EXACT);
        buildViews();
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                playBtn.setText(isPlaying ? "⏸" : "▶");
                if (mode == Mode.PHOTO) refreshCtx();
                overlay.invalidate();
            }
        });
        landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyLayout();
        setMode(Mode.NONE);
        handleIntent(getIntent());
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() { onTick(); ui.postDelayed(this, 40); }
    };

    @Override protected void onResume() { super.onResume(); ui.removeCallbacks(tick); ui.post(tick); }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
        if (micActive) finishMic();
        player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        keepScreen(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        player.release();
        if (musicPlayer != null) musicPlayer.release();
        if (!exporting) TrabajoService.stop(this);
        final Compositor pc = previewComp;
        final MediaMetadataRetriever tr = thumbRet;
        final Seg sg = imgSeg;
        exec.execute(() -> {
            if (pc != null) pc.release();
            if (sg != null) sg.close();
            if (tr != null) try { tr.release(); } catch (Exception ignored) {}
        });
        exec.shutdown();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        landscape = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyLayout();
        refreshCtx();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        else if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        if (u != null) loadVideo(u);
    }

    // ------------------------------------------------------------ pantalla

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    private TextView chip(String label, boolean active, Runnable r) {
        TextView t = tv(label, 14, active ? Color.WHITE : TEAL_T, true);
        t.setBackground(round(active ? TEAL_D : TEAL_L, 18));
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView lab(String s) {
        TextView t = tv(s, 13, Color.BLACK, true);
        t.setBackground(round(Color.WHITE, 8));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private TextView small(String s, Runnable r) {
        TextView t = tv(s, 22, TEAL_T, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(TEAL_L, 10));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void add(View v) { ctxRow.addView(v); }

    private void buildViews() {
        playerView = (PlayerView) getLayoutInflater().inflate(R.layout.reproductor, null, false);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setShutterBackgroundColor(Color.BLACK);
        playerView.setPlayer(player);

        overlay = new OverlayView(this);
        overlay.onTap = this::onVideoTap;
        overlay.onChanged = () -> { marks(); if (mode == Mode.CROP) refreshCtx(); };

        videoFrame = new ZoomFrame(this);
        videoFrame.gate = overlay::wantsPinch;
        videoFrame.box.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        videoFrame.box.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        titleView = tv("🎬 Chepe Video", 18, Color.BLACK, true);
        statusView = tv("", 12, TEAL_T, true);
        statusView.setBackground(round(TEAL_L, 8));
        statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
        statusView.setVisibility(View.GONE);
        openBtn = chip("📂 Abrir video", true, () -> pick(REQ_VIDEO, "video/*"));

        topBar = hbox();
        topBar.setPadding(dp(10), dp(6), dp(4), dp(6));

        ctxRow = hbox();
        ctxRow.setPadding(dp(6), dp(5), dp(6), dp(5));
        ctxScroll = new HorizontalScrollView(this);
        ctxScroll.setHorizontalScrollBarEnabled(false);
        ctxScroll.addView(ctxRow);

        thumbRow = hbox();
        thumbRow.setPadding(dp(6), 0, dp(6), dp(5));
        for (int i = 0; i < 5; i++) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(i == 2 ? TEAL_D : 0xFFB5D4F4, 4));
            int pd = dp(i == 2 ? 3 : 1);
            iv.setPadding(pd, pd, pd, pd);
            final int off = i - 2;
            iv.setOnClickListener(v -> step(off));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            lp.setMarginEnd(dp(4));
            thumbRow.addView(iv, lp);
            thumbs[i] = iv;
        }
        ctxBox = vbox();
        ctxBox.addView(ctxScroll);
        ctxBox.addView(thumbRow);

        timeline = new TimelineView(this);
        timeline.listener = new TimelineView.Listener() {
            @Override public void onSeek(long ms) { player.seekTo(ms); }
            @Override public void onTrim(long s, long e) { Proj.trimStart = s; Proj.trimEnd = e; if (mode == Mode.CUT) refreshCtx(); }
        };
        playBtn = small("▶", this::togglePlay);
        TextView minus = small("−", () -> timeline.zoomOut());
        TextView plus = small("+", () -> timeline.zoomIn());
        timelineRow = hbox();
        timelineRow.setPadding(dp(4), dp(2), dp(4), dp(2));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(46), dp(46));
        pl.setMarginEnd(dp(4));
        timelineRow.addView(playBtn, pl);
        timelineRow.addView(minus, new LinearLayout.LayoutParams(dp(36), dp(46)));
        timelineRow.addView(timeline, new LinearLayout.LayoutParams(0, dp(62), 1f));
        timelineRow.addView(plus, new LinearLayout.LayoutParams(dp(36), dp(46)));

        grid = new GridLayout(this);
        gridScroll = new ScrollView(this);
        addModeBtn(Mode.OPEN, "📂", "Abrir");
        addModeBtn(Mode.JOIN, "🎞️", "Unir");
        addModeBtn(Mode.CUT, "✂️", "Cortar");
        addModeBtn(Mode.SPEED, "🐢", "Lento");
        addModeBtn(Mode.MUTE, "🔇", "Mudo");
        addModeBtn(Mode.PHOTO, "📷", "Foto");
        addModeBtn(Mode.SUBS, "💬", "Letrero");
        addModeBtn(Mode.TEXT, "🔤", "Texto");
        addModeBtn(Mode.IMAGE, "🖼️", "Fotos");
        addModeBtn(Mode.CROP, "🔲", "Cuadro");
        addModeBtn(Mode.BG, "🌄", "Fondo");
        addModeBtn(Mode.LAYER, "👥", "Encima");
        addModeBtn(Mode.MUSIC, "🎵", "Música");
        addModeBtn(Mode.AUDIO, "🎧", "A M4A");
        addModeBtn(Mode.EXPORT, "💾", "MP4");
    }

    private void addModeBtn(final Mode m, String icon, String label) {
        TextView t = tv(icon + "\n" + label, 12.5f, TEAL_T, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(2), dp(4), dp(2), dp(4));
        t.setOnClickListener(v -> onModeClick(m));
        modeBtns.put(m, t);
    }

    private void styleBtn(Mode m, boolean active) {
        TextView t = modeBtns.get(m);
        if (t == null) return;
        if (active) {
            t.setBackground(round(TEAL_D, 10));
            t.setTextColor(Color.WHITE);
        } else if (m == Mode.EXPORT || m == Mode.OPEN) {
            t.setBackground(round(TEAL_D, 10));
            t.setTextColor(Color.WHITE);
        } else if (m == Mode.BG || m == Mode.LAYER || m == Mode.JOIN || m == Mode.MUSIC || m == Mode.TEXT) {
            GradientDrawable g = round(AMB_L, 10);
            g.setStroke(dp(1), AMB_B);
            t.setBackground(g);
            t.setTextColor(AMB_T);
        } else {
            t.setBackground(round(TEAL_L, 10));
            t.setTextColor(TEAL_T);
        }
        if (m == Mode.EXPORT && active) {
            GradientDrawable g = round(TEAL_D, 10);
            g.setStroke(dp(3), 0xFFEF9F27);
            t.setBackground(g);
        }
    }

    private static void detach(View v) {
        ViewParent p = v.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(v);
    }

    private void applyLayout() {
        if (panel != null) { panel.removeAllViews(); detach(panel); }
        gridScroll.removeAllViews();
        for (View v : new View[]{videoFrame, titleView, statusView, openBtn, ctxBox, timelineRow, grid, topBar, gridScroll}) detach(v);
        topBar.removeAllViews();
        grid.removeAllViews();
        grid.setColumnCount(landscape ? 2 : 5);
        for (Mode m : order) {
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(landscape ? 52 : 60);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(modeBtns.get(m), lp);
        }
        if (!landscape) {
            topBar.addView(titleView);
            topBar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
            sl.setMarginEnd(dp(6));
            topBar.addView(statusView, sl);
            topBar.addView(openBtn);
            LinearLayout root = vbox();
            root.setBackgroundColor(Color.WHITE);
            root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));
            root.addView(videoFrame, new LinearLayout.LayoutParams(-1, 0, 1f));
            root.addView(ctxBox, new LinearLayout.LayoutParams(-1, -2));
            root.addView(timelineRow, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
            gl.setMargins(dp(4), 0, dp(4), dp(6));
            root.addView(grid, gl);
            timelineRow.setBackgroundColor(Color.WHITE);
            timelineRow.setVisibility(View.VISIBLE);
            timeline.dark = false;
            panel = null;
            menuVisible = true;
            ui.removeCallbacks(autoHide);
            setContentView(root);
        } else {
            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.BLACK);
            root.addView(videoFrame, new FrameLayout.LayoutParams(-1, -1));
            panel = vbox();
            panel.setBackgroundColor(0xEE04342C);
            panel.setPadding(dp(4), dp(4), dp(4), dp(4));
            topBar.addView(openBtn);
            panel.addView(topBar);
            panel.addView(ctxBox);
            gridScroll.addView(grid, new FrameLayout.LayoutParams(-1, -2));
            panel.addView(gridScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
            root.addView(panel, new FrameLayout.LayoutParams(dp(250), -1, Gravity.END));
            FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            tl.rightMargin = dp(250);
            root.addView(timelineRow, tl);
            timelineRow.setBackgroundColor(0xCC000000);
            timeline.dark = true;
            FrameLayout.LayoutParams st = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
            st.setMargins(dp(8), dp(8), 0, 0);
            root.addView(statusView, st);
            setContentView(root);
            showMenu(true);
        }
    }

    private final Runnable autoHide = () -> { if (landscape && !exporting && !micActive) showMenu(false); };

    private void showMenu(boolean v) {
        if (!landscape || panel == null) return;
        menuVisible = v;
        panel.setVisibility(v ? View.VISIBLE : View.GONE);
        timelineRow.setVisibility(v ? View.VISIBLE : View.GONE);
        ui.removeCallbacks(autoHide);
        if (v) ui.postDelayed(autoHide, 4000);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (landscape && menuVisible && ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            ui.removeCallbacks(autoHide);
            ui.postDelayed(autoHide, 4000);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void onVideoTap() {
        long now = android.os.SystemClock.uptimeMillis();
        boolean dbl = now - lastTapT < 350;
        lastTapT = dbl ? 0 : now;
        if (dbl && videoFrame.zoomed()) videoFrame.reset();
        if (landscape) showMenu(!menuVisible);
        else togglePlay();
    }

    private void status(String s) {
        if (s == null || s.isEmpty()) { statusView.setVisibility(View.GONE); return; }
        statusView.setText(s);
        statusView.setVisibility(View.VISIBLE);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static String fmt(long ms) { return TimelineView.fmt(ms); }

    private static String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }

    private static int even(int v) { v = Math.max(2, v); return v % 2 == 0 ? v : v - 1; }

    // ------------------------------------------------------------ herramientas

    private void onModeClick(Mode m) {
        if (m == Mode.OPEN) { pick(REQ_VIDEO, "video/*"); return; }
        if (m == Mode.JOIN) {
            setMode(mode == Mode.JOIN ? Mode.NONE : Mode.JOIN);
            if (mode == Mode.JOIN && Proj.clips.isEmpty() && Proj.uri != null) addClips(Collections.singletonList(Proj.uri));
            return;
        }
        if (Proj.uri == null) { toast("Primero abra un video 📂"); pick(REQ_VIDEO, "video/*"); return; }
        if (m == Mode.MUTE) {
            if (mode != Mode.MUTE) setMode(Mode.MUTE);
            Proj.mute = !Proj.mute;
            applyVolume();
            refreshCtx();
            return;
        }
        setMode(m == mode ? Mode.NONE : m);
    }

    private void setMode(Mode m) {
        Mode prev = mode;
        if (prev == Mode.PHOTO && m != Mode.PHOTO) player.setPlaybackParameters(new PlaybackParameters(Proj.speed));
        if (prev == Mode.CROP && m != Mode.CROP && isFullCrop()) Proj.crop = null;
        mode = m;
        overlay.mode = m;
        if (m == Mode.PHOTO) {
            player.pause();
            player.setPlaybackParameters(new PlaybackParameters(0.25f));
            lastThumbPos = -1;
        }
        if (m == Mode.CROP && Proj.crop == null) { Proj.crop = new RectF(0, 0, 1, 1); overlay.cropAspect = 0f; }
        for (Mode k : order) styleBtn(k, k == m);
        refreshCtx();
        overlay.invalidate();
    }

    private void refreshCtx() {
        ctxRow.removeAllViews();
        thumbRow.setVisibility(mode == Mode.PHOTO ? View.VISIBLE : View.GONE);
        if (Proj.uri == null && mode != Mode.JOIN) {
            add(chip("📂 Abrir video", true, () -> pick(REQ_VIDEO, "video/*")));
            add(chip("🎞 Unir videos", false, () -> onModeClick(Mode.JOIN)));
            final String last = prefs.getString("last", null);
            if (last != null) add(chip("↩ Abrir el último: " + shortName(prefs.getString("lastName", "video")), false,
                    () -> loadVideo(Uri.parse(last), false)));
            return;
        }
        switch (mode) {
            case NONE:
                add(chip("📂 Abrir otro video", false, () -> pick(REQ_VIDEO, "video/*")));
                add(lab(shortName(Proj.name) + " · " + Proj.w + " × " + Proj.h + " · " + fmt(Proj.durMs)));
                add(lab("Escoja una herramienta abajo"));
                break;
            case JOIN:
                ctxJoin();
                break;
            case TEXT:
                ctxText();
                break;
            case MUSIC:
                ctxMusic();
                break;
            case AUDIO:
                add(chip("🗣 Voz · pequeño · ≈ " + audioMb(0), false, () -> exportAudio(0)));
                add(chip("🎵 Música · buena · ≈ " + audioMb(1), true, () -> exportAudio(1)));
                add(lab("Saca el sonido del pedazo " + fmt(Proj.trimStart) + " → " + fmt(Proj.trimEnd)));
                add(lab("Queda en Descargas/MiBarra/ChepeVideo/Audios"));
                break;
            case CUT:
                add(chip("⏮ Inicio aquí", false, () -> {
                    Proj.trimStart = Math.max(0, Math.min(player.getCurrentPosition(), Proj.trimEnd - 100));
                    syncTimeline(); refreshCtx();
                }));
                add(chip("Fin aquí ⏭", false, () -> {
                    Proj.trimEnd = Math.min(Proj.durMs, Math.max(player.getCurrentPosition(), Proj.trimStart + 100));
                    syncTimeline(); refreshCtx();
                }));
                add(lab("Inicio " + fmt(Proj.trimStart) + " · Fin " + fmt(Proj.trimEnd) + " · Dura " + fmt(Proj.trimEnd - Proj.trimStart)));
                add(chip("↺ Todo", false, () -> { Proj.trimStart = 0; Proj.trimEnd = Proj.durMs; syncTimeline(); refreshCtx(); }));
                break;
            case SPEED:
                for (float s : new float[]{2f, 1f, 0.5f, 0.25f}) {
                    final float sp = s;
                    add(chip(speedName(s), Proj.speed == s, () -> {
                        Proj.speed = sp;
                        player.setPlaybackParameters(new PlaybackParameters(sp));
                        refreshCtx();
                    }));
                }
                add(lab("Así queda el video final"));
                break;
            case MUTE:
                add(chip(Proj.mute ? "🔇 Sin sonido" : "🔊 Con sonido", true, () -> {
                    Proj.mute = !Proj.mute;
                    applyVolume();
                    refreshCtx();
                }));
                add(lab("Toque para cambiar"));
                break;
            case PHOTO:
                add(chip("◀ Atrás 1", false, () -> step(-1)));
                add(chip(player.isPlaying() ? "⏸ 0.25x" : "▶ 0.25x", false, this::togglePlay));
                add(chip("Adelante 1 ▶", false, () -> step(1)));
                add(chip("📷 Tomar", true, this::takePhoto));
                add(chip(photoCarta ? "📄 Carta: Sí" : "📄 Carta: No", false, () -> { photoCarta = !photoCarta; refreshCtx(); }));
                break;
            case SUBS: {
                add(chip("en".equals(Proj.lang) ? "Video en: Inglés" : "Video en: Español", false, () -> {
                    Proj.lang = "en".equals(Proj.lang) ? "es" : "en";
                    refreshCtx();
                }));
                add(chip(micActive ? "⏹ Parar" : (subsBusy ? "⏳ Trabajando…" : "✨ Hacer letreros"), true, () -> {
                    if (micActive) finishMic(); else makeSubs();
                }));
                add(chip("🎤 Por micrófono", false, this::startMicSubs));
                add(chip("✏️ Corregir", false, this::editSubs));
                String[] sm = {"👁 Ambos", "👁 Solo original", "🚫 Ocultos"};
                add(chip(sm[Proj.subsMode], false, () -> { Proj.subsMode = (Proj.subsMode + 1) % 3; refreshCtx(); }));
                add(lab(Proj.subs.size() + " letreros"));
                break;
            }
            case IMAGE: {
                final Proj.ImageLayer im = Proj.selImage;
                add(chip("🖼 Agregar foto", im == null, () -> pick(REQ_IMAGE, "image/*")));
                if (im != null) {
                    if (Proj.images.size() > 1) add(chip("▶ Siguiente foto (" + (Proj.images.indexOf(im) + 1) + "/" + Proj.images.size() + ")", false, () -> {
                        int k = (Proj.images.indexOf(im) + 1) % Proj.images.size();
                        Proj.selImage = Proj.images.get(k);
                        player.seekTo(Proj.selImage.startMs);
                        refreshCtx();
                    }));
                    add(chip(im.noBg ? "✂ Sin fondo: Sí" : "✂ Sin fondo: No", false, this::toggleImageBg));
                    add(chip("⏮ Desde aquí", false, () -> {
                        im.startMs = player.getCurrentPosition();
                        if (im.endMs <= im.startMs + 200) im.endMs = Math.min(Proj.durMs, im.startMs + 5000);
                        marks(); refreshCtx();
                    }));
                    add(chip("Hasta aquí ⏭", false, () -> {
                        im.endMs = Math.max(player.getCurrentPosition(), im.startMs + 200);
                        marks(); refreshCtx();
                    }));
                    add(lab(fmt(im.startMs) + " → " + fmt(im.endMs)));
                    add(chip("⏱ Todo el video", false, () -> { im.startMs = 0; im.endMs = Proj.durMs; marks(); refreshCtx(); }));
                    add(chip("🗑 Quitar", false, () -> {
                        Proj.images.remove(im);
                        Proj.selImage = Proj.images.isEmpty() ? null : Proj.images.get(Proj.images.size() - 1);
                        marks(); refreshCtx();
                    }));
                    add(lab("Mueva con un dedo · agrande con dos"));
                } else {
                    add(lab("La foto queda sin fondo: solo la persona"));
                }
                break;
            }
            case CROP: {
                String[] names = {"Todo", "Libre", "1:1", "9:16", "16:9", "4:5"};
                float[] asp = {-1f, 0f, 1f, 9f / 16f, 16f / 9f, 0.8f};
                boolean fullC = isFullCrop();
                for (int i = 0; i < names.length; i++) {
                    final float a = asp[i];
                    boolean act = a < 0 ? fullC : (!fullC && overlay.cropAspect == a);
                    add(chip(names[i], act, () -> setCrop(a)));
                }
                add(lab(cropInfo()));
                break;
            }
            case BG: {
                add(chip(bgGreen ? "🟩 Tela verde" : "🤖 Automático", false, () -> {
                    bgGreen = !bgGreen;
                    Proj.Background bg = Proj.bg;
                    if (bg != null) bg.green = bgGreen;
                    invalidatePreview(); refreshCtx();
                }));
                add(chip("🖼 Foto", false, () -> pick(REQ_BG_IMG, "image/*")));
                add(chip("🎨 Color", false, this::pickColor));
                add(chip("🎬 Video", false, () -> pick(REQ_BG_VID, "video/*")));
                if (Proj.bg != null) {
                    add(chip("🗑 Quitar", false, () -> { Proj.bg = null; invalidatePreview(); refreshCtx(); }));
                    add(lab("Pause el video para ver el fondo exacto"));
                } else {
                    add(lab("Escoja qué poner detrás de la persona"));
                }
                break;
            }
            case LAYER: {
                final Proj.VideoLayer L = Proj.layer;
                add(chip("🎬 Escoger video", L == null, () -> pick(REQ_LAYER, "video/*")));
                add(chip(layerGreen ? "🟩 Tela verde" : "🤖 Automático", false, () -> {
                    layerGreen = !layerGreen;
                    Proj.VideoLayer l2 = Proj.layer;
                    if (l2 != null) { l2.green = layerGreen; makeLayerStill(); }
                    invalidatePreview(); refreshCtx();
                }));
                if (L != null) {
                    add(chip("⏮ Empieza aquí", false, () -> {
                        L.startMs = player.getCurrentPosition();
                        marks(); invalidatePreview(); refreshCtx();
                    }));
                    add(lab(fmt(L.startMs) + " → " + fmt(L.startMs + L.durMs)));
                    add(chip("🗑 Quitar", false, () -> {
                        Proj.layer = null;
                        overlay.layerStill = null;
                        overlay.layerCut = null;
                        marks(); refreshCtx();
                    }));
                    add(lab("Mueva la persona con el dedo"));
                }
                break;
            }
            case EXPORT:
                for (int q = 0; q < 3; q++) {
                    final int qq = q;
                    add(chip(qName(q) + " · ≈ " + estMb(q), q == 0, () -> export(qq)));
                }
                add(lab("Se guarda en Descargas/MiBarra/ChepeVideo"));
                break;
        }
    }

    private static String speedName(float s) {
        if (s == 2f) return "⚡ 2x";
        if (s == 1f) return "Normal";
        if (s == 0.5f) return "🐢 0.5x";
        return "🐌 0.25x";
    }

    private static String qName(int q) {
        return q == 0 ? "💾 Liviano (WhatsApp)" : q == 1 ? "Buena" : "Máxima";
    }

    private String estMb(int q) {
        double secs = (Proj.trimEnd - Proj.trimStart) / 1000.0 / Math.max(0.1, Proj.speed);
        int vb = q == 0 ? 1_200_000 : q == 1 ? 2_500_000 : 6_000_000;
        double mb = secs * (vb + (Proj.mute ? 0 : 128_000)) / 8.0 / 1_000_000.0;
        return String.format(Locale.US, "%.1f MB", mb);
    }

    private void syncTimeline() {
        timeline.durMs = Proj.durMs;
        timeline.startMs = Proj.trimStart;
        timeline.endMs = Proj.trimEnd;
        timeline.invalidate();
    }

    private void marks() {
        timeline.ranges.clear();
        Proj.VideoLayer L = Proj.layer;
        if (L != null) timeline.ranges.add(new long[]{L.startMs, L.startMs + L.durMs, 0xFFEF9F27});
        for (Proj.ImageLayer im : Proj.images) timeline.ranges.add(new long[]{im.startMs, im.endMs, 0xFFD4537E});
        for (Proj.TextLayer t : Proj.texts) timeline.ranges.add(new long[]{t.startMs, t.endMs, 0xFF7F77DD});
        timeline.invalidate();
    }

    private void togglePlay() {
        if (Proj.uri == null) { pick(REQ_VIDEO, "video/*"); return; }
        if (player.isPlaying()) { player.pause(); return; }
        long p = player.getCurrentPosition();
        if (p >= Proj.trimEnd - 60 || p < Proj.trimStart || player.getPlaybackState() == Player.STATE_ENDED)
            player.seekTo(Proj.trimStart);
        player.play();
    }

    private void onTick() {
        keepScreen(exporting || subsBusy || micActive || (Proj.uri != null && player.isPlaying()));
        if (Proj.uri == null) return;
        long pos = player.getCurrentPosition();
        boolean playing = player.isPlaying();
        if (playing && !micActive) {
            if (pos >= Proj.trimEnd) { player.pause(); player.seekTo(Proj.trimStart); pos = Proj.trimStart; playing = false; }
            else if (pos < Proj.trimStart - 150) player.seekTo(Proj.trimStart);
        }
        if (micActive && (pos >= Proj.trimEnd || player.getPlaybackState() == Player.STATE_ENDED)) finishMic();
        syncMusic(pos, playing);
        timeline.setPos(pos);
        overlay.posMs = pos;
        overlay.playing = playing;
        overlay.invalidate();
        if (!playing) {
            maybePreview(pos);
            if (mode == Mode.PHOTO && pos != lastThumbPos) { lastThumbPos = pos; loadThumbs(pos); }
        }
    }

    // ------------------------------------------------------------ vista previa en pausa

    private void invalidatePreview() {
        overlay.compositeTime = -1;
        overlay.layerCutTime = -1;
        overlay.invalidate();
    }

    private void maybePreview(final long pos) {
        if (previewBusy) return;
        final boolean needBg = Proj.bg != null && overlay.compositeTime != pos;
        Proj.VideoLayer L = Proj.layer;
        final boolean needLayer = L != null && pos >= L.startMs && pos < L.startMs + L.durMs && overlay.layerCutTime != pos;
        if (!needBg && !needLayer) return;
        previewBusy = true;
        if (previewComp == null) previewComp = new Compositor(this, false);
        final Compositor comp = previewComp;
        float sc = Math.min(1f, 640f / Math.max(1, Math.max(Proj.w, Proj.h)));
        final int pw = Math.max(2, Math.round(Proj.w * sc)), ph = Math.max(2, Math.round(Proj.h * sc));
        exec.execute(() -> {
            Bitmap bgB = null, lc = null;
            if (needBg) try { bgB = comp.composeBg(pw, ph, pos); } catch (Throwable ignored) {}
            if (needLayer) try { lc = comp.layerCut(pos, 480); } catch (Throwable ignored) {}
            final Bitmap fb = bgB, fl = lc;
            ui.post(() -> {
                previewBusy = false;
                if (needBg) { overlay.composite = fb; overlay.compositeTime = pos; }
                if (needLayer) { overlay.layerCut = fl; overlay.layerCutTime = pos; }
                overlay.invalidate();
            });
        });
    }

    // ------------------------------------------------------------ abrir archivos

    private void pick(int req, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType(type);
            try { startActivityForResult(Intent.createChooser(g, "Escoger"), req); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_JOIN) {
            if (res != RESULT_OK || data == null) return;
            List<Uri> us = new ArrayList<>();
            ClipData cd = data.getClipData();
            if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) { Uri x = cd.getItemAt(k).getUri(); if (x != null) us.add(x); }
            else if (data.getData() != null) us.add(data.getData());
            for (Uri x : us) try { getContentResolver().takePersistableUriPermission(x, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            addClips(us);
            return;
        }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        switch (req) {
            case REQ_VIDEO: loadVideo(u); break;
            case REQ_IMAGE: loadImageLayer(u); break;
            case REQ_LAYER: loadVideoLayer(u); break;
            case REQ_BG_IMG: loadBgImage(u); break;
            case REQ_BG_VID: loadBgVideo(u); break;
            case REQ_MUSIC: loadMusic(u); break;
        }
    }

    private void loadVideo(final Uri u) { loadVideo(u, false); }

    private void loadVideo(final Uri u, final boolean keep) {
        status("Abriendo video…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                if (micActive) finishMic();
                Proj.reset(u, fi, keep);
                Proj.name = nameOf(u);
                prefs.edit().putString("last", u.toString()).putString("lastName", Proj.name).apply();
                overlay.vw = fi.w;
                overlay.vh = fi.h;
                overlay.composite = null;
                overlay.layerCut = null;
                overlay.layerStill = null;
                invalidatePreview();
                player.setMediaItem(MediaItem.fromUri(u));
                player.prepare();
                applyVolume();
                player.setPlaybackParameters(new PlaybackParameters(1f));
                syncTimeline();
                marks();
                setMode(Mode.NONE);
                toast("Video listo · " + fmt(fi.durMs));
            });
        });
    }

    private void loadImageLayer(final Uri u) {
        status("✂ Quitando el fondo de la foto…");
        final long pos = player.getCurrentPosition();
        exec.execute(() -> {
            Bitmap orig = Seg.load(this, u, 1600);
            Bitmap cut = null;
            String note = null;
            if (orig != null) {
                try {
                    if (Seg.hasTransparency(orig)) {
                        cut = Seg.trim(orig);
                    } else {
                        if (imgSeg == null) imgSeg = new Seg(false);
                        Bitmap c = Seg.trim(imgSeg.cutout(orig, false));
                        if (c != null && (long) c.getWidth() * c.getHeight() > (long) orig.getWidth() * orig.getHeight() / 50) cut = c;
                        else note = "No encontré una persona en la foto: queda con fondo";
                    }
                } catch (Exception e) {
                    note = "No se pudo quitar el fondo: queda con fondo";
                }
            }
            final Bitmap fo = orig, fc = cut;
            final String fn = note;
            ui.post(() -> {
                status(null);
                if (fo == null) { toast("No pude abrir la foto"); return; }
                long st = pos, en = Math.min(Proj.durMs, pos + 5000);
                if (en - st < 1000) { st = Math.max(0, Proj.durMs - 5000); en = Proj.durMs; }
                Proj.ImageLayer nl = new Proj.ImageLayer(fc != null ? fc : fo, fo, fc != null, st, en);
                Proj.images.add(nl);
                Proj.selImage = nl;
                if (mode != Mode.IMAGE) setMode(Mode.IMAGE);
                if (fn != null) toast(fn);
                marks();
                refreshCtx();
            });
        });
    }

    private void toggleImageBg() {
        final Proj.ImageLayer im = Proj.selImage;
        if (im == null) return;
        if (im.noBg) { im.bmp = im.original; im.noBg = false; refreshCtx(); return; }
        status("✂ Quitando el fondo…");
        exec.execute(() -> {
            Bitmap c = null;
            try {
                if (imgSeg == null) imgSeg = new Seg(false);
                c = Seg.trim(imgSeg.cutout(im.original, false));
            } catch (Exception ignored) {}
            final Bitmap fc = c;
            ui.post(() -> {
                status(null);
                if (fc != null) { im.bmp = fc; im.noBg = true; } else toast("No se pudo quitar el fondo");
                refreshCtx();
            });
        });
    }

    private Bitmap stillOf(Uri u, boolean green) {
        MediaMetadataRetriever r = null;
        try {
            r = Frames.open(this, u);
            Bitmap f = Frames.grab(r, 0, 480, 480);
            if (f == null) return null;
            if (imgSeg == null) imgSeg = new Seg(false);
            return imgSeg.cutout(f, green);
        } catch (Exception e) {
            return null;
        } finally {
            if (r != null) try { r.release(); } catch (Exception ignored) {}
        }
    }

    private void loadVideoLayer(final Uri u) {
        status("👥 Preparando el video de encima…");
        final long pos = player.getCurrentPosition();
        final boolean g = layerGreen;
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Bitmap still = inf == null ? null : stillOf(u, g);
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                long st = Math.max(0, Math.min(pos, Proj.durMs - 500));
                Proj.layer = new Proj.VideoLayer(u, fi.durMs, g, st, (float) fi.h / fi.w);
                overlay.layerStill = still;
                invalidatePreview();
                marks();
                refreshCtx();
            });
        });
    }

    private void makeLayerStill() {
        final Proj.VideoLayer L = Proj.layer;
        if (L == null) return;
        exec.execute(() -> {
            final Bitmap s = stillOf(L.uri, L.green);
            ui.post(() -> { overlay.layerStill = s; overlay.invalidate(); });
        });
    }

    private void loadBgImage(final Uri u) {
        status("🌄 Cargando el fondo…");
        exec.execute(() -> {
            final Bitmap b = Seg.load(this, u, 1920);
            ui.post(() -> {
                status(null);
                if (b == null) { toast("No pude abrir la foto"); return; }
                Proj.bg = new Proj.Background(1, 0, b, null, bgGreen, 0);
                invalidatePreview();
                refreshCtx();
            });
        });
    }

    private void loadBgVideo(final Uri u) {
        status("🌄 Cargando el video de fondo…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0) { toast("No pude abrir ese video"); return; }
                Proj.bg = new Proj.Background(2, 0, null, u, bgGreen, fi.durMs);
                invalidatePreview();
                refreshCtx();
            });
        });
    }

    private void pickColor() {
        final String[] names = {"⬜ Blanco", "⬛ Negro", "🟩 Verde", "🟦 Azul", "🟥 Rojo", "🟨 Amarillo", "◻️ Gris", "🟫 Café"};
        final int[] cols = {Color.WHITE, Color.BLACK, 0xFF3B6D11, 0xFF185FA5, 0xFFA32D2D, 0xFFEF9F27, 0xFF888780, 0xFF633806};
        new AlertDialog.Builder(this).setTitle("Color de fondo").setItems(names, (d, i) -> {
            Proj.bg = new Proj.Background(0, cols[i], null, null, bgGreen, 0);
            invalidatePreview();
            refreshCtx();
        }).show();
    }

    // ------------------------------------------------------------ cuadro (recorte)

    private boolean isFullCrop() {
        RectF c = Proj.crop;
        return c == null || (c.left < 0.002f && c.top < 0.002f && c.right > 0.998f && c.bottom > 0.998f);
    }

    private void setCrop(float a) {
        if (a < 0f) {
            Proj.crop = new RectF(0, 0, 1, 1);
            overlay.cropAspect = 0f;
        } else {
            overlay.cropAspect = a;
            if (a > 0f) {
                float vw = Proj.w, vh = Proj.h;
                float w = vw, h = w / a;
                if (h > vh) { h = vh; w = h * a; }
                float nw = w / vw, nh = h / vh;
                Proj.crop = new RectF((1 - nw) / 2f, (1 - nh) / 2f, (1 + nw) / 2f, (1 + nh) / 2f);
            } else if (isFullCrop()) {
                Proj.crop = new RectF(0.1f, 0.1f, 0.9f, 0.9f);
            }
        }
        overlay.invalidate();
        refreshCtx();
    }

    private String cropInfo() {
        RectF c = Proj.crop;
        if (c == null) return "Video completo";
        return "Queda de " + Math.round(Proj.w * c.width()) + " × " + Math.round(Proj.h * c.height()) + " · arrastre las esquinas";
    }

    // ------------------------------------------------------------ foto cuadro a cuadro

    private void step(int n) {
        player.pause();
        float fms = 1000f / Math.max(1f, Proj.fps);
        long t = player.getCurrentPosition() + Math.round(n * fms);
        player.seekTo(Math.max(0, Math.min(Proj.durMs, t)));
    }

    private void loadThumbs(final long pos) {
        final Uri u = Proj.uri;
        final float fms = 1000f / Math.max(1f, Proj.fps);
        exec.execute(() -> {
            try {
                if (thumbRet == null || !u.equals(thumbUri)) {
                    if (thumbRet != null) try { thumbRet.release(); } catch (Exception ignored) {}
                    thumbRet = Frames.open(this, u);
                    thumbUri = u;
                }
                final Bitmap[] bs = new Bitmap[5];
                for (int i = 0; i < 5; i++) bs[i] = Frames.grab(thumbRet, pos + Math.round((i - 2) * fms), 200, 200);
                ui.post(() -> { for (int i = 0; i < 5; i++) thumbs[i].setImageBitmap(bs[i]); });
            } catch (Exception ignored) {}
        });
    }

    private void takePhoto() {
        final long pos = player.getCurrentPosition();
        final Uri u = Proj.uri;
        final boolean carta = photoCarta;
        status("📷 Guardando foto…");
        exec.execute(() -> {
            String msg;
            MediaMetadataRetriever r = null;
            try {
                r = Frames.open(this, u);
                Bitmap b = Frames.argb(r.getFrameAtTime(pos * 1000L, MediaMetadataRetriever.OPTION_CLOSEST));
                if (b == null) throw new Exception("no salió el cuadro");
                String name = "foto_" + stamp();
                Store.saveJpg(this, b, "Fotos", name + ".jpg");
                if (carta) Store.saveJpg(this, Seg.carta(b), "Fotos", name + "_carta.jpg");
                msg = "📷 Foto guardada en Descargas/MiBarra/ChepeVideo/Fotos";
            } catch (Exception e) {
                msg = "No se pudo sacar la foto: " + e.getMessage();
            } finally {
                if (r != null) try { r.release(); } catch (Exception ignored) {}
            }
            final String m2 = msg;
            ui.post(() -> { status(null); toast(m2); });
        });
    }

    // ------------------------------------------------------------ letreros

    private String langTag() { return "en".equals(Proj.lang) ? "en-US" : "es-CO"; }

    private void needMic(Runnable r) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) r.run();
        else {
            pendingMic = r;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_MIC) return;
        Runnable r = pendingMic;
        pendingMic = null;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && r != null) r.run();
        else toast("Sin permiso del micrófono no se pueden hacer los letreros");
    }

    private void makeSubs() {
        if (subsBusy) { toast("Ya estoy haciendo los letreros"); return; }
        if (Build.VERSION.SDK_INT >= 33) needMic(this::subsFromFile);
        else askMicMode("En este celular los letreros se hacen así: el video suena en voz alta (yo subo el volumen solo) y el celular lo escucha. No hable mientras tanto. ¿Empezamos?");
    }

    private void askMicMode(String msg) {
        new AlertDialog.Builder(this).setTitle("🎤 Letreros por micrófono").setMessage(msg)
                .setPositiveButton("Empezar", (d, w) -> startMicSubs())
                .setNegativeButton("Cancelar", null).show();
    }

    private void subsFromFile() {
        final Uri u = Proj.uri;
        final long s0 = Proj.trimStart, s1 = Math.min(Proj.trimEnd, Proj.trimStart + 15 * 60_000L);
        final String lang = langTag(), src = Proj.lang;
        subsBusy = true;
        status("💬 Escuchando el video…");
        refreshCtx();
        new Thread(() -> {
            String err = null, note = null;
            List<Proj.Sub> out = new ArrayList<>();
            try {
                short[] pcm = AudioPcm.decode16k(this, u, s0, s1);
                List<int[]> segs = AudioPcm.segments(pcm);
                int fails = 0;
                for (int i = 0; i < segs.size(); i++) {
                    final int n = i + 1, tot = segs.size();
                    ui.post(() -> status("💬 Letreros " + n + " de " + tot + "…"));
                    int[] sg = segs.get(i);
                    String r = Recog.fromPcm(this, ui, pcm, sg[0], sg[1], lang);
                    if (r == null) {
                        fails++;
                        if (out.isEmpty() && fails >= 2) { err = "mic"; break; }
                        continue;
                    }
                    if (!r.trim().isEmpty())
                        out.add(new Proj.Sub(s0 + sg[0] * 1000L / 16000L, s0 + sg[1] * 1000L / 16000L, r.trim(), ""));
                }
                if (err == null && out.isEmpty()) err = segs.isEmpty() ? "No escuché voces en el video" : "mic";
                if (err == null) {
                    List<Proj.Sub> sp = splitSubs(out);
                    out.clear();
                    out.addAll(sp);
                    ui.post(() -> status("🌐 Traduciendo…"));
                    try { translate(out, src); } catch (Exception e) { note = "Letreros listos, pero sin traducción (revise el internet)"; }
                }
            } catch (Exception e) {
                err = "No se pudieron hacer los letreros: " + e.getMessage();
            }
            final String fe = err, fn = note;
            final List<Proj.Sub> fo = out;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                if (fe == null) {
                    Proj.subs.clear();
                    Proj.subs.addAll(fo);
                    toast(fn != null ? fn : "💬 " + fo.size() + " letreros listos");
                } else if ("mic".equals(fe)) {
                    askMicMode("Este celular no deja leer el sonido directo del archivo. Lo hacemos por micrófono: el video suena duro (yo subo el volumen solo) y el celular escucha. ¿Empezamos?");
                } else {
                    toast(fe);
                }
                refreshCtx();
            });
        }).start();
    }

    /** Traduce (se llama desde un hilo de trabajo). */
    private void translate(List<Proj.Sub> list, String src) throws Exception {
        if (list.isEmpty()) return;
        boolean en = "en".equals(src);
        TranslatorOptions o = new TranslatorOptions.Builder()
                .setSourceLanguage(en ? TranslateLanguage.ENGLISH : TranslateLanguage.SPANISH)
                .setTargetLanguage(en ? TranslateLanguage.SPANISH : TranslateLanguage.ENGLISH)
                .build();
        Translator t = Translation.getClient(o);
        try {
            Tasks.await(t.downloadModelIfNeeded(), 180, TimeUnit.SECONDS);
            for (Proj.Sub s : list) {
                if (s.text == null || s.text.trim().isEmpty()) continue;
                s.trans = Tasks.await(t.translate(s.text), 30, TimeUnit.SECONDS);
            }
        } finally {
            t.close();
        }
    }

    private void startMicSubs() {
        needMic(() -> {
            if (micActive) return;
            if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Este celular no tiene reconocimiento de voz"); return; }
            Proj.subs.clear();
            micActive = true;
            player.setVolume(1f);
            maxVolume();
            player.setPlaybackParameters(new PlaybackParameters(1f));
            player.seekTo(Proj.trimStart);
            player.play();
            micRec = SpeechRecognizer.createSpeechRecognizer(this);
            micRec.setRecognitionListener(micListener);
            micListen();
            status("🎤 Escuchando… no hable mientras tanto");
            if (mode != Mode.SUBS) setMode(Mode.SUBS); else refreshCtx();
        });
    }

    private void micListen() {
        if (!micActive || micRec == null) return;
        micSegStart = player.getCurrentPosition();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try { micRec.startListening(i); } catch (Exception e) { ui.postDelayed(this::micListen, 400); }
    }

    private final RecognitionListener micListener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle p) {}
        @Override public void onBeginningOfSpeech() { micSegStart = Math.max(Proj.trimStart, player.getCurrentPosition() - 300); }
        @Override public void onRmsChanged(float v) {}
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onError(int e) { if (micActive) ui.postDelayed(MainActivity.this::micListen, 250); }
        @Override public void onResults(Bundle b) {
            ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (l != null && !l.isEmpty() && l.get(0) != null && !l.get(0).trim().isEmpty()) {
                long end = player.getCurrentPosition();
                Proj.subs.add(new Proj.Sub(micSegStart, Math.max(end, micSegStart + 1200), l.get(0).trim(), ""));
                if (mode == Mode.SUBS) refreshCtx();
            }
            if (micActive) micListen();
        }
        @Override public void onPartialResults(Bundle b) {}
        @Override public void onEvent(int t, Bundle b) {}
    };

    private void finishMic() {
        if (!micActive) return;
        micActive = false;
        try { if (micRec != null) { micRec.cancel(); micRec.destroy(); } } catch (Exception ignored) {}
        micRec = null;
        player.pause();
        restoreVolume();
        applyVolume();
        player.setPlaybackParameters(new PlaybackParameters(mode == Mode.PHOTO ? 0.25f : Proj.speed));
        final List<Proj.Sub> list = splitSubs(new ArrayList<>(Proj.subs));
        Proj.subs.clear();
        Proj.subs.addAll(list);
        final String src = Proj.lang;
        if (list.isEmpty()) { status(null); toast("No escuché voces. Suba el volumen e intente otra vez"); refreshCtx(); return; }
        status("🌐 Traduciendo…");
        subsBusy = true;
        refreshCtx();
        new Thread(() -> {
            String note = null;
            try { translate(list, src); } catch (Exception e) { note = "Letreros listos, pero sin traducción (revise el internet)"; }
            final String fn = note;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                toast(fn != null ? fn : "💬 " + list.size() + " letreros listos");
                refreshCtx();
            });
        }).start();
    }

    private void editSubs() {
        final long pos = player.getCurrentPosition();
        final LinearLayout box = vbox();
        box.setPadding(dp(14), dp(6), dp(14), dp(6));
        final List<Object[]> rows = new ArrayList<>();
        TextView addB = chip("➕ Agregar letrero en " + fmt(pos), false, null);
        box.addView(addB);
        if (Proj.subs.isEmpty()) box.addView(tv("Todavía no hay letreros. Use ✨ Hacer letreros o agregue uno aquí.", 14, Color.BLACK, false));
        for (Proj.Sub s : Proj.subs) addSubRow(box, rows, s);
        addB.setOnClickListener(v -> addSubRow(box, rows, new Proj.Sub(pos, pos + 3000, "", "")));
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this).setTitle("✏️ Corregir letreros").setView(sv)
                .setPositiveButton("Guardar", (d, w) -> applySubRows(rows, false))
                .setNeutralButton("Guardar y traducir", (d, w) -> applySubRows(rows, true))
                .setNegativeButton("Cancelar", null).show();
    }

    private void addSubRow(LinearLayout box, List<Object[]> rows, Proj.Sub s) {
        TextView t = tv("⏱ " + fmt(s.startMs) + " – " + fmt(s.endMs), 13, TEAL_T, true);
        t.setPadding(0, dp(10), 0, 0);
        EditText e1 = new EditText(this);
        e1.setText(s.text);
        e1.setTextColor(Color.BLACK);
        e1.setTextSize(16);
        e1.setHint("Lo que se dice");
        EditText e2 = new EditText(this);
        e2.setText(s.trans);
        e2.setTextColor(AMB_T);
        e2.setTextSize(16);
        e2.setHint("Traducción");
        box.addView(t);
        box.addView(e1);
        box.addView(e2);
        rows.add(new Object[]{s, e1, e2});
    }

    private void applySubRows(List<Object[]> rows, boolean retranslate) {
        final List<Proj.Sub> list = new ArrayList<>();
        for (Object[] r : rows) {
            Proj.Sub s = (Proj.Sub) r[0];
            s.text = ((EditText) r[1]).getText().toString().trim();
            s.trans = ((EditText) r[2]).getText().toString().trim();
            if (!s.text.isEmpty() || !s.trans.isEmpty()) list.add(s);
        }
        Collections.sort(list, (a, b) -> Long.compare(a.startMs, b.startMs));
        Proj.subs.clear();
        Proj.subs.addAll(list);
        refreshCtx();
        if (!retranslate) return;
        final String src = Proj.lang;
        status("🌐 Traduciendo…");
        new Thread(() -> {
            String note = null;
            try { translate(list, src); } catch (Exception e) { note = "No se pudo traducir (revise el internet)"; }
            final String fn = note;
            ui.post(() -> { status(null); toast(fn != null ? fn : "Traducción lista"); refreshCtx(); });
        }).start();
    }

    // ------------------------------------------------------------ trabajos largos (guardar, unir, audio)

    private interface Done { void run(File out); }

    private void askNotif() {
        if (askedNotif || Build.VERSION.SDK_INT < 33) return;
        askedNotif = true;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            try { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF); } catch (Exception ignored) {}
    }

    private Transformer.Builder baseTransformer(int videoBitrate) {
        return new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(new DefaultEncoderFactory.Builder(this)
                        .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
                        .setEnableFallback(true)
                        .build());
    }

    /** Arranca un trabajo con el Transformer; muestra el avance y mantiene la app despierta. */
    private void runJob(Transformer.Builder b, Composition comp, final File out, final String what,
                        final Runnable cleanup, final Done done) {
        if (exporting) { toast("Ya estoy trabajando, espere que termine"); if (cleanup != null) cleanup.run(); return; }
        if (micActive) finishMic();
        player.pause();
        if (out.exists()) out.delete();
        final Transformer tr;
        try {
            tr = b.addListener(new Transformer.Listener() {
                @Override public void onCompleted(Composition c, ExportResult r) { jobEnd(out, null, done); }
                @Override public void onError(Composition c, ExportResult r, ExportException e) { jobEnd(out, e, done); }
            }).build();
        } catch (Exception e) {
            if (cleanup != null) cleanup.run();
            toast("No se pudo empezar: " + e.getMessage());
            return;
        }
        exporting = true;
        jobCleanup = cleanup;
        askNotif();
        TrabajoService.start(this, what);
        status(what + " 0 %");
        try {
            tr.start(comp, out.getAbsolutePath());
        } catch (Exception e) {
            jobEnd(out, e, done);
            return;
        }
        final ProgressHolder ph = new ProgressHolder();
        ui.post(new Runnable() {
            @Override public void run() {
                if (!exporting) return;
                try {
                    if (tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) status(what + " " + ph.progress + " %");
                } catch (Exception ignored) {}
                ui.postDelayed(this, 500);
            }
        });
    }

    private void jobEnd(final File out, Exception e, Done done) {
        if (!exporting) return;
        exporting = false;
        final Runnable c = jobCleanup;
        jobCleanup = null;
        if (c != null) new Thread(c).start();
        TrabajoService.stop(this);
        if (e != null) {
            status(null);
            out.delete();
            String code = (e instanceof ExportException) ? ((ExportException) e).getErrorCodeName() : String.valueOf(e.getMessage());
            new AlertDialog.Builder(this).setTitle("No se pudo terminar")
                    .setMessage("Error: " + code + "\n\nMándeme un pantallazo de este letrero para arreglarlo.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        done.run(out);
    }

    /** Pasa el archivo terminado a Descargas/MiBarra/ChepeVideo/(sub) y luego llama a after. */
    private interface Saved { void run(Uri u, String name, long size); }

    private void toDownloads(final File out, final String sub, final String name, final String mime, final Saved after) {
        status("💾 Pasando a Descargas…");
        exec.execute(() -> {
            Uri saved = null;
            String err = null;
            try { saved = Store.saveFile(this, out, sub, name, mime); } catch (Exception ex) { err = ex.getMessage(); }
            final long size = out.length();
            out.delete();
            final Uri fs = saved;
            final String fe = err;
            ui.post(() -> {
                status(null);
                if (fs == null) { toast("No se pudo pasar a Descargas: " + fe); return; }
                after.run(fs, name, size);
            });
        });
    }

    // ------------------------------------------------------------ guardar MP4

    private long outDurMs() { return (long) ((Proj.trimEnd - Proj.trimStart) / Math.max(0.05f, Proj.speed)); }

    private EditedMediaItemSequence musicSeq(Proj.Music mu, long outMs) {
        boolean loop = mu.durMs > 0 && mu.durMs < outMs;
        MediaItem.Builder mb = new MediaItem.Builder().setUri(mu.uri);
        if (!loop) mb.setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder().setEndPositionMs(outMs).build());
        EditedMediaItem me = new EditedMediaItem.Builder(mb.build())
                .setRemoveVideo(true)
                .setEffects(new Effects(
                        ImmutableList.<AudioProcessor>of(new Gain(mu.vol, mu.soft ? 1500 : 0, mu.soft ? 2500 : 0, outMs, false)),
                        ImmutableList.<Effect>of()))
                .build();
        return new EditedMediaItemSequence(ImmutableList.of(me), loop);
    }

    private void export(int q) {
        if (exporting) { toast("Ya estoy guardando, espere"); return; }
        final Uri u = Proj.uri;
        if (u == null) return;
        RectF crop = isFullCrop() ? null : Proj.crop;
        int srcW = Proj.w, srcH = Proj.h;
        float cw = srcW * (crop != null ? crop.width() : 1f), ch = srcH * (crop != null ? crop.height() : 1f);
        int target = q == 0 ? 480 : q == 1 ? 720 : 1080;
        int bitrate = q == 0 ? 1_200_000 : q == 1 ? 2_500_000 : 6_000_000;
        float sc = Math.min(1f, target / Math.max(1f, Math.min(cw, ch)));
        int outW = even(Math.round(cw * sc)), outH = even(Math.round(ch * sc));
        final Proj.Music mu = Proj.music;

        MediaItem item = new MediaItem.Builder().setUri(u)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(Proj.trimStart).setEndPositionMs(Proj.trimEnd).build())
                .build();
        List<Effect> fx = new ArrayList<>();
        boolean subsOn = !Proj.subs.isEmpty() && Proj.subsMode != 2;
        boolean dynamic = Proj.bg != null || Proj.layer != null;
        final ExportOverlay ov = (dynamic || !Proj.images.isEmpty() || !Proj.texts.isEmpty() || subsOn)
                ? new ExportOverlay(this, srcW, srcH, Proj.trimStart, dynamic) : null;
        if (ov != null) fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(ov)));
        if (crop != null) fx.add(new Crop(crop.left * 2f - 1f, crop.right * 2f - 1f, 1f - crop.bottom * 2f, 1f - crop.top * 2f));
        if (Proj.speed != 1f) fx.add(new SpeedChangeEffect(Proj.speed));
        fx.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT));
        List<AudioProcessor> ap = new ArrayList<>();
        if (Proj.speed != 1f && !(Proj.mute && mu == null)) {
            SonicAudioProcessor son = new SonicAudioProcessor();
            son.setSpeed(Proj.speed);
            ap.add(son);
        }
        if (mu != null) {
            float vv = Proj.mute ? 0f : mu.videoVol;
            if (vv != 1f) ap.add(new Gain(vv, 0, 0, 0, false));
        }
        EditedMediaItem edited = new EditedMediaItem.Builder(item)
                .setRemoveAudio(Proj.mute && mu == null)
                .setEffects(new Effects(ap, fx))
                .build();
        List<EditedMediaItemSequence> seqs = new ArrayList<>();
        seqs.add(new EditedMediaItemSequence(ImmutableList.of(edited)));
        if (mu != null) seqs.add(musicSeq(mu, outDurMs()));
        Composition.Builder cb = new Composition.Builder(ImmutableList.copyOf(seqs));
        if (mu != null) cb.experimentalSetForceAudioTrack(true);

        final File out = new File(getCacheDir(), "chepe_export.mp4");
        runJob(baseTransformer(bitrate), cb.build(), out, "💾 Guardando video…",
                ov == null ? null : ov::release,
                f -> {
                    final String name = "ChepeVideo_" + stamp() + ".mp4";
                    toDownloads(f, "", name, "video/mp4", (uu, nm, size) -> showSaved(uu, nm, size, "video/mp4", "✅ Video listo", ""));
                });
    }

    private void showSaved(final Uri u, String name, long size, final String mime, String title, String sub) {
        String mb = String.format(Locale.US, "%.1f MB", size / 1_000_000.0);
        new AlertDialog.Builder(this).setTitle(title)
                .setMessage("Quedó en Descargas/MiBarra/ChepeVideo" + (sub.isEmpty() ? "" : "/" + sub) + "\n\n" + name + "\nPesa " + mb)
                .setPositiveButton("📤 Compartir", (d, w) -> {
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType(mime);
                    s.putExtra(Intent.EXTRA_STREAM, u);
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(s, "Compartir")); } catch (Exception ignored) {}
                })
                .setNeutralButton("▶ Ver", (d, w) -> {
                    Intent v = new Intent(Intent.ACTION_VIEW);
                    v.setDataAndType(u, mime);
                    v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(v); } catch (Exception ignored) {}
                })
                .setNegativeButton("OK", null).show();
    }

    // ------------------------------------------------------------ video a audio M4A

    private String audioMb(int q) {
        double secs = outDurMs() / 1000.0;
        int kbps = q == 0 ? 48 : 96;
        return String.format(Locale.US, "%.1f MB", secs * kbps / 8.0 / 1000.0);
    }

    private void exportAudio(final int q) {
        final Uri u = Proj.uri;
        if (u == null) return;
        MediaItem item = new MediaItem.Builder().setUri(u)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(Proj.trimStart).setEndPositionMs(Proj.trimEnd).build())
                .build();
        List<AudioProcessor> ap = new ArrayList<>();
        if (q == 0) ap.add(new Gain(1f, 0, 0, 0, true));
        if (Proj.speed != 1f || q == 0) {
            SonicAudioProcessor son = new SonicAudioProcessor();
            if (Proj.speed != 1f) son.setSpeed(Proj.speed);
            if (q == 0) son.setOutputSampleRateHz(24000);
            ap.add(son);
        }
        EditedMediaItem edited = new EditedMediaItem.Builder(item)
                .setRemoveVideo(true)
                .setEffects(new Effects(ap, ImmutableList.<Effect>of()))
                .build();
        Composition comp = new Composition.Builder(ImmutableList.of(new EditedMediaItemSequence(ImmutableList.of(edited)))).build();
        Transformer.Builder b = new Transformer.Builder(this)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(new AudioRate(new DefaultEncoderFactory.Builder(this).setEnableFallback(true).build(),
                        q == 0 ? 48_000 : 96_000));
        final File out = new File(getCacheDir(), "chepe_audio.m4a");
        runJob(b, comp, out, "🎧 Sacando el audio…", null, f -> {
            String base = Proj.name == null || Proj.name.isEmpty() ? "audio" : Proj.name.replaceAll("\\.[^.]*$", "");
            base = base.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ _-]", "").trim();
            if (base.length() > 30) base = base.substring(0, 30);
            final String name = (base.isEmpty() ? "audio" : base) + "_" + stamp() + ".m4a";
            toDownloads(f, "Audios", name, "audio/mp4", (uu, nm, size) -> showSaved(uu, nm, size, "audio/mp4", "✅ Audio listo", "Audios"));
        });
    }

    // ------------------------------------------------------------ unir videos

    private void pickMulti() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQ_JOIN); }
        catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType("video/*");
            g.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try { startActivityForResult(Intent.createChooser(g, "Escoger videos"), REQ_JOIN); } catch (Exception ignored) {}
        }
    }

    private void addClips(final List<Uri> us) {
        if (us.isEmpty()) return;
        status("🎞 Revisando " + us.size() + (us.size() == 1 ? " video…" : " videos…"));
        exec.execute(() -> {
            final List<Proj.Clip> got = new ArrayList<>();
            int bad = 0;
            for (Uri x : us) {
                Frames.VInfo fi = null;
                try { fi = Frames.info(this, x); } catch (Exception ignored) {}
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { bad++; continue; }
                Proj.Clip c = new Proj.Clip(x, nameOf(x), fi.durMs, fi.w, fi.h, Proj.joinTrans);
                MediaMetadataRetriever r = null;
                try {
                    r = Frames.open(this, x);
                    c.thumb = Frames.grab(r, Math.min(800, fi.durMs / 2), 160, 160);
                } catch (Exception ignored) {
                } finally {
                    if (r != null) try { r.release(); } catch (Exception ignored) {}
                }
                got.add(c);
            }
            final int fb = bad;
            ui.post(() -> {
                status(null);
                Proj.clips.addAll(got);
                if (fb > 0) toast(fb == 1 ? "Un video no se pudo abrir" : fb + " videos no se pudieron abrir");
                if (mode != Mode.JOIN) setMode(Mode.JOIN); else refreshCtx();
            });
        });
    }

    private long joinTotal() {
        long t = 0;
        for (Proj.Clip c : Proj.clips) t += c.durMs;
        return t;
    }

    private void ctxJoin() {
        final int n = Proj.clips.size();
        add(chip("➕ Agregar videos", n < 2, this::pickMulti));
        for (int i = 0; i < n; i++) {
            final int idx = i;
            Proj.Clip c = Proj.clips.get(i);
            LinearLayout cc = hbox();
            cc.setBackground(round(AMB_L, 10));
            cc.setPadding(dp(4), dp(3), dp(10), dp(3));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (c.thumb != null) iv.setImageBitmap(c.thumb);
            else iv.setBackgroundColor(0xFF2C2C2A);
            cc.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
            TextView t = tv(" " + (i + 1) + " · " + fmt(c.durMs) + (i < n - 1 ? "\n " + TRANS[c.trans] : ""), 12.5f, AMB_T, true);
            cc.addView(t);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMarginEnd(dp(6));
            cc.setLayoutParams(lp);
            cc.setOnClickListener(v -> clipMenu(idx));
            add(cc);
        }
        if (n == 0) { add(lab("Agregue los videos en el orden que los quiere")); return; }
        add(chip("✨ " + TRANS[Proj.joinTrans] + " para todos", false, () ->
                new AlertDialog.Builder(this).setTitle("Transición para todos").setItems(TRANS, (d, w) -> {
                    Proj.joinTrans = w;
                    for (Proj.Clip c : Proj.clips) c.trans = w;
                    refreshCtx();
                }).show()));
        add(chip(Proj.joinSoft ? "🌅 Entrada y salida suave: Sí" : "🌅 Entrada y salida suave: No", false, () -> {
            Proj.joinSoft = !Proj.joinSoft;
            refreshCtx();
        }));
        add(chip("📐 " + FORMATS[Proj.joinFormat], false, () -> { Proj.joinFormat = (Proj.joinFormat + 1) % FORMATS.length; refreshCtx(); }));
        add(chip("🎞 Unir ahora", true, this::doJoin));
        add(lab(n + (n == 1 ? " video · " : " videos · ") + fmt(joinTotal())));
        add(chip("🗑 Vaciar lista", false, () -> { Proj.clips.clear(); refreshCtx(); }));
    }

    private void clipMenu(final int idx) {
        if (idx < 0 || idx >= Proj.clips.size()) return;
        final Proj.Clip c = Proj.clips.get(idx);
        final boolean last = idx == Proj.clips.size() - 1;
        List<String> items = new ArrayList<>();
        items.add("◀ Pasar antes");
        items.add("Pasar después ▶");
        items.add(last ? "✨ (es el último: no lleva transición)" : "✨ Transición después: " + TRANS[c.trans]);
        items.add("▶ Ver este video");
        items.add("🗑 Quitar de la lista");
        new AlertDialog.Builder(this).setTitle("Video " + (idx + 1) + " · " + shortName(c.name))
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    List<Proj.Clip> l = new ArrayList<>(Proj.clips);
                    if (w == 0 && idx > 0) { Collections.swap(l, idx, idx - 1); }
                    else if (w == 1 && idx < l.size() - 1) { Collections.swap(l, idx, idx + 1); }
                    else if (w == 2 && !last) {
                        new AlertDialog.Builder(this).setTitle("Transición después del video " + (idx + 1))
                                .setItems(TRANS, (d2, w2) -> { c.trans = w2; refreshCtx(); }).show();
                        return;
                    } else if (w == 3) {
                        Intent v = new Intent(Intent.ACTION_VIEW);
                        v.setDataAndType(c.uri, "video/*");
                        v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { startActivity(v); } catch (Exception ignored) { toast("No hay con qué ver el video"); }
                        return;
                    } else if (w == 4) { l.remove(idx); }
                    Proj.clips.clear();
                    Proj.clips.addAll(l);
                    refreshCtx();
                }).show();
    }

    private int[] joinSize(Proj.Clip first) {
        switch (Proj.joinFormat) {
            case 1: return new int[]{720, 1280};
            case 2: return new int[]{1280, 720};
            case 3: return new int[]{720, 720};
        }
        int fw = first.w > 0 ? first.w : 720, fh = first.h > 0 ? first.h : 1280;
        float sc = Math.min(1f, 720f / Math.max(1, Math.min(fw, fh)));
        return new int[]{even(Math.round(fw * sc)), even(Math.round(fh * sc))};
    }

    private void doJoin() {
        final List<Proj.Clip> cl = new ArrayList<>(Proj.clips);
        if (cl.size() < 2) { toast("Agregue por lo menos 2 videos ➕"); return; }
        int[] wh = joinSize(cl.get(0));
        int W = wh[0], H = wh[1];
        ImmutableList.Builder<EditedMediaItem> items = ImmutableList.builder();
        int n = cl.size();
        for (int i = 0; i < n; i++) {
            Proj.Clip c = cl.get(i);
            int inT = i > 0 ? cl.get(i - 1).trans : (Proj.joinSoft ? 1 : 0);
            int outT = i < n - 1 ? c.trans : (Proj.joinSoft ? 1 : 0);
            long tt = Math.min(TRANS_MS, c.durMs / 3);
            List<Effect> fx = new ArrayList<>();
            fx.add(Presentation.createForWidthAndHeight(W, H, Presentation.LAYOUT_SCALE_TO_FIT));
            if (TransMotion.moves(inT) || TransMotion.moves(outT))
                fx.add(new TransMotion(inT, outT, c.durMs, tt, (float) W / H));
            boolean fi = inT == 1 || inT == 2, fo = outT == 1 || outT == 2;
            if (fi || fo) fx.add(new TransFade(fi, fo, c.durMs, tt));
            items.add(new EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                    .setEffects(new Effects(ImmutableList.<AudioProcessor>of(), fx))
                    .build());
        }
        Composition comp = new Composition.Builder(ImmutableList.of(new EditedMediaItemSequence(items.build())))
                .experimentalSetForceAudioTrack(true)
                .build();
        final File out = new File(getCacheDir(), "chepe_union.mp4");
        runJob(baseTransformer(6_000_000), comp, out, "🎞 Uniendo videos…", null, f -> {
            final String name = "Unido_" + stamp() + ".mp4";
            toDownloads(f, "Unidos", name, "video/mp4", (uu, nm, size) -> {
                loadVideo(uu, true);
                new AlertDialog.Builder(this).setTitle("✅ Videos unidos")
                        .setMessage("Quedó en Descargas/MiBarra/ChepeVideo/Unidos\n\n" + nm
                                + "\n\nYa lo tiene abierto: ahora puede ponerle textos 🔤, fotos 🖼️, música 🎵 y guardarlo con 💾 MP4.")
                        .setPositiveButton("OK", null).show();
            });
        });
    }

    // ------------------------------------------------------------ textos

    private Proj.TextLayer newText(String txt) {
        long pos = player.getCurrentPosition();
        long st = pos, en = Math.min(Proj.durMs, pos + 4000);
        if (en - st < 1000) { st = Math.max(0, Proj.durMs - 4000); en = Proj.durMs; }
        return new Proj.TextLayer(txt, st, en);
    }

    private void ctxText() {
        final Proj.TextLayer t = Proj.selText;
        add(chip("➕ Escribir texto", t == null, () -> editText(newText(""), true)));
        add(chip("🎂 Cumpleaños", false, () -> {
            Proj.TextLayer x = newText("¡Feliz cumpleaños!");
            x.style = 3; x.anim = 5; x.size = 0.11f; x.cy = 0.18f;
            editText(x, true);
        }));
        add(chip("📢 Publicidad", false, () -> {
            Proj.TextLayer x = newText("¡Oferta especial!");
            x.style = 2; x.anim = 2; x.size = 0.08f; x.cy = 0.8f;
            editText(x, true);
        }));
        if (t == null) { add(lab("Escriba lo que quiera encima del video")); return; }
        if (Proj.texts.size() > 1) add(chip("▶ Siguiente texto (" + (Proj.texts.indexOf(t) + 1) + "/" + Proj.texts.size() + ")", false, () -> {
            int k = (Proj.texts.indexOf(t) + 1) % Proj.texts.size();
            Proj.selText = Proj.texts.get(k);
            player.seekTo(Proj.selText.startMs);
            refreshCtx();
        }));
        add(chip("✏️ Cambiar", false, () -> editText(t, false)));
        add(chip("⏮ Desde aquí", false, () -> {
            t.startMs = player.getCurrentPosition();
            if (t.endMs <= t.startMs + 300) t.endMs = Math.min(Proj.durMs, t.startMs + 4000);
            marks(); refreshCtx();
        }));
        add(chip("Hasta aquí ⏭", false, () -> {
            t.endMs = Math.max(player.getCurrentPosition(), t.startMs + 300);
            marks(); refreshCtx();
        }));
        add(lab(fmt(t.startMs) + " → " + fmt(t.endMs)));
        add(chip("⏱ Todo el video", false, () -> { t.startMs = 0; t.endMs = Proj.durMs; marks(); refreshCtx(); }));
        add(chip("🗑 Quitar", false, () -> {
            Proj.texts.remove(t);
            Proj.selText = Proj.texts.isEmpty() ? null : Proj.texts.get(Proj.texts.size() - 1);
            marks(); refreshCtx();
        }));
        add(lab("Mueva con un dedo · agrande con dos"));
    }

    /** Fila de opciones donde se escoge una sola. */
    private HorizontalScrollView choices(String[] labels, int[] colors, int selected, IntConsumer onPick) {
        final LinearLayout row = hbox();
        row.setPadding(0, dp(4), 0, dp(4));
        final List<TextView> all = new ArrayList<>();
        final int[] sel = {selected};
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            TextView t = tv(labels[i], 14, TEAL_T, true);
            t.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMarginEnd(dp(6));
            t.setLayoutParams(lp);
            all.add(t);
            row.addView(t);
        }
        final Runnable paint = () -> {
            for (int i = 0; i < all.size(); i++) {
                TextView t = all.get(i);
                boolean on = i == sel[0];
                if (colors != null) {
                    GradientDrawable g = round(colors[i], 18);
                    g.setStroke(dp(on ? 4 : 1), on ? 0xFFEF9F27 : 0xFF888780);
                    t.setBackground(g);
                    int c = colors[i];
                    boolean darkC = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 < 140;
                    t.setTextColor(darkC ? Color.WHITE : Color.BLACK);
                } else {
                    t.setBackground(round(on ? TEAL_D : TEAL_L, 18));
                    t.setTextColor(on ? Color.WHITE : TEAL_T);
                }
            }
        };
        for (int i = 0; i < all.size(); i++) {
            final int k = i;
            all.get(i).setOnClickListener(v -> { sel[0] = k; paint.run(); onPick.accept(k); });
        }
        paint.run();
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    private static int indexOf(int[] a, int v) {
        for (int i = 0; i < a.length; i++) if (a[i] == v) return i;
        return 0;
    }

    private void editText(final Proj.TextLayer t, final boolean isNew) {
        player.pause();
        final LinearLayout box = vbox();
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        final EditText et = new EditText(this);
        et.setText(t.text);
        et.setHint("Escriba aquí el texto");
        et.setTextColor(Color.BLACK);
        et.setTextSize(19);
        et.setMinLines(2);
        et.setSelection(et.getText().length());
        box.addView(et);
        final int[] v = {t.style, t.color, t.anim};
        box.addView(tv("Estilo", 13, TEAL_T, true));
        box.addView(choices(TextPainter.STYLES, null, v[0], k -> v[0] = k));
        box.addView(tv("Color", 13, TEAL_T, true));
        box.addView(choices(TextPainter.COLOR_NAMES, TextPainter.COLORS, indexOf(TextPainter.COLORS, v[1]), k -> v[1] = TextPainter.COLORS[k]));
        box.addView(tv("Movimiento al aparecer", 13, TEAL_T, true));
        box.addView(choices(TextPainter.ANIMS, null, v[2], k -> v[2] = k));
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(isNew ? "🔤 Texto nuevo" : "✏️ Cambiar texto").setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    String txt = et.getText().toString().trim();
                    if (txt.isEmpty()) { toast("El texto quedó vacío"); return; }
                    t.text = txt;
                    t.style = v[0];
                    t.color = v[1];
                    t.anim = v[2];
                    if (isNew) Proj.texts.add(t);
                    Proj.selText = t;
                    if (mode != Mode.TEXT) setMode(Mode.TEXT);
                    player.seekTo(t.startMs);
                    marks();
                    refreshCtx();
                    overlay.invalidate();
                })
                .setNegativeButton("Cancelar", null);
        if (!isNew) b.setNeutralButton("🗑 Quitar", (d, w) -> {
            Proj.texts.remove(t);
            Proj.selText = Proj.texts.isEmpty() ? null : Proj.texts.get(Proj.texts.size() - 1);
            marks();
            refreshCtx();
        });
        b.show();
    }

    // ------------------------------------------------------------ música

    private void ctxMusic() {
        final Proj.Music mu = Proj.music;
        add(chip(mu == null ? "🎵 Escoger música" : "🎵 Cambiar música", mu == null, () -> pick(REQ_MUSIC, "audio/*")));
        if (mu == null) { add(lab("Búsquela en la carpeta que quiera")); return; }
        add(lab("🎶 " + shortName(mu.name) + " · " + fmt(mu.durMs)));
        add(chip("−", false, () -> { mu.vol = Math.max(0f, Math.round(mu.vol * 10f - 1f) / 10f); refreshCtx(); }));
        add(lab("Música " + Math.round(mu.vol * 100) + " %"));
        add(chip("+", false, () -> { mu.vol = Math.min(1f, Math.round(mu.vol * 10f + 1f) / 10f); refreshCtx(); }));
        add(chip("−", false, () -> { mu.videoVol = Math.max(0f, Math.round(mu.videoVol * 10f - 1f) / 10f); applyVolume(); refreshCtx(); }));
        add(lab("Voz del video " + Math.round(mu.videoVol * 100) + " %"));
        add(chip("+", false, () -> { mu.videoVol = Math.min(1f, Math.round(mu.videoVol * 10f + 1f) / 10f); applyVolume(); refreshCtx(); }));
        add(chip(mu.soft ? "🌅 Entra y sale suave: Sí" : "🌅 Entra y sale suave: No", false, () -> { mu.soft = !mu.soft; refreshCtx(); }));
        add(chip("🗑 Quitar", false, () -> {
            Proj.music = null;
            if (musicPlayer != null) musicPlayer.stop();
            applyVolume();
            refreshCtx();
        }));
    }

    private void loadMusic(final Uri u) {
        status("🎵 Cargando la música…");
        exec.execute(() -> {
            long d = 0;
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, u);
                d = Frames.parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            } catch (Exception ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) {}
            }
            final long fd = d;
            final String nm = nameOf(u);
            ui.post(() -> {
                status(null);
                if (fd <= 0) { toast("No pude abrir esa música"); return; }
                Proj.Music old = Proj.music;
                Proj.Music mu = new Proj.Music(u, nm, fd);
                if (old != null) { mu.vol = old.vol; mu.videoVol = old.videoVol; mu.soft = old.soft; }
                Proj.music = mu;
                if (musicPlayer == null) {
                    musicPlayer = new ExoPlayer.Builder(this).build();
                    musicPlayer.setRepeatMode(Player.REPEAT_MODE_ONE);
                }
                musicPlayer.setMediaItem(MediaItem.fromUri(u));
                musicPlayer.prepare();
                applyVolume();
                if (mode != Mode.MUSIC) setMode(Mode.MUSIC); else refreshCtx();
                toast("🎵 Música lista: dele ▶ para oírla con el video");
            });
        });
    }

    private void syncMusic(long pos, boolean playing) {
        ExoPlayer mp = musicPlayer;
        if (mp == null) return;
        Proj.Music mu = Proj.music;
        if (mu == null || !playing || micActive || exporting) {
            if (mp.getPlayWhenReady()) mp.pause();
            return;
        }
        mp.setVolume(mu.vol);
        long want = (long) ((pos - Proj.trimStart) / Math.max(0.05f, Proj.speed));
        if (want < 0) want = 0;
        if (mu.durMs > 0) want %= mu.durMs;
        if (!mp.getPlayWhenReady()) {
            mp.seekTo(want);
            mp.play();
        } else if (mp.getPlaybackState() == Player.STATE_READY && Math.abs(mp.getCurrentPosition() - want) > 700) {
            mp.seekTo(want);
        }
    }

    private void applyVolume() {
        if (micActive) return;
        Proj.Music mu = Proj.music;
        player.setVolume(Proj.mute ? 0f : (mu != null ? mu.videoVol : 1f));
    }

    // ------------------------------------------------------------ utilidades

    private void keepScreen(boolean on) {
        if (on == screenOn) return;
        screenOn = on;
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** Para los letreros por micrófono: el video suena a todo volumen y después se deja como estaba. */
    private void maxVolume() {
        try {
            AudioManager am = getSystemService(AudioManager.class);
            if (am == null) return;
            if (savedVol < 0) savedVol = am.getStreamVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
        } catch (Exception ignored) {}
    }

    private void restoreVolume() {
        if (savedVol < 0) return;
        try {
            AudioManager am = getSystemService(AudioManager.class);
            if (am != null) am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVol, 0);
        } catch (Exception ignored) {}
        savedVol = -1;
    }

    /** Parte los letreros largos en pedazos cortos (máximo 7 palabras) repartiendo el tiempo, para que vayan al ritmo. */
    private static List<Proj.Sub> splitSubs(List<Proj.Sub> in) {
        List<Proj.Sub> out = new ArrayList<>();
        for (Proj.Sub s : in) {
            String txt = s.text == null ? "" : s.text.trim();
            String[] w = txt.isEmpty() ? new String[0] : txt.split("\\s+");
            if (w.length <= 8) { out.add(s); continue; }
            int parts = (w.length + 6) / 7;
            int per = (w.length + parts - 1) / parts;
            int totalChars = txt.length();
            long span = Math.max(1, s.endMs - s.startMs);
            long t = s.startMs;
            int used = 0;
            for (int p = 0; p < parts; p++) {
                int a = p * per, b = Math.min(w.length, a + per);
                if (a >= b) break;
                StringBuilder sb = new StringBuilder();
                for (int k = a; k < b; k++) { if (sb.length() > 0) sb.append(' '); sb.append(w[k]); }
                used += sb.length() + 1;
                long end = p == parts - 1 || b == w.length ? s.endMs : s.startMs + span * Math.min(used, totalChars) / Math.max(1, totalChars);
                out.add(new Proj.Sub(t, Math.max(end, t + 600), sb.toString(), ""));
                t = end;
            }
        }
        return out;
    }

    private String nameOf(Uri u) {
        if (u == null) return "";
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String n = c.getString(0);
                    if (n != null) return n;
                }
            } catch (Exception ignored) {}
        }
        String n = u.getLastPathSegment();
        return n == null ? "" : n;
    }

    private static String shortName(String n) {
        if (n == null) return "";
        return n.length() > 26 ? n.substring(0, 23) + "…" : n;
    }
}
