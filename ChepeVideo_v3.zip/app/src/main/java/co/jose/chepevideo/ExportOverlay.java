package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;

import androidx.media3.effect.BitmapOverlay;

/** Capa del tamaño del cuadro que lleva todo lo que se pone encima del video. */
public final class ExportOverlay extends BitmapOverlay {

    private final Compositor comp;
    private final int W, H;
    private final long trimStartMs;
    private final boolean dynamic;
    private final Bitmap[] bufs = new Bitmap[2];
    private int idx = 0;
    private String lastKey = null;
    private long firstTs = -1;
    private boolean absolute = false;

    public ExportOverlay(Context ctx, int w, int h, long trimStartMs, boolean dynamic) {
        this.comp = new Compositor(ctx, true);
        this.W = w; this.H = h;
        this.trimStartMs = trimStartMs;
        this.dynamic = dynamic;
        bufs[0] = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bufs[1] = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    }

    @Override
    public Bitmap getBitmap(long presentationTimeUs) {
        if (firstTs < 0) {
            firstTs = presentationTimeUs;
            absolute = trimStartMs > 500 && presentationTimeUs >= (trimStartMs - 500) * 1000L;
        }
        long t = absolute ? presentationTimeUs / 1000L : trimStartMs + presentationTimeUs / 1000L;
        String sk = dynamic ? null : Compositor.stillKey(t);
        String key = sk == null ? ("d" + t) : sk;
        if (key.equals(lastKey)) return bufs[idx];
        lastKey = key;
        idx = 1 - idx;
        Bitmap b = bufs[idx];
        b.eraseColor(Color.TRANSPARENT);
        comp.draw(new Canvas(b), W, H, t, true);
        return b;
    }

    public void release() {
        comp.release();
    }
}
