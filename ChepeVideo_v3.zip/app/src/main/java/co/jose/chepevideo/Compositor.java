package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.util.HashMap;

/** Arma cada cuadro: fondo nuevo + persona, video de encima, foto y letreros. */
public final class Compositor {

    private final Context ctx;
    private final Seg seg;
    private final SubPainter subs = new SubPainter();
    private final TextPainter texts = new TextPainter();
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final HashMap<String, MediaMetadataRetriever> rets = new HashMap<>();
    private final HashMap<String, Uri> keys = new HashMap<>();

    public Compositor(Context c, boolean stream) {
        ctx = c.getApplicationContext();
        seg = new Seg(stream);
    }

    private MediaMetadataRetriever ret(String name, Uri uri) {
        MediaMetadataRetriever old = rets.get(name);
        if (old != null && uri.equals(keys.get(name))) return old;
        if (old != null) try { old.release(); } catch (Exception ignored) {}
        MediaMetadataRetriever r = Frames.open(ctx, uri);
        rets.put(name, r);
        keys.put(name, uri);
        return r;
    }

    public static RectF layerRect(float cx, float cy, float scale, float aspectHW, float W, float H) {
        float lw = scale * W, lh = lw * aspectHW;
        return new RectF(cx * W - lw / 2f, cy * H - lh / 2f, cx * W + lw / 2f, cy * H + lh / 2f);
    }

    private void drawCover(Canvas c, Bitmap b, int W, int H) {
        float s = Math.max((float) W / b.getWidth(), (float) H / b.getHeight());
        float dw = b.getWidth() * s, dh = b.getHeight() * s;
        c.drawBitmap(b, null, new RectF((W - dw) / 2f, (H - dh) / 2f, (W + dw) / 2f, (H + dh) / 2f), paint);
    }

    /** Fondo nuevo y la persona del video principal encima. */
    public void drawBg(Canvas c, int W, int H, long t) throws Exception {
        Proj.Background bg = Proj.bg;
        Uri uri = Proj.uri;
        if (bg == null || uri == null) return;
        if (bg.type == 0) c.drawColor(bg.color);
        else if (bg.type == 1 && bg.bmp != null) drawCover(c, bg.bmp, W, H);
        else if (bg.type == 2 && bg.uri != null) {
            long d = Math.max(1, bg.durMs);
            Bitmap f = Frames.grab(ret("bg", bg.uri), t % d, W, H);
            if (f != null) drawCover(c, f, W, H);
        }
        Bitmap mf = Frames.grab(ret("main", uri), t, W, H);
        if (mf == null) return;
        c.drawBitmap(seg.cutout(mf, bg.green), null, new RectF(0, 0, W, H), paint);
    }

    public Bitmap composeBg(int W, int H, long t) throws Exception {
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        drawBg(new Canvas(b), W, H, t);
        return b;
    }

    /** La persona del video de encima, sin fondo, en ese momento. */
    public Bitmap layerCut(long t, int maxSide) throws Exception {
        Proj.VideoLayer L = Proj.layer;
        if (L == null) return null;
        Bitmap f = Frames.grab(ret("layer", L.uri), t - L.startMs, maxSide, maxSide);
        if (f == null) return null;
        return seg.cutout(f, L.green);
    }

    /** Cuadro completo para el video final. */
    public void draw(Canvas c, int W, int H, long t, boolean withSubs) {
        try {
            if (Proj.bg != null) drawBg(c, W, H, t);
        } catch (Throwable ignored) {}
        try {
            Proj.VideoLayer L = Proj.layer;
            if (L != null && t >= L.startMs && t < L.startMs + L.durMs) {
                RectF r = layerRect(L.cx, L.cy, L.scale, L.aspect, W, H);
                int ms = (int) Math.max(64, Math.min(1280, Math.max(r.width(), r.height())));
                Bitmap cut = layerCut(t, ms);
                if (cut != null) c.drawBitmap(cut, null, r, paint);
            }
        } catch (Throwable ignored) {}
        for (Proj.ImageLayer im : Proj.images) {
            if (t < im.startMs || t >= im.endMs) continue;
            Bitmap b = im.bmp;
            if (b == null) continue;
            c.drawBitmap(b, null, layerRect(im.cx, im.cy, im.scale, (float) b.getHeight() / b.getWidth(), W, H), paint);
        }
        for (Proj.TextLayer tl : Proj.texts) {
            try { texts.draw(c, tl, 0, 0, W, H, t); } catch (Throwable ignored) {}
        }
        if (withSubs) subs.draw(c, 0, 0, W, H, t);
    }

    /** Llave de lo que se ve en ese momento; null si hay algo moviéndose (hay que dibujar cada cuadro). */
    public static String stillKey(long t) {
        StringBuilder k = new StringBuilder("s");
        Proj.Sub s = SubPainter.at(t);
        k.append(s == null ? -1 : System.identityHashCode(s));
        for (Proj.ImageLayer im : Proj.images) k.append(t >= im.startMs && t < im.endMs ? 'i' : 'n');
        for (Proj.TextLayer tl : Proj.texts) {
            if (TextPainter.animating(tl, t)) return null;
            k.append(t >= tl.startMs && t < tl.endMs ? 't' : 'n');
        }
        return k.toString();
    }

    public void release() {
        for (MediaMetadataRetriever r : rets.values()) try { r.release(); } catch (Exception ignored) {}
        rets.clear();
        keys.clear();
        seg.close();
    }
}
