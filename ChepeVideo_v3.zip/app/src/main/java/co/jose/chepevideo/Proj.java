package co.jose.chepevideo;

import android.graphics.Bitmap;
import android.graphics.RectF;
import android.net.Uri;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Todo lo que el usuario va armando sobre el video. */
public final class Proj {

    public static final class Sub {
        public long startMs, endMs;
        public volatile String text, trans;
        public Sub(long s, long e, String t, String tr) { startMs = s; endMs = e; text = t; trans = tr; }
    }

    public static final class ImageLayer {
        public volatile Bitmap bmp;
        public final Bitmap original;
        public volatile boolean noBg;
        public volatile long startMs, endMs;
        public volatile float cx = 0.5f, cy = 0.55f, scale = 0.4f;
        public ImageLayer(Bitmap b, Bitmap orig, boolean nb, long s, long e) { bmp = b; original = orig; noBg = nb; startMs = s; endMs = e; }
    }

    /** Texto escrito encima del video. size = fracción del lado corto del cuadro. */
    public static final class TextLayer {
        public volatile String text;
        public volatile int color = 0xFFFFFFFF, style = 1, anim = 1;
        public volatile float cx = 0.5f, cy = 0.2f, size = 0.08f;
        public volatile long startMs, endMs;
        public TextLayer(String t, long s, long e) { text = t; startMs = s; endMs = e; }
    }

    public static final class VideoLayer {
        public final Uri uri;
        public final long durMs;
        public final float aspect; // alto / ancho
        public volatile boolean green;
        public volatile long startMs;
        public volatile float cx = 0.72f, cy = 0.62f, scale = 0.45f;
        public VideoLayer(Uri u, long d, boolean g, long s, float a) { uri = u; durMs = d; green = g; startMs = s; aspect = a; }
    }

    /** type: 0 color, 1 foto, 2 video */
    public static final class Background {
        public final int type, color;
        public final Bitmap bmp;
        public final Uri uri;
        public final long durMs;
        public volatile boolean green;
        public Background(int t, int c, Bitmap b, Uri u, boolean g, long d) { type = t; color = c; bmp = b; uri = u; green = g; durMs = d; }
    }

    /** Música de fondo. vol = volumen de la música, videoVol = volumen del sonido del video. */
    public static final class Music {
        public final Uri uri;
        public final String name;
        public final long durMs;
        public volatile float vol = 0.6f, videoVol = 1f;
        public volatile boolean soft = true;
        public Music(Uri u, String n, long d) { uri = u; name = n; durMs = d; }
    }

    /** Un video de la lista para unir. trans = transición después de este video. */
    public static final class Clip {
        public final Uri uri;
        public final String name;
        public final long durMs;
        public final int w, h;
        public volatile int trans;
        public volatile Bitmap thumb;
        public Clip(Uri u, String n, long d, int w, int h, int t) { uri = u; name = n; durMs = d; this.w = w; this.h = h; trans = t; }
    }

    public static volatile Uri uri;
    public static volatile String name = "";
    public static volatile long durMs;
    public static volatile int w, h;
    public static volatile float fps = 30f;
    public static volatile long trimStart, trimEnd;
    public static volatile float speed = 1f;
    public static volatile boolean mute;
    public static volatile RectF crop;
    public static final List<Sub> subs = new CopyOnWriteArrayList<>();
    public static volatile int subsMode; // 0 ambos, 1 solo original, 2 ocultos
    public static volatile String lang = "en";
    public static final List<ImageLayer> images = new CopyOnWriteArrayList<>();
    public static volatile ImageLayer selImage;
    public static final List<TextLayer> texts = new CopyOnWriteArrayList<>();
    public static volatile TextLayer selText;
    public static volatile VideoLayer layer;
    public static volatile Background bg;
    public static volatile Music music;
    public static final List<Clip> clips = new CopyOnWriteArrayList<>();
    public static volatile int joinTrans = 1, joinFormat;
    public static volatile boolean joinSoft = true;

    /** keep = conservar textos, fotos y música (cuando el video nuevo sale de unir). */
    public static void reset(Uri u, Frames.VInfo i, boolean keep) {
        uri = u; durMs = i.durMs; w = i.w; h = i.h; fps = i.fps;
        trimStart = 0; trimEnd = i.durMs; speed = 1f; mute = false; crop = null;
        subs.clear(); layer = null; bg = null;
        if (!keep) {
            images.clear(); selImage = null;
            texts.clear(); selText = null;
            music = null;
        } else {
            for (TextLayer t : texts) { if (t.startMs >= durMs) t.startMs = 0; if (t.endMs > durMs) t.endMs = durMs; }
            for (ImageLayer m : images) { if (m.startMs >= durMs) m.startMs = 0; if (m.endMs > durMs) m.endMs = durMs; }
        }
    }

    public static boolean anyImageAt(long t) {
        for (ImageLayer m : images) if (t >= m.startMs && t < m.endMs) return true;
        return false;
    }

    private Proj() {}
}
