package co.jose.chepevideo;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

/** Dibuja los textos escritos por el usuario, con su estilo y su animación. */
public final class TextPainter {

    public static final String[] STYLES = {"Sombra", "Contorno", "Caja", "Cumpleaños", "Brillo"};
    public static final String[] ANIMS = {"Quieto", "Aparece", "Sube", "Letra por letra", "Crece", "Rebota"};
    public static final int[] COLORS = {0xFFFFFFFF, 0xFF000000, 0xFFFAC775, 0xFFE24B4A, 0xFF5DCAA5,
            0xFF85B7EB, 0xFFED93B1, 0xFFEF9F27};
    public static final String[] COLOR_NAMES = {"Blanco", "Negro", "Dorado", "Rojo", "Verde", "Azul", "Rosado", "Naranja"};

    static final long IN_MS = 700, OUT_MS = 350;

    private final TextPaint fill = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint stroke = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TextPainter() {
        fill.setTypeface(Typeface.DEFAULT_BOLD);
        stroke.setTypeface(Typeface.DEFAULT_BOLD);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
    }

    /** true si en ese momento el texto se está moviendo (entrando o saliendo). */
    public static boolean animating(Proj.TextLayer t, long ms) {
        if (t.anim == 0 || ms < t.startMs || ms >= t.endMs) return false;
        long in = inLen(t);
        return ms - t.startMs < in || t.endMs - ms < OUT_MS;
    }

    static long inLen(Proj.TextLayer t) {
        if (t.anim == 3) return Math.max(IN_MS, Math.min(4000, 70L * (t.text == null ? 0 : t.text.length())));
        return IN_MS;
    }

    private static float ease(float p) { p = Math.max(0f, Math.min(1f, p)); return 1f - (1f - p) * (1f - p) * (1f - p); }

    private static float bounce(float p) {
        p = Math.max(0f, Math.min(1f, p));
        return (float) (1.0 - Math.exp(-6.0 * p) * Math.cos(p * 14.0));
    }

    private StaticLayout layout(String s, TextPaint p, int maxW) {
        return StaticLayout.Builder.obtain(s, 0, s.length(), p, Math.max(20, maxW))
                .setAlignment(Layout.Alignment.ALIGN_CENTER).build();
    }

    private void setup(Proj.TextLayer t, float W, float H) {
        float px = Math.max(8f, t.size * Math.min(W, H));
        fill.setTextSize(px);
        stroke.setTextSize(px);
        stroke.setStrokeWidth(px * 0.14f);
        fill.clearShadowLayer();
        int c = t.color;
        switch (t.style) {
            case 0:
                fill.setShadowLayer(px * 0.12f, px * 0.05f, px * 0.07f, 0xDD000000);
                break;
            case 3:
                c = 0xFFFAC775;
                stroke.setColor(0xFF993556);
                fill.setShadowLayer(px * 0.15f, 0, px * 0.08f, 0x99000000);
                break;
            case 4:
                fill.setShadowLayer(px * 0.45f, 0, 0, c);
                break;
            default:
                stroke.setColor(c == 0xFF000000 ? 0xFFFFFFFF : 0xFF000000);
        }
        fill.setColor(c);
    }

    /** Rectángulo que ocupa el texto (sin animación), en coordenadas del cuadro. */
    public RectF bounds(Proj.TextLayer t, float left, float top, float W, float H) {
        String s = t.text == null ? "" : t.text;
        if (s.isEmpty()) s = " ";
        setup(t, W, H);
        StaticLayout lay = layout(s, fill, (int) (W * 0.92f));
        float lw = 0;
        for (int k = 0; k < lay.getLineCount(); k++) lw = Math.max(lw, lay.getLineWidth(k));
        float lh = lay.getHeight();
        float pad = fill.getTextSize() * 0.35f;
        float cx = left + t.cx * W, cy = top + t.cy * H;
        return new RectF(cx - lw / 2f - pad, cy - lh / 2f - pad, cx + lw / 2f + pad, cy + lh / 2f + pad);
    }

    public void draw(Canvas c, Proj.TextLayer t, float left, float top, float W, float H, long ms) {
        if (ms < t.startMs || ms >= t.endMs) return;
        String s = t.text;
        if (s == null || s.trim().isEmpty() || W < 10 || H < 10) return;
        float alpha = 1f, scale = 1f, dy = 0f;
        long since = ms - t.startMs, left2 = t.endMs - ms;
        if (t.anim != 0) {
            float p = since / (float) inLen(t);
            switch (t.anim) {
                case 1: alpha = ease(p); break;
                case 2: alpha = ease(p); dy = (1f - ease(p)) * H * 0.12f; break;
                case 3: {
                    int n = Math.max(0, Math.min(s.length(), Math.round(s.length() * Math.min(1f, p))));
                    if (n == 0) return;
                    s = s.substring(0, n);
                    break;
                }
                case 4: scale = 0.25f + 0.75f * ease(p); alpha = Math.min(1f, p * 2f); break;
                case 5: scale = Math.max(0.05f, bounce(p)); break;
            }
            if (left2 < OUT_MS) alpha *= Math.max(0f, left2 / (float) OUT_MS);
        }
        if (alpha <= 0.01f) return;
        setup(t, W, H);
        int maxW = (int) (W * 0.92f);
        StaticLayout full = layout(t.text, fill, maxW);
        StaticLayout lay = layout(s, fill, maxW);
        float lw = 0;
        for (int k = 0; k < full.getLineCount(); k++) lw = Math.max(lw, full.getLineWidth(k));
        float lh = full.getHeight();
        float px = fill.getTextSize();
        float cx = left + t.cx * W, cy = top + t.cy * H + dy;
        int a = Math.round(alpha * 255f);
        float pad = px * 0.35f;
        c.save();
        c.scale(scale, scale, cx, cy);
        c.saveLayerAlpha(cx - lw / 2f - pad - px, cy - lh / 2f - pad - px, cx + lw / 2f + pad + px, cy + lh / 2f + pad + px, a);
        if (t.style == 2) {
            box.setColor(t.color == 0xFFFFFFFF || t.color == 0xFFFAC775 ? 0xE6A32D2D : 0xE6FFFFFF);
            if (t.color == 0xFF000000) box.setColor(0xE6FAC775);
            c.drawRoundRect(cx - lw / 2f - pad, cy - lh / 2f - pad * 0.6f, cx + lw / 2f + pad, cy + lh / 2f + pad * 0.6f, px * 0.3f, px * 0.3f, box);
        }
        c.translate(cx - maxW / 2f, cy - lh / 2f);
        if (t.style == 1 || t.style == 3) {
            StaticLayout sl = layout(s, stroke, maxW);
            sl.draw(c);
        }
        lay.draw(c);
        c.restore();
        c.restore();
    }
}
