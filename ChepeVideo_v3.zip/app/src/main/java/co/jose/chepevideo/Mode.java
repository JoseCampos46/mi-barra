package co.jose.chepevideo;

public enum Mode { NONE, OPEN, JOIN, CUT, SPEED, MUTE, PHOTO, SUBS, TEXT, IMAGE, CROP, BG, LAYER, MUSIC, AUDIO, EXPORT }
