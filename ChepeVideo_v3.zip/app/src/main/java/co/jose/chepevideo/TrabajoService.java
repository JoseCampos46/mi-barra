package co.jose.chepevideo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Mientras Chepe Video guarda o une, este aviso mantiene la app despierta
 * para que el celular no la cierre (aunque la pantalla se apague o se use otra app).
 * Cuando termina se quita solo: no gasta batería cuando no se está trabajando.
 */
public class TrabajoService extends Service {

    private static final String CH = "trabajo";
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Runnable pendingStop;
    private PowerManager.WakeLock lock;

    public static void start(Context c, String text) {
        if (pendingStop != null) { H.removeCallbacks(pendingStop); pendingStop = null; }
        Intent i = new Intent(c, TrabajoService.class).putExtra("t", text);
        try { c.startForegroundService(i); } catch (Exception ignored) {}
    }

    public static void stop(final Context c) {
        final Context app = c.getApplicationContext();
        if (pendingStop != null) H.removeCallbacks(pendingStop);
        pendingStop = () -> {
            pendingStop = null;
            try { app.stopService(new Intent(app, TrabajoService.class)); } catch (Exception ignored) {}
        };
        H.postDelayed(pendingStop, 2500);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String t = intent == null ? null : intent.getStringExtra("t");
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CH) == null)
                nm.createNotificationChannel(new NotificationChannel(CH, "Trabajando", NotificationManager.IMPORTANCE_LOW));
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("Chepe Video")
                    .setContentText(t == null ? "Trabajando…" : t)
                    .setSmallIcon(android.R.drawable.stat_sys_download)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(7, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (lock == null) {
                PowerManager pm = getSystemService(PowerManager.class);
                lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chepevideo:trabajo");
                lock.setReferenceCounted(false);
            }
            lock.acquire(2 * 60 * 60 * 1000L);
        } catch (Exception ignored) {}
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) {}
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
