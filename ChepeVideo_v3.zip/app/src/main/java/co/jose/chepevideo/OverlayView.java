package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * Va encima del video: muestra fondo nuevo, persona de encima, foto, letreros y el recuadro de "Cuadro".
 * Tocar la persona o la foto la mueve; tocar el video principal llama a onTap (abre / cierra el menú).
 */
public class OverlayView extends View {

    public int vw, vh;
    public long posMs;
    public boolean playing;
    public Mode mode = Mode.NONE;
    public Bitmap composite, layerCut, layerStill;
    public long compositeTime = -1, layerCutTime = -1;
    public float cropAspect = 0f;
    public Runnable onTap, onChanged;

    private final float dp;
    private final RectF vr = new RectF();
    private final Paint bmpP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dim = new Paint();
    private final Paint cropP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thin = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handleP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintTx = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SubPainter subs = new SubPainter();
    private final TextPainter textP = new TextPainter();
    private final Paint selP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Proj.ImageLayer dragImg;
    private Proj.TextLayer dragText;
    private final ScaleGestureDetector scaleDet;

    private int target; // 1 foto, 2 video de encima, 3 mover recuadro, 4..7 esquinas, 8 texto
    private boolean dragging, moved;
    private float lastX, lastY, downX, downY;
    private long downT;

    public OverlayView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        dash.setStyle(Paint.Style.STROKE);
        dash.setColor(Color.WHITE);
        dash.setStrokeWidth(2 * dp);
        dash.setPathEffect(new DashPathEffect(new float[]{10 * dp, 6 * dp}, 0f));
        dim.setColor(0x99000000);
        cropP.setStyle(Paint.Style.STROKE);
        cropP.setColor(0xFF5DCAA5);
        cropP.setStrokeWidth(3 * dp);
        thin.setStyle(Paint.Style.STROKE);
        thin.setColor(0x88FFFFFF);
        thin.setStrokeWidth(1 * dp);
        handleP.setColor(Color.WHITE);
        hintBg.setColor(0xAA000000);
        hintTx.setColor(Color.WHITE);
        hintTx.setTextSize(13 * dp);
        selP.setStyle(Paint.Style.STROKE);
        selP.setColor(0xFFEF9F27);
        selP.setStrokeWidth(2 * dp);
        selP.setPathEffect(new DashPathEffect(new float[]{8 * dp, 5 * dp}, 0f));
        scaleDet = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                Proj.ImageLayer im = dragImg;
                Proj.VideoLayer L = Proj.layer;
                Proj.TextLayer tl = dragText;
                if (target == 1 && im != null) im.scale = clamp(im.scale * f, 0.05f, 2f);
                else if (target == 2 && L != null) L.scale = clamp(L.scale * f, 0.05f, 2f);
                else if (target == 8 && tl != null) tl.size = clamp(tl.size * f, 0.02f, 0.4f);
                invalidate();
                return true;
            }
        });
    }

    /** true si los dos dedos son para agrandar la persona o la foto de encima (no para el zoom de la pantalla). */
    public boolean wantsPinch() {
        if (target == 1 || target == 2 || target == 8) return true;
        if (mode == Mode.LAYER && Proj.layer != null) return true;
        if (mode == Mode.TEXT && Proj.selText != null) return true;
        return mode == Mode.IMAGE && Proj.selImage != null;
    }

    private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }

    private void calcRect() {
        if (vw <= 0 || vh <= 0) { vr.set(0, 0, getWidth(), getHeight()); return; }
        float s = Math.min((float) getWidth() / vw, (float) getHeight() / vh);
        float w = vw * s, h = vh * s;
        vr.set((getWidth() - w) / 2f, (getHeight() - h) / 2f, (getWidth() + w) / 2f, (getHeight() + h) / 2f);
    }

    private RectF imgRect(Proj.ImageLayer im) {
        if (im == null || posMs < im.startMs || posMs >= im.endMs) return null;
        Bitmap b = im.bmp;
        if (b == null) return null;
        RectF r = Compositor.layerRect(im.cx, im.cy, im.scale, (float) b.getHeight() / b.getWidth(), vr.width(), vr.height());
        r.offset(vr.left, vr.top);
        return r;
    }

    private RectF layRect() {
        Proj.VideoLayer L = Proj.layer;
        if (L == null || posMs < L.startMs || posMs >= L.startMs + L.durMs) return null;
        RectF r = Compositor.layerRect(L.cx, L.cy, L.scale, L.aspect, vr.width(), vr.height());
        r.offset(vr.left, vr.top);
        return r;
    }

    private Bitmap layerBmp() {
        return (!playing && layerCut != null && layerCutTime == posMs) ? layerCut : layerStill;
    }

    private RectF cropView(RectF c) {
        return new RectF(vr.left + c.left * vr.width(), vr.top + c.top * vr.height(),
                vr.left + c.right * vr.width(), vr.top + c.bottom * vr.height());
    }

    private static boolean full(RectF c) {
        return c.left < 0.002f && c.top < 0.002f && c.right > 0.998f && c.bottom > 0.998f;
    }

    private static int alphaAt(Bitmap b, RectF r, float x, float y) {
        if (b == null || r.width() < 1 || r.height() < 1) return 255;
        int px = (int) ((x - r.left) / r.width() * b.getWidth());
        int py = (int) ((y - r.top) / r.height() * b.getHeight());
        int best = 0;
        for (int dy = -6; dy <= 6; dy += 6)
            for (int dx = -6; dx <= 6; dx += 6) {
                int xx = Math.max(0, Math.min(b.getWidth() - 1, px + dx));
                int yy = Math.max(0, Math.min(b.getHeight() - 1, py + dy));
                best = Math.max(best, Color.alpha(b.getPixel(xx, yy)));
            }
        return best;
    }

    @Override
    protected void onDraw(Canvas c) {
        calcRect();
        if (Proj.uri == null) return;
        if (Proj.bg != null && !playing && composite != null && compositeTime == posMs)
            c.drawBitmap(composite, null, vr, bmpP);
        RectF lr = layRect();
        if (lr != null) {
            Bitmap b = layerBmp();
            if (b != null) c.drawBitmap(b, null, lr, bmpP);
            if (dragging && target == 2) c.drawRect(lr, dash);
        }
        for (Proj.ImageLayer im : Proj.images) {
            RectF ir = imgRect(im);
            if (ir == null) continue;
            c.drawBitmap(im.bmp, null, ir, bmpP);
            if (dragging && target == 1 && dragImg == im) c.drawRect(ir, dash);
            else if (mode == Mode.IMAGE && Proj.selImage == im && Proj.images.size() > 1) c.drawRect(ir, selP);
        }
        for (Proj.TextLayer tl : Proj.texts) {
            textP.draw(c, tl, vr.left, vr.top, vr.width(), vr.height(), posMs);
            if (mode == Mode.TEXT && posMs >= tl.startMs && posMs < tl.endMs
                    && ((dragging && target == 8 && dragText == tl) || (!dragging && Proj.selText == tl)))
                c.drawRect(textP.bounds(tl, vr.left, vr.top, vr.width(), vr.height()), dragging ? dash : selP);
        }
        subs.draw(c, vr.left, vr.top, vr.width(), vr.height(), posMs);

        RectF cr = Proj.crop;
        if (cr != null && (mode == Mode.CROP || !full(cr))) {
            RectF r = cropView(cr);
            c.drawRect(vr.left, vr.top, vr.right, r.top, dim);
            c.drawRect(vr.left, r.bottom, vr.right, vr.bottom, dim);
            c.drawRect(vr.left, r.top, r.left, r.bottom, dim);
            c.drawRect(r.right, r.top, vr.right, r.bottom, dim);
            if (mode == Mode.CROP) {
                c.drawRect(r, cropP);
                for (int i = 1; i < 3; i++) {
                    float xx = r.left + r.width() * i / 3f, yy = r.top + r.height() * i / 3f;
                    c.drawLine(xx, r.top, xx, r.bottom, thin);
                    c.drawLine(r.left, yy, r.right, yy, thin);
                }
                float rad = 9 * dp;
                c.drawCircle(r.left, r.top, rad, handleP);
                c.drawCircle(r.right, r.top, rad, handleP);
                c.drawCircle(r.left, r.bottom, rad, handleP);
                c.drawCircle(r.right, r.bottom, rad, handleP);
            }
        }

        String hint = null;
        if (Proj.bg != null && playing) hint = "Pause para ver el fondo exacto";
        else if (Proj.bg != null && compositeTime != posMs) hint = "Calculando el fondo…";
        if (hint != null) {
            float tw = hintTx.measureText(hint);
            float x0 = vr.left + 8 * dp, y0 = vr.top + 8 * dp;
            c.drawRoundRect(x0, y0, x0 + tw + 16 * dp, y0 + 24 * dp, 6 * dp, 6 * dp, hintBg);
            c.drawText(hint, x0 + 8 * dp, y0 + 17 * dp, hintTx);
        }
    }

    private int hit(float x, float y) {
        RectF cr = Proj.crop;
        if (mode == Mode.CROP && cr != null) {
            RectF r = cropView(cr);
            float tol = 30 * dp;
            if (Math.hypot(x - r.left, y - r.top) < tol) return 4;
            if (Math.hypot(x - r.right, y - r.top) < tol) return 5;
            if (Math.hypot(x - r.left, y - r.bottom) < tol) return 6;
            if (Math.hypot(x - r.right, y - r.bottom) < tol) return 7;
            if (r.contains(x, y)) return 3;
        }
        for (int i = Proj.texts.size() - 1; i >= 0; i--) {
            Proj.TextLayer tl = Proj.texts.get(i);
            if (posMs < tl.startMs || posMs >= tl.endMs) continue;
            if (textP.bounds(tl, vr.left, vr.top, vr.width(), vr.height()).contains(x, y)) { dragText = tl; return 8; }
        }
        for (int i = Proj.images.size() - 1; i >= 0; i--) {
            Proj.ImageLayer im = Proj.images.get(i);
            RectF ir = imgRect(im);
            if (ir != null && ir.contains(x, y) && alphaAt(im.bmp, ir, x, y) > 40) { dragImg = im; return 1; }
        }
        RectF lr = layRect();
        if (lr != null && lr.contains(x, y) && alphaAt(layerBmp(), lr, x, y) > 40) return 2;
        return 0;
    }

    private void drag(float dx, float dy, float x, float y) {
        float W = Math.max(1, vr.width()), H = Math.max(1, vr.height());
        if (target == 1) {
            Proj.ImageLayer im = dragImg;
            if (im != null) { im.cx = clamp(im.cx + dx / W, -0.2f, 1.2f); im.cy = clamp(im.cy + dy / H, -0.2f, 1.2f); }
        } else if (target == 8) {
            Proj.TextLayer tl = dragText;
            if (tl != null) { tl.cx = clamp(tl.cx + dx / W, 0f, 1f); tl.cy = clamp(tl.cy + dy / H, 0f, 1f); }
        } else if (target == 2) {
            Proj.VideoLayer L = Proj.layer;
            if (L != null) { L.cx = clamp(L.cx + dx / W, -0.2f, 1.2f); L.cy = clamp(L.cy + dy / H, -0.2f, 1.2f); }
        } else if (target == 3) {
            RectF c = Proj.crop;
            if (c != null) {
                float w = c.width(), h = c.height();
                float nx = clamp(c.left + dx / W, 0f, 1f - w), ny = clamp(c.top + dy / H, 0f, 1f - h);
                c.set(nx, ny, nx + w, ny + h);
            }
        } else if (target >= 4 && target <= 7) {
            RectF c = Proj.crop;
            if (c != null) moveCorner(c, target, x, y);
        }
    }

    private void moveCorner(RectF c, int t, float x, float y) {
        float nx = clamp((x - vr.left) / Math.max(1, vr.width()), 0f, 1f);
        float ny = clamp((y - vr.top) / Math.max(1, vr.height()), 0f, 1f);
        boolean leftSide = (t == 4 || t == 6), topSide = (t == 4 || t == 5);
        float fx = leftSide ? c.right : c.left;
        float fy = topSide ? c.bottom : c.top;
        float w = clamp(Math.abs(nx - fx), 0.1f, 1f);
        float h = clamp(Math.abs(ny - fy), 0.1f, 1f);
        if (cropAspect > 0f && vw > 0 && vh > 0) {
            h = w * vw / (cropAspect * vh);
            if (h > 1f) { h = 1f; w = h * cropAspect * vh / vw; }
        }
        float left = leftSide ? fx - w : fx;
        float top = topSide ? fy - h : fy;
        left = clamp(left, 0f, Math.max(0f, 1f - w));
        top = clamp(top, 0f, Math.max(0f, 1f - h));
        c.set(left, top, Math.min(1f, left + w), Math.min(1f, top + h));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaleDet.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                downT = e.getEventTime();
                moved = false;
                dragImg = null;
                dragText = null;
                target = Proj.uri == null ? 0 : hit(e.getX(), e.getY());
                if (target == 1 && dragImg != null) Proj.selImage = dragImg;
                if (target == 8 && dragText != null) Proj.selText = dragText;
                dragging = target != 0;
                invalidate();
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                moved = true;
                if (target == 0) {
                    if (mode == Mode.LAYER && Proj.layer != null) target = 2;
                    else if (mode == Mode.IMAGE && Proj.selImage != null) { target = 1; dragImg = Proj.selImage; }
                    else if (mode == Mode.TEXT && Proj.selText != null) { target = 8; dragText = Proj.selText; }
                    dragging = target != 0;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(e.getX() - downX) > 10 * dp || Math.abs(e.getY() - downY) > 10 * dp) moved = true;
                if (e.getPointerCount() == 1 && target != 0) {
                    drag(e.getX() - lastX, e.getY() - lastY, e.getX(), e.getY());
                    invalidate();
                }
                lastX = e.getX();
                lastY = e.getY();
                break;
            case MotionEvent.ACTION_POINTER_UP: {
                int keep = e.getActionIndex() == 0 ? 1 : 0;
                if (keep < e.getPointerCount()) { lastX = e.getX(keep); lastY = e.getY(keep); }
                break;
            }
            case MotionEvent.ACTION_UP: {
                boolean had = target != 0;
                dragging = false;
                target = 0;
                if (!had && !moved && e.getEventTime() - downT < 400) {
                    if (onTap != null) onTap.run();
                } else if (had && onChanged != null) {
                    onChanged.run();
                }
                invalidate();
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                target = 0;
                break;
        }
        return true;
    }
}
