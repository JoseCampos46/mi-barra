package co.jose.micontrol;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;

/** Cuando se cumple el tiempo de Dormir, apaga el televisor escogido. No gasta batería mientras espera. */
public class DormirReceiver extends BroadcastReceiver {

    static void programar(Context c, int minutos) {
        long fin = System.currentTimeMillis() + minutos * 60_000L;
        Tv.prefs(c).edit().putLong("dormir", fin).putInt("dormirTv", Tv.prefs(c).getInt("actual", 0)).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pendiente(c);
        if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fin, pi);
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fin, pi);
    }

    static void cancelar(Context c) {
        Tv.prefs(c).edit().remove("dormir").apply();
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pendiente(c));
    }

    private static PendingIntent pendiente(Context c) {
        return PendingIntent.getBroadcast(c, 7, new Intent(c, DormirReceiver.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                JSONArray l = Tv.lista(c);
                int k = Tv.prefs(c).getInt("dormirTv", 0);
                Tv.prefs(c).edit().remove("dormir").apply();
                if (k < l.length()) Tv.apagarYa(c, l.optJSONObject(k));
            } finally { pr.finish(); }
        }).start();
    }
}
