package co.jose.micontrol;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Habla con el televisor: Samsung y LG por Wi‑Fi, otros por Bluetooth.
 * También busca televisores, despierta el Samsung por Wi‑Fi y usa la nube de Samsung (SmartThings).
 */
final class Tv {
    interface Oyente {
        void estado(String s);
        void entradasLg(JSONArray d);
    }

    private final Context ctx;
    private final Oyente oyente;
    private Ws ws, puntero;
    private JSONObject o;
    private int idMsg;
    private boolean mudo, reproduciendo = true;
    private volatile boolean lgListo;

    Tv(Context c, Oyente oy) { ctx = c.getApplicationContext(); oyente = oy; }

    String marca() { return o == null ? "" : o.optString("m"); }
    boolean esLg() { return "lg".equals(marca()); }
    boolean esBt() { return "bt".equals(marca()); }
    boolean conectado() {
        if (esBt()) return BtHid.get().listo();
        return ws != null && ws.abierto();
    }

    private void estado(String s) { if (oyente != null) oyente.estado(s); }

    // ---------------- Guardado ----------------

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("tv", Context.MODE_PRIVATE); }

    static JSONArray lista(Context c) {
        try { return new JSONArray(prefs(c).getString("tvs", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    // ---------------- Conectar ----------------

    // Reconexión automática: mientras la app esté abierta, si se cae la conexión se vuelve a conectar sola.
    private final android.os.Handler hr = new android.os.Handler(android.os.Looper.getMainLooper());
    private volatile boolean activo;
    private volatile int vuelta;
    private Runnable guardar;
    private int espera = 3000;

    /** La pantalla avisa si está abierta (true) o cerrada (false). Cerrada = no gasta batería. */
    void activo(boolean si) {
        activo = si;
        espera = 3000;
        hr.removeCallbacksAndMessages(null);
        if (!si) desconectar();
    }

    private void reintentar(int v) {
        if (!activo || v != vuelta || o == null) return;
        hr.removeCallbacksAndMessages(null);
        hr.postDelayed(() -> { if (activo && v == vuelta && !conectado()) conectar(o, guardar); }, espera);
        espera = Math.min(espera * 2, 30000);
    }

    void desconectar() {
        vuelta++;
        if (ws != null) ws.cerrar();
        if (puntero != null) puntero.cerrar();
        ws = null; puntero = null; lgListo = false;
    }

    /** Conecta en un hilo aparte. Si no responde, busca el televisor solo (por si el router le cambió el número). */
    void conectar(JSONObject tv, Runnable alGuardar) {
        desconectar();
        o = tv;
        guardar = alGuardar;
        final int v = vuelta;
        if (o == null) { estado("Toque ☰ → Agregar otro televisor"); return; }
        if (esBt()) {
            estado("Conectando por Bluetooth con " + o.optString("n") + "…");
            BtHid.get().iniciar(ctx, o.optString("ip"));
            return;
        }
        estado("Conectando con " + o.optString("n") + "…");
        new Thread(() -> {
            try {
                abrir(o);
                espera = 3000;
            } catch (Exception e) {
                if (v != vuelta) return;
                estado("🔎 No respondió en " + o.optString("ip") + ". Buscándolo en el Wi‑Fi…");
                String nueva = rebuscar(o);
                if (nueva != null && !nueva.equals(o.optString("ip"))) {
                    try { o.put("ip", nueva); } catch (Exception ignored) {}
                    if (alGuardar != null) alGuardar.run();
                    try { abrir(o); espera = 3000; return; } catch (Exception ignored) {}
                }
                estado("⏳ " + o.optString("n") + " no responde (¿apagado?). Sigo intentando solo…");
                reintentar(v);
            }
        }).start();
    }

    private void abrir(JSONObject t) throws Exception {
        if (esLg()) abrirLg(t.optString("ip"), t); else abrirSamsung(t.optString("ip"), t);
    }

    /** Cada conexión tiene su número: si se cierra una vieja (porque cambiamos de TV), no se reconecta. */
    private Ws.Oyente oyenteDe(int v) {
        return new Ws.Oyente() {
            @Override public void mensaje(String t) { recibir(t); }
            @Override public void cerrado(String porque) {
                if (!activo || v != vuelta) return;
                estado("⏳ Se cortó la conexión. Volviendo a conectar solo…");
                hr.post(() -> reintentar(v));
            }
        };
    }

    private void abrirSamsung(String ip, JSONObject t) throws Exception {
        Ws.Oyente oy = oyenteDe(vuelta);
        String nombre = android.util.Base64.encodeToString("Mi Control".getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
        String tok = t.optString("tok");
        ws = new Ws(oy);
        try {
            ws.conectar("wss://" + ip + ":8002/api/v2/channels/samsung.remote.control?name=" + nombre + (tok.isEmpty() ? "" : "&token=" + tok), 4000);
        } catch (Exception e) {
            ws = new Ws(oy);
            ws.conectar("ws://" + ip + ":8001/api/v2/channels/samsung.remote.control?name=" + nombre, 4000);
        }
        estado("✅ Conectado con " + t.optString("n") + (tok.isEmpty() ? "  (si el TV pregunta, toque Permitir)" : ""));
        // Guardar la dirección física para poder prenderlo por Wi‑Fi
        try {
            String info = leerUrl("http://" + ip + ":8001/api/v2/", 2500);
            String mac = new JSONObject(info).optJSONObject("device").optString("wifiMac");
            if (!mac.isEmpty()) t.put("mac", mac);
        } catch (Exception ignored) {}
    }

    private void abrirLg(String ip, JSONObject t) throws Exception {
        Ws.Oyente oy = oyenteDe(vuelta);
        ws = new Ws(oy);
        try { ws.conectar("ws://" + ip + ":3000", 4000); }
        catch (Exception e) { ws = new Ws(oy); ws.conectar("wss://" + ip + ":3001", 4000); }
        ws.texto(registroLg(t.optString("tok")).toString());
        estado("Conectando con " + t.optString("n") + "… si el TV pregunta, acepte con el control normal");
    }

    static JSONObject registroLg(String clave) throws Exception {
        JSONObject p = new JSONObject();
        p.put("forcePairing", false);
        p.put("pairingType", "PROMPT");
        if (!clave.isEmpty()) p.put("client-key", clave);
        JSONObject man = new JSONObject();
        man.put("manifestVersion", 1);
        man.put("appVersion", "1.1");
        JSONArray perm = new JSONArray();
        for (String x : new String[]{"LAUNCH", "LAUNCH_WEBAPP", "APP_TO_APP", "CLOSE", "TEST_OPEN", "TEST_PROTECTED", "CONTROL_AUDIO", "CONTROL_DISPLAY",
                "CONTROL_INPUT_JOYSTICK", "CONTROL_INPUT_MEDIA_RECORDING", "CONTROL_INPUT_MEDIA_PLAYBACK", "CONTROL_INPUT_TV", "CONTROL_POWER",
                "READ_APP_STATUS", "READ_CURRENT_CHANNEL", "READ_INPUT_DEVICE_LIST", "READ_NETWORK_STATE", "READ_RUNNING_APPS", "READ_TV_CHANNEL_LIST",
                "WRITE_NOTIFICATION_TOAST", "READ_POWER_STATE", "READ_COUNTRY_INFO", "CONTROL_INPUT_TEXT", "CONTROL_MOUSE_AND_KEYBOARD", "READ_INSTALLED_APPS"})
            perm.put(x);
        man.put("permissions", perm);
        p.put("manifest", man);
        return new JSONObject().put("type", "register").put("id", "registro").put("payload", p);
    }

    private void recibir(String t) {
        try {
            JSONObject m = new JSONObject(t);
            if (esLg()) {
                if ("registered".equals(m.optString("type"))) {
                    String k = m.optJSONObject("payload") == null ? "" : m.optJSONObject("payload").optString("client-key");
                    if (!k.isEmpty()) { o.put("tok", k); if (guardar != null) guardar.run(); }
                    lgListo = true;
                    estado("✅ Conectado con " + o.optString("n"));
                    pedirLg("ptr", "ssap://com.webos.service.networkinput/getPointerInputSocket", null);
                } else if ("ptr".equals(m.optString("id"))) {
                    String ruta = m.optJSONObject("payload").optString("socketPath");
                    new Thread(() -> {
                        try { puntero = new Ws(new Ws.Oyente() { public void mensaje(String x) {} public void cerrado(String x) {} }); puntero.conectar(ruta, 4000); }
                        catch (Exception e) { estado("Las flechas no conectaron: " + e.getMessage()); }
                    }).start();
                } else if ("entradas".equals(m.optString("id"))) {
                    if (oyente != null) oyente.entradasLg(m.optJSONObject("payload").optJSONArray("devices"));
                } else if ("error".equals(m.optString("type"))) {
                    estado("El televisor dijo: " + m.optString("error"));
                }
            } else {
                String ev = m.optString("event");
                if ("ms.channel.connect".equals(ev)) {
                    JSONObject d = m.optJSONObject("data");
                    if (d != null && !d.optString("token").isEmpty()) { o.put("tok", d.optString("token")); if (guardar != null) guardar.run(); }
                    estado("✅ Conectado con " + o.optString("n"));
                } else if ("ms.channel.unauthorized".equals(ev)) {
                    estado("El TV no dio permiso. En el TV: Ajustes → General → Administrador de dispositivos externos → permitir Mi Control");
                }
            }
        } catch (Exception ignored) {}
    }

    void pedirLg(String id, String uri, JSONObject payload) {
        if (ws == null || !ws.abierto()) return;
        try {
            JSONObject r = new JSONObject().put("type", "request").put("id", id == null ? "m" + (idMsg++) : id).put("uri", uri);
            if (payload != null) r.put("payload", payload);
            ws.texto(r.toString());
        } catch (Exception ignored) {}
    }

    // ---------------- Teclas ----------------

    /** Nombres de teclas propios de la app: UP DOWN LEFT RIGHT ENTER BACK HOME MENU VOLUP VOLDOWN MUTE CHUP CHDOWN POWER
     *  PLAYPAUSE FF REWIND REC CAPTION MTS SOURCE 0‑9 */
    boolean tecla(String k) {
        if (esBt()) { new Thread(() -> BtHid.get().tecla(k)).start(); return BtHid.get().listo(); }
        if (!conectado()) return false;
        new Thread(() -> {
            try {
                if (esLg()) teclaLg(k); else teclaSamsung(k);
            } catch (Exception ignored) {}
        }).start();
        return true;
    }

    private void teclaSamsung(String k) throws Exception {
        String sk;
        switch (k) {
            case "BACK": sk = "KEY_RETURN"; break;
            case "PLAYPAUSE": sk = reproduciendo ? "KEY_PAUSE" : "KEY_PLAY"; reproduciendo = !reproduciendo; break;
            case "REC": sk = "KEY_REC"; break;
            default: sk = "KEY_" + k;
        }
        JSONObject p = new JSONObject().put("Cmd", "Click").put("DataOfCmd", sk).put("Option", "false").put("TypeOfRemote", "SendRemoteKey");
        ws.texto(new JSONObject().put("method", "ms.remote.control").put("params", p).toString());
    }

    private void teclaLg(String k) throws Exception {
        switch (k) {
            case "VOLUP": pedirLg(null, "ssap://audio/volumeUp", null); return;
            case "VOLDOWN": pedirLg(null, "ssap://audio/volumeDown", null); return;
            case "MUTE": mudo = !mudo; pedirLg(null, "ssap://audio/setMute", new JSONObject().put("mute", mudo)); return;
            case "CHUP": pedirLg(null, "ssap://tv/channelUp", null); return;
            case "CHDOWN": pedirLg(null, "ssap://tv/channelDown", null); return;
            case "POWER": pedirLg(null, "ssap://system/turnOff", null); return;
            case "PLAYPAUSE": pedirLg(null, reproduciendo ? "ssap://media.controls/pause" : "ssap://media.controls/play", null); reproduciendo = !reproduciendo; return;
            case "FF": pedirLg(null, "ssap://media.controls/fastForward", null); return;
            case "REWIND": pedirLg(null, "ssap://media.controls/rewind", null); return;
        }
        String n = k;
        if ("REC".equals(k)) n = "RECORD";
        else if ("CAPTION".equals(k)) n = "CC";
        else if ("MTS".equals(k)) n = "AUDIODESCRIPTION";
        else if ("SOURCE".equals(k)) n = "INPUT";
        if (puntero != null && puntero.abierto()) puntero.texto("type:button\nname:" + n + "\n\n");
        else estado("Las flechas todavía están conectando…");
    }

    /** Escribe un número de canal y lo confirma. */
    void irACanal(String numero) {
        new Thread(() -> {
            for (char c : numero.toCharArray()) {
                if (!Character.isDigit(c)) continue;
                tecla(String.valueOf(c));
                try { Thread.sleep(350); } catch (Exception ignored) {}
            }
            try { Thread.sleep(400); } catch (Exception ignored) {}
            tecla("ENTER");
        }).start();
    }

    void entrada() {
        if (esLg()) pedirLg("entradas", "ssap://tv/getExternalInputList", null); else tecla("SOURCE");
    }

    void cambiarEntradaLg(String id) {
        try { pedirLg(null, "ssap://tv/switchInput", new JSONObject().put("inputId", id)); } catch (Exception ignored) {}
    }

    // ---------------- Apps ----------------

    /** Catálogo: clave, nombre, color de fondo, color de letra, id Samsung, id LG */
    static final Object[][] APPS = {
            {"youtube", "YouTube", 0xFFE62117, 0xFFFFFFFF, "111299001912", "youtube.leanback.v4"},
            {"netflix", "Netflix", 0xFF000000, 0xFFE50914, "3201907018807", "netflix"},
            {"prime", "Prime", 0xFF00A8E1, 0xFFFFFFFF, "3201910019365", "amazon"},
            {"disney", "Disney+", 0xFF113CCF, 0xFFFFFFFF, "3201901017640", "com.disney.disneyplus-prod"},
            {"spotify", "Spotify", 0xFF1DB954, 0xFF000000, "3201606009684", "spotify-beehive"},
            {"navegador", "Internet", 0xFF455A64, 0xFFFFFFFF, "org.tizen.browser", "com.webos.app.browser"},
    };

    static Object[] app(String clave) {
        for (Object[] a : APPS) if (a[0].equals(clave)) return a;
        return null;
    }

    boolean abrirApp(String clave, String buscar) {
        if (esBt()) { estado("Por Bluetooth no se pueden abrir apps: use Inicio y las flechas"); return false; }
        if (!conectado()) return false;
        Object[] a = app(clave);
        if (a == null) return false;
        new Thread(() -> {
            try {
                if (esLg()) {
                    JSONObject p = new JSONObject().put("id", a[5]);
                    if (buscar != null && "youtube".equals(clave))
                        p.put("params", new JSONObject().put("contentTarget", "https://www.youtube.com/tv?#/search?q=" + URLEncoder.encode(buscar, "UTF-8")));
                    pedirLg(null, "ssap://system.launcher/launch", p);
                } else {
                    JSONObject d = new JSONObject().put("appId", a[4]).put("action_type", "youtube".equals(clave) ? "DEEP_LINK" : "NATIVE_LAUNCH");
                    if (buscar != null) d.put("metaTag", "search_query=" + URLEncoder.encode(buscar, "UTF-8"));
                    ws.texto(new JSONObject().put("method", "ms.channel.emit")
                            .put("params", new JSONObject().put("event", "ed.apps.launch").put("to", "host").put("data", d)).toString());
                }
                reproduciendo = true;
            } catch (Exception ignored) {}
        }).start();
        return true;
    }

    // ---------------- YouTube: el celular busca, el televisor reproduce ----------------

    /** Busca en YouTube desde el celular. Devuelve {idVideo, título, duración}. */
    static java.util.List<String[]> buscarYoutube(String q) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL("https://www.youtube.com/results?hl=es&gl=CO&search_query=" + URLEncoder.encode(q, "UTF-8")).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36");
        c.setRequestProperty("Accept-Language", "es-CO,es;q=0.9");
        c.setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI");
        String html = leer(c.getInputStream());
        java.util.List<String[]> r = new java.util.ArrayList<>();
        java.util.Set<String> vistos = new java.util.HashSet<>();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"videoRenderer\":\\{\"videoId\":\"([\\w-]{11})\"").matcher(html);
        java.util.regex.Pattern pt = java.util.regex.Pattern.compile("\"title\":\\{\"runs\":\\[\\{\"text\":\"((?:[^\"\\\\]|\\\\.)*)\"");
        java.util.regex.Pattern pd = java.util.regex.Pattern.compile("\"lengthText\":\\{\"accessibility\":\\{\"accessibilityData\":\\{\"label\":\"[^\"]*\"\\}\\},\"simpleText\":\"([^\"]*)\"");
        while (m.find() && r.size() < 25) {
            String id = m.group(1);
            if (!vistos.add(id)) continue;
            String trozo = html.substring(m.end(), Math.min(html.length(), m.end() + 4000));
            java.util.regex.Matcher mt = pt.matcher(trozo);
            if (!mt.find()) continue;
            String titulo;
            try { titulo = new JSONObject("{\"t\":\"" + mt.group(1) + "\"}").getString("t"); } catch (Exception e) { titulo = mt.group(1); }
            java.util.regex.Matcher md = pd.matcher(trozo);
            r.add(new String[]{id, titulo, md.find() ? md.group(1) : ""});
        }
        return r;
    }

    /** Pone un video de YouTube en el televisor. */
    boolean verYoutube(String id) {
        if (esBt()) { estado("Por Bluetooth no se puede mandar el video: abra YouTube en el televisor"); return false; }
        if (!conectado()) return false;
        new Thread(() -> {
            try {
                if (esLg()) {
                    pedirLg(null, "ssap://system.launcher/launch", new JSONObject().put("id", "youtube.leanback.v4")
                            .put("params", new JSONObject().put("contentTarget", "https://www.youtube.com/tv?v=" + id)));
                } else {
                    JSONObject d = new JSONObject().put("appId", "111299001912").put("action_type", "DEEP_LINK").put("metaTag", "v=" + id);
                    ws.texto(new JSONObject().put("method", "ms.channel.emit")
                            .put("params", new JSONObject().put("event", "ed.apps.launch").put("to", "host").put("data", d)).toString());
                }
                reproduciendo = true;
            } catch (Exception ignored) {}
        }).start();
        return true;
    }

    boolean escribir(String t) {
        if (t.trim().isEmpty()) return false;
        if (esBt()) { if (!BtHid.get().listo()) return false; new Thread(() -> BtHid.get().escribir(t)).start(); return true; }
        if (!conectado()) return false;
        new Thread(() -> {
            try {
                if (esLg()) {
                    pedirLg(null, "ssap://com.webos.service.ime/insertText", new JSONObject().put("text", t).put("replace", 0));
                    Thread.sleep(300);
                    pedirLg(null, "ssap://com.webos.service.ime/sendEnterKey", null);
                } else {
                    String b64 = android.util.Base64.encodeToString(t.getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
                    ws.texto(new JSONObject().put("method", "ms.remote.control").put("params",
                            new JSONObject().put("Cmd", b64).put("DataOfCmd", "base64").put("TypeOfRemote", "SendInputString")).toString());
                    Thread.sleep(300);
                    ws.texto(new JSONObject().put("method", "ms.remote.control").put("params", new JSONObject().put("TypeOfRemote", "SendInputEnd")).toString());
                }
                estado("✅ Escrito en el TV: «" + t + "»");
            } catch (Exception ignored) {}
        }).start();
        return true;
    }

    // ---------------- Buscar en el Wi‑Fi ----------------

    /** Devuelve ip → {marca, nombre}. Tarda unos 4 segundos. */
    static Map<String, String[]> buscar(Context c) {
        Map<String, String[]> enc = new LinkedHashMap<>();
        WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiManager.MulticastLock ml = wm.createMulticastLock("tv");
        try {
            ml.acquire();
            DatagramSocket s = new DatagramSocket();
            s.setSoTimeout(700);
            String[] st = {"urn:dial-multiscreen-org:service:dial:1", "urn:samsung.com:device:RemoteControlReceiver:1",
                    "urn:lge-com:service:webos-second-screen:1", "ssdp:all"};
            InetAddress grupo = InetAddress.getByName("239.255.255.250");
            for (int vez = 0; vez < 2; vez++) for (String x : st) {
                byte[] d = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + x + "\r\n\r\n").getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(d, d.length, grupo, 1900));
            }
            long fin = System.currentTimeMillis() + 4000;
            byte[] buf = new byte[4096];
            while (System.currentTimeMillis() < fin) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    s.receive(p);
                    String r = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).toLowerCase();
                    String ip = p.getAddress().getHostAddress();
                    String marca = r.contains("samsung") ? "samsung" : (r.contains("webos") || r.contains("lge") || r.contains("lg electronics")) ? "lg" : null;
                    if (marca != null && !enc.containsKey(ip)) enc.put(ip, new String[]{marca, marca.equals("lg") ? "LG" : "Samsung"});
                } catch (java.net.SocketTimeoutException ignored) {}
            }
            s.close();
        } catch (Exception ignored) {
        } finally { try { ml.release(); } catch (Exception ignored) {} }
        return enc;
    }

    /** Busca el mismo televisor con otra dirección. */
    private String rebuscar(JSONObject t) {
        Map<String, String[]> enc = buscar(ctx);
        String mac = t.optString("mac");
        String unico = null;
        int cuantos = 0;
        for (Map.Entry<String, String[]> e : enc.entrySet()) {
            if (!e.getValue()[0].equals(t.optString("m"))) continue;
            cuantos++;
            unico = e.getKey();
            if (!mac.isEmpty() && "samsung".equals(t.optString("m"))) {
                try {
                    String info = leerUrl("http://" + e.getKey() + ":8001/api/v2/", 2500);
                    if (mac.equalsIgnoreCase(new JSONObject(info).optJSONObject("device").optString("wifiMac"))) return e.getKey();
                } catch (Exception ignored) {}
            }
        }
        return cuantos == 1 ? unico : null;
    }

    // ---------------- Prender por Wi‑Fi (Samsung) ----------------

    static boolean despertar(String mac) {
        try {
            String[] h = mac.split("[:-]");
            if (h.length != 6) return false;
            byte[] m = new byte[6];
            for (int i = 0; i < 6; i++) m[i] = (byte) Integer.parseInt(h[i], 16);
            byte[] d = new byte[102];
            for (int i = 0; i < 6; i++) d[i] = (byte) 0xFF;
            for (int i = 6; i < d.length; i += 6) System.arraycopy(m, 0, d, i, 6);
            DatagramSocket s = new DatagramSocket();
            s.setBroadcast(true);
            InetAddress b = InetAddress.getByName("255.255.255.255");
            for (int i = 0; i < 3; i++) { s.send(new DatagramPacket(d, d.length, b, 9)); Thread.sleep(100); }
            s.close();
            return true;
        } catch (Exception e) { return false; }
    }

    // ---------------- Nube de Samsung (fuera de casa) ----------------

    /** prender = true/false. Devuelve un mensaje para mostrar. */
    static String nubeSamsung(String codigo, boolean prender) {
        try {
            String lista = pedirNube("GET", "https://api.smartthings.com/v1/devices", codigo, null);
            JSONArray items = new JSONObject(lista).optJSONArray("items");
            String id = null, nombre = "";
            for (int i = 0; items != null && i < items.length(); i++) {
                JSONObject d = items.getJSONObject(i);
                String tipo = d.optJSONObject("ocf") == null ? "" : d.optJSONObject("ocf").optString("ocfDeviceType");
                String txt = (d.optString("label") + " " + d.optString("name") + " " + tipo).toLowerCase();
                if (tipo.equals("oic.d.tv") || txt.contains("tv")) { id = d.optString("deviceId"); nombre = d.optString("label", d.optString("name")); break; }
            }
            if (id == null) return "No encontré televisores en su cuenta Samsung";
            JSONObject cmd = new JSONObject().put("commands", new JSONArray().put(new JSONObject()
                    .put("component", "main").put("capability", "switch").put("command", prender ? "on" : "off")));
            pedirNube("POST", "https://api.smartthings.com/v1/devices/" + id + "/commands", codigo, cmd.toString());
            return (prender ? "✅ Mandé prender " : "✅ Mandé apagar ") + nombre;
        } catch (Exception e) {
            return "❌ No funcionó por internet: " + e.getMessage();
        }
    }

    private static String pedirNube(String metodo, String url, String codigo, String cuerpo) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(metodo);
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Authorization", "Bearer " + codigo.trim());
        c.setRequestProperty("Accept", "application/json");
        if (cuerpo != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = c.getOutputStream()) { os.write(cuerpo.getBytes(StandardCharsets.UTF_8)); }
        }
        int r = c.getResponseCode();
        if (r == 401 || r == 403) throw new Exception("el código de Samsung no sirve o se venció");
        if (r >= 300) throw new Exception("respuesta " + r);
        return leer(c.getInputStream());
    }

    static String leerUrl(String url, int espera) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(espera);
        c.setReadTimeout(espera);
        return leer(c.getInputStream());
    }

    private static String leer(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toString("UTF-8");
    }

    // ---------------- Apagar sin pantalla (para Dormir) ----------------

    /** Se usa desde el temporizador: se conecta, apaga y cierra. Bloquea unos segundos. */
    static void apagarYa(Context c, JSONObject t) {
        if (t == null) return;
        String m = t.optString("m");
        try {
            if ("bt".equals(m)) { BtHid.get().tecla("POWER"); return; }
            Ws w = new Ws(new Ws.Oyente() { public void mensaje(String x) {} public void cerrado(String x) {} });
            String ip = t.optString("ip");
            if ("lg".equals(m)) {
                final boolean[] listo = {false};
                Ws[] ref = {null};
                Ws wl = new Ws(new Ws.Oyente() {
                    public void mensaje(String x) { if (x.contains("\"registered\"")) listo[0] = true; }
                    public void cerrado(String x) {}
                });
                ref[0] = wl;
                try { wl.conectar("ws://" + ip + ":3000", 4000); } catch (Exception e) { wl.conectar("wss://" + ip + ":3001", 4000); }
                wl.texto(registroLg(t.optString("tok")).toString());
                for (int i = 0; i < 30 && !listo[0]; i++) Thread.sleep(100);
                wl.texto(new JSONObject().put("type", "request").put("id", "off").put("uri", "ssap://system/turnOff").toString());
                Thread.sleep(500);
                wl.cerrar();
            } else {
                String nombre = android.util.Base64.encodeToString("Mi Control".getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
                String tok = t.optString("tok");
                try { w.conectar("wss://" + ip + ":8002/api/v2/channels/samsung.remote.control?name=" + nombre + (tok.isEmpty() ? "" : "&token=" + tok), 4000); }
                catch (Exception e) { w = new Ws(new Ws.Oyente() { public void mensaje(String x) {} public void cerrado(String x) {} }); w.conectar("ws://" + ip + ":8001/api/v2/channels/samsung.remote.control?name=" + nombre, 4000); }
                Thread.sleep(800);
                JSONObject p = new JSONObject().put("Cmd", "Click").put("DataOfCmd", "KEY_POWER").put("Option", "false").put("TypeOfRemote", "SendRemoteKey");
                w.texto(new JSONObject().put("method", "ms.remote.control").put("params", p).toString());
                Thread.sleep(500);
                w.cerrar();
            }
        } catch (Exception e) {
            String codigo = prefs(c).getString("st", "");
            if ("samsung".equals(m) && !codigo.isEmpty()) nubeSamsung(codigo, false);
        }
    }
}
