package co.jose.micontrol;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;

import java.util.concurrent.Executors;

/**
 * El celular se hace pasar por un teclado + control Bluetooth.
 * Sirve para televisores Android TV / Google TV y la cajita inteligente de Claro.
 */
@SuppressLint("MissingPermission")
final class BtHid {
    interface Oyente { void estado(String s, boolean conectado, BluetoothDevice d); }

    private static BtHid uno;
    static synchronized BtHid get() { if (uno == null) uno = new BtHid(); return uno; }

    private BluetoothHidDevice hid;
    private BluetoothDevice conectado;
    private boolean registrado;
    private Oyente oyente;
    private String pendiente;

    private static final byte[] DESCRIPTOR = {
            // Teclado (reporte 1)
            0x05, 0x01, 0x09, 0x06, (byte) 0xA1, 0x01, (byte) 0x85, 0x01,
            0x05, 0x07, 0x19, (byte) 0xE0, 0x29, (byte) 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, (byte) 0x95, 0x08, (byte) 0x81, 0x02,
            (byte) 0x95, 0x01, 0x75, 0x08, (byte) 0x81, 0x01,
            (byte) 0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, (byte) 0x81, 0x00,
            (byte) 0xC0,
            // Control multimedia (reporte 2)
            0x05, 0x0C, 0x09, 0x01, (byte) 0xA1, 0x01, (byte) 0x85, 0x02,
            0x15, 0x00, 0x26, (byte) 0xFF, 0x03, 0x19, 0x00, 0x2A, (byte) 0xFF, 0x03, 0x75, 0x10, (byte) 0x95, 0x01, (byte) 0x81, 0x00,
            (byte) 0xC0
    };

    void oyente(Oyente o) { oyente = o; }
    boolean listo() { return hid != null && conectado != null; }
    BluetoothDevice dispositivo() { return conectado; }

    private void avisar(String s) { if (oyente != null) oyente.estado(s, conectado != null, conectado); }

    private final BluetoothHidDevice.Callback cb = new BluetoothHidDevice.Callback() {
        @Override public void onAppStatusChanged(BluetoothDevice d, boolean reg) {
            registrado = reg;
            if (reg && pendiente != null && hid != null) {
                BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                try { hid.connect(a.getRemoteDevice(pendiente)); } catch (Exception ignored) {}
                pendiente = null;
            }
        }
        @Override public void onConnectionStateChanged(BluetoothDevice d, int st) {
            if (st == BluetoothProfile.STATE_CONNECTED) { conectado = d; avisar("✅ Conectado por Bluetooth con " + nombre(d)); }
            else if (st == BluetoothProfile.STATE_DISCONNECTED) { if (d.equals(conectado)) conectado = null; avisar("Bluetooth desconectado"); }
            else if (st == BluetoothProfile.STATE_CONNECTING) avisar("Conectando por Bluetooth…");
        }
    };

    static String nombre(BluetoothDevice d) {
        try { String n = d.getName(); return n == null ? d.getAddress() : n; } catch (Exception e) { return d.getAddress(); }
    }

    /** Prepara el celular como control Bluetooth. Si llega una dirección, se conecta a ese televisor. */
    void iniciar(Context c, String direccion) {
        pendiente = direccion;
        if (hid != null) {
            if (registrado && direccion != null) {
                try { hid.connect(BluetoothAdapter.getDefaultAdapter().getRemoteDevice(direccion)); } catch (Exception ignored) {}
                pendiente = null;
            }
            return;
        }
        BluetoothManager bm = (BluetoothManager) c.getApplicationContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter a = bm == null ? null : bm.getAdapter();
        if (a == null) { avisar("Este celular no tiene Bluetooth"); return; }
        if (!a.isEnabled()) { avisar("Prenda el Bluetooth del celular"); return; }
        a.getProfileProxy(c.getApplicationContext(), new BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int p, BluetoothProfile proxy) {
                hid = (BluetoothHidDevice) proxy;
                BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings("Mi Control", "Control remoto", "Jose",
                        BluetoothHidDevice.SUBCLASS1_COMBO, DESCRIPTOR);
                try { hid.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), cb); } catch (Exception e) { avisar("No pude activar el Bluetooth: " + e.getMessage()); }
            }
            @Override public void onServiceDisconnected(int p) { hid = null; registrado = false; conectado = null; }
        }, BluetoothProfile.HID_DEVICE);
    }

    void conectar(BluetoothDevice d) { if (hid != null) try { hid.connect(d); } catch (Exception ignored) {} }

    // ---------- Mandar teclas ----------

    private void teclado(int codigo) {
        if (!listo()) return;
        byte[] r = new byte[8];
        r[2] = (byte) codigo;
        hid.sendReport(conectado, 1, r);
        try { Thread.sleep(25); } catch (Exception ignored) {}
        hid.sendReport(conectado, 1, new byte[8]);
    }

    private void teclaShift(int codigo) {
        if (!listo()) return;
        byte[] r = new byte[8];
        r[0] = 0x02;
        r[2] = (byte) codigo;
        hid.sendReport(conectado, 1, r);
        try { Thread.sleep(25); } catch (Exception ignored) {}
        hid.sendReport(conectado, 1, new byte[8]);
    }

    private void multimedia(int uso) {
        if (!listo()) return;
        hid.sendReport(conectado, 2, new byte[]{(byte) (uso & 0xFF), (byte) (uso >> 8)});
        try { Thread.sleep(25); } catch (Exception ignored) {}
        hid.sendReport(conectado, 2, new byte[]{0, 0});
    }

    /** Las mismas teclas que usa el resto de la app. */
    boolean tecla(String k) {
        if (!listo()) return false;
        switch (k) {
            case "UP": teclado(0x52); break;
            case "DOWN": teclado(0x51); break;
            case "LEFT": teclado(0x50); break;
            case "RIGHT": teclado(0x4F); break;
            case "ENTER": teclado(0x28); break;
            case "BACK": multimedia(0x0224); break;
            case "HOME": multimedia(0x0223); break;
            case "MENU": multimedia(0x0040); break;
            case "VOLUP": multimedia(0x00E9); break;
            case "VOLDOWN": multimedia(0x00EA); break;
            case "MUTE": multimedia(0x00E2); break;
            case "CHUP": multimedia(0x009C); break;
            case "CHDOWN": multimedia(0x009D); break;
            case "POWER": multimedia(0x0030); break;
            case "PLAYPAUSE": multimedia(0x00CD); break;
            case "FF": multimedia(0x00B3); break;
            case "REWIND": multimedia(0x00B4); break;
            case "REC": multimedia(0x00B2); break;
            case "CAPTION": multimedia(0x0061); break;
            default:
                if (k.length() == 1 && Character.isDigit(k.charAt(0))) { int n = k.charAt(0) - '0'; teclado(n == 0 ? 0x27 : 0x1D + n); }
        }
        return true;
    }

    /** Escribe letras como si fuera un teclado. */
    void escribir(String t) {
        for (char ch : t.toCharArray()) {
            char c = Character.toLowerCase(quitarTilde(ch));
            boolean may = Character.isUpperCase(quitarTilde(ch));
            int cod = -1;
            if (c >= 'a' && c <= 'z') cod = 0x04 + (c - 'a');
            else if (c >= '1' && c <= '9') cod = 0x1E + (c - '1');
            else if (c == '0') cod = 0x27;
            else if (c == ' ') cod = 0x2C;
            else if (c == '.') cod = 0x37;
            else if (c == ',') cod = 0x36;
            else if (c == '-') cod = 0x2D;
            if (cod < 0) continue;
            if (may) teclaShift(cod); else teclado(cod);
            try { Thread.sleep(30); } catch (Exception ignored) {}
        }
        teclado(0x28);
    }

    private static char quitarTilde(char c) {
        switch (c) {
            case 'á': return 'a'; case 'é': return 'e'; case 'í': return 'i'; case 'ó': return 'o'; case 'ú': case 'ü': return 'u'; case 'ñ': return 'n';
            case 'Á': return 'A'; case 'É': return 'E'; case 'Í': return 'I'; case 'Ó': return 'O'; case 'Ú': return 'U'; case 'Ñ': return 'N';
            default: return c;
        }
    }
}
