package co.jose.mibarra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Graba la voz aunque la pantalla esté apagada. Numera sola: Grabación 001, 002… */
public class GrabadoraService extends Service {
    static final String PARAR = "co.jose.mibarra.GRAB_PARAR";
    static final String PAUSA = "co.jose.mibarra.GRAB_PAUSA";
    static volatile boolean grabando, pausado;
    /** Milisegundos ya grabados antes de la última pausa. */
    static volatile long acumulado;
    static volatile long inicio;
    static volatile int numero;
    static MediaRecorder mr;

    private ParcelFileDescriptor pfd;
    private Uri uri;
    private String nombreArchivo;

    static File indice(android.content.Context c) { return new File(c.getFilesDir(), "grabaciones.txt"); }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        if (i == null || PARAR.equals(i.getAction())) { parar(); return START_NOT_STICKY; }
        if (PAUSA.equals(i.getAction())) { pausaOSeguir(); return START_NOT_STICKY; }
        if (grabando) return START_NOT_STICKY;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("grabadora", "Reproductor", NotificationManager.IMPORTANCE_LOW));
        numero = getSharedPreferences("barra", MODE_PRIVATE).getInt("numGrab", 0) + 1;
        pausado = false;
        acumulado = 0;
        startForeground(31, aviso(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        try {
            String fecha = new java.text.SimpleDateFormat("yyyy-MM-dd HH.mm", Locale.US).format(new java.util.Date());
            nombreArchivo = String.format(Locale.US, "Grabacion %03d - %s.m4a", numero, fecha);
            uri = Util.crearEnDescargas(this, nombreArchivo, "audio/mp4");
            pfd = getContentResolver().openFileDescriptor(uri, "rw");
            mr = new MediaRecorder();
            mr.setAudioSource(i.getBooleanExtra("lejos", false)
                    ? MediaRecorder.AudioSource.VOICE_COMMUNICATION : MediaRecorder.AudioSource.MIC);
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mr.setAudioChannels(1);
            mr.setAudioSamplingRate(44100);
            mr.setAudioEncodingBitRate(64000);
            mr.setOutputFile(pfd.getFileDescriptor());
            mr.prepare();
            mr.start();
            inicio = System.currentTimeMillis();
            grabando = true;
            getSystemService(NotificationManager.class).notify(31, aviso());
            getSharedPreferences("barra", MODE_PRIVATE).edit().putInt("numGrab", numero).apply();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo grabar: " + e.getMessage(), Toast.LENGTH_LONG).show();
            limpiar(false);
        }
        return START_NOT_STICKY;
    }

    private void parar() {
        if (!grabando) { limpiar(false); return; }
        boolean ok = true;
        long dur = segundos() * 1000;
        try { mr.stop(); } catch (Exception e) { ok = false; }
        if (ok) {
            try (FileWriter w = new FileWriter(indice(this), StandardCharsets.UTF_8, true)) {
                w.write(uri + "\t" + numero + "\t\t" + System.currentTimeMillis() + "\t" + dur + "\t" + nombreArchivo + "\n");
            } catch (Exception ignored) {}
            Toast.makeText(this, String.format(Locale.US, "💾 Grabación %03d guardada en Descargas/MiBarra/Grabadora", numero),
                    Toast.LENGTH_LONG).show();
        }
        limpiar(ok);
    }

    /** Tiempo grabado sin contar las pausas. */
    static long segundos() {
        if (!grabando) return 0;
        return (acumulado + (pausado ? 0 : System.currentTimeMillis() - inicio)) / 1000;
    }

    private void pausaOSeguir() {
        if (!grabando || mr == null) return;
        try {
            if (pausado) { mr.resume(); inicio = System.currentTimeMillis(); pausado = false; }
            else { mr.pause(); acumulado += System.currentTimeMillis() - inicio; pausado = true; }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo pausar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        getSystemService(NotificationManager.class).notify(31, aviso());
    }

    /** Aviso de arriba con cara de reproductor de música: ⏸/▶ y ⏹. */
    private Notification aviso() {
        PendingIntent abrir = PendingIntent.getActivity(this, 0, new Intent(this, GrabadoraActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent parar = PendingIntent.getService(this, 1, new Intent(this, GrabadoraService.class).setAction(PARAR),
                PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pausa = PendingIntent.getService(this, 2, new Intent(this, GrabadoraService.class).setAction(PAUSA),
                PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, "grabadora")
                .setContentTitle(String.format(Locale.US, "♪ Pista %03d", numero))
                .setContentText(pausado ? "En pausa" : "Reproduciendo")
                .setSmallIcon(pausado ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play)
                .setContentIntent(abrir)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(null, pausado ? "▶" : "⏸", pausa).build())
                .addAction(new Notification.Action.Builder(null, "⏹", parar).build())
                .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1))
                .setOngoing(true);
        if (grabando && !pausado) {
            b.setUsesChronometer(true).setShowWhen(true).setWhen(System.currentTimeMillis() - segundos() * 1000);
        }
        return b.build();
    }

    private void limpiar(boolean ok) {
        grabando = false;
        pausado = false;
        if (mr != null) { try { mr.release(); } catch (Exception ignored) {} mr = null; }
        if (pfd != null) { try { pfd.close(); } catch (Exception ignored) {} pfd = null; }
        if (uri != null) {
            try { if (ok) Util.terminar(this, uri); else getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            uri = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
}
