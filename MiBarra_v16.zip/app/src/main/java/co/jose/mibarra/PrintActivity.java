package co.jose.mibarra;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.nio.file.Files;

/** Muestra lo que se va a imprimir y abre la ventana de impresión (también permite "Guardar como PDF"). */
public class PrintActivity extends Activity {
    private WebView wv;
    private boolean enviado;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);
        String titulo = getIntent().getStringExtra("titulo");
        final String nombre = titulo != null ? titulo : "Mi Barra";
        String html = getIntent().getStringExtra("html");
        String img = getIntent().getStringExtra("imagen");
        if (img != null) {
            try {
                byte[] d = Files.readAllBytes(new File(img).toPath());
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                float relacion = o.outWidth > 0 ? (float) o.outHeight / o.outWidth : 1f;
                int ancho = (int) Math.min(100, 125f / relacion);
                html = "<html><body style='margin:0;text-align:center'><img style='width:" + ancho
                        + "%' src='data:image/png;base64," + Base64.encodeToString(d, Base64.NO_WRAP)
                        + "'></body></html>";
            } catch (Exception e) {
                html = "<p>No se pudo leer la imagen</p>";
            }
        }
        if (html == null) html = "<p>Nada para imprimir</p>";
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                if (enviado) return;
                enviado = true;
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print(nombre, v.createPrintDocumentAdapter(nombre), new PrintAttributes.Builder().build());
            }
        });
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }
}
