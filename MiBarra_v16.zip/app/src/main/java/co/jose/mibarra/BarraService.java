package co.jose.mibarra;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** La barrita lateral izquierda con todos los atajos. */
public class BarraService extends AccessibilityService {

    private WindowManager wm;
    private Handler h;
    private SharedPreferences prefs;
    private View pestana, pestanaDer, panel, filtro;
    private TextView botonDetener;

    // Copiar a Word
    private boolean copiando, bajando;
    private List<String> acumulado = new ArrayList<>();
    private int sinNuevas, vueltas;
    private String origen = "";
    private final Runnable pasoR = this::paso;

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        h = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences("barra_servicio", MODE_PRIVATE);
        aplicarFiltro(prefs.getInt("luz", 0));
        instancia = this;
        if (prefs.getBoolean("barraVisible", false)) pestana = crearPestana(false);
        if (prefs.getBoolean("botonAyuda", true)) crearBotonAyuda();
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(AVISO_BARRA);
            if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(receptor, f, RECEIVER_NOT_EXPORTED);
            else registerReceiver(receptor, f);
        } catch (Exception ignored) {}
        mantenerViva();
    }

    /** Un aviso fijo en notificaciones hace que Xiaomi y otros no maten la barra. */
    private void mantenerViva() {
        try {
            android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
            nm.createNotificationChannel(new android.app.NotificationChannel("barra", "Mi Barra activa",
                    android.app.NotificationManager.IMPORTANCE_MIN));
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(this, 0,
                    new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification n = new android.app.Notification.Builder(this, "barra")
                    .setContentTitle("Mi Barra está activa")
                    .setContentText("Deslice desde el borde izquierdo o derecho")
                    .setSmallIcon(android.R.drawable.ic_menu_sort_by_size)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (android.os.Build.VERSION.SDK_INT >= 34)
                startForeground(21, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else
                startForeground(21, n);
        } catch (Throwable ignored) {
            // Si el celular no lo permite, la barra sigue funcionando igual
        }
    }

    static final String AVISO_BARRA = "co.jose.mibarra.BARRA";
    static volatile BarraService instancia;

    /** El Launcher (en otro proceso) le pide mostrar u ocultar la barrita, o una acción rápida. */
    private final android.content.BroadcastReceiver receptor = new android.content.BroadcastReceiver() {
        @Override public void onReceive(android.content.Context c, Intent i) {
            if (i.hasExtra("visible")) {
                boolean v = i.getBooleanExtra("visible", true);
                prefs.edit().putBoolean("barraVisible", v).apply();
                if (v && pestana == null) pestana = crearPestana(false);
                if (pestana != null) pestana.setVisibility(v ? View.VISIBLE : View.GONE);
            }
            if (i.hasExtra("boton")) {
                boolean v = i.getBooleanExtra("boton", true);
                prefs.edit().putBoolean("botonAyuda", v).apply();
                if (v) crearBotonAyuda(); else { quitar(botonAyuda); botonAyuda = null; quitar(menuAyuda); menuAyuda = null; }
            }
            if (i.hasExtra("ocultarTemporal") && botonAyuda != null) {
                boolean o = i.getBooleanExtra("ocultarTemporal", false);
                botonAyuda.setVisibility(o ? View.GONE : View.VISIBLE);
                if (o) { quitar(menuAyuda); menuAyuda = null; }
            }
            String a = i.getStringExtra("accion");
            if (a != null) accionRapida(a);
        }
    };

    /** Botones de la cortina de arriba y del Launcher: primero se quita la cortina y luego se hace. */
    void accionRapida(String a) {
        if (android.os.Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE);
        else try { sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)); } catch (Exception ignored) {}
        h.postDelayed(() -> {
            switch (a) {
                case "pantallazo": pantallazo(); break;
                case "word": copiar(true); break;
                case "wordArriba": copiar(false); break;
                case "imprimir": imprimirPantalla(); break;
                case "luz": {
                    int actual = prefs.getInt("luz", 0);
                    int nuevo = actual > 0 ? 0 : Math.max(30, prefs.getInt("luzUltima", 40));
                    if (actual > 0) prefs.edit().putInt("luzUltima", actual).apply();
                    prefs.edit().putInt("luz", nuevo).apply();
                    aplicarFiltro(nuevo);
                    break;
                }
                case "menu": abrirMenuAyuda(); break;
                case "bloquear": if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); break;
            }
        }, 700);
    }

    // ---------------- Botón redondo de ayudas (arriba a la izquierda) ----------------
    // Un toque: pantallazo, copiar a Word, calculadora, grabar pantalla.
    // Mientras graba la pantalla, el mismo botón se vuelve ⏹ rojo: un toque y para.
    // Dejándolo presionado se puede correr a otro lado.

    private TextView botonAyuda;
    private View menuAyuda;
    private WindowManager.LayoutParams lpBoton;
    private android.animation.ObjectAnimator latido;

    private void crearBotonAyuda() {
        if (botonAyuda != null) return;
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        int tam = Util.dp(this, prefs.getInt("botonTam", 50));
        lpBoton = lp(tam, tam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        lpBoton.gravity = Gravity.TOP | Gravity.START;
        lpBoton.x = prefs.getInt("botonX", Util.dp(this, 6));
        lpBoton.y = prefs.getInt("botonY", dimSistema("status_bar_height") + Util.dp(this, 4));
        final float[] t0 = new float[4];
        final boolean[] mov = new boolean[1];
        t.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    t0[0] = e.getRawX(); t0[1] = e.getRawY(); t0[2] = lpBoton.x; t0[3] = lpBoton.y; mov[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - t0[0], dy = e.getRawY() - t0[1];
                    if (!mov[0] && !prefs.getBoolean("botonFijo", false) && Math.hypot(dx, dy) > Util.dp(this, 12) && e.getEventTime() - e.getDownTime() > 350) mov[0] = true;
                    if (escondido && dx > Util.dp(this, 20)) { esconderBoton(false); return true; }
                    if (mov[0]) {
                        lpBoton.x = (int) (t0[2] + dx); lpBoton.y = (int) Math.max(0, t0[3] + dy);
                        try { wm.updateViewLayout(v, lpBoton); } catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (mov[0]) prefs.edit().putInt("botonX", lpBoton.x).putInt("botonY", lpBoton.y).apply();
                    else if (Math.hypot(e.getRawX() - t0[0], e.getRawY() - t0[1]) < Util.dp(this, 12)) {
                        if (escondido) esconderBoton(false);
                        else if (GrabarService.grabando) startService(new Intent(this, GrabarService.class).setAction(GrabarService.PARAR));
                        else if (copiando) terminarCopia();
                        else abrirMenuAyuda();
                    }
                    return true;
            }
            return false;
        });
        try { wm.addView(t, lpBoton); botonAyuda = t; } catch (Exception ignored) {}
        pintarBotonAyuda();
    }

    private void pintarBotonAyuda() {
        if (botonAyuda == null) return;
        boolean graba = GrabarService.grabando;
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                graba ? new int[]{0xFFFF1744, 0xFFB71C1C} : new int[]{0xFFFF9800, 0xFFE91E63});
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(Util.dp(this, 2), Color.WHITE);
        botonAyuda.setBackground(g);
        botonAyuda.setText(graba ? "⏹" : "✦");
        botonAyuda.setTextSize(graba ? 22 : 24);
        botonAyuda.setAlpha(escondido ? 0.85f : prefs.getInt("botonOpaco", 92) / 100f);
        if (escondido && !graba) {
            botonAyuda.setText("");
            GradientDrawable r = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFFFF9800, 0xFFE91E63});
            r.setCornerRadius(Util.dp(this, 5));
            botonAyuda.setBackground(r);
        } else if (!graba) {
            botonAyuda.setTextSize(prefs.getInt("botonTam", 50) * 0.48f);
        }
        if (latido != null) { latido.cancel(); latido = null; botonAyuda.setScaleX(1f); botonAyuda.setScaleY(1f); }
        if (graba) {
            latido = android.animation.ObjectAnimator.ofPropertyValuesHolder(botonAyuda,
                    android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.15f),
                    android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.15f));
            latido.setDuration(600);
            latido.setRepeatCount(android.animation.ValueAnimator.INFINITE);
            latido.setRepeatMode(android.animation.ValueAnimator.REVERSE);
            latido.start();
        }
    }

    /** El menú del botón redondo: 4 ayudas grandes. */
    private void abrirMenuAyuda() {
        if (menuAyuda != null) { quitar(menuAyuda); menuAyuda = null; return; }
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = Util.dp(this, 8);
        l.setPadding(pad, pad, pad, pad);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF0182032);
        g.setCornerRadius(Util.dp(this, 20));
        g.setStroke(Util.dp(this, 1), 0x44FFFFFF);
        l.setBackground(g);
        Object[][] ops = {
                {"📸  Pantallazo", (Runnable) this::pantallazo},
                {"📄  Copiar a Word ⬇", (Runnable) () -> copiar(true)},
                {"🧮  Calculadora", (Runnable) () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 0))},
                {"🎥  Grabar pantalla", (Runnable) () -> abrir(new Intent(this, GrabarActivity.class))},
        };
        for (Object[] o : ops) {
            Runnable r = (Runnable) o[1];
            Button b = boton(l, (String) o[0], () -> { quitar(menuAyuda); menuAyuda = null; h.postDelayed(r, 250); });
            b.setTextSize(17);
            ((LinearLayout.LayoutParams) b.getLayoutParams()).height = Util.dp(this, 56);
        }
        // Versión 15: volumen y brillo con una sola barrita cada uno
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        final TextView[] tVol = new TextView[1];
        tVol[0] = barrita(l, nombreVolumen(am.getStreamVolume(AudioManager.STREAM_MUSIC)), maxVol,
                am.getStreamVolume(AudioManager.STREAM_MUSIC), v -> {
                    try { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0); } catch (Exception ignored) {}
                    tVol[0].setText(nombreVolumen(v));
                });
        int brillo;
        try { brillo = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS); } catch (Exception e) { brillo = 128; }
        barrita(l, "☀  Brillo", 255, Math.min(255, brillo), v -> {
            if (!Settings.System.canWrite(this)) {
                if (!pidioBrillo) {
                    pidioBrillo = true;
                    aviso("Permita a Mi Barra «Modificar la configuración del sistema» y vuelva a probar el brillo");
                    quitar(menuAyuda); menuAyuda = null;
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                                android.net.Uri.parse("package:" + getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception ignored) {}
                }
                return;
            }
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, Math.max(5, v));
            } catch (Exception ignored) {}
        });
        // Versión 16: ajustes del propio botón
        TextView aj = new TextView(this);
        aj.setText("Ajustes del botón");
        aj.setTextColor(0xFFFFD54A);
        aj.setTextSize(14);
        aj.setPadding(Util.dp(this, 6), Util.dp(this, 12), 0, 0);
        l.addView(aj);
        barrita(l, "Tamaño", 40, prefs.getInt("botonTam", 50) - 34, v -> {
            prefs.edit().putInt("botonTam", v + 34).apply();
            aplicarTamano();
        });
        barrita(l, "Transparencia", 75, 100 - prefs.getInt("botonOpaco", 92), v -> {
            prefs.edit().putInt("botonOpaco", 100 - v).apply();
            if (botonAyuda != null) botonAyuda.setAlpha((100 - v) / 100f);
        });
        LinearLayout fila3 = new LinearLayout(this);
        boolean fijo = prefs.getBoolean("botonFijo", false);
        String[] tx = {fijo ? "🔓 Soltar" : "📌 Fijar", "🙈 Esconder", "↖ Esquina"};
        Runnable[] ac = {
                () -> { boolean f = !prefs.getBoolean("botonFijo", false); prefs.edit().putBoolean("botonFijo", f).apply();
                        aviso(f ? "📌 Botón fijo: ya no se mueve sin querer" : "🔓 Ahora lo puede mover dejándolo presionado"); },
                () -> esconderBoton(true),
                () -> {
                    prefs.edit().remove("botonX").remove("botonY").apply();
                    if (lpBoton != null) {
                        lpBoton.x = Util.dp(this, 6);
                        lpBoton.y = dimSistema("status_bar_height") + Util.dp(this, 4);
                        try { wm.updateViewLayout(botonAyuda, lpBoton); } catch (Exception ignored) {}
                    }
                }};
        for (int i = 0; i < 3; i++) {
            Runnable r = ac[i];
            Button b = new Button(this);
            b.setText(tx[i]);
            b.setAllCaps(false);
            b.setTextSize(13);
            b.setTextColor(Color.WHITE);
            b.setPadding(0, 0, 0, 0);
            GradientDrawable gb = new GradientDrawable();
            gb.setColor(0xFF2B3459);
            gb.setCornerRadius(Util.dp(this, 10));
            b.setBackground(gb);
            b.setOnClickListener(v -> { quitar(menuAyuda); menuAyuda = null; r.run(); });
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Util.dp(this, 48), 1f);
            bp.setMargins(Util.dp(this, 2), Util.dp(this, 8), Util.dp(this, 2), 0);
            fila3.addView(b, bp);
        }
        l.addView(fila3);
        Button cerrarM = boton(l, "✕  Cerrar", () -> { quitar(menuAyuda); menuAyuda = null; });
        GradientDrawable gc = new GradientDrawable();
        gc.setColor(0xFF5A2A2A);
        gc.setCornerRadius(Util.dp(this, 10));
        cerrarM.setBackground(gc);
        l.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) { quitar(menuAyuda); menuAyuda = null; return true; }
            return false;
        });
        WindowManager.LayoutParams p = lp(Util.dp(this, 270), ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = Math.max(Util.dp(this, 4), lpBoton == null ? 0 : lpBoton.x);
        p.y = (lpBoton == null ? Util.dp(this, 60) : lpBoton.y) + Util.dp(this, 56);
        // Versión 16: si el menú no cabe, se puede bajar con el dedo
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxAlto = dm.heightPixels - p.y - Util.dp(this, 56);
        if (maxAlto < Util.dp(this, 320)) { p.y = Math.max(Util.dp(this, 30), dm.heightPixels - Util.dp(this, 620)); maxAlto = dm.heightPixels - p.y - Util.dp(this, 56); }
        final int tope = maxAlto;
        ScrollView sv = new ScrollView(this) {
            @Override protected void onMeasure(int w, int hm) {
                super.onMeasure(w, MeasureSpec.makeMeasureSpec(tope, MeasureSpec.AT_MOST));
            }
        };
        sv.setBackground(l.getBackground());
        l.setBackground(null);
        sv.addView(l);
        sv.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) { quitar(menuAyuda); menuAyuda = null; return true; }
            return false;
        });
        try { wm.addView(sv, p); menuAyuda = sv; } catch (Exception ignored) {}
    }

    private boolean pidioBrillo;
    private boolean escondido;

    private void aplicarTamano() {
        if (botonAyuda == null || lpBoton == null || escondido) return;
        int t = Util.dp(this, prefs.getInt("botonTam", 50));
        lpBoton.width = t; lpBoton.height = t;
        botonAyuda.setTextSize(t / getResources().getDisplayMetrics().density * 0.45f);
        try { wm.updateViewLayout(botonAyuda, lpBoton); } catch (Exception ignored) {}
    }

    /** Esconder: queda una rayita en el borde izquierdo. Tocarla o deslizarla hacia adentro lo trae de vuelta. */
    private void esconderBoton(boolean si) {
        if (botonAyuda == null || lpBoton == null) return;
        escondido = si;
        if (si) {
            lpBoton.x = 0;
            lpBoton.width = Util.dp(this, 10);
            lpBoton.height = Util.dp(this, 56);
            aviso("🙈 Botón escondido: toque o deslice la rayita del borde para traerlo");
        } else {
            int t = Util.dp(this, prefs.getInt("botonTam", 50));
            lpBoton.width = t; lpBoton.height = t;
            lpBoton.x = prefs.getInt("botonX", Util.dp(this, 6));
        }
        try { wm.updateViewLayout(botonAyuda, lpBoton); } catch (Exception ignored) {}
        pintarBotonAyuda();
        if (!si) aplicarTamano();
    }

    interface AlMover { void valor(int v); }

    private String nombreVolumen(int v) { return v == 0 ? "🔇  Volumen (silencio)" : "🔊  Volumen"; }

    /** Una barrita para deslizar con el dedo: a la izquierda baja, a la derecha sube. */
    private TextView barrita(LinearLayout l, String nombre, int max, int valor, AlMover m) {
        TextView t = new TextView(this);
        t.setText(nombre);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setPadding(Util.dp(this, 6), Util.dp(this, 10), 0, 0);
        l.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(valor);
        sb.setPadding(Util.dp(this, 16), Util.dp(this, 8), Util.dp(this, 16), Util.dp(this, 8));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { if (u) m.valor(v); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        l.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Util.dp(this, 44)));
        return t;
    }

    /** Números grandes 3, 2, 1 en el centro; luego empieza a grabar. No estorba los toques. */
    void cuentaRegresiva(Runnable alTerminar) {
        h.post(() -> {
            TextView n = new TextView(this);
            n.setGravity(Gravity.CENTER);
            n.setTextColor(Color.WHITE);
            n.setTextSize(90);
            n.setShadowLayer(Util.dp(this, 8), 0, 0, Color.BLACK);
            WindowManager.LayoutParams p = lp(Util.dp(this, 200), Util.dp(this, 200),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            p.gravity = Gravity.CENTER;
            boolean puesto;
            try { wm.addView(n, p); puesto = true; } catch (Exception e) { puesto = false; }
            final boolean ok = puesto;
            for (int i = 0; i < 3; i++) {
                final String txt = String.valueOf(3 - i);
                h.postDelayed(() -> { if (ok) n.setText(txt); }, i * 1000L);
            }
            h.postDelayed(() -> {
                if (ok) quitar(n);
                h.postDelayed(alTerminar, 150);
            }, 3000);
        });
    }

    /** La grabación avisa cuando empieza y cuando para: el botón redondo cambia a ⏹ y vuelve. */
    void mostrarPararGrabacion(boolean si) {
        h.post(() -> {
            if (botonAyuda == null) crearBotonAyuda();
            pintarBotonAyuda();
        });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        copiando = false;
        instancia = null;
        try { unregisterReceiver(receptor); } catch (Exception ignored) {}
        quitar(botonAyuda); quitar(menuAyuda);
        quitar(pestana); quitar(pestanaDer); quitar(panel); quitar(filtro); quitar(botonDetener);
        super.onDestroy();
    }

    private void quitar(View v) {
        if (v != null && v.isAttachedToWindow()) {
            try { wm.removeView(v); } catch (Exception ignored) {}
        }
    }

    private WindowManager.LayoutParams lp(int w, int alto, int flags) {
        return new WindowManager.LayoutParams(w, alto,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private int dimSistema(String nombre) {
        int id = getResources().getIdentifier(nombre, "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    // ---------------- Pestañitas (izquierda: herramientas · derecha: en la vía) ----------------

    /**
     * Rayita casi invisible en el borde (2 dp a la vista, 12 dp para tocar).
     * Deslice el dedo hacia adentro: abre. Déjela presionada 1 segundo y arrástrela arriba o abajo: queda fija donde la suelte.
     */
    private View crearPestana(boolean derecha) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(derecha ? 0x7743A047 : 0x77909CAA);
        g.setCornerRadius(Util.dp(this, 2));
        int borde = Util.dp(this, 10);
        v.setBackground(new android.graphics.drawable.InsetDrawable(g, derecha ? borde : 0, 0, derecha ? 0 : borde, 0));
        WindowManager.LayoutParams p = lp(Util.dp(this, 12), Util.dp(this, 56),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        p.gravity = (derecha ? Gravity.END : Gravity.START) | Gravity.TOP;
        p.x = 0;
        int idEstado = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int arriba = (idEstado > 0 ? getResources().getDimensionPixelSize(idEstado) : Util.dp(this, 28)) + Util.dp(this, 4);
        p.y = prefs.getInt(derecha ? "pestYDer" : "pestYIzq", arriba);
        v.addOnLayoutChangeListener((vv, l, t, rr, b, ol, ot, or, ob) ->
                vv.setSystemGestureExclusionRects(Collections.singletonList(new Rect(0, 0, rr - l, b - t))));
        final float[] x0 = new float[1], y0 = new float[1];
        final int[] yIni = new int[1];
        final boolean[] moviendo = new boolean[1], abrio = new boolean[1];
        final android.os.Handler hh = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable largo = () -> {
            moviendo[0] = true;
            g.setColor(0xFFFFC107);
            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            Toast.makeText(this, "Arrástrela arriba o abajo y suéltela donde no estorbe", Toast.LENGTH_SHORT).show();
        };
        v.setOnTouchListener((vv, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    x0[0] = ev.getRawX(); y0[0] = ev.getRawY(); yIni[0] = p.y;
                    moviendo[0] = false; abrio[0] = false;
                    hh.postDelayed(largo, 900);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = ev.getRawX() - x0[0], dy = ev.getRawY() - y0[0];
                    if (moviendo[0]) {
                        int alto = getResources().getDisplayMetrics().heightPixels;
                        p.y = Math.max(0, Math.min(alto - Util.dp(this, 80), yIni[0] + (int) dy));
                        try { wm.updateViewLayout(v, p); } catch (Exception ignored) {}
                        return true;
                    }
                    if (Math.abs(dx) > Util.dp(this, 8) || Math.abs(dy) > Util.dp(this, 8)) hh.removeCallbacks(largo);
                    if (!abrio[0] && (derecha ? -dx : dx) > Util.dp(this, 16)) { abrio[0] = true; abrirPanel(derecha); }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    hh.removeCallbacks(largo);
                    if (moviendo[0]) {
                        moviendo[0] = false;
                        g.setColor(derecha ? 0x7743A047 : 0x77909CAA);
                        prefs.edit().putInt(derecha ? "pestYDer" : "pestYIzq", p.y).apply();
                        Toast.makeText(this, "📌 Quedó fija aquí", Toast.LENGTH_SHORT).show();
                    }
                    // Un toque suelto NO abre: solo deslizando el dedo hacia adentro, para no estorbar a otras apps.
                    return true;
            }
            return false;
        });
        wm.addView(v, p);
        return v;
    }

    // ---------------- Paneles con secciones ----------------

    private static final String[] SEC_IZQ = {"⚡\nRápido", "📝\nOficina", "🧮\nObra", "🏠\nCasa", "🛣️\nViaje", "📷\nMedios"};
    private static final String[] SEC_DER = SEC_IZQ;
    private boolean ladoDerecha;
    private LinearLayout contenido;
    private Button[] pestanasSec;

    private void abrirPanel(boolean derecha) {
        if (panel != null) return;
        ladoDerecha = derecha;
        int pad = Util.dp(this, 6);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setPadding(pad, pad, pad, pad);
        GradientDrawable g = new GradientDrawable();
        g.setColor(derecha ? 0xF01B2A20 : 0xF0202830);
        float r = Util.dp(this, 16);
        g.setCornerRadii(derecha ? new float[]{r, r, 0, 0, 0, 0, r, r} : new float[]{0, 0, r, r, r, r, 0, 0});
        raiz.setBackground(g);

        String[] secs = derecha ? SEC_DER : SEC_IZQ;
        LinearLayout tabs = new LinearLayout(this);
        pestanasSec = new Button[secs.length];
        for (int i = 0; i < secs.length; i++) {
            final int k = i;
            Button b = new Button(this);
            b.setText(secs[i]);
            b.setAllCaps(false);
            b.setTextSize(10);
            b.setTextColor(Color.WHITE);
            b.setPadding(0, Util.dp(this, 4), 0, Util.dp(this, 4));
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setOnClickListener(v -> ponerSeccion(k));
            pestanasSec[i] = b;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Util.dp(this, 58), 1f);
            lp.setMargins(Util.dp(this, 1), 0, Util.dp(this, 1), 0);
            tabs.addView(b, lp);
        }
        raiz.addView(tabs);

        ScrollView sv = new ScrollView(this);
        contenido = new LinearLayout(this);
        contenido.setOrientation(LinearLayout.VERTICAL);
        sv.addView(contenido);
        raiz.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout pie = new LinearLayout(this);
        pie.setOrientation(LinearLayout.VERTICAL);
        boton(pie, "✕  Cerrar", this::cerrarPanel);
        raiz.addView(pie);

        raiz.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) { cerrarPanel(); return true; }
            return false;
        });
        // No tapa la barra de estado de arriba ni los botones ■ ● ◀ de abajo
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int arriba = dimSistema("status_bar_height"), abajo = dimSistema("navigation_bar_height");
        WindowManager.LayoutParams p = lp(Util.dp(this, 300), dm.heightPixels - arriba - abajo,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        p.gravity = (derecha ? Gravity.END : Gravity.START) | Gravity.TOP;
        p.y = arriba;
        wm.addView(raiz, p);
        panel = raiz;
        ponerSeccion(Math.min(prefs.getInt(derecha ? "secDer" : "secIzq", 0), secs.length - 1));
    }

    private void ponerSeccion(int k) {
        prefs.edit().putInt(ladoDerecha ? "secDer" : "secIzq", k).apply();
        for (int i = 0; i < pestanasSec.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == k ? (ladoDerecha ? 0xFF2E7D32 : 0xFF1565C0) : 0xFF34404C);
            g.setCornerRadius(Util.dp(this, 10));
            pestanasSec[i].setBackground(g);
        }
        contenido.removeAllViews();
        switch (k) {
            case 0: seccionAtajos(contenido, Util.dp(this, 8)); break;
            case 1: seccionOficina(contenido); break;
            case 2: seccionCalculo(contenido); break;
            case 3: seccionCasa(contenido); break;
            case 4: seccionViaje(contenido); seccionBuscar(contenido); break;
            default: seccionCamara(contenido);
        }
    }

    /** Fila de botones pequeños (para volumen y "buscar cerca"). */
    private void fila(LinearLayout l, String[] textos, Runnable[] acciones) {
        LinearLayout f = new LinearLayout(this);
        for (int i = 0; i < textos.length; i++) {
            Button b = boton(new LinearLayout(this), textos[i], acciones[i]);
            ((ViewGroup) b.getParent()).removeView(b);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, 0, 0, 0);
            b.setTextSize(14);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Util.dp(this, 50), 1f);
            p.setMargins(i == 0 ? 0 : Util.dp(this, 3), Util.dp(this, 6), 0, 0);
            f.addView(b, p);
        }
        l.addView(f);
    }

    private void titulito(LinearLayout l, String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFF9FB3C8);
        v.setTextSize(13);
        v.setPadding(Util.dp(this, 6), Util.dp(this, 12), 0, 0);
        l.addView(v);
    }

    private void seccionCasa(LinearLayout lista) {
        boton(lista, "📅  Recordatorios (almanaque)", () -> abrir(new Intent(this, RecordatoriosActivity.class)));
        boton(lista, "⏱  Reloj de cocina y recetas", () -> abrir(new Intent(this, RelojActivity.class)));
        boton(lista, "🌙  Reloj de noche", () -> abrir(new Intent(this, NocheActivity.class)));
        boton(lista, "💌  Saludos y memes", () -> abrir(new Intent(this, SaludosActivity.class)));
        boton(lista, "📚  Enciclopedia", () -> abrir(new Intent(this, EnciclopediaActivity.class)));
        boton(lista, "🏠  Mi Barra Inicio (escritorio)", () -> abrir(new Intent(this, InicioActivity.class)));
    }

    private void seccionAtajos(LinearLayout lista, int pad) {
        boton(lista, linternaPrendida ? "🔦  Apagar linterna" : "🔦  Linterna", this::linterna);
        boton(lista, "📸  Pantallazo", this::pantallazo);
        boton(lista, GrabarService.grabando ? "⏹  Parar grabación de pantalla" : "🎥  Grabar la pantalla", this::grabar);
        boton(lista, "📄  Copiar a Word ⬇ bajando", () -> copiar(true));
        boton(lista, "📄  Copiar a Word ⬆ subiendo", () -> copiar(false));
        boton(lista, "🖨  Imprimir pantalla", this::imprimirPantalla);
        titulito(lista, "Volumen");
        fila(lista, new String[]{"🔊 +", "🔉 −", "🔇"}, new Runnable[]{() -> volumen(AudioManager.ADJUST_RAISE),
                () -> volumen(AudioManager.ADJUST_LOWER), () -> volumen(AudioManager.ADJUST_TOGGLE_MUTE)});
        fila(lista, new String[]{"📶 Wi‑Fi", "📱 Datos"}, new Runnable[]{() -> abrir(new Intent(Settings.Panel.ACTION_WIFI)),
                () -> abrir(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))});
        boton(lista, "📴  Apagar / Reiniciar", () -> {
            cerrarPanel();
            performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
        });

        final TextView tl = new TextView(this);
        tl.setTextColor(Color.WHITE);
        tl.setTextSize(16);
        tl.setPadding(pad, Util.dp(this, 12), pad, 0);
        int luz = prefs.getInt("luz", 0);
        tl.setText("🌙  Luz azul: " + luz + "%");
        lista.addView(tl);
        SeekBar sb = new SeekBar(this);
        sb.setMax(80);
        sb.setProgress(luz);
        sb.setPadding(Util.dp(this, 16), Util.dp(this, 14), Util.dp(this, 16), Util.dp(this, 14));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                tl.setText("🌙  Luz azul: " + p + "%");
                aplicarFiltro(p);
                prefs.edit().putInt("luz", p).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        lista.addView(sb);
    }

    private void seccionOficina(LinearLayout lista) {
        boton(lista, "📝  Cuaderno (mini Word)", () -> abrir(new Intent(this, NotasActivity.class)));
        boton(lista, "📊  Cuentas (mini Excel)", () -> abrir(new Intent(this, HojaActivity.class)));
        boton(lista, "🧾  Cuenta de cobro", () -> abrir(new Intent(this, CobroActivity.class)));
        boton(lista, "🛒  Lista de compras", () -> abrir(new Intent(this, ComprasActivity.class)));
        boton(lista, "📇  Proveedores", () -> abrir(new Intent(this, ProveedoresActivity.class)));
        boton(lista, "📄  Escáner con nivel", () -> abrir(new Intent(this, EscanerActivity.class)));
        boton(lista, "📑  PDF: unir, separar, fotos", () -> abrir(new Intent(this, MainActivity.class)));
    }

    private void seccionCalculo(LinearLayout lista) {
        boton(lista, "🧮  Calculadora", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 0)));
        boton(lista, "📏  mm ↔ pulgadas", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 1)));
        boton(lista, "🏗️  Concreto", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 2)));
        boton(lista, "🧱  Ladrillo / farol", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 3)));
        boton(lista, "📸  Foto con medidas", () -> abrir(new Intent(this, MedidasActivity.class)));
        boton(lista, "📐  Nivel y plomada", () -> abrir(new Intent(this, NivelActivity.class)));
        boton(lista, "📐  Grados: techo, pasamanos, tubo", () -> abrir(new Intent(this, NivelActivity.class).putExtra("modo", 3)));
    }

    private void seccionCamara(LinearLayout lista) {
        boton(lista, "📷  Cámara Mi Barra (foto)", () -> abrir(new Intent(this, CamaraActivity.class)));
        boton(lista, "🎬  Cámara Mi Barra (video)", () -> abrir(new Intent(this, CamaraActivity.class).putExtra("video", true)));
        boton(lista, "🎵  Grabadora de voz", () -> abrir(new Intent(this, GrabadoraActivity.class)));
        boton(lista, GrabarService.grabando ? "⏹  Parar grabación de pantalla" : "🎥  Grabar la pantalla", this::grabar);
    }

    private boolean grabandoRecorrido() { return RecorridoService.estado(this).exists(); }

    private void seccionViaje(LinearLayout lista) {
        boolean rec = grandandoSeguro();
        boton(lista, "📍  Aquí estoy (mapa + dirección)", () -> abrir(new Intent(this, AquiEstoyActivity.class)));
        boton(lista, rec ? "🔴  Recorrido (grabando)" : "🛣️  Recorridos: grabar y ver", () -> abrir(new Intent(this, RecorridoActivity.class)));
        if (rec) boton(lista, "📌  Marcar boya aquí", () -> abrir(new Intent(this, RecorridoActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("boya", true)));
        boton(lista, "🏍  Antes de salir (revisión, pico y placa)", () -> abrir(new Intent(this, ChequeoActivity.class)));
        boton(lista, "🗺  Ruta de ciudad a ciudad", () -> abrir(new Intent(this, ParadasActivity.class).putExtra("modo", "viaje")));
        boton(lista, "📦  Reparto (varias paradas)", () -> abrir(new Intent(this, ParadasActivity.class).putExtra("modo", "reparto")));
        boton(lista, "📂  Mis rutas y repartos", () -> abrir(new Intent(this, ParadasActivity.class)));
    }

    private void seccionBuscar(LinearLayout lista) {
        titulito(lista, "🔎 Buscar cerca");
        fila(lista, new String[]{"⛽ Gasolina", "🍽 Comida"}, new Runnable[]{() -> buscarCerca("gasolinera"), () -> buscarCerca("restaurante")});
        fila(lista, new String[]{"🏥 Hospital", "💊 Droguería"}, new Runnable[]{() -> buscarCerca("hospital"), () -> buscarCerca("droguería")});
        fila(lista, new String[]{"🔧 Motos", "🚗 Carros"}, new Runnable[]{() -> buscarCerca("taller de motos"), () -> buscarCerca("taller mecánico")});
        fila(lista, new String[]{"🏧 Cajero", "🔩 Ferretería"}, new Runnable[]{() -> buscarCerca("cajero automático"), () -> buscarCerca("ferretería")});
    }

    private boolean grandandoSeguro() {
        try { return grabandoRecorrido(); } catch (Exception e) { return false; }
    }

    private void buscarCerca(String que) {
        Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=" + android.net.Uri.encode(que)));
        i.setPackage("com.google.android.apps.maps");
        if (i.resolveActivity(getPackageManager()) == null) {
            i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/maps/search/"
                    + android.net.Uri.encode(que + " cerca de mí")));
        }
        abrir(i);
    }

    private void cerrarPanel() {
        quitar(panel);
        panel = null;
    }

    private Button boton(LinearLayout l, String t, Runnable accion) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(Util.dp(this, 14), 0, Util.dp(this, 8), 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF34404C);
        g.setCornerRadius(Util.dp(this, 10));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Util.dp(this, 50));
        p.topMargin = Util.dp(this, 6);
        b.setOnClickListener(v -> accion.run());
        l.addView(b, p);
        return b;
    }

    // ---------------- Linterna (no necesita permiso de cámara) ----------------

    private boolean linternaPrendida;
    private android.hardware.camera2.CameraManager.TorchCallback vigiaLinterna;

    private String camaraConFlash(android.hardware.camera2.CameraManager cm) throws Exception {
        for (String id : cm.getCameraIdList()) {
            android.hardware.camera2.CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            Boolean f = ch.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
            Integer lado = ch.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
            if (Boolean.TRUE.equals(f) && lado != null && lado == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        return null;
    }

    private void linterna() {
        try {
            android.hardware.camera2.CameraManager cm = getSystemService(android.hardware.camera2.CameraManager.class);
            String id = camaraConFlash(cm);
            if (id == null) { Toast.makeText(this, "Este celular no tiene linterna", Toast.LENGTH_SHORT).show(); return; }
            if (vigiaLinterna == null) {
                final String cid = id;
                vigiaLinterna = new android.hardware.camera2.CameraManager.TorchCallback() {
                    @Override public void onTorchModeChanged(String camId, boolean prendida) {
                        if (camId.equals(cid)) linternaPrendida = prendida;
                    }
                };
                cm.registerTorchCallback(vigiaLinterna, new android.os.Handler(android.os.Looper.getMainLooper()));
            }
            cm.setTorchMode(id, !linternaPrendida);
            linternaPrendida = !linternaPrendida;
            cerrarPanel();
        } catch (Exception e) {
            Toast.makeText(this, "La linterna está ocupada (¿cámara abierta?)", Toast.LENGTH_SHORT).show();
        }
    }

    private void abrir(Intent i) {
        cerrarPanel();
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { aviso("No se pudo abrir"); }
    }

    // ---------------- Acciones sencillas ----------------

    private void volumen(int dir) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        try {
            am.adjustSuggestedStreamVolume(dir, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
        } catch (Exception e) {
            try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI); }
            catch (Exception ignored) { aviso("El celular no permitió cambiar el volumen"); }
        }
    }

    private void grabar() {
        cerrarPanel();
        if (GrabarService.grabando) {
            startService(new Intent(this, GrabarService.class).setAction(GrabarService.PARAR));
        } else {
            abrir(new Intent(this, GrabarActivity.class));
        }
    }

    // ---------------- Luz azul ----------------

    private void aplicarFiltro(int pct) {
        if (pct <= 0) {
            quitar(filtro);
            filtro = null;
            return;
        }
        int a = Math.round(pct / 100f * 200);
        int color = (a << 24) | 0x00FF8A20;
        if (filtro == null) {
            filtro = new View(this);
            WindowManager.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            wm.addView(filtro, p);
        }
        filtro.setBackgroundColor(color);
    }

    // ---------------- Pantallazo e imprimir ----------------

    private interface AlCapturar { void listo(Bitmap b); }

    private void capturar(AlCapturar cb) {
        cerrarPanel();
        final boolean habiaFiltro = filtro != null;
        if (habiaFiltro) filtro.setVisibility(View.GONE);
        if (pestana != null) pestana.setVisibility(View.GONE);
        if (pestanaDer != null) pestanaDer.setVisibility(View.GONE);
        if (botonAyuda != null) botonAyuda.setVisibility(View.INVISIBLE);
        h.postDelayed(() -> takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                restaurar(habiaFiltro);
                HardwareBuffer hb = r.getHardwareBuffer();
                Bitmap b = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                Bitmap c = b == null ? null : b.copy(Bitmap.Config.ARGB_8888, false);
                hb.close();
                if (c == null) { aviso("No se pudo tomar el pantallazo"); return; }
                cb.listo(c);
            }
            @Override public void onFailure(int codigo) {
                restaurar(habiaFiltro);
                // Plan B: el pantallazo normal del celular
                performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
            }
        }), 450);
    }

    private void restaurar(boolean habiaFiltro) {
        if (habiaFiltro && filtro != null) filtro.setVisibility(View.VISIBLE);
        if (pestana != null && prefs.getBoolean("barraVisible", false)) pestana.setVisibility(View.VISIBLE);
        if (pestanaDer != null) pestanaDer.setVisibility(View.VISIBLE);
        if (botonAyuda != null) botonAyuda.setVisibility(View.VISIBLE);
    }

    private void pantallazo() {
        capturar(b -> new Thread(() -> {
            try {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 100, o);
                Util.guardarBytes(this, "Pantallazo_" + Util.fecha() + ".png", "image/png", o.toByteArray());
                h.post(() -> aviso("📸 Pantallazo guardado en la Galería (álbum Mi Barra)"));
            } catch (Exception e) {
                h.post(() -> aviso("Error al guardar: " + e.getMessage()));
            }
        }).start());
    }

    private void imprimirPantalla() {
        capturar(b -> {
            try {
                File f = new File(getCacheDir(), "imprimir.png");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    b.compress(Bitmap.CompressFormat.PNG, 100, o);
                }
                Intent i = new Intent(this, PrintActivity.class)
                        .putExtra("imagen", f.getAbsolutePath())
                        .putExtra("titulo", "Pantalla " + Util.fecha());
                abrir(i);
            } catch (Exception e) {
                aviso("Error: " + e.getMessage());
            }
        });
    }

    // ---------------- Copiar a Word con desplazamiento ----------------

    private void copiar(boolean abajo) {
        if (copiando) return;
        cerrarPanel();
        copiando = true;
        bajando = abajo;
        acumulado = new ArrayList<>();
        sinNuevas = 0;
        vueltas = 0;
        origen = "";
        mostrarDetener();
        h.postDelayed(pasoR, 600);
    }

    private void mostrarDetener() {
        TextView t = new TextView(this);
        t.setText("⏹ Detener y guardar");
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        int p = Util.dp(this, 12);
        t.setPadding(p * 2, p, p * 2, p);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xEEC62828);
        g.setCornerRadius(Util.dp(this, 24));
        t.setBackground(g);
        t.setOnClickListener(v -> terminarCopia());
        WindowManager.LayoutParams lp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = Util.dp(this, 36);
        wm.addView(t, lp);
        botonDetener = t;
    }

    private void paso() {
        if (!copiando) return;
        AccessibilityNodeInfo raiz = getRootInActiveWindow();
        List<String> nuevas = new ArrayList<>();
        if (raiz != null) {
            if (origen.isEmpty() && raiz.getPackageName() != null) origen = raiz.getPackageName().toString();
            AccessibilityNodeInfo zona = desplazable(raiz);
            juntar(zona != null ? zona : raiz, nuevas);
        }
        int antes = acumulado.size();
        unir(nuevas);
        sinNuevas = (acumulado.size() == antes) ? sinNuevas + 1 : 0;
        vueltas++;
        // No para solo: sigue hasta que usted toque Detener. Si ya no sale nada nuevo, avisa que parece el final.
        boolean finalPagina = sinNuevas >= 3;
        if (botonDetener != null) botonDetener.setText(finalPagina
                ? "✅ Parece el final · toque para guardar (" + acumulado.size() + " líneas)"
                : "⏹ Detener y guardar (" + acumulado.size() + " líneas)");
        if (vueltas > 5000) { terminarCopia(); return; }
        deslizar();
        h.postDelayed(pasoR, finalPagina ? 1500 : 850);
    }

    /** Busca la zona que se desplaza (la conversación o la página), la más grande. */
    private AccessibilityNodeInfo desplazable(AccessibilityNodeInfo raiz) {
        AccessibilityNodeInfo[] mejor = new AccessibilityNodeInfo[1];
        long[] area = new long[1];
        buscar(raiz, mejor, area, 0);
        return mejor[0];
    }

    private void buscar(AccessibilityNodeInfo n, AccessibilityNodeInfo[] mejor, long[] area, int nivel) {
        if (n == null || nivel > 60) return;
        if (n.isScrollable()) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            long a = (long) r.width() * r.height();
            if (a > area[0]) { area[0] = a; mejor[0] = n; }
        }
        for (int i = 0; i < n.getChildCount(); i++) buscar(n.getChild(i), mejor, area, nivel + 1);
    }

    private void juntar(AccessibilityNodeInfo n, List<String> out) {
        if (n == null) return;
        CharSequence pk = n.getPackageName();
        if (pk != null && getPackageName().contentEquals(pk)) return;
        if (!n.isEditable()) {
            CharSequence t = n.getText();
            if (t != null) {
                for (String l : t.toString().split("\n")) {
                    l = l.trim();
                    if (!l.isEmpty()) out.add(l);
                }
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) juntar(n.getChild(i), out);
    }

    private void unir(List<String> nuevas) {
        if (nuevas.isEmpty()) return;
        if (acumulado.isEmpty()) { acumulado.addAll(nuevas); return; }
        if (bajando) {
            int k = solape(acumulado, nuevas);
            acumulado.addAll(nuevas.subList(k, nuevas.size()));
        } else {
            int k = solape(nuevas, acumulado);
            acumulado.addAll(0, nuevas.subList(0, nuevas.size() - k));
        }
    }

    /** Cuántas líneas del final de "a" coinciden con el comienzo de "b". */
    private static int solape(List<String> a, List<String> b) {
        int max = Math.min(a.size(), b.size());
        for (int k = max; k > 0; k--) {
            boolean ok = true;
            for (int i = 0; i < k; i++) {
                if (!a.get(a.size() - k + i).equals(b.get(i))) { ok = false; break; }
            }
            if (ok) return k;
        }
        return 0;
    }

    /** Desliza el dedo despacio (sin "lanzar") para avanzar menos de una pantalla. */
    private void deslizar() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.6f;
        float y1 = dm.heightPixels * 0.70f, y2 = dm.heightPixels * 0.35f;
        Path p = new Path();
        if (bajando) { p.moveTo(x, y1); p.lineTo(x, y2); }
        else { p.moveTo(x, y2); p.lineTo(x, y1); }
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 600)).build(), null, null);
    }

    private void terminarCopia() {
        if (!copiando) return;
        copiando = false;
        h.removeCallbacks(pasoR);
        quitar(botonDetener);
        botonDetener = null;
        final List<String> l = new ArrayList<>(acumulado);
        if (l.isEmpty()) { aviso("No encontré texto para copiar en esta pantalla"); return; }
        final String titulo = "Copiado de " + nombreApp(origen) + " — "
                + new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(new Date());
        aviso("⏳ Guardando el Word…");
        new Thread(() -> {
            try {
                Util.guardarBytes(this, "Copia_" + Util.fecha() + ".docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        Util.crearDocx(titulo, l));
                h.post(() -> aviso("📄 Word guardado en Descargas (" + l.size() + " líneas)"));
            } catch (Exception e) {
                h.post(() -> aviso("Error al guardar: " + e.getMessage()));
            }
        }).start();
    }

    private static String nombreApp(String pk) {
        if (pk == null || pk.isEmpty()) return "la pantalla";
        if (pk.startsWith("com.whatsapp")) return "WhatsApp";
        if (pk.equals("com.android.chrome")) return "Chrome";
        if (pk.contains("browser")) return "el navegador";
        return pk;
    }
}
