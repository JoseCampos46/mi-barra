package co.jose.djchepe;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Random;

/**
 * v7: sonidos de emisora profesional — barrido de aire (whoosh), impacto grave y las ráfagas
 * con la voz de Jose ("DJ Chepe Gallego" y "Gallego" que se va alejando en eco).
 */
public final class Emisora {

    static final int SR = 44100;

    /** Barrido de aire que sube y cruza de izquierda a derecha. Estéreo, pico = 1. */
    public static float[] whoosh(double secs, long seed) {
        int n = (int) (secs * SR);
        Random r = new Random(seed);
        float[] m = new float[n];
        double b0 = 0, b2 = 0, a1 = 0, a2 = 0, x1 = 0, x2 = 0, y1 = 0, y2 = 0;
        for (int i = 0; i < n; i++) {
            if (i % 256 == 0) {
                double x = i / (double) n;
                double f = 300 * Math.pow(20, x);            // de 300 a 6000 Hz
                double w = 2 * Math.PI * f / SR, al = Math.sin(w) / (2 * 1.0), a0 = 1 + al;
                b0 = al / a0; b2 = -al / a0; a1 = -2 * Math.cos(w) / a0; a2 = (1 - al) / a0;
            }
            double xin = r.nextFloat() * 2 - 1;
            double y = b0 * xin + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1; x1 = xin; y2 = y1; y1 = y;
            m[i] = (float) y;
        }
        float pk = 1e-6f;
        for (int i = 0; i < n; i++) {
            double x = i / (double) n;
            double env = Math.pow(x, 2.5);
            int fin = n - i;
            if (fin < SR / 20) env *= fin / (SR / 20.0);
            m[i] *= (float) env;
            pk = Math.max(pk, Math.abs(m[i]));
        }
        float[] st = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double p = i / (double) n * Math.PI / 2;
            float v = m[i] / pk;
            st[2 * i] = v * (float) Math.cos(p);
            st[2 * i + 1] = v * (float) Math.sin(p);
        }
        return st;
    }

    /** Golpe grave ("bum") con un toque de aire. Estéreo, pico = 1. */
    public static float[] impacto(double secs) {
        int n = (int) (secs * SR);
        Random r = new Random(5);
        float[] st = new float[n * 2];
        double ph = 0, lp = 0;
        float pk = 1e-6f;
        float[] m = new float[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            double fr = 40 + 80 * Math.exp(-t * 12);
            ph += 2 * Math.PI * fr / SR;
            double boom = Math.sin(ph) * Math.exp(-t * 2.8);
            double nz = (r.nextFloat() * 2 - 1) * Math.exp(-t * 35) * 0.35;
            lp += (nz - lp) * 0.3;                            // aire suave, sin chasquido
            m[i] = (float) (boom + lp);
            pk = Math.max(pk, Math.abs(m[i]));
        }
        for (int i = 0; i < n; i++) { st[2 * i] = m[i] / pk; st[2 * i + 1] = m[i] / pk; }
        return st;
    }

    /** Lo mismo en mono para la botonera (short, como los demás sonidos). */
    static short[] mono(float[] st, float vol) {
        short[] s = new short[st.length / 2];
        for (int i = 0; i < s.length; i++) s[i] = (short) ((st[2 * i] + st[2 * i + 1]) * 0.5f * vol * 32000f);
        return s;
    }

    /** Carga una ráfaga que viene dentro de la app (assets) como estéreo 44.100 Hz. */
    public static short[] cargar(Context ctx, String asset) throws Exception {
        File f = new File(ctx.getCacheDir(), "v7_" + asset);
        if (!f.exists() || f.length() == 0) {
            try (InputStream in = ctx.getAssets().open(asset); FileOutputStream os = new FileOutputStream(f)) {
                byte[] b = new byte[16384];
                int k;
                while ((k = in.read(b)) > 0) os.write(b, 0, k);
            }
        }
        Dec.Pcm p = Dec.decodeStereo(ctx, Uri.fromFile(f), 30);
        if (p.sr == SR) return Arrays.copyOf(p.d, p.frames * 2);
        Resampler rs = new Resampler();
        short[] o = rs.process(p.d, p.frames, 2, p.sr);
        return Arrays.copyOf(o, rs.frames * 2);
    }

    /** Pasa la voz a float con el volumen pedido (fuerza promedio mientras habla). */
    public static float[] nivelar(short[] v, double rmsObjetivo) {
        int peak = 1;
        for (short s : v) peak = Math.max(peak, Math.abs(s));
        double sum = 0;
        long n = 0;
        for (short s : v) if (Math.abs(s) > peak * 0.05) { sum += (double) s * s; n++; }
        double rms = n > 0 ? Math.sqrt(sum / n) : 1;
        float g = (float) (rmsObjetivo / Math.max(1, rms));
        g = Math.min(g, 0.95f * 32767f / peak * 1.4f);          // el limitador se encarga del resto
        float[] f = new float[v.length];
        for (int i = 0; i < v.length; i++) f[i] = v[i] * g;
        return f;
    }

    /** Cuadro donde empieza y donde termina de hablar. */
    public static int[] habla(float[] st) {
        int n = st.length / 2;
        float pk = 1e-6f;
        for (float x : st) pk = Math.max(pk, Math.abs(x));
        float thr = pk * 0.1f;
        int a = 0, b = n - 1;
        while (a < n - 1 && Math.max(Math.abs(st[2 * a]), Math.abs(st[2 * a + 1])) < thr) a++;
        while (b > a && Math.max(Math.abs(st[2 * b]), Math.abs(st[2 * b + 1])) < thr) b--;
        return new int[]{a, b};
    }

    /** Suma src (estéreo) dentro de dst desde el cuadro "at" (puede ser negativo: se corta). */
    public static void sumar(float[] dst, float[] src, int at, float g) {
        int nd = dst.length / 2, ns = src.length / 2;
        for (int k = 0; k < ns; k++) {
            int o = at + k;
            if (o < 0) continue;
            if (o >= nd) break;
            dst[2 * o] += src[2 * k] * g;
            dst[2 * o + 1] += src[2 * k + 1] * g;
        }
    }

    private Emisora() {}
}
