package co.jose.micatalogo;

import android.content.ContentResolver;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

/**
 * Habla con Gemini usando la llave gratis de Google AI Studio.
 * 1) Mirar una foto o un video y leer lo que dice cada producto (sin inventar).
 * 2) Buscar en internet la ficha técnica y las tiendas con precio (con Google).
 */
final class Gemini {

    private static final String BASE = "https://generativelanguage.googleapis.com";
    private static final String[] MODELOS = {"gemini-flash-latest", "gemini-2.5-flash"};

    /** Error entendible para mostrarle a Jose. */
    static class Falla extends Exception {
        Falla(String m) { super(m); }
    }

    private Gemini() {}

    // ───────────────────────── 1. Mirar foto o video ─────────────────────────

    private static final String PIDE_LEER =
            "Eres el ayudante de un catálogo de productos en Colombia. Mira con cuidado %s.\n"
            + "Haz una lista de cada producto DISTINTO que se vea con claridad (máximo 30). Si el mismo producto aparece varias veces, ponlo una sola vez.\n"
            + "REGLA DE ORO: escribe SOLO lo que se pueda LEER o VER en la imagen. No inventes ni adivines. Si un dato no se ve, déjalo vacío \"\".\n"
            + "Responde SOLO con un arreglo JSON, sin texto antes ni después, así:\n"
            + "[{\"nombre\":\"qué es, corto y en español (ej. Cafetera percoladora)\",\"marca\":\"\",\"referencia\":\"modelo o referencia escrita\","
            + "\"potencia\":\"vatios, HP o amperios si están escritos\",\"codigo\":\"números del código de barras si se leen completos\","
            + "\"otros\":\"capacidad, voltaje, medidas u otros datos ESCRITOS en el producto o la caja\",\"segundo\":0,"
            + "\"caja\":[ymin,xmin,ymax,xmax]}]\n"
            + "\"segundo\" es el segundo del video donde mejor se ve el producto (0 si es una foto). "
            + "\"caja\" es el recuadro del producto en ese momento, con números de 0 a 1000.";

    /** Lee los productos de una foto (JPEG). */
    static JSONArray leerFoto(String llave, byte[] jpeg) throws Falla {
        JSONObject parte = new JSONObject();
        try {
            parte.put("inline_data", new JSONObject().put("mime_type", "image/jpeg")
                    .put("data", android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)));
        } catch (Exception e) { throw new Falla("No pude preparar la foto"); }
        return comoLista(preguntar(llave, parte, String.format(PIDE_LEER, "esta foto"), false).texto);
    }

    /** Sube el video a Gemini (puede ser grande) y lee los productos. */
    static JSONArray leerVideo(String llave, ContentResolver cr, Uri video, String mime, long tamano, Avance avance) throws Falla {
        String uriArchivo = subir(llave, cr, video, mime, tamano, avance);
        JSONObject parte = new JSONObject();
        try {
            parte.put("file_data", new JSONObject().put("mime_type", mime).put("file_uri", uriArchivo));
        } catch (Exception e) { throw new Falla("No pude preparar el video"); }
        avance.decir("Gemini está mirando el video…");
        return comoLista(preguntar(llave, parte, String.format(PIDE_LEER, "este video recorriendo una tienda"), false).texto);
    }

    interface Avance { void decir(String s); }

    private static final String PIDE_TARJETA =
            "Esta es la foto de la tarjeta de presentación de un almacén o negocio en Colombia, o la foto del frente del almacén (letrero, vitrina, avisos pegados).\n"
            + "Lee SOLO lo que está escrito. No inventes nada; si un dato no está, déjalo vacío \"\".\n"
            + "Responde SOLO con un objeto JSON, sin texto antes ni después:\n"
            + "{\"nombre\":\"nombre del almacén\",\"vende\":\"qué vende o qué servicio presta, corto\",\"contacto\":\"nombre de la persona si aparece\","
            + "\"telefonos\":[\"cada teléfono o celular tal como está escrito\"],\"whatsapp\":\"número de WhatsApp si lo indica\","
            + "\"direccion\":\"\",\"ciudad\":\"\",\"correo\":\"\",\"web\":\"\",\"redes\":\"Instagram, Facebook u otras\",\"horario\":\"\","
            + "\"caja_tarjeta\":[ymin,xmin,ymax,xmax],\"caja_logo\":[ymin,xmin,ymax,xmax]}\n"
            + "caja_tarjeta es el borde de la tarjeta en la foto (si es el frente del almacén, toda la foto: [0,0,1000,1000]) y caja_logo el logo o dibujo del almacén (vacío [] si no tiene), con números de 0 a 1000.";

    private static final String PIDE_CASA =
            "Esta es la foto de una casa, apartamento o lote que están vendiendo o arrendando en Colombia.\n"
            + "Lee SOLO lo que está escrito en los avisos (Se vende, Se arrienda, teléfonos, precio, área, etc.). No inventes nada; si no está, \"\".\n"
            + "Responde SOLO con un objeto JSON, sin texto antes ni después:\n"
            + "{\"nombre\":\"Casa en venta, Apartamento en arriendo, Lote en venta… según el aviso\",\"precio\":\"tal como está escrito\","
            + "\"detalles\":\"área, habitaciones, baños, pisos u otros datos escritos\",\"contacto\":\"nombre si aparece\","
            + "\"telefonos\":[\"cada teléfono tal como está escrito\"],\"whatsapp\":\"\",\"inmobiliaria\":\"\",\"direccion\":\"si está escrita\","
            + "\"caja_tarjeta\":[0,0,1000,1000],\"caja_logo\":[]}";

    /** Lee los avisos de una casa en venta. */
    static JSONObject leerCasa(String llave, byte[] jpeg) throws Falla {
        JSONObject parte = new JSONObject();
        try {
            parte.put("inline_data", new JSONObject().put("mime_type", "image/jpeg")
                    .put("data", android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)));
        } catch (Exception e) { throw new Falla("No pude preparar la foto"); }
        try {
            return comoObjeto(preguntar(llave, parte, PIDE_CASA, false).texto);
        } catch (Falla f) {
            if (f.getMessage() != null && f.getMessage().startsWith("Gemini no encontró la ficha")) return new JSONObject();
            throw f;
        }
    }

    /** Lee una tarjeta de presentación o el frente de un almacén. */
    static JSONObject leerTarjeta(String llave, byte[] jpeg) throws Falla {
        JSONObject parte = new JSONObject();
        try {
            parte.put("inline_data", new JSONObject().put("mime_type", "image/jpeg")
                    .put("data", android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)));
        } catch (Exception e) { throw new Falla("No pude preparar la foto"); }
        try {
            return comoObjeto(preguntar(llave, parte, PIDE_TARJETA, false).texto);
        } catch (Falla f) {
            if (f.getMessage() != null && f.getMessage().startsWith("Gemini no encontró la ficha"))
                throw new Falla("No pude leer la tarjeta ni el letrero. Tome la foto de frente, cerquita y con buena luz.");
            throw f;
        }
    }

    // ───────────────────────── 2. Ficha y precios con Google ─────────────────────────

    private static final String PIDE_BUSCAR =
            "Busca en internet este producto: %s.\n"
            + "Necesito su ficha técnica y dónde comprarlo en Colombia con el precio de hoy.\n"
            + "REGLAS: usa la página oficial del fabricante o de tiendas serias. Pon SOLO datos que hayas encontrado en una página; "
            + "si no lo confirmaste, \"confirmado\": false. NO inventes precios, tiendas ni enlaces.\n"
            + "Tiendas: primero de Colombia (Alkosto, Ktronix, Éxito, Falabella, Homecenter, Mercado Libre, Olímpica, Jumbo u otras), "
            + "precio en pesos colombianos (moneda COP). Si está en Amazon, agrégalo con precio en dólares (moneda USD). Máximo 8 tiendas.\n"
            + "Responde SOLO con un objeto JSON, sin texto antes ni después:\n"
            + "{\"nombre\":\"qué es, corto en español\",\"marca\":\"\",\"referencia\":\"\",\"codigo\":\"\","
            + "\"ficha\":[{\"dato\":\"Potencia\",\"valor\":\"1090 W\",\"fuente\":\"dirección de la página donde lo viste\",\"confirmado\":true}],"
            + "\"tiendas\":[{\"tienda\":\"Alkosto\",\"precio\":249900,\"moneda\":\"COP\",\"url\":\"\"}]}\n"
            + "En la ficha incluye, si existen: Potencia, Voltaje, Capacidad, Medidas, Peso, Material, Garantía y lo más importante del producto.";

    /** Resultado de la búsqueda: el JSON y las páginas que Google consultó. */
    static final class Busqueda {
        JSONObject datos;
        JSONArray fuentes;
    }

    static Busqueda buscarFicha(String llave, JSONObject p) throws Falla {
        StringBuilder q = new StringBuilder();
        String n = p.optString("nombre"), m = p.optString("marca"), r = p.optString("referencia"), k = p.optString("codigo");
        if (!n.isEmpty()) q.append(n);
        if (!m.isEmpty()) q.append(", marca ").append(m);
        if (!r.isEmpty()) q.append(", referencia ").append(r);
        if (!k.isEmpty()) q.append(", código de barras ").append(k);
        String o = p.optString("otros");
        if (!o.isEmpty()) q.append(" (datos de la etiqueta: ").append(o).append(")");
        Respuesta res = preguntar(llave, null, String.format(PIDE_BUSCAR, q.toString()), true);
        Busqueda b = new Busqueda();
        b.datos = comoObjeto(res.texto);
        b.fuentes = res.fuentes;
        return b;
    }

    // ───────────────────────── Conversación con el servidor ─────────────────────────

    private static final class Respuesta {
        String texto;
        JSONArray fuentes = new JSONArray();
    }

    private static Respuesta preguntar(String llave, JSONObject parteArchivo, String instruccion, boolean conGoogle) throws Falla {
        JSONObject cuerpo = new JSONObject();
        try {
            JSONArray partes = new JSONArray();
            if (parteArchivo != null) partes.put(parteArchivo);
            partes.put(new JSONObject().put("text", instruccion));
            cuerpo.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", partes)));
            JSONObject cfg = new JSONObject().put("temperature", 0.1);
            if (conGoogle) cuerpo.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));
            else cfg.put("responseMimeType", "application/json");
            cuerpo.put("generationConfig", cfg);
        } catch (Exception e) { throw new Falla("No pude preparar la pregunta"); }

        Falla ultima = null;
        for (String modelo : MODELOS) {
            try {
                String r = pedir("POST", BASE + "/v1beta/models/" + modelo + ":generateContent", llave,
                        cuerpo.toString().getBytes(StandardCharsets.UTF_8), "application/json", 120000);
                return leerRespuesta(r);
            } catch (Modelo404 e) {
                ultima = new Falla("Gemini no tiene disponible el modelo " + modelo);
            }
        }
        throw ultima != null ? ultima : new Falla("Gemini no respondió");
    }

    private static Respuesta leerRespuesta(String json) throws Falla {
        try {
            JSONObject o = new JSONObject(json);
            JSONArray cand = o.optJSONArray("candidates");
            if (cand == null || cand.length() == 0) {
                JSONObject fb = o.optJSONObject("promptFeedback");
                throw new Falla(fb != null ? "Gemini no quiso responder esta vez. Pruebe otra foto." : "Gemini no respondió nada");
            }
            JSONObject c0 = cand.getJSONObject(0);
            Respuesta r = new Respuesta();
            StringBuilder sb = new StringBuilder();
            JSONObject cont = c0.optJSONObject("content");
            JSONArray partes = cont != null ? cont.optJSONArray("parts") : null;
            if (partes != null) for (int i = 0; i < partes.length(); i++) {
                JSONObject pa = partes.optJSONObject(i);
                if (pa != null && !pa.optBoolean("thought", false)) sb.append(pa.optString("text"));
            }
            r.texto = sb.toString();
            JSONObject gm = c0.optJSONObject("groundingMetadata");
            JSONArray ch = gm != null ? gm.optJSONArray("groundingChunks") : null;
            if (ch != null) for (int i = 0; i < ch.length(); i++) {
                JSONObject w = ch.optJSONObject(i) != null ? ch.optJSONObject(i).optJSONObject("web") : null;
                if (w != null && !w.optString("uri").isEmpty())
                    r.fuentes.put(new JSONObject().put("titulo", w.optString("title", "Página")).put("url", w.optString("uri")));
            }
            if (r.texto.trim().isEmpty()) throw new Falla("Gemini respondió vacío. Intente de nuevo.");
            return r;
        } catch (Falla f) {
            throw f;
        } catch (Exception e) {
            throw new Falla("No entendí la respuesta de Gemini");
        }
    }

    /** Sube un archivo grande por partes (método "resumable" de Google) y espera a que quede listo. */
    private static String subir(String llave, ContentResolver cr, Uri video, String mime, long tamano, Avance avance) throws Falla {
        String urlSubida;
        try {
            avance.decir("Subiendo el video a Gemini…");
            HttpURLConnection c = abrir("POST", BASE + "/upload/v1beta/files", llave, 60000);
            c.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
            c.setRequestProperty("X-Goog-Upload-Command", "start");
            c.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(tamano));
            c.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime);
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            try (OutputStream o = c.getOutputStream()) {
                o.write("{\"file\":{\"display_name\":\"video_catalogo\"}}".getBytes(StandardCharsets.UTF_8));
            }
            revisar(c);
            urlSubida = c.getHeaderField("x-goog-upload-url");
            c.disconnect();
            if (urlSubida == null) throw new Falla("Gemini no dio dónde subir el video");

            HttpURLConnection s = (HttpURLConnection) new URL(urlSubida).openConnection();
            s.setRequestMethod("POST");
            s.setConnectTimeout(30000);
            s.setReadTimeout(300000);
            s.setDoOutput(true);
            s.setFixedLengthStreamingMode(tamano);
            s.setRequestProperty("X-Goog-Upload-Offset", "0");
            s.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
            long enviados = 0;
            int ultimoPct = -1;
            try (InputStream in = cr.openInputStream(video); OutputStream o = s.getOutputStream()) {
                if (in == null) throw new Falla("No pude abrir el video");
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    o.write(buf, 0, n);
                    enviados += n;
                    int pct = (int) (enviados * 100 / Math.max(1, tamano));
                    if (pct != ultimoPct && pct % 5 == 0) { ultimoPct = pct; avance.decir("Subiendo el video… " + pct + " %"); }
                }
            }
            String r = revisar(s);
            JSONObject archivo = new JSONObject(r).getJSONObject("file");
            String nombre = archivo.getString("name"), uri = archivo.getString("uri");
            String estado = archivo.optString("state", "PROCESSING");
            int vueltas = 0;
            while (!"ACTIVE".equals(estado)) {
                if ("FAILED".equals(estado)) throw new Falla("Gemini no pudo leer ese video. Pruebe con otro.");
                if (++vueltas > 90) throw new Falla("Gemini se demoró mucho preparando el video");
                avance.decir("Gemini está preparando el video… " + (vueltas * 3) + " s");
                Thread.sleep(3000);
                String g = pedir("GET", BASE + "/v1beta/" + nombre, llave, null, null, 30000);
                estado = new JSONObject(g).optString("state", "PROCESSING");
            }
            return uri;
        } catch (Falla f) {
            throw f;
        } catch (UnknownHostException e) {
            throw new Falla("No hay internet. Conéctese y vuelva a intentar.");
        } catch (Exception e) {
            throw new Falla("Se cortó la subida del video. Revise el internet y vuelva a intentar.");
        }
    }

    private static final class Modelo404 extends Falla { Modelo404() { super("modelo"); } }

    private static HttpURLConnection abrir(String metodo, String url, String llave, int tiempo) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(metodo);
        c.setConnectTimeout(30000);
        c.setReadTimeout(tiempo);
        c.setRequestProperty("x-goog-api-key", llave);
        return c;
    }

    private static String pedir(String metodo, String url, String llave, byte[] cuerpo, String tipo, int tiempo) throws Falla {
        try {
            HttpURLConnection c = abrir(metodo, url, llave, tiempo);
            if (cuerpo != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", tipo);
                c.setFixedLengthStreamingMode(cuerpo.length);
                try (OutputStream o = c.getOutputStream()) { o.write(cuerpo); }
            }
            String r = revisar(c);
            c.disconnect();
            return r;
        } catch (Falla f) {
            throw f;
        } catch (UnknownHostException e) {
            throw new Falla("No hay internet. Conéctese y vuelva a intentar.");
        } catch (java.net.SocketTimeoutException e) {
            throw new Falla("Gemini se demoró mucho en responder. Intente de nuevo.");
        } catch (Exception e) {
            throw new Falla("No me pude comunicar con Gemini. Revise el internet.");
        }
    }

    /** Lee la respuesta y traduce los errores de Google a palabras sencillas. */
    private static String revisar(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String cuerpo = in == null ? "" : leerTodo(in);
        if (code < 400) return cuerpo;
        String msg = "";
        try { msg = new JSONObject(cuerpo).getJSONObject("error").optString("message"); } catch (Exception ignored) {}
        String bajo = msg.toLowerCase(java.util.Locale.ROOT);
        if (code == 429) throw new Falla("Se acabó el cupo gratis de Gemini por ahora. Espere un rato o intente mañana. No le cobran nada.");
        if (code == 404 && bajo.contains("model")) throw new Modelo404();
        if (bajo.contains("api key") || bajo.contains("api_key") || code == 401 || code == 403)
            throw new Falla("La llave de Gemini no sirve. Toque 🔑 Llave y péguela de nuevo.");
        if (code >= 500) throw new Falla("Gemini está ocupado en este momento. Intente en un ratico.");
        throw new Falla("Gemini dijo que no (" + code + "). " + (msg.length() > 120 ? msg.substring(0, 120) : msg));
    }

    static String leerTodo(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toString("UTF-8");
    }

    // ───────────────────────── Sacar el JSON del texto ─────────────────────────

    private static String sinAdornos(String t) {
        return t.replace("```json", "").replace("```JSON", "").replace("```", "").trim();
    }

    static JSONArray comoLista(String t) throws Falla {
        String s = sinAdornos(t);
        try {
            int a = s.indexOf('['), b = s.lastIndexOf(']');
            if (a >= 0 && b > a) return new JSONArray(s.substring(a, b + 1));
            int x = s.indexOf('{'), y = s.lastIndexOf('}');
            if (x >= 0 && y > x) return new JSONArray().put(new JSONObject(s.substring(x, y + 1)));
        } catch (Exception ignored) {}
        throw new Falla("Gemini no encontró productos claros. Acérquese más y con buena luz.");
    }

    static JSONObject comoObjeto(String t) throws Falla {
        String s = sinAdornos(t);
        try {
            int x = s.indexOf('{'), y = s.lastIndexOf('}');
            if (x >= 0 && y > x) return new JSONObject(s.substring(x, y + 1));
        } catch (Exception ignored) {}
        throw new Falla("Gemini no encontró la ficha de ese producto en internet.");
    }
}
