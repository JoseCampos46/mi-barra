package co.jose.micatalogo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** El catálogo: una lista de productos guardada en el celular, con fotos pequeñas (unos 20 KB cada una). */
final class Almacen {

    private static JSONArray productos;
    private static long ultimoId;

    private Almacen() {}

    private static File archivo(Context c) { return new File(c.getFilesDir(), "catalogo.json"); }

    static File carpetaFotos(Context c) {
        File f = new File(c.getFilesDir(), "fotos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    static synchronized JSONArray todos(Context c) {
        if (productos == null) {
            productos = new JSONArray();
            File f = archivo(c);
            if (f.exists()) {
                try (InputStream in = new FileInputStream(f)) {
                    byte[] b = new byte[(int) f.length()];
                    int n = 0;
                    while (n < b.length) {
                        int r = in.read(b, n, b.length - n);
                        if (r < 0) break;
                        n += r;
                    }
                    productos = new JSONArray(new String(b, 0, n, StandardCharsets.UTF_8));
                } catch (Exception ignored) {}
            }
        }
        return productos;
    }

    static synchronized void guardar(Context c) {
        try {
            File tmp = new File(c.getFilesDir(), "catalogo.tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) {
                o.write(todos(c).toString().getBytes(StandardCharsets.UTF_8));
            }
            tmp.renameTo(archivo(c));
        } catch (Exception ignored) {}
    }

    static synchronized long nuevoId() {
        long t = System.currentTimeMillis();
        if (t <= ultimoId) t = ultimoId + 1;
        ultimoId = t;
        return t;
    }

    /** Los productos, del más nuevo al más viejo. */
    static synchronized List<JSONObject> lista(Context c) { return lista(c, ""); }

    /** Sitios guardados: "almacen" (tarjetas y frentes) o "casa" (casas en venta). Del más nuevo al más viejo. */
    static synchronized List<JSONObject> sitios(Context c, String tipo) { return lista(c, tipo); }

    private static List<JSONObject> lista(Context c, String tipo) {
        JSONArray a = todos(c);
        List<JSONObject> r = new ArrayList<>();
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && tipo.equals(o.optString("tipo"))) r.add(o);
        }
        return r;
    }

    static synchronized JSONObject buscar(Context c, long id) {
        JSONArray a = todos(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optLong("id") == id) return o;
        }
        return null;
    }

    static synchronized void agregar(Context c, JSONObject p) {
        todos(c).put(p);
        guardar(c);
    }

    static synchronized void borrar(Context c, long id) {
        JSONArray a = todos(c), n = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (o.optLong("id") == id) {
                for (String k : new String[]{"foto", "logo", "dueno", "mapa"}) {
                    String f = o.optString(k);
                    if (!f.isEmpty()) new File(carpetaFotos(c), f).delete();
                }
            } else n.put(o);
        }
        productos = n;
        guardar(c);
    }

    /** ¿Ya está en el catálogo? Se compara por código de barras o por marca + referencia. */
    static synchronized JSONObject repetido(Context c, String marca, String referencia, String codigo) {
        String m = limpio(marca), r = limpio(referencia), k = limpio(codigo);
        for (JSONObject o : lista(c)) {
            if (!k.isEmpty() && k.equals(limpio(o.optString("codigo")))) return o;
            if (!r.isEmpty() && r.equals(limpio(o.optString("referencia")))
                    && (m.isEmpty() || m.equals(limpio(o.optString("marca"))))) return o;
        }
        return null;
    }

    static String limpio(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    /** Guarda la foto pequeña (máximo 320 px, unos 20 KB) y devuelve el nombre del archivo. */
    static String guardarFoto(Context c, Bitmap b, long id) { return guardarFoto(c, b, id, 320, 80); }

    /** Tarjetas: 720 px para que se lean los números (unos 40 KB). */
    static String guardarFoto(Context c, Bitmap b, long id, int max, int calidad) {
        return guardarFotoNombre(c, b, String.valueOf(id), max, calidad);
    }

    static String guardarFotoNombre(Context c, Bitmap b, String base, int max, int calidad) {
        if (b == null) return "";
        try {
            int lado = Math.max(b.getWidth(), b.getHeight());
            Bitmap p = b;
            if (lado > max) p = Bitmap.createScaledBitmap(b, b.getWidth() * max / lado, b.getHeight() * max / lado, true);
            String nombre = base + ".jpg";
            try (FileOutputStream o = new FileOutputStream(new File(carpetaFotos(c), nombre))) {
                p.compress(Bitmap.CompressFormat.JPEG, calidad, o);
            }
            return nombre;
        } catch (Exception e) {
            return "";
        }
    }

    static Bitmap foto(Context c, JSONObject p) { return imagen(c, p, "foto"); }

    static Bitmap logo(Context c, JSONObject p) { return imagen(c, p, "logo"); }

    static Bitmap imagenDe(Context c, JSONObject p, String clave) { return imagen(c, p, clave); }

    private static Bitmap imagen(Context c, JSONObject p, String clave) {
        String n = p.optString(clave);
        if (n.isEmpty()) return null;
        File f = new File(carpetaFotos(c), n);
        return f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
    }

    static String hoy() {
        return new SimpleDateFormat("d MMM yyyy", new Locale("es", "CO")).format(new Date());
    }

    /** El precio más bajo de las tiendas en pesos (o el primero si solo hay en dólares). */
    static JSONObject masBarata(JSONObject p) {
        JSONArray t = p.optJSONArray("tiendas");
        if (t == null) return null;
        JSONObject mejor = null;
        for (int i = 0; i < t.length(); i++) {
            JSONObject o = t.optJSONObject(i);
            if (o == null || o.optDouble("precio", 0) <= 0) continue;
            boolean pesos = !o.optString("moneda").toUpperCase(Locale.ROOT).startsWith("USD");
            if (mejor == null) { mejor = o; continue; }
            boolean mejorPesos = !mejor.optString("moneda").toUpperCase(Locale.ROOT).startsWith("USD");
            if (pesos && !mejorPesos) mejor = o;
            else if (pesos == mejorPesos && o.optDouble("precio") < mejor.optDouble("precio")) mejor = o;
        }
        return mejor;
    }

    /** Nombre corto para mostrar: "Cafetera Hamilton Beach". */
    static String titulo(JSONObject p) {
        String n = p.optString("nombre").trim(), m = p.optString("marca").trim();
        if (n.isEmpty()) n = "Producto";
        if (!m.isEmpty() && !n.toLowerCase(Locale.ROOT).contains(m.toLowerCase(Locale.ROOT))) n = n + " " + m;
        return n;
    }

    /** Lo que se usa para buscar el producto en internet o en Mi Barra. */
    static String busqueda(JSONObject p) {
        StringBuilder s = new StringBuilder();
        for (String k : new String[]{"nombre", "marca", "referencia"}) {
            String v = p.optString(k).trim();
            if (!v.isEmpty()) s.append(s.length() > 0 ? " " : "").append(v);
        }
        if (s.length() == 0) s.append(p.optString("codigo"));
        return s.toString();
    }
}
