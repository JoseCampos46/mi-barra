package co.jose.micatalogo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.CancellationSignal;

/** Toma la ubicación una sola vez (no deja el GPS prendido gastando batería). */
final class Gps {

    interface Listo { void ubicacion(Location l); }

    private Gps() {}

    static boolean tienePermiso(Context c) {
        return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Devuelve la mejor ubicación que consiga en unos segundos (o la última conocida). */
    @SuppressWarnings("MissingPermission")
    static void pedir(Context c, Listo listo) {
        if (!tienePermiso(c)) { listo.ubicacion(null); return; }
        LocationManager lm = c.getSystemService(LocationManager.class);
        if (lm == null) { listo.ubicacion(null); return; }
        final boolean[] hecho = {false};
        final Location[] ultima = {ultimaConocida(lm)};
        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        Runnable fin = () -> {
            if (hecho[0]) return;
            hecho[0] = true;
            listo.ubicacion(ultima[0]);
        };
        if (Build.VERSION.SDK_INT >= 30) {
            CancellationSignal cancelar = new CancellationSignal();
            for (String prov : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                try {
                    if (!lm.isProviderEnabled(prov)) continue;
                    lm.getCurrentLocation(prov, cancelar, c.getMainExecutor(), l -> {
                        if (l == null || hecho[0]) return;
                        if (ultima[0] == null || l.getAccuracy() <= ultima[0].getAccuracy() || l.getTime() > ultima[0].getTime()) ultima[0] = l;
                        if (LocationManager.GPS_PROVIDER.equals(l.getProvider()) || l.getAccuracy() < 40) {
                            cancelar.cancel();
                            fin.run();
                        }
                    });
                } catch (Exception ignored) {}
            }
            h.postDelayed(() -> { cancelar.cancel(); fin.run(); }, 15000);
        } else {
            fin.run();
        }
    }

    @SuppressWarnings("MissingPermission")
    private static Location ultimaConocida(LocationManager lm) {
        Location mejor = null;
        for (String prov : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(prov);
                if (l != null && (mejor == null || l.getTime() > mejor.getTime())) mejor = l;
            } catch (Exception ignored) {}
        }
        return mejor;
    }
}
