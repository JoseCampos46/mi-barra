package co.jose.micatalogo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;

/** Arma la imagen de una ficha (para WhatsApp) y el catálogo en PDF tamaño carta. Letras en negro nítido. */
final class Imagenes {

    private static final int NEGRO = 0xFF111111, VERDE = 0xFF2E7D32, AMBAR = 0xFF854F0B, LINEA = 0xFFBDBDBD;

    private Imagenes() {}

    private static TextPaint letra(float tam, boolean negrilla, int color) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(tam);
        p.setColor(color);
        p.setTypeface(negrilla ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return p;
    }

    /** Escribe un texto que puede ocupar varias líneas. Devuelve la nueva altura (y). */
    private static float escribir(Canvas c, String t, TextPaint p, float x, float y, int ancho, int maxLineas) {
        if (t == null || t.isEmpty()) return y;
        StaticLayout l = StaticLayout.Builder.obtain(t, 0, t.length(), p, ancho)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setMaxLines(maxLineas)
                .setEllipsize(android.text.TextUtils.TruncateAt.END).build();
        c.save();
        c.translate(x, y);
        l.draw(c);
        c.restore();
        return y + l.getHeight();
    }

    // ───────────────────────── Ficha para WhatsApp ─────────────────────────

    /** Imagen JPEG liviana (1080 de ancho) con la ficha completa del producto. */
    static byte[] ficha(Context ctx, JSONObject p) {
        int W = 1080, M = 48;
        Bitmap b = Bitmap.createBitmap(W, 3600, Bitmap.Config.RGB_565);
        Canvas c = new Canvas(b);
        c.drawColor(Color.WHITE);
        float y = M;
        Bitmap foto = Almacen.foto(ctx, p);
        int lado = 280;
        float xTexto = M;
        if (foto != null) {
            float esc = Math.min(lado / (float) foto.getWidth(), lado / (float) foto.getHeight());
            int fw = Math.round(foto.getWidth() * esc), fh = Math.round(foto.getHeight() * esc);
            c.drawBitmap(foto, null, new Rect(M, (int) y, M + fw, (int) y + fh), new Paint(Paint.FILTER_BITMAP_FLAG));
            xTexto = M + lado + 32;
        }
        int anchoTexto = (int) (W - M - xTexto);
        float yt = escribir(c, Almacen.titulo(p), letra(54, true, NEGRO), xTexto, y, anchoTexto, 3);
        String linea = unir(" · ", p.optString("referencia").isEmpty() ? "" : "Ref. " + p.optString("referencia"), p.optString("marca"));
        yt = escribir(c, linea, letra(38, false, NEGRO), xTexto, yt + 8, anchoTexto, 2);
        if (!p.optString("codigo").isEmpty()) yt = escribir(c, "Código " + p.optString("codigo"), letra(34, false, NEGRO), xTexto, yt + 6, anchoTexto, 1);
        y = Math.max(y + (foto != null ? lado : 0), yt) + 36;

        // Ficha técnica
        y = escribir(c, "Ficha técnica", letra(44, true, NEGRO), M, y, W - 2 * M, 1) + 12;
        for (String[] f : filasFicha(p)) {
            y = fila(c, f[0], f[1], "1".equals(f[2]), M, y, W - 2 * M);
        }
        y += 28;

        // Tiendas
        JSONArray t = p.optJSONArray("tiendas");
        if (t != null && t.length() > 0) {
            y = escribir(c, "Dónde comprar (precio estimado)", letra(44, true, NEGRO), M, y, W - 2 * M, 1) + 12;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.optJSONObject(i);
                if (o == null) continue;
                TextPaint izq = letra(38, false, NEGRO), der = letra(38, true, NEGRO);
                String precio = Comun.plata(o.optDouble("precio"), o.optString("moneda"));
                c.drawText(o.optString("tienda"), M, y + 40, izq);
                c.drawText(precio, W - M - der.measureText(precio), y + 40, der);
                y += 58;
                Paint l = new Paint();
                l.setColor(LINEA);
                c.drawRect(M, y - 4, W - M, y - 2, l);
            }
            y = escribir(c, "Precios del " + p.optString("fechaPrecios") + " · pueden cambiar", letra(30, false, NEGRO), M, y + 8, W - 2 * M, 1);
        }
        y = escribir(c, "Hecho con Mi Catálogo", letra(28, false, NEGRO), M, y + 30, W - 2 * M, 1) + M;

        Bitmap fin = Bitmap.createBitmap(b, 0, 0, W, Math.min(b.getHeight(), (int) y));
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        fin.compress(Bitmap.CompressFormat.JPEG, 85, o);
        return o.toByteArray();
    }

    /** Una fila "dato ........ valor ✓" o "⚠ por verificar". */
    private static float fila(Canvas c, String dato, String valor, boolean ok, float x, float y, int ancho) {
        TextPaint izq = letra(36, false, NEGRO), der = letra(36, true, ok ? VERDE : AMBAR);
        String v = ok ? valor + "  ✓" : (valor.isEmpty() ? "Por verificar  ⚠" : valor + "  ⚠");
        float anchoValor = Math.min(der.measureText(v), ancho * 0.62f);
        c.drawText(dato, x, y + 38, izq);
        StaticLayout l = StaticLayout.Builder.obtain(v, 0, v.length(), der, (int) anchoValor + 2)
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setMaxLines(2).build();
        c.save();
        c.translate(x + ancho - anchoValor - 2, y + 4);
        l.draw(c);
        c.restore();
        float alto = Math.max(54, l.getHeight() + 14);
        Paint ln = new Paint();
        ln.setColor(LINEA);
        c.drawRect(x, y + alto - 4, x + ancho, y + alto - 2, ln);
        return y + alto;
    }

    /** Las filas de la ficha: lo leído en la etiqueta y lo confirmado en internet. {dato, valor, ok("1"/"0"), fuente} */
    static java.util.List<String[]> filasFicha(JSONObject p) {
        java.util.List<String[]> r = new java.util.ArrayList<>();
        java.util.Set<String> vistos = new java.util.HashSet<>();
        String pot = p.optString("potencia");
        String fuentePot = p.optString("potenciaFuente");
        r.add(new String[]{"Potencia", pot, pot.isEmpty() ? "0" : "1",
                pot.isEmpty() ? "" : ("usted".equals(fuentePot) ? "corregido por usted" : "etiqueta".equals(fuentePot) ? "leído en la foto" : "internet")});
        vistos.add("potencia");
        if (!p.optString("otros").isEmpty()) {
            r.add(new String[]{"En la etiqueta", p.optString("otros"), "1", "leído en la foto"});
        }
        JSONArray f = p.optJSONArray("ficha");
        if (f != null) for (int i = 0; i < f.length(); i++) {
            JSONObject d = f.optJSONObject(i);
            if (d == null) continue;
            String dato = d.optString("dato");
            String clave = Almacen.limpio(dato);
            if (clave.isEmpty() || vistos.contains(clave)) continue;
            vistos.add(clave);
            r.add(new String[]{dato, d.optString("valor"), d.optBoolean("ok") ? "1" : "0", d.optString("fuente")});
        }
        return r;
    }

    private static String unir(String sep, String... partes) {
        StringBuilder s = new StringBuilder();
        for (String x : partes) if (x != null && !x.trim().isEmpty()) s.append(s.length() > 0 ? sep : "").append(x.trim());
        return s.toString();
    }

    // ───────────────────────── Catálogo en PDF tamaño carta ─────────────────────────

    /** PDF carta (612 × 792 puntos), 6 productos por hoja, fotos pequeñas para que pese poco. */
    static byte[] catalogo(Context ctx, List<JSONObject> lista) throws Exception {
        PdfDocument doc = new PdfDocument();
        int W = 612, H = 792, M = 36, FILA = 112, porHoja = 6;
        int hojas = Math.max(1, (lista.size() + porHoja - 1) / porHoja);
        for (int h = 0; h < hojas; h++) {
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, h + 1).create());
            Canvas c = pg.getCanvas();
            c.drawText("Mi Catálogo", M, M + 20, letra(20, true, NEGRO));
            TextPaint fecha = letra(10, false, NEGRO);
            String f = Almacen.hoy() + " · " + lista.size() + " productos";
            c.drawText(f, W - M - fecha.measureText(f), M + 20, fecha);
            Paint ln = new Paint();
            ln.setColor(NEGRO);
            c.drawRect(M, M + 30, W - M, M + 31, ln);
            float y = M + 42;
            for (int i = h * porHoja; i < Math.min(lista.size(), (h + 1) * porHoja); i++) {
                JSONObject p = lista.get(i);
                Bitmap foto = Almacen.foto(ctx, p);
                float xT = M;
                if (foto != null) {
                    int lado = 92;
                    float esc = Math.min(lado / (float) foto.getWidth(), lado / (float) foto.getHeight());
                    int fw = Math.round(foto.getWidth() * esc), fh = Math.round(foto.getHeight() * esc);
                    Bitmap chica = Bitmap.createScaledBitmap(foto, Math.max(1, fw * 3 / 2), Math.max(1, fh * 3 / 2), true);
                    c.drawBitmap(chica, null, new RectF(M, y, M + fw, y + fh), new Paint(Paint.FILTER_BITMAP_FLAG));
                    xT = M + lado + 12;
                }
                int ancho = (int) (W - M - xT);
                float yy = escribir(c, Almacen.titulo(p), letra(12.5f, true, NEGRO), xT, y, ancho, 1);
                yy = escribir(c, unir(" · ", p.optString("referencia").isEmpty() ? "" : "Ref. " + p.optString("referencia"),
                        p.optString("potencia").isEmpty() ? "" : "Potencia " + p.optString("potencia"),
                        p.optString("codigo").isEmpty() ? "" : "Cód. " + p.optString("codigo")), letra(10, false, NEGRO), xT, yy + 2, ancho, 2);
                JSONObject barata = Almacen.masBarata(p);
                if (barata != null) {
                    yy = escribir(c, "Desde " + Comun.plata(barata.optDouble("precio"), barata.optString("moneda")) + " en " + barata.optString("tienda")
                            + "  (precio estimado del " + p.optString("fechaPrecios") + ")", letra(10.5f, true, NEGRO), xT, yy + 3, ancho, 1);
                    JSONArray t = p.optJSONArray("tiendas");
                    StringBuilder otras = new StringBuilder();
                    if (t != null) for (int k = 0; k < t.length() && k < 4; k++) {
                        JSONObject o = t.optJSONObject(k);
                        if (o == null) continue;
                        otras.append(otras.length() > 0 ? "   ·   " : "").append(o.optString("tienda")).append(" ")
                                .append(Comun.plata(o.optDouble("precio"), o.optString("moneda")));
                    }
                    escribir(c, otras.toString(), letra(9.5f, false, NEGRO), xT, yy + 2, ancho, 2);
                } else {
                    escribir(c, "Sin precios todavía", letra(10, false, NEGRO), xT, yy + 3, ancho, 1);
                }
                y += FILA;
                Paint sep = new Paint();
                sep.setColor(LINEA);
                c.drawRect(M, y - 8, W - M, y - 7.5f, sep);
            }
            TextPaint pie = letra(9, false, NEGRO);
            String n = "Hoja " + (h + 1) + " de " + hojas;
            c.drawText(n, W - M - pie.measureText(n), H - M + 10, pie);
            doc.finishPage(pg);
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        doc.writeTo(o);
        doc.close();
        return o.toByteArray();
    }
}
