package co.jose.micatalogo;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.util.Locale;

/** Ayudas comunes de Mi Catálogo: colores, botones, guardar en Descargas/MiBarra/Catalogo y enviar por WhatsApp. */
public abstract class Comun extends Activity {

    static final String CARPETA = Environment.DIRECTORY_DOWNLOADS + "/MiBarra/Catalogo";

    // Letras siempre en negro nítido; los colores solo para botones y marcas
    static final int NEGRO = 0xFF111111, FONDO = 0xFFF4F7F6, BLANCO = 0xFFFFFFFF, LINEA = 0xFFD3D1C7;
    static final int VERDE = 0xFF0F6E56, VERDE_CLARO = 0xFFE1F5EE, VERDE_OK = 0xFF2E7D32;
    static final int CORAL = 0xFF993C1D, CORAL_CLARO = 0xFFFAECE7;
    static final int MORADO = 0xFF3C3489, MORADO_CLARO = 0xFFEEEDFE;
    static final int AMBAR = 0xFF854F0B, AMBAR_CLARO = 0xFFFAEEDA;
    static final int WHATSAPP = 0xFF25A244;

    final Handler ui = new Handler(Looper.getMainLooper());

    void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    int dp(float v) { return dp(this, v); }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout.LayoutParams peso(float w, int altoDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, altoDp > 0 ? dp(altoDp) : ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    LinearLayout.LayoutParams todo() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    static GradientDrawable fondo(int radioPx, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radioPx);
        return g;
    }

    static GradientDrawable borde(int radioPx, int color, int borde, int anchoPx) {
        GradientDrawable g = fondo(radioPx, color);
        g.setStroke(anchoPx, borde);
        return g;
    }

    TextView texto(String t, float sp, boolean negrilla) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(NEGRO);
        v.setTypeface(negrilla ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return v;
    }

    /** Botón con fondo claro y letra oscura del mismo color (se lee bien al sol). */
    TextView boton(String t, int claro, int oscuro, Runnable r) {
        TextView b = texto(t, 16, true);
        b.setTextColor(oscuro);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        b.setBackground(borde(dp(12), claro, oscuro, dp(1)));
        b.setOnClickListener(v -> r.run());
        return b;
    }

    /** Botón lleno (para la acción principal). */
    TextView botonLleno(String t, int color, Runnable r) {
        TextView b = texto(t, 16, true);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(6), dp(12), dp(6), dp(12));
        b.setBackground(fondo(dp(12), color));
        b.setOnClickListener(v -> r.run());
        return b;
    }

    /** $219.900 para pesos; US$ 73,89 para dólares. */
    static String plata(double valor, String moneda) {
        if (valor <= 0) return "Sin precio";
        if (moneda != null && moneda.toUpperCase(Locale.ROOT).startsWith("USD")) {
            NumberFormat f = NumberFormat.getNumberInstance(new Locale("es", "CO"));
            f.setMinimumFractionDigits(2);
            f.setMaximumFractionDigits(2);
            return "US$ " + f.format(valor);
        }
        NumberFormat f = NumberFormat.getNumberInstance(new Locale("es", "CO"));
        f.setMaximumFractionDigits(0);
        return "$" + f.format(Math.round(valor));
    }

    /** Guarda un archivo en Descargas/MiBarra/Catalogo (si él mueve la carpeta, se vuelve a crear sola). */
    Uri guardar(String nombre, String mime, byte[] datos) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, CARPETA);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("No se pudo crear el archivo");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null) throw new IOException("No se pudo escribir el archivo");
            o.write(datos);
        }
        ContentValues fin = new ContentValues();
        fin.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContentResolver().update(u, fin, null, null);
        return u;
    }

    /** Manda un archivo (con un texto) a WhatsApp; si no está, deja escoger la app. */
    void enviarWhatsApp(Uri archivo, String mime, String textoMensaje) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        if (archivo != null) i.putExtra(Intent.EXTRA_STREAM, archivo);
        if (textoMensaje != null) i.putExtra(Intent.EXTRA_TEXT, textoMensaje);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        for (String pq : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            try {
                startActivity(new Intent(i).setPackage(pq));
                return;
            } catch (Exception ignored) {}
        }
        try { startActivity(Intent.createChooser(i, "Enviar con…")); } catch (Exception e) { aviso("No hay con qué enviarlo"); }
    }

    // ───── Llamar con un toque ─────
    private String numeroPorLlamar;
    static final int PERMISO_LLAMAR = 22;

    void llamar(String numero) {
        String n = numero.replaceAll("[^0-9+]", "");
        if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try { startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + n))); return; } catch (Exception ignored) {}
            try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + n))); } catch (Exception ignored) {}
        } else {
            numeroPorLlamar = n;
            requestPermissions(new String[]{android.Manifest.permission.CALL_PHONE}, PERMISO_LLAMAR);
        }
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] res) {
        super.onRequestPermissionsResult(r, p, res);
        if (r == PERMISO_LLAMAR && numeroPorLlamar != null) {
            boolean si = res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            String n = numeroPorLlamar;
            numeroPorLlamar = null;
            try { startActivity(new Intent(si ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + n))); } catch (Exception ignored) {}
        }
    }

    /** Escribir por WhatsApp a un número de Colombia (le pone el 57 si no lo tiene). */
    void escribirWhatsApp(String numero, String mensaje) {
        String n = numero.replaceAll("[^0-9]", "");
        if (n.length() == 10) n = "57" + n;
        abrirUrl("https://wa.me/" + n + (mensaje == null ? "" : "?text=" + Uri.encode(mensaje)));
    }

    void abrirUrl(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { aviso("No se pudo abrir la página"); }
    }

    /** "Más tiendas": le pasa el nombre a Buscar precios de Mi Barra (así no repetimos herramientas). */
    void masTiendas(String busqueda) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, busqueda);
        i.setClassName("co.jose.mibarra", "co.jose.mibarra.PreciosActivity");
        try {
            startActivity(i);
        } catch (Exception e) {
            aviso("No encontré Buscar precios de Mi Barra; lo busco en Google");
            abrirUrl("https://www.google.com/search?tbm=shop&gl=co&hl=es&q=" + Uri.encode(busqueda));
        }
    }
}
