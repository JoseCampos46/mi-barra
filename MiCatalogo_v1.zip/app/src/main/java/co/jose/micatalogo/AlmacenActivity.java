package co.jose.micatalogo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Un almacén o una casa en venta: logo, foto, teléfonos para llamar con un toque, GPS y mapa. */
public class AlmacenActivity extends Comun {

    private static final int PERMISO_GPS = 31;
    private JSONObject a;
    private LinearLayout raiz;
    private boolean casa;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        a = Almacen.buscar(this, getIntent().getLongExtra("id", 0));
        if (a == null) { finish(); return; }
        casa = "casa".equals(a.optString("tipo"));
        getWindow().setStatusBarColor(FONDO);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        raiz = vertical();
        raiz.setPadding(dp(12), dp(10), dp(12), dp(20));
        raiz.setBackgroundColor(FONDO);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(FONDO);
        sv.addView(raiz);
        setContentView(sv);
        pintar();
    }

    private void pintar() {
        raiz.removeAllViews();
        LinearLayout cab = horizontal();
        cab.addView(boton("←", BLANCO, NEGRO, this::finish), new LinearLayout.LayoutParams(dp(52), dp(46)));
        cab.addView(texto(casa ? "  Casa en venta" : "  Almacén", 19, true), new LinearLayout.LayoutParams(0, -2, 1f));
        raiz.addView(cab, todo());

        LinearLayout t = vertical();
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setBackground(borde(dp(14), BLANCO, LINEA, dp(1)));

        LinearLayout arriba = horizontal();
        Bitmap logo = Almacen.logo(this, a);
        if (logo != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(logo);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            arriba.addView(iv, new LinearLayout.LayoutParams(dp(72), dp(72)));
        }
        LinearLayout tx = vertical();
        tx.setPadding(logo != null ? dp(12) : 0, 0, 0, 0);
        tx.addView(texto(a.optString("nombre").isEmpty() ? "Sin nombre" : a.optString("nombre"), 20, true));
        String sub = casa ? InicioActivity.unir(a.optString("precio"), a.optString("inmobiliaria")) : a.optString("vende");
        if (!sub.isEmpty()) tx.addView(texto(sub, 15, false));
        arriba.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        t.addView(arriba, todo());

        // Teléfonos: un toque y llama
        JSONArray tel = a.optJSONArray("telefonos");
        if (tel != null) for (int i = 0; i < tel.length(); i++) {
            String n = tel.optString(i);
            LinearLayout f = horizontal();
            f.addView(botonLleno("📞 Llamar  " + n, WHATSAPP, () -> llamar(n)), peso(1, 56));
            TextView wa = boton("💬", 0xFFEAF3DE, 0xFF27500A, () -> escribirWhatsApp(n, null));
            f.addView(wa, new LinearLayout.LayoutParams(dp(60), dp(56)));
            LinearLayout.LayoutParams lp = todo();
            lp.topMargin = dp(6);
            t.addView(f, lp);
        }
        if (!a.optString("whatsapp").isEmpty()) {
            String w = a.optString("whatsapp");
            LinearLayout.LayoutParams lp = todo();
            lp.topMargin = dp(6);
            t.addView(boton("💬 WhatsApp  " + w, 0xFFEAF3DE, 0xFF27500A, () -> escribirWhatsApp(w, null)), lp);
        }

        // Datos leídos
        String[][] datos = casa
                ? new String[][]{{"Detalles", "detalles"}, {"Contacto", "contacto"}, {"Dirección del aviso", "direccion"}}
                : new String[][]{{"Contacto", "contacto"}, {"Dirección", "direccion"}, {"Ciudad", "ciudad"}, {"Horario", "horario"},
                {"Correo", "correo"}, {"Página", "web"}, {"Redes", "redes"}};
        for (String[] d : datos) {
            String v = a.optString(d[1]);
            if (v.isEmpty()) continue;
            View fila = filaDato(d[0], v);
            if (d[1].equals("correo")) fila.setOnClickListener(x -> abrirUrl("mailto:" + v));
            if (d[1].equals("web")) fila.setOnClickListener(x -> abrirUrl(v.startsWith("http") ? v : "https://" + v));
            t.addView(fila, todo());
        }
        if (!a.optString("direccionGps").isEmpty()) t.addView(filaDato("📍 GPS", a.optString("direccionGps")), todo());

        // Foto de la tarjeta / de la casa
        imagen(t, Almacen.foto(this, a), casa ? "Foto de la casa" : "Foto de la tarjeta");
        if (casa) imagen(t, Almacen.imagenDe(this, a, "dueno"), "Foto del dueño");
        Bitmap mapa = Almacen.imagenDe(this, a, "mapa");
        if (mapa != null) {
            ImageView m = imagen(t, mapa, "Mapa (como «Aquí estoy»)");
            m.setOnClickListener(v -> comoLlegar());
        }
        LinearLayout.LayoutParams tp = todo();
        tp.topMargin = dp(8);
        raiz.addView(t, tp);

        boolean hayGps = a.has("lat");
        LinearLayout f1 = horizontal();
        if (hayGps) {
            f1.addView(boton("📍 Cómo llegar", 0xFFE6F1FB, 0xFF0C447C, this::comoLlegar), peso(1, 58));
            f1.addView(boton("💬 Enviar ubicación", 0xFFEAF3DE, 0xFF27500A, this::enviarUbicacion), peso(1, 58));
        } else {
            f1.addView(boton("📍 Guardar GPS aquí", 0xFFE6F1FB, 0xFF0C447C, this::guardarGpsAqui), peso(1, 58));
            f1.addView(boton("💬 Enviar por WhatsApp", 0xFFEAF3DE, 0xFF27500A, this::enviarUbicacion), peso(1, 58));
        }
        LinearLayout.LayoutParams bp = todo();
        bp.topMargin = dp(8);
        raiz.addView(f1, bp);
        LinearLayout f2 = horizontal();
        f2.addView(boton("✏️ Corregir datos", BLANCO, NEGRO, this::corregir), peso(1, 54));
        if (hayGps) f2.addView(boton("📍 Cambiar GPS a aquí", BLANCO, NEGRO, this::guardarGpsAqui), peso(1, 54));
        raiz.addView(f2, todo());
        TextView borrar = texto("🗑 Borrar", 15, false);
        borrar.setGravity(Gravity.CENTER);
        borrar.setPadding(0, dp(18), 0, dp(6));
        borrar.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("¿Borrar?").setMessage(a.optString("nombre"))
                .setPositiveButton("Borrar", (d, w) -> { Almacen.borrar(this, a.optLong("id")); finish(); })
                .setNegativeButton("No", null).show());
        raiz.addView(borrar, todo());
    }

    private View filaDato(String nombre, String valor) {
        LinearLayout f = horizontal();
        f.setPadding(0, dp(8), 0, dp(8));
        f.addView(texto(nombre, 14, false), new LinearLayout.LayoutParams(dp(110), -2));
        TextView v = texto(valor, 15, true);
        v.setTextIsSelectable(true);
        f.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return f;
    }

    private ImageView imagen(LinearLayout donde, Bitmap b, String titulo) {
        if (b == null) return new ImageView(this);
        TextView tt = texto(titulo, 14, true);
        tt.setPadding(0, dp(12), 0, dp(4));
        donde.addView(tt, todo());
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(b);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setOnClickListener(v -> {
            ImageView g = new ImageView(this);
            g.setImageBitmap(b);
            g.setAdjustViewBounds(true);
            new AlertDialog.Builder(this).setView(g).setPositiveButton("Cerrar", null).show();
        });
        donde.addView(iv, todo());
        return iv;
    }

    private String mapsUrl() {
        return String.format(Locale.US, "https://www.google.com/maps/search/?api=1&query=%.6f,%.6f", a.optDouble("lat"), a.optDouble("lon"));
    }

    private void comoLlegar() {
        if (!a.has("lat")) return;
        String nav = String.format(Locale.US, "google.navigation:q=%.6f,%.6f", a.optDouble("lat"), a.optDouble("lon"));
        try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(nav))); }
        catch (Exception e) { abrirUrl(mapsUrl()); }
    }

    private void enviarUbicacion() {
        StringBuilder s = new StringBuilder();
        s.append(casa ? "🏠 *" : "🏪 *").append(a.optString("nombre").isEmpty() ? "Sin nombre" : a.optString("nombre")).append("*");
        String sub = casa ? InicioActivity.unir(a.optString("precio"), a.optString("detalles")) : a.optString("vende");
        if (!sub.isEmpty()) s.append("\n").append(sub);
        JSONArray tel = a.optJSONArray("telefonos");
        if (tel != null) for (int i = 0; i < tel.length(); i++) s.append("\n📞 ").append(tel.optString(i));
        String dir = !a.optString("direccion").isEmpty() ? a.optString("direccion") : a.optString("direccionGps");
        if (!dir.isEmpty()) s.append("\n📍 ").append(dir);
        if (a.has("lat")) s.append("\n").append(mapsUrl());
        String texto = s.toString();
        Bitmap img = Almacen.imagenDe(this, a, "mapa");
        if (img == null) img = Almacen.foto(this, a);
        if (img == null) { enviarWhatsApp(null, "text/plain", texto); return; }
        Bitmap fin = img;
        InicioActivity.TRABAJOS.execute(() -> {
            try {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                fin.compress(Bitmap.CompressFormat.JPEG, 80, o);
                Uri u = guardar("Ubicacion_" + Almacen.limpio(a.optString("nombre")) + "_" + System.currentTimeMillis() % 100000 + ".jpg", "image/jpeg", o.toByteArray());
                ui.post(() -> enviarWhatsApp(u, "image/jpeg", texto));
            } catch (Exception e) {
                ui.post(() -> enviarWhatsApp(null, "text/plain", texto));
            }
        });
    }

    private void guardarGpsAqui() {
        if (!Gps.tienePermiso(this)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISO_GPS);
            return;
        }
        aviso("Buscando su ubicación…");
        Gps.pedir(this, l -> {
            if (l == null) { aviso("No conseguí la ubicación. Revise que el GPS esté prendido."); return; }
            InicioActivity.TRABAJOS.execute(() -> {
                Trabajo.ponerGps(getApplicationContext(), a, l);
                Almacen.guardar(getApplicationContext());
                ui.post(() -> { if (!isDestroyed()) { pintar(); aviso("📍 GPS guardado"); } });
            });
        });
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] res) {
        super.onRequestPermissionsResult(r, p, res);
        if (r == PERMISO_GPS) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) guardarGpsAqui();
            else aviso("Sin permiso de ubicación no puedo guardar el GPS");
        }
    }

    private void corregir() {
        LinearLayout c = vertical();
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        String[][] campos = casa
                ? new String[][]{{"nombre", "Qué es"}, {"precio", "Precio"}, {"detalles", "Detalles"}, {"contacto", "Contacto"},
                {"whatsapp", "WhatsApp"}, {"inmobiliaria", "Inmobiliaria"}, {"direccion", "Dirección"}}
                : new String[][]{{"nombre", "Nombre del almacén"}, {"vende", "Qué vende"}, {"contacto", "Contacto"}, {"whatsapp", "WhatsApp"},
                {"direccion", "Dirección"}, {"ciudad", "Ciudad"}, {"horario", "Horario"}, {"correo", "Correo"}, {"web", "Página"}, {"redes", "Redes"}};
        List<EditText> eds = new ArrayList<>();
        for (String[] cmp : campos) {
            c.addView(texto(cmp[1], 13, true));
            EditText e = new EditText(this);
            e.setText(a.optString(cmp[0]));
            e.setTextColor(NEGRO);
            c.addView(e, todo());
            eds.add(e);
        }
        c.addView(texto("Teléfonos (uno por línea)", 13, true));
        EditText tels = new EditText(this);
        StringBuilder sb = new StringBuilder();
        JSONArray tel = a.optJSONArray("telefonos");
        if (tel != null) for (int i = 0; i < tel.length(); i++) sb.append(i > 0 ? "\n" : "").append(tel.optString(i));
        tels.setText(sb.toString());
        tels.setTextColor(NEGRO);
        tels.setInputType(android.text.InputType.TYPE_CLASS_PHONE | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        tels.setSingleLine(false);
        tels.setMinLines(2);
        c.addView(tels, todo());
        ScrollView sv = new ScrollView(this);
        sv.addView(c);
        new AlertDialog.Builder(this).setTitle("✏️ Corregir datos").setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    try {
                        for (int i = 0; i < campos.length; i++) a.put(campos[i][0], eds.get(i).getText().toString().trim());
                        JSONArray n = new JSONArray();
                        for (String l : tels.getText().toString().split("[\\n,;]+")) {
                            String x = l.trim();
                            if (x.replaceAll("\\D", "").length() >= 7) n.put(x);
                        }
                        a.put("telefonos", n);
                    } catch (Exception ignored) {}
                    Almacen.guardar(this);
                    pintar();
                    aviso("Guardado ✓");
                })
                .setNegativeButton("Cancelar", null).show();
    }
}
