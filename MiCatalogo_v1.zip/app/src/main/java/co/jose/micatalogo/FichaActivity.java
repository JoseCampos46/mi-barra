package co.jose.micatalogo;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** La ficha de un producto: datos con ✅ confirmado o ⚠️ por verificar, tiendas con precio estimado y botones. */
public class FichaActivity extends Comun {

    private JSONObject p;
    private LinearLayout raiz;
    private TextView estado;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Almacen.buscar(this, getIntent().getLongExtra("id", 0));
        if (p == null) { finish(); return; }
        getWindow().setStatusBarColor(FONDO);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        raiz = vertical();
        raiz.setPadding(dp(12), dp(10), dp(12), dp(20));
        raiz.setBackgroundColor(FONDO);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(FONDO);
        sv.addView(raiz);
        setContentView(sv);
        pintar();
    }

    private void pintar() {
        raiz.removeAllViews();
        LinearLayout cab = horizontal();
        TextView atras = boton("←", BLANCO, NEGRO, this::finish);
        cab.addView(atras, new LinearLayout.LayoutParams(dp(52), dp(46)));
        TextView t = texto("  Ficha del producto", 19, true);
        cab.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        raiz.addView(cab, todo());

        // Encabezado: foto pequeña y nombre
        LinearLayout tarjeta = vertical();
        tarjeta.setPadding(dp(12), dp(12), dp(12), dp(12));
        tarjeta.setBackground(borde(dp(14), BLANCO, LINEA, dp(1)));
        LinearLayout arriba = horizontal();
        Bitmap foto = Almacen.foto(this, p);
        if (foto != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(foto);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setOnClickListener(v -> verFoto(foto));
            arriba.addView(iv, new LinearLayout.LayoutParams(dp(104), dp(104)));
        }
        LinearLayout tx = vertical();
        tx.setPadding(dp(12), 0, 0, 0);
        tx.addView(texto(Almacen.titulo(p), 19, true));
        String linea = InicioActivity.unir(p.optString("marca"), p.optString("referencia").isEmpty() ? "" : "Ref. " + p.optString("referencia"));
        if (!linea.isEmpty()) tx.addView(texto(linea, 15, false));
        if (!p.optString("codigo").isEmpty()) tx.addView(texto("Código " + p.optString("codigo"), 14, false));
        arriba.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        tarjeta.addView(arriba, todo());

        estado = texto("", 15, true);
        estado.setTextColor(0xFF412402);
        estado.setPadding(dp(10), dp(8), dp(10), dp(8));
        estado.setBackground(fondo(dp(10), AMBAR_CLARO));
        estado.setVisibility(View.GONE);
        LinearLayout.LayoutParams ep = todo();
        ep.topMargin = dp(8);
        tarjeta.addView(estado, ep);

        // Ficha técnica
        tarjeta.addView(seccion("Ficha técnica"), todo());
        for (String[] f : Imagenes.filasFicha(p)) tarjeta.addView(filaDato(f[0], f[1], "1".equals(f[2]), f[3]), todo());
        if (!p.optBoolean("buscado")) tarjeta.addView(nota("Toque «Buscar ficha y precios» para completar con internet."), todo());

        // Tiendas
        tarjeta.addView(seccion("Dónde comprar (precio estimado)"), todo());
        JSONArray tiendas = p.optJSONArray("tiendas");
        if (tiendas != null && tiendas.length() > 0) {
            for (int i = 0; i < tiendas.length(); i++) {
                JSONObject o = tiendas.optJSONObject(i);
                if (o != null) tarjeta.addView(filaTienda(o), todo());
            }
            tarjeta.addView(nota("Precios del " + p.optString("fechaPrecios") + " · pueden cambiar. Toque una tienda para ver."), todo());
        } else {
            tarjeta.addView(nota(p.optBoolean("buscado") ? "No encontré precios confiables en internet. Pruebe «Más tiendas»." : "Todavía no se han buscado precios."), todo());
        }
        JSONArray fuentes = p.optJSONArray("fuentes");
        if (fuentes != null && fuentes.length() > 0) {
            StringBuilder sb = new StringBuilder("Páginas consultadas: ");
            for (int i = 0; i < fuentes.length() && i < 6; i++) {
                JSONObject o = fuentes.optJSONObject(i);
                if (o != null) sb.append(i > 0 ? ", " : "").append(o.optString("titulo"));
            }
            TextView fv = nota(sb.toString());
            fv.setOnClickListener(v -> verFuentes(fuentes));
            tarjeta.addView(fv, todo());
        }
        LinearLayout.LayoutParams tp = todo();
        tp.topMargin = dp(8);
        raiz.addView(tarjeta, tp);

        // Botones 2 x 2
        LinearLayout f1 = horizontal();
        f1.addView(boton(p.optBoolean("buscado") ? "🔄 Actualizar precios" : "🔎 Buscar ficha y precios", MORADO_CLARO, MORADO, this::buscar), peso(1, 58));
        f1.addView(boton("💬 Enviar ficha", 0xFFEAF3DE, 0xFF27500A, this::enviar), peso(1, 58));
        LinearLayout.LayoutParams bp = todo();
        bp.topMargin = dp(8);
        raiz.addView(f1, bp);
        LinearLayout f2 = horizontal();
        f2.addView(boton("✏️ Corregir datos", BLANCO, NEGRO, this::corregir), peso(1, 58));
        f2.addView(boton("💲 Más tiendas", AMBAR_CLARO, AMBAR, () -> masTiendas(Almacen.busqueda(p))), peso(1, 58));
        raiz.addView(f2, todo());
        TextView borrar = texto("🗑 Borrar este producto", 15, false);
        borrar.setGravity(Gravity.CENTER);
        borrar.setPadding(0, dp(18), 0, dp(6));
        borrar.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("¿Borrar este producto?").setMessage(Almacen.titulo(p))
                .setPositiveButton("Borrar", (d, w) -> { Almacen.borrar(this, p.optLong("id")); finish(); })
                .setNegativeButton("No", null).show());
        raiz.addView(borrar, todo());
    }

    private TextView seccion(String t) {
        TextView v = texto(t, 17, true);
        v.setPadding(0, dp(14), 0, dp(4));
        return v;
    }

    private TextView nota(String t) {
        TextView v = texto(t, 13, false);
        v.setPadding(0, dp(6), 0, dp(2));
        return v;
    }

    private View filaDato(String dato, String valor, boolean ok, String fuente) {
        LinearLayout f = horizontal();
        f.setPadding(0, dp(6), 0, dp(6));
        f.setBackground(borde(0, ok ? BLANCO : AMBAR_CLARO, BLANCO, 0));
        LinearLayout izq = vertical();
        izq.addView(texto(dato, 15, false));
        if (!fuente.isEmpty()) izq.addView(texto(fuente, 12, false));
        f.addView(izq, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView v = texto(ok ? valor : (valor.isEmpty() ? "Por verificar" : valor), 15, true);
        v.setGravity(Gravity.END);
        if (!ok) v.setTextColor(0xFF412402);
        f.addView(v, new LinearLayout.LayoutParams(0, -2, 1.3f));
        TextView ic = texto(ok ? "✅" : "⚠️", 16, false);
        ic.setGravity(Gravity.END);
        f.addView(ic, new LinearLayout.LayoutParams(dp(30), -2));
        return f;
    }

    private View filaTienda(JSONObject o) {
        LinearLayout f = horizontal();
        f.setPadding(0, dp(10), 0, dp(10));
        f.addView(texto(o.optString("tienda"), 16, false), new LinearLayout.LayoutParams(0, -2, 1f));
        f.addView(texto(plata(o.optDouble("precio"), o.optString("moneda")), 16, true));
        f.addView(texto("  ↗", 16, false));
        String url = o.optString("url");
        f.setOnClickListener(v -> abrirUrl(url));
        return f;
    }

    private void verFoto(Bitmap b) {
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(b);
        iv.setAdjustViewBounds(true);
        new AlertDialog.Builder(this).setView(iv).setPositiveButton("Cerrar", null).show();
    }

    private void verFuentes(JSONArray f) {
        List<String> nombres = new ArrayList<>();
        List<String> urls = new ArrayList<>();
        for (int i = 0; i < f.length(); i++) {
            JSONObject o = f.optJSONObject(i);
            if (o == null) continue;
            nombres.add(o.optString("titulo"));
            urls.add(o.optString("url"));
        }
        new AlertDialog.Builder(this).setTitle("Páginas consultadas")
                .setItems(nombres.toArray(new String[0]), (d, i) -> abrirUrl(urls.get(i)))
                .setNegativeButton("Cerrar", null).show();
    }

    private void mostrarEstado(String s) {
        ui.post(() -> {
            if (isDestroyed() || estado == null) return;
            estado.setText(s);
            estado.setVisibility(s == null ? View.GONE : View.VISIBLE);
        });
    }

    private void buscar() {
        String k = getSharedPreferences("chepe", MODE_PRIVATE).getString("llave", "");
        if (k.isEmpty()) { aviso("Primero ponga la llave de Gemini (🔑 en la pantalla principal)"); return; }
        mostrarEstado("🔎 Buscando la ficha técnica y los precios en internet… (unos segundos)");
        InicioActivity.TRABAJOS.execute(() -> {
            try {
                Trabajo.completar(getApplicationContext(), k, p);
                ui.post(() -> { if (!isDestroyed()) { pintar(); aviso("✓ Ficha y precios al día"); } });
            } catch (Gemini.Falla f) {
                mostrarEstado(null);
                ui.post(() -> aviso(f.getMessage()));
            }
        });
    }

    static String resumen(JSONObject p) {
        StringBuilder s = new StringBuilder("*").append(Almacen.titulo(p)).append("*");
        if (!p.optString("referencia").isEmpty()) s.append("\nRef. ").append(p.optString("referencia"));
        if (!p.optString("potencia").isEmpty()) s.append("\nPotencia: ").append(p.optString("potencia"));
        JSONObject b = Almacen.masBarata(p);
        if (b != null) s.append("\nDesde ").append(plata(b.optDouble("precio"), b.optString("moneda"))).append(" en ").append(b.optString("tienda"))
                .append(" (precio estimado del ").append(p.optString("fechaPrecios")).append(")");
        return s.toString();
    }

    private void enviar() {
        InicioActivity.TRABAJOS.execute(() -> {
            try {
                byte[] img = Imagenes.ficha(getApplicationContext(), p);
                Uri u = guardar("Ficha_" + Almacen.limpio(Almacen.titulo(p)) + "_" + System.currentTimeMillis() % 100000 + ".jpg", "image/jpeg", img);
                ui.post(() -> enviarWhatsApp(u, "image/jpeg", resumen(p)));
            } catch (Exception e) {
                ui.post(() -> aviso("No pude armar la ficha"));
            }
        });
    }

    /** Corregir: el cursor se pone donde quiera y se cambia solo esa letra o número. */
    private void corregir() {
        LinearLayout c = vertical();
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        String[][] campos = {{"nombre", "Qué es"}, {"marca", "Marca"}, {"referencia", "Referencia"}, {"potencia", "Potencia"},
                {"codigo", "Código de barras"}, {"otros", "Datos de la etiqueta"}};
        List<EditText> eds = new ArrayList<>();
        for (String[] cmp : campos) {
            c.addView(texto(cmp[1], 13, true));
            EditText e = new EditText(this);
            e.setText(p.optString(cmp[0]));
            e.setTextColor(NEGRO);
            c.addView(e, todo());
            eds.add(e);
        }
        JSONArray ficha = p.optJSONArray("ficha");
        List<EditText> edsFicha = new ArrayList<>();
        if (ficha != null) for (int i = 0; i < ficha.length(); i++) {
            JSONObject d = ficha.optJSONObject(i);
            if (d == null || d.optString("dato").toLowerCase().contains("potencia")) { edsFicha.add(null); continue; }
            c.addView(texto(d.optString("dato"), 13, true));
            EditText e = new EditText(this);
            e.setText(d.optString("valor"));
            e.setHint("Por verificar");
            e.setTextColor(NEGRO);
            c.addView(e, todo());
            edsFicha.add(e);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(c);
        new AlertDialog.Builder(this).setTitle("✏️ Corregir datos").setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    try {
                        for (int i = 0; i < campos.length; i++) {
                            String nuevo = eds.get(i).getText().toString().trim();
                            if (!nuevo.equals(p.optString(campos[i][0]))) {
                                p.put(campos[i][0], nuevo);
                                if (campos[i][0].equals("potencia")) p.put("potenciaFuente", nuevo.isEmpty() ? "" : "usted");
                            }
                        }
                        if (ficha != null) for (int i = 0; i < ficha.length() && i < edsFicha.size(); i++) {
                            EditText e = edsFicha.get(i);
                            JSONObject dd = ficha.optJSONObject(i);
                            if (e == null || dd == null) continue;
                            String nuevo = e.getText().toString().trim();
                            if (!nuevo.equals(dd.optString("valor"))) {
                                dd.put("valor", nuevo);
                                dd.put("ok", !nuevo.isEmpty());
                                dd.put("fuente", nuevo.isEmpty() ? "" : "corregido por usted");
                            }
                        }
                    } catch (Exception ignored) {}
                    Almacen.guardar(this);
                    pintar();
                    aviso("Guardado ✓");
                })
                .setNegativeButton("Cancelar", null).show();
    }
}
