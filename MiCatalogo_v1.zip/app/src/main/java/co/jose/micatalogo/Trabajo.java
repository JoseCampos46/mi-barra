package co.jose.micatalogo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Convierte lo que responde Gemini en productos del catálogo. Todo corre en segundo plano y solo mientras se usa. */
final class Trabajo {

    private Trabajo() {}

    /** Resultado de agregar productos. */
    static final class Agregados {
        final List<Long> nuevos = new ArrayList<>();
        int repetidos;
    }

    // ───────── Foto ─────────

    static Agregados foto(Context c, String llave, Uri u) throws Gemini.Falla {
        Bitmap bm = abrirFoto(c, u, 1600);
        if (bm == null) throw new Gemini.Falla("No pude abrir la foto");
        ByteArrayOutputStream jpg = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 85, jpg);
        JSONArray lista = Gemini.leerFoto(llave, jpg.toByteArray());
        Agregados r = new Agregados();
        for (int i = 0; i < lista.length(); i++) {
            JSONObject it = lista.optJSONObject(i);
            if (it == null) continue;
            agregar(c, it, recortar(bm, it.optJSONArray("caja")), "foto", r);
        }
        return r;
    }

    static Bitmap abrirFoto(Context c, Uri u, int maxLado) {
        try {
            return ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.getContentResolver(), u), (dec, info, src) -> {
                int w = info.getSize().getWidth(), h = info.getSize().getHeight(), lado = Math.max(w, h);
                if (lado > maxLado) dec.setTargetSize(w * maxLado / lado, h * maxLado / lado);
                dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        } catch (Exception e) {
            return null;
        }
    }

    // ───────── Video ─────────

    static Agregados video(Context c, String llave, Uri u, String mime, long tamano, Gemini.Avance avance) throws Gemini.Falla {
        JSONArray lista = Gemini.leerVideo(llave, c.getContentResolver(), u, mime, tamano, avance);
        avance.decir("Sacando las fotos de cada producto…");
        Agregados r = new Agregados();
        MediaMetadataRetriever mm = new MediaMetadataRetriever();
        try {
            mm.setDataSource(c, u);
            for (int i = 0; i < lista.length(); i++) {
                JSONObject it = lista.optJSONObject(i);
                if (it == null) continue;
                Bitmap cuadro = null;
                try {
                    long us = (long) (Math.max(0, it.optDouble("segundo", 0)) * 1_000_000L);
                    cuadro = mm.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, 1024, 1024);
                } catch (Exception ignored) {}
                agregar(c, it, recortar(cuadro, it.optJSONArray("caja")), "video", r);
            }
        } catch (Exception e) {
            // Si no se pueden sacar las fotos, igual se guardan los productos
            for (int i = 0; i < lista.length(); i++) {
                JSONObject it = lista.optJSONObject(i);
                if (it != null) agregar(c, it, null, "video", r);
            }
        } finally {
            try { mm.release(); } catch (Exception ignored) {}
        }
        return r;
    }

    // ───────── Almacenes y casas en venta ─────────

    /**
     * Guarda un sitio: "almacen" (tarjeta o frente del almacén) o "casa" (casa en venta).
     * Gemini lee lo escrito; se guarda el GPS con la foto del mapa como en "Aquí estoy" de Mi Barra.
     */
    static long sitio(Context c, String llave, String tipo, Uri u, Uri dueno, android.location.Location gps) throws Gemini.Falla {
        Bitmap bm = abrirFoto(c, u, 1600);
        if (bm == null) throw new Gemini.Falla("No pude abrir la foto");
        ByteArrayOutputStream jpg = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 88, jpg);
        boolean casa = "casa".equals(tipo);
        JSONObject t = casa ? Gemini.leerCasa(llave, jpg.toByteArray()) : Gemini.leerTarjeta(llave, jpg.toByteArray());
        JSONObject a = new JSONObject();
        try {
            long id = Almacen.nuevoId();
            a.put("id", id);
            a.put("tipo", tipo);
            a.put("creado", System.currentTimeMillis());
            for (String k : new String[]{"nombre", "vende", "contacto", "whatsapp", "direccion", "ciudad", "correo", "web", "redes",
                    "horario", "precio", "detalles", "inmobiliaria"})
                a.put(k, limpia(t.optString(k)));
            if (casa && a.optString("nombre").isEmpty()) a.put("nombre", "Casa en venta");
            JSONArray tel = new JSONArray();
            JSONArray tt = t.optJSONArray("telefonos");
            if (tt != null) for (int i = 0; i < tt.length(); i++) {
                String n = limpia(tt.optString(i));
                if (n.replaceAll("\\D", "").length() >= 7) tel.put(n);
            }
            a.put("telefonos", tel);
            Bitmap tarjeta = casa ? bm : recortar(bm, t.optJSONArray("caja_tarjeta"));
            a.put("foto", Almacen.guardarFoto(c, tarjeta, id, 720, 75));
            JSONArray cl = t.optJSONArray("caja_logo");
            Bitmap logo = !casa && cl != null && cl.length() == 4 ? recortar(bm, cl) : null;
            a.put("logo", logo != null && logo != bm ? Almacen.guardarFoto(c, logo, -id, 160, 85) : "");
            if (dueno != null) {
                Bitmap d = abrirFoto(c, dueno, 800);
                a.put("dueno", d != null ? Almacen.guardarFotoNombre(c, d, id + "_dueno", 480, 75) : "");
            }
            if (gps != null) ponerGps(c, a, gps);
        } catch (Exception e) {
            throw new Gemini.Falla("No pude guardar " + (casa ? "la casa" : "el almacén"));
        }
        if (!casa && a.optString("nombre").isEmpty() && a.optJSONArray("telefonos").length() == 0)
            throw new Gemini.Falla("No pude leer la tarjeta ni el letrero. Tome la foto de frente, cerquita y con buena luz.");
        Almacen.agregar(c, a);
        return a.optLong("id");
    }

    /** Guarda las coordenadas, la dirección (calle, barrio, ciudad) y la foto del mapa. */
    static void ponerGps(Context c, JSONObject a, android.location.Location gps) {
        try {
            a.put("lat", gps.getLatitude());
            a.put("lon", gps.getLongitude());
            String dir = "";
            try {
                List<android.location.Address> ad = new android.location.Geocoder(c, new Locale("es", "CO"))
                        .getFromLocation(gps.getLatitude(), gps.getLongitude(), 1);
                if (ad != null && !ad.isEmpty()) {
                    android.location.Address x = ad.get(0);
                    StringBuilder sb = new StringBuilder();
                    for (String p : new String[]{x.getThoroughfare() != null && x.getSubThoroughfare() != null
                            ? x.getThoroughfare() + " # " + x.getSubThoroughfare() : x.getThoroughfare(),
                            x.getSubLocality(), x.getLocality()}) {
                        if (p != null && !p.isEmpty() && sb.indexOf(p) < 0) sb.append(sb.length() > 0 ? ", " : "").append(p);
                    }
                    dir = sb.length() > 0 ? sb.toString() : (x.getAddressLine(0) != null ? x.getAddressLine(0) : "");
                }
            } catch (Exception ignored) {}
            a.put("direccionGps", dir);
            String lugar = "📍 " + (a.optString("nombre").isEmpty() ? "Aquí estaba" : a.optString("nombre"));
            String pie = (dir.isEmpty() ? "" : dir + "\n") + String.format(Locale.US, "%.6f, %.6f", gps.getLatitude(), gps.getLongitude())
                    + " · " + Almacen.hoy();
            Bitmap mapa = MapaFoto.crear(gps.getLatitude(), gps.getLongitude(), lugar, pie);
            a.put("mapa", mapa != null ? Almacen.guardarFotoNombre(c, mapa, a.optLong("id") + "_mapa", 640, 70) : "");
        } catch (Exception ignored) {}
    }

    // ───────── Código de barras ─────────

    static long codigo(Context c, String llave, String codigo) throws Gemini.Falla {
        JSONObject rep = Almacen.repetido(c, "", "", codigo);
        if (rep != null) return -rep.optLong("id");
        JSONObject p = nuevo("código");
        try { p.put("codigo", codigo); } catch (Exception ignored) {}
        completar(c, llave, p);
        if (p.optString("nombre").isEmpty() && p.optString("marca").isEmpty())
            throw new Gemini.Falla("No encontré en internet un producto con el código " + codigo + ". Pruebe con una foto.");
        Almacen.agregar(c, p);
        return p.optLong("id");
    }

    // ───────── Ficha técnica y precios (con Google) ─────────

    /** Busca la ficha y los precios y los pone en el producto. Guarda el catálogo. */
    static void completar(Context c, String llave, JSONObject p) throws Gemini.Falla {
        Gemini.Busqueda b = Gemini.buscarFicha(llave, p);
        boolean hayFuentes = b.fuentes != null && b.fuentes.length() > 0;
        try {
            for (String k : new String[]{"nombre", "marca", "referencia", "codigo"}) {
                String v = b.datos.optString(k).trim();
                if (p.optString(k).trim().isEmpty() && !v.isEmpty() && !v.equalsIgnoreCase("null")) p.put(k, v);
            }
            JSONArray ficha = new JSONArray();
            JSONArray fi = b.datos.optJSONArray("ficha");
            if (fi != null) for (int i = 0; i < fi.length(); i++) {
                JSONObject d = fi.optJSONObject(i);
                if (d == null) continue;
                String dato = d.optString("dato").trim(), valor = d.optString("valor").trim();
                if (dato.isEmpty()) continue;
                boolean ok = d.optBoolean("confirmado", false) && hayFuentes && !valor.isEmpty() && !valor.equalsIgnoreCase("null");
                if (!ok) valor = "";
                ficha.put(new JSONObject().put("dato", dato).put("valor", valor)
                        .put("ok", ok).put("fuente", ok ? dominio(d.optString("fuente")) : ""));
                // La potencia: si no se leyó en la etiqueta, se toma de internet solo si quedó confirmada
                if (dato.toLowerCase(Locale.ROOT).contains("potencia") && ok && p.optString("potencia").isEmpty()) {
                    p.put("potencia", valor);
                    p.put("potenciaFuente", "internet");
                }
            }
            p.put("ficha", ficha);
            JSONArray tiendas = new JSONArray();
            JSONArray ti = b.datos.optJSONArray("tiendas");
            if (ti != null && hayFuentes) for (int i = 0; i < ti.length() && tiendas.length() < 8; i++) {
                JSONObject t = ti.optJSONObject(i);
                if (t == null) continue;
                String nom = t.optString("tienda").trim();
                double precio = t.optDouble("precio", 0);
                if (nom.isEmpty() || precio <= 0 || Double.isNaN(precio)) continue;
                String url = t.optString("url").trim();
                if (!url.startsWith("http")) url = "https://www.google.com/search?tbm=shop&gl=co&hl=es&q="
                        + Uri.encode(nom + " " + Almacen.busqueda(p));
                String moneda = t.optString("moneda", "COP");
                tiendas.put(new JSONObject().put("tienda", nom).put("precio", precio)
                        .put("moneda", moneda.isEmpty() ? "COP" : moneda).put("url", url));
            }
            p.put("tiendas", tiendas);
            p.put("fuentes", b.fuentes != null ? b.fuentes : new JSONArray());
            p.put("fechaPrecios", Almacen.hoy());
            p.put("buscado", true);
        } catch (Exception e) {
            throw new Gemini.Falla("No pude ordenar la ficha que llegó");
        }
        Almacen.guardar(c);
    }

    private static String dominio(String u) {
        if (u == null) return "";
        String s = u.replaceFirst("^https?://", "").replaceFirst("^www\\.", "");
        int i = s.indexOf('/');
        return i > 0 ? s.substring(0, i) : s;
    }

    // ───────── Ayudas ─────────

    static JSONObject nuevo(String origen) {
        JSONObject p = new JSONObject();
        try {
            p.put("id", Almacen.nuevoId());
            p.put("creado", System.currentTimeMillis());
            p.put("origen", origen);
            for (String k : new String[]{"nombre", "marca", "referencia", "potencia", "codigo", "otros", "foto", "potenciaFuente"}) p.put(k, "");
        } catch (Exception ignored) {}
        return p;
    }

    private static void agregar(Context c, JSONObject it, Bitmap foto, String origen, Agregados r) {
        String marca = limpia(it.optString("marca")), ref = limpia(it.optString("referencia")), cod = limpia(it.optString("codigo"));
        if (!cod.matches("\\d{8,14}")) cod = "";
        if (Almacen.repetido(c, marca, ref, cod) != null) { r.repetidos++; return; }
        JSONObject p = nuevo(origen);
        try {
            p.put("nombre", limpia(it.optString("nombre")));
            p.put("marca", marca);
            p.put("referencia", ref);
            p.put("codigo", cod);
            p.put("otros", limpia(it.optString("otros")));
            String pot = limpia(it.optString("potencia"));
            p.put("potencia", pot);
            p.put("potenciaFuente", pot.isEmpty() ? "" : "etiqueta");
            p.put("foto", Almacen.guardarFoto(c, foto, p.optLong("id")));
        } catch (Exception ignored) {}
        if (p.optString("nombre").isEmpty() && marca.isEmpty() && ref.isEmpty()) return;
        Almacen.agregar(c, p);
        r.nuevos.add(p.optLong("id"));
    }

    private static String limpia(String s) {
        if (s == null) return "";
        s = s.trim();
        return s.equalsIgnoreCase("null") || s.equals("-") || s.equalsIgnoreCase("n/a") ? "" : s;
    }

    /** Recorta el producto con el recuadro que dio Gemini (0 a 1000), con un poquito de margen. */
    static Bitmap recortar(Bitmap b, JSONArray caja) {
        if (b == null) return null;
        try {
            if (caja == null || caja.length() != 4) return b;
            double y0 = caja.getDouble(0), x0 = caja.getDouble(1), y1 = caja.getDouble(2), x1 = caja.getDouble(3);
            if (y1 <= y0 || x1 <= x0 || y1 > 1000 || x1 > 1000 || y0 < 0 || x0 < 0) return b;
            double mx = (x1 - x0) * 0.06, my = (y1 - y0) * 0.06;
            int l = (int) Math.max(0, (x0 - mx) * b.getWidth() / 1000), t = (int) Math.max(0, (y0 - my) * b.getHeight() / 1000);
            int r = (int) Math.min(b.getWidth(), (x1 + mx) * b.getWidth() / 1000), d = (int) Math.min(b.getHeight(), (y1 + my) * b.getHeight() / 1000);
            if (r - l < 24 || d - t < 24) return b;
            return Bitmap.createBitmap(b, l, t, r - l, d - t);
        } catch (Exception e) {
            return b;
        }
    }
}
