package co.jose.micatalogo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pantalla principal: Foto, Video, Código, Almacén y Casa; la lista con pestañas; catálogo PDF y enviar todo. */
public class InicioActivity extends Comun {

    static final ExecutorService TRABAJOS = Executors.newSingleThreadExecutor();

    private static final int FOTO_CAM = 1, FOTO_GAL = 2, VIDEO_CAM = 3, VIDEO_GAL = 4, CODIGO = 5,
            SITIO_CAM = 6, SITIO_GAL = 7, DUENO_CAM = 8, PERMISO_CAMARA = 20, PERMISO_GPS = 21;

    private String pestana = "";          // "" productos, "almacen", "casa"
    private LinearLayout lista, abajo;
    private TextView estado, cuenta, tabProd, tabAlm, tabCasa;
    private EditText buscar;

    // Lo que está pendiente mientras se usa la cámara
    private Uri pendiente, sitioFoto;
    private String tipoSitio = "almacen";
    private Location gps;
    private Runnable trasPermiso;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (b != null) {
            String u = b.getString("pendiente"), s = b.getString("sitioFoto");
            if (u != null) pendiente = Uri.parse(u);
            if (s != null) sitioFoto = Uri.parse(s);
            tipoSitio = b.getString("tipoSitio", "almacen");
            pestana = b.getString("pestana", "");
            if (b.containsKey("lat")) {
                gps = new Location("guardado");
                gps.setLatitude(b.getDouble("lat"));
                gps.setLongitude(b.getDouble("lon"));
            }
        }
        getWindow().setStatusBarColor(FONDO);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        armar();
        if (llave().isEmpty()) ui.postDelayed(() -> pedirLlave(null), 400);
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        if (pendiente != null) o.putString("pendiente", pendiente.toString());
        if (sitioFoto != null) o.putString("sitioFoto", sitioFoto.toString());
        o.putString("tipoSitio", tipoSitio);
        o.putString("pestana", pestana);
        if (gps != null) { o.putDouble("lat", gps.getLatitude()); o.putDouble("lon", gps.getLongitude()); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        pintarLista();
    }

    // ───────────────────────── Pantalla ─────────────────────────

    private void armar() {
        LinearLayout raiz = vertical();
        raiz.setPadding(dp(10), dp(10), dp(10), dp(16));
        raiz.setBackgroundColor(FONDO);

        LinearLayout cab = horizontal();
        TextView titulo = texto("Mi Catálogo", 24, true);
        cab.addView(titulo, new LinearLayout.LayoutParams(0, -2, 1f));
        cuenta = texto("", 14, false);
        cab.addView(cuenta);
        TextView llaveB = boton("🔑 Llave", BLANCO, NEGRO, () -> pedirLlave(null));
        llaveB.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(8);
        cab.addView(llaveB, lp);
        raiz.addView(cab, todo());

        estado = texto("", 15, true);
        estado.setPadding(dp(12), dp(10), dp(12), dp(10));
        estado.setBackground(fondo(dp(10), AMBAR_CLARO));
        estado.setTextColor(0xFF412402);
        estado.setVisibility(View.GONE);
        LinearLayout.LayoutParams ep = todo();
        ep.topMargin = dp(8);
        raiz.addView(estado, ep);

        LinearLayout f1 = horizontal();
        f1.addView(grande("📷", "Foto", VERDE_CLARO, VERDE, this::foto), peso(1, 84));
        f1.addView(grande("🎥", "Video", CORAL_CLARO, CORAL, this::video), peso(1, 84));
        f1.addView(grande("▥", "Código", MORADO_CLARO, MORADO, this::codigo), peso(1, 84));
        LinearLayout.LayoutParams fp = todo();
        fp.topMargin = dp(6);
        raiz.addView(f1, fp);
        LinearLayout f2 = horizontal();
        f2.addView(grande("🏪", "Almacén", AMBAR_CLARO, AMBAR, this::almacen), peso(1, 70));
        f2.addView(grande("🏠", "Casa en venta", 0xFFE6F1FB, 0xFF0C447C, this::casa), peso(1, 70));
        raiz.addView(f2, todo());

        LinearLayout tabs = horizontal();
        tabProd = pestanaBoton("Productos", "");
        tabAlm = pestanaBoton("Almacenes", "almacen");
        tabCasa = pestanaBoton("Casas", "casa");
        tabs.addView(tabProd, peso(1, 46));
        tabs.addView(tabAlm, peso(1, 46));
        tabs.addView(tabCasa, peso(1, 46));
        LinearLayout.LayoutParams tp = todo();
        tp.topMargin = dp(8);
        raiz.addView(tabs, tp);

        buscar = new EditText(this);
        buscar.setHint("🔎 Buscar en mi catálogo");
        buscar.setTextColor(NEGRO);
        buscar.setHintTextColor(0xFF555555);
        buscar.setTextSize(17);
        buscar.setSingleLine(true);
        buscar.setPadding(dp(12), dp(10), dp(12), dp(10));
        buscar.setBackground(borde(dp(10), BLANCO, LINEA, dp(1)));
        buscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { pintarLista(); }
        });
        LinearLayout.LayoutParams bp = todo();
        bp.topMargin = dp(6);
        raiz.addView(buscar, bp);

        lista = vertical();
        LinearLayout.LayoutParams lip = todo();
        lip.topMargin = dp(6);
        raiz.addView(lista, lip);

        abajo = horizontal();
        abajo.addView(boton("📄 Catálogo PDF", BLANCO, NEGRO, () -> pdf(false)), peso(1, 54));
        abajo.addView(boton("💬 Enviar todo", 0xFFEAF3DE, 0xFF27500A, () -> pdf(true)), peso(1, 54));
        LinearLayout.LayoutParams ap = todo();
        ap.topMargin = dp(8);
        raiz.addView(abajo, ap);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(FONDO);
        sv.addView(raiz);
        setContentView(sv);
    }

    private TextView grande(String icono, String nombre, int claro, int oscuro, Runnable r) {
        TextView t = boton(icono + "\n" + nombre, claro, oscuro, r);
        t.setTextSize(17);
        t.setLineSpacing(0, 1.05f);
        return t;
    }

    private TextView pestanaBoton(String nombre, String tipo) {
        TextView t = boton(nombre, BLANCO, NEGRO, () -> {
            pestana = tipo;
            pintarLista();
        });
        t.setTextSize(15);
        return t;
    }

    private void marcarPestanas() {
        int np = Almacen.lista(this).size(), na = Almacen.sitios(this, "almacen").size(), nc = Almacen.sitios(this, "casa").size();
        tabProd.setText("Productos (" + np + ")");
        tabAlm.setText("Almacenes (" + na + ")");
        tabCasa.setText("Casas (" + nc + ")");
        for (TextView t : new TextView[]{tabProd, tabAlm, tabCasa}) {
            boolean sel = (t == tabProd && pestana.isEmpty()) || (t == tabAlm && pestana.equals("almacen")) || (t == tabCasa && pestana.equals("casa"));
            t.setBackground(sel ? fondo(dp(10), NEGRO) : borde(dp(10), BLANCO, LINEA, dp(1)));
            t.setTextColor(sel ? BLANCO : NEGRO);
        }
        cuenta.setText((np + na + nc) + " guardados");
        abajo.setVisibility(pestana.isEmpty() && np > 0 ? View.VISIBLE : View.GONE);
    }

    static String sinTildes(String s) {
        return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT);
    }

    private void pintarLista() {
        if (lista == null) return;
        marcarPestanas();
        lista.removeAllViews();
        String q = sinTildes(buscar.getText().toString().trim());
        List<JSONObject> items = pestana.isEmpty() ? Almacen.lista(this) : Almacen.sitios(this, pestana);
        int mostrados = 0;
        for (JSONObject p : items) {
            if (!q.isEmpty() && !sinTildes(p.toString()).contains(q)) continue;
            lista.addView(pestana.isEmpty() ? filaProducto(p) : filaSitio(p), todo());
            mostrados++;
        }
        if (mostrados == 0) {
            String m = !q.isEmpty() ? "No encontré nada con esa palabra."
                    : pestana.isEmpty() ? "Toque 📷 Foto, 🎥 Video o ▥ Código para agregar su primer producto."
                    : pestana.equals("almacen") ? "Toque 🏪 Almacén y tómele foto a la tarjeta o al frente del almacén."
                    : "Toque 🏠 Casa en venta y tómele foto a la casa (y al dueño si quiere).";
            TextView v = texto(m, 16, false);
            v.setGravity(Gravity.CENTER);
            v.setPadding(dp(16), dp(28), dp(16), dp(28));
            lista.addView(v, todo());
        }
    }

    private ImageView miniatura(android.graphics.Bitmap b, String icono) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(fondo(dp(8), 0xFFE8E6DF));
        iv.setClipToOutline(true);
        if (b != null) iv.setImageBitmap(b);
        return iv;
    }

    private View cuadroIcono(String icono) {
        TextView t = texto(icono, 28, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(fondo(dp(8), 0xFFE8E6DF));
        return t;
    }

    private View filaProducto(JSONObject p) {
        LinearLayout f = horizontal();
        f.setPadding(dp(4), dp(8), dp(4), dp(8));
        f.setBackground(borde(0, BLANCO, LINEA, 1));
        Bitmap foto = Almacen.foto(this, p);
        View mini = foto != null ? miniatura(foto, "") : cuadroIcono("código".equals(p.optString("origen")) ? "▥" : "📦");
        f.addView(mini, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout tx = vertical();
        tx.setPadding(dp(10), 0, dp(6), 0);
        tx.addView(texto(Almacen.titulo(p), 16, true));
        StringBuilder l2 = new StringBuilder();
        if (!p.optString("referencia").isEmpty()) l2.append("Ref. ").append(p.optString("referencia"));
        if (!p.optString("potencia").isEmpty()) l2.append(l2.length() > 0 ? " · " : "").append(p.optString("potencia"));
        if (l2.length() > 0) tx.addView(texto(l2.toString(), 14, false));
        JSONObject barata = Almacen.masBarata(p);
        JSONArray t = p.optJSONArray("tiendas");
        String l3 = barata != null ? "Desde " + plata(barata.optDouble("precio"), barata.optString("moneda")) + " · " + t.length() + (t.length() == 1 ? " tienda" : " tiendas")
                : p.optBoolean("buscado") ? "Sin precios en internet" : "Toque para buscar ficha y precios";
        tx.addView(texto(l3, 14, barata != null));
        f.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView wa = texto("💬", 26, false);
        wa.setGravity(Gravity.CENTER);
        wa.setOnClickListener(v -> enviarFicha(p));
        f.addView(wa, new LinearLayout.LayoutParams(dp(48), dp(56)));
        long id = p.optLong("id");
        f.setOnClickListener(v -> startActivity(new Intent(this, FichaActivity.class).putExtra("id", id)));
        f.setOnLongClickListener(v -> { preguntarBorrar(p); return true; });
        return f;
    }

    private View filaSitio(JSONObject a) {
        LinearLayout caja = vertical();
        caja.setPadding(dp(4), dp(8), dp(4), dp(8));
        caja.setBackground(borde(0, BLANCO, LINEA, 1));
        LinearLayout f = horizontal();
        Bitmap logo = Almacen.logo(this, a);
        if (logo == null) logo = Almacen.foto(this, a);
        f.addView(logo != null ? miniatura(logo, "") : cuadroIcono("casa".equals(a.optString("tipo")) ? "🏠" : "🏪"),
                new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout tx = vertical();
        tx.setPadding(dp(10), 0, dp(6), 0);
        tx.addView(texto(a.optString("nombre").isEmpty() ? "Sin nombre" : a.optString("nombre"), 16, true));
        String l2 = "casa".equals(a.optString("tipo")) ? unir(a.optString("precio"), a.optString("detalles")) : a.optString("vende");
        if (!l2.isEmpty()) tx.addView(texto(l2, 14, false));
        String dir = !a.optString("direccion").isEmpty() ? a.optString("direccion") : a.optString("direccionGps");
        if (!dir.isEmpty()) tx.addView(texto("📍 " + dir, 13, false));
        f.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        caja.addView(f, todo());
        JSONArray tel = a.optJSONArray("telefonos");
        if (tel != null && tel.length() > 0) {
            LinearLayout tf = horizontal();
            for (int i = 0; i < tel.length() && i < 2; i++) {
                String n = tel.optString(i);
                tf.addView(boton("📞 " + n, 0xFFEAF3DE, 0xFF27500A, () -> llamar(n)), peso(1, 48));
            }
            LinearLayout.LayoutParams tp = todo();
            tp.topMargin = dp(4);
            caja.addView(tf, tp);
        }
        long id = a.optLong("id");
        caja.setOnClickListener(v -> startActivity(new Intent(this, AlmacenActivity.class).putExtra("id", id)));
        caja.setOnLongClickListener(v -> { preguntarBorrar(a); return true; });
        return caja;
    }

    static String unir(String... partes) {
        StringBuilder s = new StringBuilder();
        for (String x : partes) if (x != null && !x.trim().isEmpty()) s.append(s.length() > 0 ? " · " : "").append(x.trim());
        return s.toString();
    }

    private void preguntarBorrar(JSONObject p) {
        String n = p.has("tipo") && !p.optString("tipo").isEmpty() ? p.optString("nombre") : Almacen.titulo(p);
        new AlertDialog.Builder(this).setTitle("¿Borrar?").setMessage(n)
                .setPositiveButton("Borrar", (d, w) -> { Almacen.borrar(this, p.optLong("id")); pintarLista(); })
                .setNegativeButton("No", null).show();
    }

    private void mostrarEstado(String s) {
        ui.post(() -> {
            if (isDestroyed()) return;
            estado.setText(s);
            estado.setVisibility(s == null || s.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    // ───────────────────────── Llave de Gemini ─────────────────────────

    String llave() { return getSharedPreferences("chepe", MODE_PRIVATE).getString("llave", ""); }

    private void pedirLlave(Runnable luego) {
        EditText e = new EditText(this);
        e.setHint("Pegue aquí la llave (empieza por AIza)");
        e.setText(llave());
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        e.setTextColor(NEGRO);
        LinearLayout c = vertical();
        c.setPadding(dp(18), dp(6), dp(18), 0);
        TextView ay = texto("1. Abra Google AI Studio (Claves de API).\n2. Toque copiar en su llave.\n3. Vuelva aquí y toque «Pegar».", 15, false);
        c.addView(ay);
        c.addView(e, todo());
        AlertDialog d = new AlertDialog.Builder(this).setTitle("🔑 Llave de Gemini").setView(c)
                .setPositiveButton("Guardar", null)
                .setNeutralButton("Pegar", null)
                .setNegativeButton("Después", null).create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                try {
                    ClipboardManager cm = getSystemService(ClipboardManager.class);
                    CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                    e.setText(t.toString().trim());
                } catch (Exception ex) { aviso("No hay nada copiado"); }
            });
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String k = e.getText().toString().trim().replaceAll("\\s", "");
                if (k.length() < 30) { aviso("Esa llave está incompleta. Cópiela otra vez."); return; }
                getSharedPreferences("chepe", MODE_PRIVATE).edit().putString("llave", k).apply();
                aviso("Llave guardada ✓");
                d.dismiss();
                if (luego != null) luego.run();
            });
        });
        d.show();
    }

    /** Antes de usar Gemini: si no hay llave, la pide primero. */
    private void conLlave(Runnable r) {
        if (llave().isEmpty()) pedirLlave(r);
        else r.run();
    }

    // ───────────────────────── Botones ─────────────────────────

    private void foto() {
        conLlave(() -> elegir("¿De dónde sale la foto?", new String[]{"📷 Tomar foto", "🖼 De la galería"}, i -> {
            if (i == 0) camara(FOTO_CAM, "producto");
            else galeria("image/*", FOTO_GAL);
        }));
    }

    private void video() {
        conLlave(() -> elegir("Video de la tienda (pase despacio, 30 a 60 segundos)", new String[]{"🎥 Grabar video", "🖼 De la galería"}, i -> {
            if (i == 0) conPermisoCamara(() -> {
                Intent v = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                v.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 120);
                v.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
                try { startActivityForResult(v, VIDEO_CAM); } catch (Exception e) { aviso("No encontré la cámara de video"); }
            });
            else galeria("video/*", VIDEO_GAL);
        }));
    }

    private void codigo() {
        conLlave(() -> startActivityForResult(new Intent(this, CodigoActivity.class), CODIGO));
    }

    private void almacen() {
        conLlave(() -> elegir("Almacén", new String[]{"📇 Foto de la tarjeta", "🏪 Foto del almacén (frente o letrero)", "🖼 De la galería"}, i -> {
            tipoSitio = "almacen";
            if (i < 2) { pedirGps(); camara(SITIO_CAM, "almacen"); }
            else galeria("image/*", SITIO_GAL);
        }));
    }

    private void casa() {
        conLlave(() -> elegir("Casa en venta", new String[]{"📷 Tomar foto de la casa", "🖼 De la galería"}, i -> {
            tipoSitio = "casa";
            if (i == 0) { pedirGps(); camara(SITIO_CAM, "casa"); }
            else galeria("image/*", SITIO_GAL);
        }));
    }

    interface Eleccion { void escogio(int i); }

    private void elegir(String titulo, String[] ops, Eleccion e) {
        new AlertDialog.Builder(this).setTitle(titulo).setItems(ops, (d, i) -> e.escogio(i)).setNegativeButton("Cancelar", null).show();
    }

    private void galeria(String tipo, int codigo) {
        try { startActivityForResult(Intent.createChooser(new Intent(Intent.ACTION_GET_CONTENT).setType(tipo), "Escoja"), codigo); }
        catch (Exception e) { aviso("No encontré la galería"); }
    }

    private void conPermisoCamara(Runnable r) {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) r.run();
        else { trasPermiso = r; requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISO_CAMARA); }
    }

    /** Abre la cámara del celular; la foto grande se borra después, solo queda la pequeña. */
    private void camara(int codigo, String nombre) {
        conPermisoCamara(() -> {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, "tmp_" + nombre + "_" + System.currentTimeMillis() + ".jpg");
                v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, CARPETA + "/Temporal");
                pendiente = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, pendiente);
                i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(i, codigo);
            } catch (Exception e) {
                aviso("No pude abrir la cámara");
            }
        });
    }

    private void borrarTemporal(Uri u) {
        if (u == null) return;
        try { getContentResolver().delete(u, null, null); } catch (Exception ignored) {}
    }

    private void pedirGps() {
        gps = null;
        if (!Gps.tienePermiso(this)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISO_GPS);
            return;
        }
        Gps.pedir(this, l -> gps = l);
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] res) {
        super.onRequestPermissionsResult(r, p, res);
        boolean si = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (r == PERMISO_CAMARA) {
            if (si && trasPermiso != null) trasPermiso.run();
            else if (!si) aviso("Sin permiso de cámara no puedo tomar la foto");
            trasPermiso = null;
        } else if (r == PERMISO_GPS) {
            if (si) Gps.pedir(this, l -> gps = l);
            else aviso("Sin permiso de ubicación no se guarda el GPS");
        }
    }

    // ───────────────────────── Resultados ─────────────────────────

    @Override
    protected void onActivityResult(int r, int res, Intent d) {
        super.onActivityResult(r, res, d);
        if (res != RESULT_OK) {
            if (r == FOTO_CAM || r == SITIO_CAM || r == DUENO_CAM) borrarTemporal(pendiente);
            if (r == DUENO_CAM && sitioFoto != null) procesarSitio(sitioFoto, true, null); // sin foto del dueño
            pendiente = null;
            return;
        }
        Uri u = d != null ? d.getData() : null;
        switch (r) {
            case FOTO_CAM: procesarFoto(pendiente, true); pendiente = null; break;
            case FOTO_GAL: if (u != null) procesarFoto(u, false); break;
            case VIDEO_CAM:
            case VIDEO_GAL: if (u != null) procesarVideo(u); break;
            case CODIGO: if (d != null && d.getStringExtra("codigo") != null) procesarCodigo(d.getStringExtra("codigo")); break;
            case SITIO_CAM:
                if ("casa".equals(tipoSitio)) {
                    sitioFoto = pendiente;
                    pendiente = null;
                    new AlertDialog.Builder(this).setTitle("¿Le toma foto al dueño?")
                            .setMessage("Queda guardada junto con la casa (pequeña, para recordar con quién habló).")
                            .setPositiveButton("📷 Sí", (x, w) -> camara(DUENO_CAM, "dueno"))
                            .setNegativeButton("No", (x, w) -> procesarSitio(sitioFoto, true, null))
                            .setCancelable(false).show();
                } else { procesarSitio(pendiente, true, null); pendiente = null; }
                break;
            case SITIO_GAL: if (u != null) procesarSitio(u, false, null); break;
            case DUENO_CAM: procesarSitio(sitioFoto, true, pendiente); pendiente = null; break;
        }
    }

    private void procesarFoto(Uri u, boolean temporal) {
        if (u == null) return;
        String k = llave();
        mostrarEstado("📷 Gemini está leyendo la foto…");
        TRABAJOS.execute(() -> {
            try {
                Trabajo.Agregados a = Trabajo.foto(getApplicationContext(), k, u);
                if (temporal) borrarTemporal(u);
                ui.post(() -> { pestana = ""; pintarLista(); });
                if (a.nuevos.isEmpty()) {
                    mostrarEstado(null);
                    ui.post(() -> aviso(a.repetidos > 0 ? "Ese producto ya estaba en el catálogo" : "No vi productos claros. Acérquese más y con buena luz."));
                    return;
                }
                if (a.nuevos.size() == 1) {
                    // Un solo producto: de una vez se busca su ficha y los precios
                    mostrarEstado("🔎 Buscando la ficha técnica y los precios en internet…");
                    JSONObject p = Almacen.buscar(getApplicationContext(), a.nuevos.get(0));
                    try { if (p != null) Trabajo.completar(getApplicationContext(), k, p); }
                    catch (Gemini.Falla f) { ui.post(() -> aviso(f.getMessage())); }
                }
                mostrarEstado(null);
                ui.post(() -> {
                    pintarLista();
                    aviso("✓ " + a.nuevos.size() + (a.nuevos.size() == 1 ? " producto agregado" : " productos agregados")
                            + (a.repetidos > 0 ? " (" + a.repetidos + " ya estaban)" : ""));
                });
            } catch (Gemini.Falla f) {
                if (temporal) borrarTemporal(u);
                mostrarEstado(null);
                ui.post(() -> aviso(f.getMessage()));
            }
        });
    }

    private void procesarVideo(Uri u) {
        String k = llave();
        long tamano = -1;
        String mime = getContentResolver().getType(u);
        if (mime == null || !mime.startsWith("video/")) mime = "video/mp4";
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) tamano = c.getLong(0);
        } catch (Exception ignored) {}
        if (tamano <= 0) { aviso("No pude leer el tamaño del video"); return; }
        if (tamano > 1024L * 1024 * 1024) { aviso("Ese video es muy grande. Grabe uno más corto (máximo 2 minutos)."); return; }
        final long tam = tamano;
        final String mm = mime;
        mostrarEstado("🎥 Preparando el video… (" + (tam / (1024 * 1024)) + " MB)");
        TRABAJOS.execute(() -> {
            try {
                Trabajo.Agregados a = Trabajo.video(getApplicationContext(), k, u, mm, tam, this::mostrarEstado);
                mostrarEstado(null);
                ui.post(() -> {
                    pestana = "";
                    pintarLista();
                    aviso(a.nuevos.isEmpty() ? (a.repetidos > 0 ? "Todos esos productos ya estaban" : "No vi productos claros en el video")
                            : "✓ " + a.nuevos.size() + " productos agregados del video" + (a.repetidos > 0 ? " (" + a.repetidos + " ya estaban)" : "")
                            + ". Toque cada uno para buscar su ficha y precios.");
                });
            } catch (Gemini.Falla f) {
                mostrarEstado(null);
                ui.post(() -> aviso(f.getMessage()));
            }
        });
    }

    private void procesarCodigo(String cod) {
        String k = llave();
        mostrarEstado("▥ Buscando el código " + cod + " en internet…");
        TRABAJOS.execute(() -> {
            try {
                long id = Trabajo.codigo(getApplicationContext(), k, cod);
                mostrarEstado(null);
                ui.post(() -> {
                    pestana = "";
                    pintarLista();
                    if (id < 0) aviso("Ese producto ya estaba en el catálogo");
                    startActivity(new Intent(this, FichaActivity.class).putExtra("id", Math.abs(id)));
                });
            } catch (Gemini.Falla f) {
                mostrarEstado(null);
                ui.post(() -> aviso(f.getMessage()));
            }
        });
    }

    private void procesarSitio(Uri foto, boolean temporal, Uri dueno) {
        if (foto == null) return;
        String k = llave(), tipo = tipoSitio;
        Location g = temporal ? gps : null;
        sitioFoto = null;
        mostrarEstado("casa".equals(tipo) ? "🏠 Leyendo los avisos de la casa y guardando el GPS…" : "🏪 Leyendo la tarjeta y guardando el GPS…");
        TRABAJOS.execute(() -> {
            try {
                long id = Trabajo.sitio(getApplicationContext(), k, tipo, foto, dueno, g);
                if (temporal) { borrarTemporal(foto); borrarTemporal(dueno); }
                mostrarEstado(null);
                ui.post(() -> {
                    pestana = tipo;
                    pintarLista();
                    if (temporal && g == null) aviso("Quedó guardado, pero sin GPS (no se consiguió la ubicación). Ábralo y toque «Guardar GPS aquí».");
                    startActivity(new Intent(this, AlmacenActivity.class).putExtra("id", id));
                });
            } catch (Gemini.Falla f) {
                if (temporal) { borrarTemporal(foto); borrarTemporal(dueno); }
                mostrarEstado(null);
                ui.post(() -> aviso(f.getMessage()));
            }
        });
    }

    // ───────────────────────── Compartir ─────────────────────────

    private void enviarFicha(JSONObject p) {
        TRABAJOS.execute(() -> {
            try {
                byte[] img = Imagenes.ficha(getApplicationContext(), p);
                Uri u = guardar("Ficha_" + Almacen.limpio(Almacen.titulo(p)) + "_" + System.currentTimeMillis() % 100000 + ".jpg", "image/jpeg", img);
                ui.post(() -> enviarWhatsApp(u, "image/jpeg", FichaActivity.resumen(p)));
            } catch (Exception e) {
                ui.post(() -> aviso("No pude armar la ficha"));
            }
        });
    }

    private void pdf(boolean enviar) {
        List<JSONObject> items = Almacen.lista(this);
        if (items.isEmpty()) { aviso("No hay productos todavía"); return; }
        mostrarEstado("📄 Armando el catálogo en PDF tamaño carta…");
        TRABAJOS.execute(() -> {
            try {
                byte[] b = Imagenes.catalogo(getApplicationContext(), items);
                String nombre = "Catalogo_" + Almacen.hoy().replace(" ", "_") + "_" + System.currentTimeMillis() % 10000 + ".pdf";
                Uri u = guardar(nombre, "application/pdf", b);
                mostrarEstado(null);
                ui.post(() -> {
                    aviso("Guardado en Descargas/MiBarra/Catalogo (" + Math.max(1, b.length / 1024) + " KB)");
                    if (enviar) enviarWhatsApp(u, "application/pdf", "Catálogo de productos · " + Almacen.hoy());
                    else {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/pdf")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                        } catch (Exception e) { aviso("No tengo con qué abrir el PDF, pero quedó guardado"); }
                    }
                });
            } catch (Exception e) {
                mostrarEstado(null);
                ui.post(() -> aviso("No pude armar el PDF"));
            }
        });
    }
}
