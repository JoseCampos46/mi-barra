package co.jose.chepeestudio;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;

import java.io.File;
import java.nio.ShortBuffer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * El motor de sonido de Chepe Estudio: 16 canales como una organeta (el 10 es la batería),
 * hasta 64 notas al tiempo, con sonidos reales del banco SF2.
 * Canal 0 = su mano derecha, 1 = capa, 2 = bajo, 3 = acompañamiento, 4 = fondo, 9 = batería.
 */
public final class Motor implements Runnable {

    public static final int SR = 44100, BLOCK = 128, MAXV = 64;

    public interface Clock { void block(Motor m, int frames); }

    public interface Listener { void event(int status, int d1, int d2); }

    private final Sf2 sf;
    private final ShortBuffer smp;
    private final Voice[] voices = new Voice[MAXV];
    private final int[] bank = new int[16], prog = new int[16];
    private final float[] chVol = new float[16];
    private final boolean[] sustain = new boolean[16];
    private final ConcurrentLinkedQueue<int[]> q = new ConcurrentLinkedQueue<>();
    private volatile boolean running = true, active = true;
    private final Object lock = new Object();
    public volatile float master = 0.8f;
    public volatile Clock clock;
    public volatile Listener listener;
    private volatile Rec rec;
    private long stamp;

    public Motor(Sf2 s) { this(s, true); }

    /** conHilo = false solo para pruebas (sin parlante). */
    Motor(Sf2 s, boolean conHilo) {
        sf = s;
        smp = s.smpl;
        for (int i = 0; i < MAXV; i++) voices[i] = new Voice();
        for (int i = 0; i < 16; i++) chVol[i] = 1f;
        bank[9] = 128;
        if (!conHilo) return;
        Thread t = new Thread(this, "motor");
        t.setPriority(Thread.MAX_PRIORITY);
        t.start();
    }

    /** Calcula un bloque de sonido (estéreo intercalado) sin mandarlo al parlante. */
    void procesar(float[] mix, int n) {
        Clock c = clock;
        if (c != null) c.block(this, n);
        int[] e;
        while ((e = q.poll()) != null) handle(e);
        java.util.Arrays.fill(mix, 0f);
        for (Voice v : voices) if (v.on) v.render(mix, n);
        stamp += n;
    }

    // ---------------- órdenes (se pueden llamar desde cualquier hilo)

    public void noteOn(int ch, int key, int vel) { q.add(new int[]{0x90 | ch, key, vel}); }
    public void noteOff(int ch, int key) { q.add(new int[]{0x80 | ch, key, 0}); }
    public void program(int ch, int bk, int pg) { q.add(new int[]{0xC0 | ch, pg, bk}); }
    public void volume(int ch, float v) { q.add(new int[]{0xB0 | ch, 7, Math.round(v * 127)}); }
    public void pedal(int ch, boolean on) { q.add(new int[]{0xB0 | ch, 64, on ? 127 : 0}); }
    public void allOff(int ch) { q.add(new int[]{0xB0 | ch, 123, 0}); }
    public int programOf(int ch) { return prog[ch]; }
    public int bankOf(int ch) { return bank[ch]; }

    /** Encender o apagar el sonido (para no gastar batería con la app en segundo plano). */
    public void setActive(boolean on) {
        synchronized (lock) { active = on; lock.notifyAll(); }
    }

    public void release() { running = false; setActive(true); stopRec(); }

    public boolean isRecording() { return rec != null; }

    public void startRec(File f) throws Exception {
        if (rec != null) return;
        Rec r = new Rec(f);
        r.start();
        rec = r;
        stamp = 0;
    }

    public File stopRec() {
        Rec r = rec;
        rec = null;
        if (r == null) return null;
        r.stopAndWait();
        return r.file;
    }

    /** Muestras desde que empezó a grabar (para el archivo MIDI). */
    public long stamp() { return stamp; }

    // ---------------- dentro del hilo de sonido

    private void handle(int[] e) {
        int st = e[0] & 0xF0, ch = e[0] & 0x0F;
        switch (st) {
            case 0x90:
                if (e[2] == 0) off(ch, e[1]); else on(ch, e[1], e[2]);
                break;
            case 0x80: off(ch, e[1]); break;
            case 0xC0: prog[ch] = e[1]; bank[ch] = e[2]; break;
            case 0xB0:
                if (e[1] == 7) chVol[ch] = e[2] / 127f;
                else if (e[1] == 64) {
                    sustain[ch] = e[2] >= 64;
                    if (!sustain[ch]) for (Voice v : voices) if (v.on && v.ch == ch && v.held) { v.held = false; v.release(); }
                } else if (e[1] == 123) {
                    for (Voice v : voices) if (v.on && v.ch == ch) v.release();
                }
                break;
        }
        Listener l = listener;
        if (l != null) l.event(e[0], e[1], e[2]);
    }

    private void on(int ch, int key, int vel) {
        Sf2.Preset p = sf.preset(bank[ch], prog[ch]);
        if (p == null) return;
        for (Sf2.Zone z : p.zones) {
            if (key < z.keyLo || key > z.keyHi || vel < z.velLo || vel > z.velHi) continue;
            if (z.exclusive != 0)
                for (Voice v : voices) if (v.on && v.ch == ch && v.z.exclusive == z.exclusive) v.kill();
            Voice v = free();
            v.start(ch, key, vel, z, chVol[ch]);
        }
    }

    private void off(int ch, int key) {
        for (Voice v : voices) {
            if (!v.on || v.ch != ch || v.key != key || v.stage >= 5) continue;
            if (sustain[ch]) v.held = true;
            else v.release();
        }
    }

    private Voice free() {
        Voice best = null;
        for (Voice v : voices) if (!v.on) return v;
        // roba la nota más vieja que ya se esté apagando, si no la más vieja
        for (Voice v : voices) if (v.stage >= 5 && (best == null || v.age > best.age)) best = v;
        if (best == null) for (Voice v : voices) if (best == null || v.age > best.age) best = v;
        return best;
    }

    @Override
    public void run() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack.Builder b = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(Math.max(min, BLOCK * 4 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM);
        if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
        AudioTrack at = b.build();
        float[] mix = new float[BLOCK * 2];
        short[] out = new short[BLOCK * 2];
        at.play();
        boolean playing = true;
        while (running) {
            if (!active) {
                if (playing) { at.pause(); at.flush(); playing = false; }
                synchronized (lock) { while (!active && running) { try { lock.wait(); } catch (InterruptedException ignored) {} } }
                if (!running) break;
                at.play();
                playing = true;
            }
            try {
                procesar(mix, BLOCK);
                stamp -= BLOCK;
                float m = master;
                for (int i = 0; i < BLOCK * 2; i++) {
                    float x = mix[i] * m;
                    float ax = Math.abs(x);
                    if (ax > 0.8f) x = Math.signum(x) * (0.8f + 0.2f * (float) Math.tanh((ax - 0.8f) / 0.2f));
                    if (x > 1f) x = 1f; else if (x < -1f) x = -1f;
                    out[i] = (short) (x * 32767f);
                }
            } catch (Throwable t) {
                java.util.Arrays.fill(out, (short) 0);
            }
            at.write(out, 0, out.length);
            stamp += BLOCK;
            Rec r = rec;
            if (r != null) r.feed(out.clone());
        }
        try { at.stop(); } catch (Exception ignored) {}
        at.release();
    }

    // ---------------- una nota sonando

    private final class Voice {
        boolean on, held;
        int ch, key, stage; // 0 espera 1 sube 2 sostiene 3 baja 4 queda 5 suelta
        long age;
        Sf2.Zone z;
        double pos, step;
        float gL, gR, envDb, envAmp, stageLeft, attackLen;
        float decayRate, releaseRate;
        // filtro
        boolean filt;
        float fb0, fb1, fb2, fa1, fa2, x1, x2, y1, y2;

        void start(int c, int k, int vel, Sf2.Zone zz, float chv) {
            on = true;
            held = false;
            ch = c;
            key = k;
            z = zz;
            age = 0;
            for (Voice v : voices) if (v.on) v.age++;
            pos = zz.start;
            double cents = (k - zz.rootKey) * zz.scaleTuning + zz.tuneCents;
            step = Math.pow(2, cents / 1200.0) * zz.sampleRate / SR;
            float velAmp = (vel / 127f) * (vel / 127f);
            float amp = (float) Math.pow(10, -zz.attenuation * 0.4 / 20.0) * velAmp * chv * 1.7f;
            double ang = (zz.pan + 500) / 1000.0 * Math.PI / 2;
            gL = (float) (amp * Math.cos(ang));
            gR = (float) (amp * Math.sin(ang));
            stage = 0;
            stageLeft = zz.delay * SR;
            envAmp = 0;
            envDb = 0;
            attackLen = Math.max(1, zz.attack * SR);
            decayRate = 100f / Math.max(1, zz.decay * SR);
            releaseRate = 100f / Math.max(1, zz.release * SR);
            x1 = x2 = y1 = y2 = 0;
            filt = zz.filterHz < 16000;
            if (filt) {
                double w = 2 * Math.PI * Math.max(40, zz.filterHz) / SR, cs = Math.cos(w), al = Math.sin(w) / (2 * 0.707);
                double a0 = 1 + al;
                fb0 = (float) ((1 - cs) / 2 / a0); fb1 = (float) ((1 - cs) / a0); fb2 = fb0;
                fa1 = (float) (-2 * cs / a0); fa2 = (float) ((1 - al) / a0);
            }
        }

        void release() {
            if (stage < 5) { stage = 5; }
        }

        void kill() { releaseRate = 100f / (SR * 0.02f); stage = 5; }

        /** Volumen de la envolvente para el próximo pedazo (se calcula una vez por bloque y se va suavizando). */
        private float envStep(int n) {
            switch (stage) {
                case 0:
                    stageLeft -= n;
                    if (stageLeft <= 0) { stage = 1; stageLeft = attackLen; }
                    return 0f;
                case 1:
                    stageLeft -= n;
                    envAmp = Math.min(1f, 1f - stageLeft / attackLen);
                    if (stageLeft <= 0) { stage = 2; envAmp = 1f; stageLeft = z.hold * SR; }
                    return envAmp;
                case 2:
                    stageLeft -= n;
                    if (stageLeft <= 0) stage = 3;
                    return 1f;
                case 3:
                    envDb += decayRate * n;
                    if (envDb >= z.sustainDb) { envDb = z.sustainDb; stage = 4; }
                    if (envDb >= 96) { on = false; return 0f; }
                    return envAmp = db(envDb);
                case 4:
                    if (z.sustainDb >= 96) { on = false; return 0f; }
                    return envAmp = db(envDb);
                default:
                    // al soltar: baja desde donde iba
                    if (envAmp > 0 && envDb <= 0 && envAmp < 1f) envDb = (float) (-20 * Math.log10(Math.max(1e-5, envAmp)));
                    envDb += releaseRate * n;
                    if (envDb >= 90) { on = false; return 0f; }
                    return envAmp = db(envDb);
            }
        }

        private float db(float d) { return (float) Math.pow(10, -d / 20.0); }

        void render(float[] mix, int n) {
            float e0 = envAmp;
            float e1 = envStep(n);
            if (!on) return;
            float de = (e1 - e0) / n;
            float e = e0;
            int lm = z.loopMode;
            boolean loop = lm == 1 || (lm == 3 && stage < 5);
            int end = z.end, ls = z.loopStart, le = z.loopEnd;
            double p = pos, st = step;
            ShortBuffer s = smp;
            for (int i = 0; i < n; i++) {
                int ip = (int) p;
                if (loop) {
                    if (ip >= le) { p -= (le - ls); ip = (int) p; }
                } else if (ip >= end - 1) { on = false; break; }
                int i2 = ip + 1;
                if (loop && i2 >= le) i2 = ls;
                float a = s.get(ip), b = s.get(Math.min(i2, end - 1));
                float x = (a + (b - a) * (float) (p - ip)) / 32768f;
                if (filt) {
                    float y = fb0 * x + fb1 * x1 + fb2 * x2 - fa1 * y1 - fa2 * y2;
                    x2 = x1; x1 = x; y2 = y1; y1 = y;
                    x = y;
                }
                x *= e;
                e += de;
                mix[2 * i] += x * gL;
                mix[2 * i + 1] += x * gR;
                p += st;
            }
            pos = p;
        }
    }

    // ---------------- grabar lo que suena

    static final class Rec implements Runnable {
        final File file;
        final Aac aac;
        final LinkedBlockingQueue<short[]> qq = new LinkedBlockingQueue<>();
        volatile boolean stop;
        Thread t;

        Rec(File f) throws Exception { file = f; aac = new Aac(f, 192000); }

        void start() { t = new Thread(this, "grabar"); t.start(); }

        void feed(short[] b) { qq.add(b); }

        void stopAndWait() {
            stop = true;
            try { t.join(15000); } catch (InterruptedException ignored) {}
        }

        @Override
        public void run() {
            try {
                while (!stop || !qq.isEmpty()) {
                    short[] b = qq.poll(100, TimeUnit.MILLISECONDS);
                    if (b != null) aac.write(b, 0, b.length / 2);
                }
            } catch (Exception ignored) {
            } finally {
                aac.finish();
            }
        }
    }
}
