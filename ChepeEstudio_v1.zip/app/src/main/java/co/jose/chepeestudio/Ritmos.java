package co.jose.chepeestudio;

import java.util.ArrayList;
import java.util.List;

/**
 * El arreglista automático (como en las Yamaha): batería, bajo y acompañamiento
 * que siguen el acorde que usted toca con la mano izquierda.
 */
public final class Ritmos implements Motor.Clock {

    // ---------------- estilos

    public static final class Estilo {
        final String nombre;
        final int tempo, pasosPorTiempo, kit;
        final int progBajo, progAcomp, progFondo; // -1 = sin fondo
        final String[][] bateria; // {tecla, patrón}
        final String bajo, acomp;
        final int largoAcomp; // cuántos pasos dura cada golpe del acompañamiento

        Estilo(String n, int t, int ppt, int kit, int pb, int pa, int pf, String bajo, String acomp, int largo, String[]... bat) {
            nombre = n; tempo = t; pasosPorTiempo = ppt; this.kit = kit;
            progBajo = pb; progAcomp = pa; progFondo = pf;
            this.bajo = bajo; this.acomp = acomp; largoAcomp = largo; bateria = bat;
        }

        int pasos() { return bajo.length(); }
    }

    // Batería General MIDI: 36 bombo, 37 aro, 38 caja, 42 hi-hat, 45 tom, 49 platillo, 56 cencerro,
    // 60/61 bongó, 62/63/64 congas, 65/66 timbal, 69 cabasa, 70 maracas, 73/74 güiro, 75 clave
    public static final Estilo[] ESTILOS = {
            new Estilo("Salsa", 180, 2, 0, 33, 0, -1,
                    "...R..5....R..5.", ".C.CC.C..C.CC.C.", 1,
                    new String[]{"75", "..x.x...x..x..x."},
                    new String[]{"56", "x.o.x.o.x.o.x.o."},
                    new String[]{"62", "..x.......x....."},
                    new String[]{"63", ".......X.......X"},
                    new String[]{"64", "......x.......x."},
                    new String[]{"36", "x.......x......."}),
            new Estilo("Cumbia", 96, 2, 0, 33, 21, -1,
                    "R...5...", ".c.c.c.c", 1,
                    new String[]{"73", "x.xxx.xx"},
                    new String[]{"69", "o.o.o.o."},
                    new String[]{"63", "..x...x."},
                    new String[]{"64", "x...x..."},
                    new String[]{"36", "x...x..."}),
            new Estilo("Vallenato", 112, 2, 0, 33, 21, -1,
                    "R..5R..5", ".c.c.c.c", 1,
                    new String[]{"65", "x.x.x.xx"},
                    new String[]{"73", "x.xxx.xx"},
                    new String[]{"36", "x...x..."}),
            new Estilo("Merengue", 130, 2, 0, 33, 0, -1,
                    "R.5.R.5.", ".c.c.c.c", 1,
                    new String[]{"45", "x...x..x"},
                    new String[]{"37", "..x...x."},
                    new String[]{"70", "xoxoxoxo"},
                    new String[]{"36", "x.x.x.x."}),
            new Estilo("Bachata", 128, 2, 0, 33, 24, -1,
                    "R..5..8.", "R358R358", 1,
                    new String[]{"60", "x.x.x..."},
                    new String[]{"61", "......x."},
                    new String[]{"70", "x.xxx.xx"},
                    new String[]{"36", "x...x..."}),
            new Estilo("Balada", 72, 2, 40, 33, 0, 48,
                    "R...5...", "R583R583", 1,
                    new String[]{"36", "x....x.."},
                    new String[]{"37", "..x...x."},
                    new String[]{"42", "o.o.o.o."}),
            new Estilo("Pop", 110, 2, 0, 33, 0, -1,
                    "R.RR.R.5", "C..c.C..", 2,
                    new String[]{"36", "x...x.x."},
                    new String[]{"38", "..x...x."},
                    new String[]{"42", "xoxoxoxo"}),
            new Estilo("Rock", 122, 2, 16, 34, 29, -1,
                    "RRRRRRRR", "P.PP.PP.", 1,
                    new String[]{"36", "x..xx..."},
                    new String[]{"38", "..X...X."},
                    new String[]{"42", "xxxxxxxx"}),
    };

    // ---------------- acordes

    public static final String[] NOTAS = {"Do", "Do#", "Re", "Mib", "Mi", "Fa", "Fa#", "Sol", "Lab", "La", "Sib", "Si"};
    static final int[][] TIPOS = {{0, 4, 7}, {0, 3, 7}, {0, 4, 7, 10}, {0, 3, 7, 10}, {0, 4, 7, 11}, {0, 3, 6}, {0, 5, 7}, {0, 4, 8}};
    static final String[] NOMBRE_TIPO = {"mayor", "menor", "7", "m7", "maj7", "disminuido", "sus4", "aumentado"};

    /** Reconoce el acorde de las teclas de la mano izquierda. Devuelve {raíz, tipo} o null. */
    public static int[] reconocer(List<Integer> teclas) {
        if (teclas.isEmpty()) return null;
        int low = 999;
        int mask = 0;
        for (int k : teclas) { mask |= 1 << (k % 12); low = Math.min(low, k); }
        if (Integer.bitCount(mask) == 1) return new int[]{low % 12, 0};
        int best = -1, bestT = 0, bestScore = -99;
        for (int r = 0; r < 12; r++) {
            if ((mask & (1 << r)) == 0) continue;
            for (int t = 0; t < TIPOS.length; t++) {
                int tm = 0;
                for (int iv : TIPOS[t]) tm |= 1 << ((r + iv) % 12);
                int hit = Integer.bitCount(mask & tm), miss = Integer.bitCount(mask & ~tm);
                int score = hit * 3 - miss * 4 - Integer.bitCount(tm & ~mask) + (r == low % 12 ? 1 : 0) - t / 4;
                if (score > bestScore) { bestScore = score; best = r; bestT = t; }
            }
        }
        return best < 0 ? null : new int[]{best, bestT};
    }

    public static String nombre(int[] ac) {
        if (ac == null) return "—";
        return NOTAS[ac[0]] + " " + NOMBRE_TIPO[ac[1]];
    }

    // ---------------- reproducción

    private volatile Estilo estilo = ESTILOS[0];
    public volatile int tempo = ESTILOS[0].tempo;
    public volatile float volumen = 0.85f;
    private volatile boolean sonando, pedirArranque, pedirParada;
    private volatile int[] acorde = {0, 0};
    private volatile boolean cambioAcorde;
    private double muestrasPorPaso, faltan;
    private int paso;
    private final List<int[]> apagar = new ArrayList<>(); // {canal, tecla, muestras que faltan}
    private final List<Integer> fondo = new ArrayList<>();
    public volatile int pasoVisible = -1;

    public Estilo estilo() { return estilo; }
    public boolean sonando() { return sonando; }
    public int[] acorde() { return acorde; }

    public void setEstilo(Estilo e) {
        estilo = e;
        tempo = e.tempo;
        cambioAcorde = true;
    }

    public void setAcorde(int[] a) {
        if (a == null) return;
        int[] old = acorde;
        if (old != null && old[0] == a[0] && old[1] == a[1]) return;
        acorde = a;
        cambioAcorde = true;
    }

    public void arrancar() { pedirArranque = true; }
    public void parar() { pedirParada = true; }

    private void programas(Motor m) {
        Estilo e = estilo;
        m.program(9, 128, e.kit);
        m.program(2, 0, e.progBajo);
        m.program(3, 0, e.progAcomp);
        if (e.progFondo >= 0) m.program(4, 0, e.progFondo);
        float v = volumen;
        m.volume(2, v);
        m.volume(3, v * 0.75f);
        m.volume(4, v * 0.5f);
    }

    @Override
    public void block(Motor m, int frames) {
        if (pedirParada) {
            pedirParada = false;
            if (sonando) { sonando = false; apagarTodo(m); pasoVisible = -1; }
        }
        if (pedirArranque) {
            pedirArranque = false;
            if (!sonando) {
                programas(m);
                sonando = true;
                paso = 0;
                faltan = 0;
                cambioAcorde = false;
            }
        }
        // notas que ya deben callar
        for (int i = apagar.size() - 1; i >= 0; i--) {
            int[] a = apagar.get(i);
            a[2] -= frames;
            if (a[2] <= 0) { m.noteOff(a[0], a[1]); apagar.remove(i); }
        }
        if (!sonando) return;
        Estilo e = estilo;
        muestrasPorPaso = Motor.SR * 60.0 / Math.max(30, tempo) / e.pasosPorTiempo;
        if (cambioAcorde) {
            cambioAcorde = false;
            programas(m);
            tocarFondo(m, e);
        }
        faltan -= frames;
        while (faltan <= 0) {
            tocarPaso(m, e, paso % e.pasos());
            pasoVisible = paso % e.pasos();
            paso++;
            faltan += muestrasPorPaso;
        }
    }

    private void apagarTodo(Motor m) {
        for (int[] a : apagar) m.noteOff(a[0], a[1]);
        apagar.clear();
        for (int k : fondo) m.noteOff(4, k);
        fondo.clear();
        m.allOff(2);
        m.allOff(3);
    }

    private void nota(Motor m, int ch, int key, int vel, double pasos) {
        if (key < 0 || key > 127) return;
        m.noteOn(ch, key, Math.max(1, Math.min(127, Math.round(vel * volumen))));
        apagar.add(new int[]{ch, key, (int) (pasos * muestrasPorPaso * 0.92)});
    }

    private int[] tonos(int[] ac) {
        int[] t = TIPOS[ac[1]];
        int[] r = new int[t.length];
        int raiz = 48 + ac[0];
        for (int i = 0; i < t.length; i++) {
            int k = raiz + t[i];
            while (k < 55) k += 12;
            while (k > 70) k -= 12;
            r[i] = k;
        }
        java.util.Arrays.sort(r);
        return r;
    }

    private int grado(int[] ac, char c) {
        int r = 36 + ac[0];
        if (r > 43) r -= 12;
        int[] t = TIPOS[ac[1]];
        switch (c) {
            case 'R': return r;
            case '3': return r + t[1];
            case '5': return r + t[Math.min(2, t.length - 1)];
            case '8': return r + 12;
            default: return -1;
        }
    }

    private void tocarFondo(Motor m, Estilo e) {
        for (int k : fondo) m.noteOff(4, k);
        fondo.clear();
        if (e.progFondo < 0 || !sonando) return;
        for (int k : tonos(acorde)) {
            m.noteOn(4, k, Math.round(70 * volumen));
            fondo.add(k);
        }
    }

    private void tocarPaso(Motor m, Estilo e, int p) {
        int[] ac = acorde;
        // batería
        for (String[] b : e.bateria) {
            char c = b[1].charAt(p % b[1].length());
            int vel = c == 'X' ? 118 : c == 'x' ? 96 : c == 'o' ? 62 : 0;
            if (vel > 0) nota(m, 9, Integer.parseInt(b[0]), vel, 1);
        }
        // bajo
        char cb = e.bajo.charAt(p);
        if (cb != '.') {
            int largo = 1;
            while (largo < e.pasos() && e.bajo.charAt((p + largo) % e.pasos()) == '.') largo++;
            nota(m, 2, grado(ac, cb), 100, Math.min(largo, 4));
        }
        // acompañamiento
        char ca = e.acomp.charAt(p);
        if (ca == 'C' || ca == 'c') {
            int vel = ca == 'C' ? 92 : 70;
            for (int k : tonos(ac)) nota(m, 3, k, vel, e.largoAcomp);
        } else if (ca == 'P') {
            int r = 40 + ac[0];
            if (r > 47) r -= 12;
            nota(m, 3, r, 100, e.largoAcomp);
            nota(m, 3, r + 7, 95, e.largoAcomp);
            nota(m, 3, r + 12, 90, e.largoAcomp);
        } else if (ca != '.') {
            int k = grado(ac, ca);
            if (k >= 0) nota(m, 3, k + 24, 80, e.largoAcomp + 0.5);
        }
    }
}
