package co.jose.chepeestudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final int OSC = 0xFF151515, GRIS = 0xFF2A2A2A, VERDE = 0xFF0F6E56, MORADO = 0xFF534AB7, CAFE = 0xFF854F0B, ROJO = 0xFFE24B4A;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Motor motor;
    private final Ritmos ritmos = new Ritmos();
    private Teclado teclado;
    private TextView status, bInstr, bCapa, bSost, bRec, bRitmo, bAcordes, lAcorde, lTempo, lPulso;
    private final List<TextView> bEstilos = new ArrayList<>();
    private int instr = 0, capa = -1;
    private boolean sostener, acordesSolos = true;
    private final List<Integer> izquierda = new ArrayList<>();
    private Midi midi;
    private float volTeclado = 0.9f;

    // ------------------------------------------------------------ inicio

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pantallaCompleta();
        TextView cargando = tv("🎹 Chepe Estudio\n\nCargando los sonidos reales…", 20, Color.WHITE);
        cargando.setGravity(Gravity.CENTER);
        cargando.setBackgroundColor(OSC);
        setContentView(cargando);
        new Thread(() -> {
            String err = null;
            Sf2 sf = null;
            try (AssetFileDescriptor afd = getAssets().openFd("banco.sf2");
                 FileInputStream in = new FileInputStream(afd.getFileDescriptor())) {
                FileChannel ch = in.getChannel();
                MappedByteBuffer m = ch.map(FileChannel.MapMode.READ_ONLY, afd.getStartOffset(), afd.getLength());
                sf = new Sf2(m);
            } catch (Throwable t) {
                err = t.getMessage();
            }
            final Sf2 fs = sf;
            final String fe = err;
            ui.post(() -> {
                if (fs == null) { cargando.setText("No pude cargar los sonidos: " + fe); return; }
                motor = new Motor(fs);
                motor.clock = ritmos;
                motor.program(0, 0, instr);
                motor.program(1, 0, 48);
                armarPantalla();
            });
        }).start();
    }

    private void pantallaCompleta() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) pantallaCompleta(); }

    @Override
    protected void onResume() {
        super.onResume();
        if (motor != null) motor.setActive(true);
        ui.removeCallbacks(pulso);
        ui.post(pulso);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(pulso);
        // fuera de la app no gasta batería (salvo que esté grabando)
        if (motor != null && !motor.isRecording()) {
            ritmos.parar();
            ui.postDelayed(() -> { if (motor != null && !motor.isRecording() && !hasWindowFocus()) motor.setActive(false); }, 300);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (motor != null) {
            if (motor.isRecording()) pararGrabacion();
            motor.release();
        }
    }

    // ------------------------------------------------------------ ayudas

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable fondo(int c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(dp(8));
        return g;
    }

    private TextView boton(String s, int c, Runnable r) {
        TextView t = tv(s, 14, Color.WHITE);
        t.setBackground(fondo(c));
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        if (r != null) t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -1);
        lp.setMarginEnd(dp(5));
        t.setLayoutParams(lp);
        return t;
    }

    private void color(TextView t, int c) { t.setBackground(fondo(c)); }

    private LinearLayout fila(LinearLayout parent, int alto) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.HORIZONTAL);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(4), dp(3), dp(4), dp(3));
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(f, new HorizontalScrollView.LayoutParams(-2, -1));
        parent.addView(h, new LinearLayout.LayoutParams(-1, dp(alto)));
        return f;
    }

    private SeekBar barra(LinearLayout f, String nombre, int valor, SeekBar.OnSeekBarChangeListener l) {
        f.addView(tv(nombre, 13, Color.WHITE));
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(valor);
        s.setOnSeekBarChangeListener(l);
        f.addView(s, new LinearLayout.LayoutParams(dp(120), -1));
        return s;
    }

    private interface Val { void v(int x); }

    private SeekBar.OnSeekBarChangeListener cambia(Val v) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int x, boolean u) { if (u) v.v(x); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        };
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ------------------------------------------------------------ pantalla

    private void armarPantalla() {
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(OSC);

        // fila 1: instrumento, capa, octava, sostener, grabar, volumen, cerrar
        LinearLayout f1 = fila(raiz, 46);
        bInstr = boton("🎹 " + Instrumentos.NOMBRES[instr], VERDE, () -> escoger(false));
        f1.addView(bInstr);
        bCapa = boton("＋ Capa: No", GRIS, () -> escoger(true));
        f1.addView(bCapa);
        f1.addView(boton("◀ Octava", GRIS, () -> octava(-12)));
        f1.addView(boton("Octava ▶", GRIS, () -> octava(12)));
        f1.addView(boton("Teclas −", GRIS, () -> teclas(-2)));
        f1.addView(boton("Teclas +", GRIS, () -> teclas(2)));
        bSost = boton("Sostener: No", GRIS, this::sostener);
        f1.addView(bSost);
        bRec = boton("⏺ Grabar", ROJO, this::grabar);
        f1.addView(bRec);
        barra(f1, " Teclado ", 90, cambia(x -> { volTeclado = x / 100f; motor.volume(0, volTeclado); motor.volume(1, volTeclado * 0.8f); }));
        barra(f1, " Ritmo ", 85, cambia(x -> { ritmos.volumen = x / 100f; motor.volume(2, x / 100f); motor.volume(3, x / 100f * 0.75f); motor.volume(9, x / 100f); }));
        f1.addView(boton("✕", GRIS, this::finish));

        // fila 2: ritmos y acordes
        LinearLayout f2 = fila(raiz, 46);
        for (Ritmos.Estilo e : Ritmos.ESTILOS) {
            TextView t = boton(e.nombre, e == ritmos.estilo() ? CAFE : GRIS, () -> estilo(e));
            bEstilos.add(t);
            f2.addView(t);
        }
        bRitmo = boton("▶ Ritmo", MORADO, this::ritmo);
        f2.addView(bRitmo);
        f2.addView(boton("−", GRIS, () -> tempo(-4)));
        lTempo = tv(" " + ritmos.tempo + " ", 15, Color.WHITE);
        f2.addView(lTempo);
        f2.addView(boton("+", GRIS, () -> tempo(4)));
        bAcordes = boton("Acordes solos: Sí", MORADO, this::acordes);
        f2.addView(bAcordes);
        lAcorde = tv("  Acorde: —  ", 15, 0xFFFAC775);
        f2.addView(lAcorde);
        lPulso = tv("○○○○", 18, 0xFF5DCAA5);
        f2.addView(lPulso);

        // fila 3: batería
        LinearLayout f3 = fila(raiz, 44);
        String[] pn = {"Bombo", "Caja", "Platillo", "Hi-hat", "Timbal", "Conga", "Conga baja", "Bongó", "Cencerro", "Maracas", "Güiro", "Clave", "Aplauso", "Tom"};
        int[] pk = {36, 38, 49, 42, 65, 63, 64, 60, 56, 70, 73, 75, 39, 45};
        for (int i = 0; i < pn.length; i++) {
            final int k = pk[i];
            TextView t = boton(pn[i], 0xFF3C3489, null);
            t.setOnTouchListener((v, e) -> {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    motor.noteOn(9, k, 115);
                    v.setAlpha(0.6f);
                    ui.postDelayed(() -> motor.noteOff(9, k), 600);
                } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1f);
                }
                return true;
            });
            f3.addView(t);
        }

        status = tv("", 12, 0xFFFAC775);
        status.setVisibility(View.GONE);
        raiz.addView(status);

        teclado = new Teclado(this);
        teclado.oyente = this::tecla;
        raiz.addView(teclado, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(raiz);
        acordesCorte();
        motor.program(9, 128, 0);
    }

    // ------------------------------------------------------------ tocar

    private void tecla(int n, int f, boolean abajo) {
        if (motor == null) return;
        if (acordesSolos && n < teclado.corte) {
            if (abajo) { if (!izquierda.contains(n)) izquierda.add(n); }
            else izquierda.remove((Integer) n);
            if (abajo) {
                int[] ac = Ritmos.reconocer(izquierda);
                if (ac != null) {
                    ritmos.setAcorde(ac);
                    lAcorde.setText("  Acorde: " + Ritmos.nombre(ac) + "  ");
                    if (!ritmos.sonando()) { ritmos.arrancar(); bRitmo.setText("⏹ Parar"); }
                }
            }
            return;
        }
        if (abajo) {
            motor.noteOn(0, n, f);
            if (capa >= 0) motor.noteOn(1, n, Math.round(f * 0.85f));
        } else {
            motor.noteOff(0, n);
            if (capa >= 0) motor.noteOff(1, n);
        }
    }

    private void escoger(boolean esCapa) {
        String[] fam = new String[Instrumentos.FAMILIAS.length + (esCapa ? 2 : 1)];
        int o = 0;
        if (esCapa) fam[o++] = "✕ Sin capa";
        fam[o++] = "★ Los más usados";
        for (String s : Instrumentos.FAMILIAS) fam[o++] = s;
        final int off = o - Instrumentos.FAMILIAS.length;
        new AlertDialog.Builder(this).setTitle(esCapa ? "Instrumento de la capa" : "Escoja la familia")
                .setItems(fam, (d, w) -> {
                    if (esCapa && w == 0) { capa = -1; motor.allOff(1); bCapa.setText("＋ Capa: No"); color(bCapa, GRIS); return; }
                    int[] lista;
                    if (w == off - 1) lista = Instrumentos.FAVORITOS;
                    else {
                        int fm = w - off;
                        lista = new int[8];
                        for (int i = 0; i < 8; i++) lista[i] = fm * 8 + i;
                    }
                    String[] nn = new String[lista.length];
                    for (int i = 0; i < lista.length; i++) nn[i] = Instrumentos.NOMBRES[lista[i]];
                    final int[] fl = lista;
                    new AlertDialog.Builder(this).setTitle("Escoja el instrumento")
                            .setItems(nn, (d2, w2) -> poner(esCapa, fl[w2])).show();
                }).show();
    }

    private void poner(boolean esCapa, int p) {
        if (esCapa) {
            capa = p;
            motor.allOff(1);
            motor.program(1, 0, p);
            bCapa.setText("＋ Capa: " + Instrumentos.NOMBRES[p]);
            color(bCapa, VERDE);
        } else {
            instr = p;
            motor.allOff(0);
            motor.program(0, 0, p);
            bInstr.setText("🎹 " + Instrumentos.NOMBRES[p]);
        }
    }

    private void octava(int d) {
        int n = teclado.primera + d;
        if (n < 12 || n > 96) return;
        teclado.primera = n;
        acordesCorte();
        teclado.invalidate();
    }

    private void teclas(int d) {
        teclado.blancas = Math.max(8, Math.min(29, teclado.blancas + d));
        teclado.invalidate();
    }

    private void sostener() {
        sostener = !sostener;
        motor.pedal(0, sostener);
        motor.pedal(1, sostener);
        bSost.setText(sostener ? "Sostener: Sí" : "Sostener: No");
        color(bSost, sostener ? VERDE : GRIS);
    }

    private void acordes() {
        acordesSolos = !acordesSolos;
        bAcordes.setText(acordesSolos ? "Acordes solos: Sí" : "Acordes solos: No");
        color(bAcordes, acordesSolos ? MORADO : GRIS);
        izquierda.clear();
        acordesCorte();
    }

    private void acordesCorte() {
        teclado.corte = acordesSolos ? teclado.primera + 12 : -1;
        teclado.invalidate();
    }

    private void estilo(Ritmos.Estilo e) {
        ritmos.setEstilo(e);
        lTempo.setText(" " + ritmos.tempo + " ");
        for (int i = 0; i < bEstilos.size(); i++) color(bEstilos.get(i), Ritmos.ESTILOS[i] == e ? CAFE : GRIS);
    }

    private void ritmo() {
        if (ritmos.sonando()) { ritmos.parar(); bRitmo.setText("▶ Ritmo"); }
        else { ritmos.arrancar(); bRitmo.setText("⏹ Parar"); }
    }

    private void tempo(int d) {
        ritmos.tempo = Math.max(40, Math.min(240, ritmos.tempo + d));
        lTempo.setText(" " + ritmos.tempo + " ");
    }

    private final Runnable pulso = new Runnable() {
        @Override
        public void run() {
            if (lPulso != null) {
                int p = ritmos.pasoVisible;
                Ritmos.Estilo e = ritmos.estilo();
                if (p < 0 || !ritmos.sonando()) lPulso.setText("○○○○");
                else {
                    int tiempo = (p / e.pasosPorTiempo) % 4;
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < 4; i++) sb.append(i == tiempo ? '●' : '○');
                    lPulso.setText(sb.toString());
                }
                if (!ritmos.sonando() && bRitmo != null && bRitmo.getText().toString().startsWith("⏹")) bRitmo.setText("▶ Ritmo");
            }
            ui.postDelayed(this, 60);
        }
    };

    // ------------------------------------------------------------ grabar

    private void grabar() {
        if (motor == null) return;
        if (motor.isRecording()) { pararGrabacion(); return; }
        try {
            midi = new Midi(ritmos.tempo);
            final Midi mm = midi;
            motor.listener = (st, d1, d2) -> mm.add(motor.stamp(), st, d1, d2);
            motor.startRec(new File(getCacheDir(), "grabando.m4a"));
            // deja anotados los instrumentos con que empezó
            motor.program(0, 0, instr);
            if (capa >= 0) motor.program(1, 0, capa);
            for (int ch : new int[]{2, 3, 4, 9}) motor.program(ch, motor.bankOf(ch), motor.programOf(ch));
            bRec.setText("⏹ Parar y guardar");
            toast("⏺ Grabando todo lo que suena");
        } catch (Exception e) {
            toast("No se pudo grabar: " + e.getMessage());
        }
    }

    private void pararGrabacion() {
        final File f = motor.stopRec();
        motor.listener = null;
        final Midi mm = midi;
        midi = null;
        bRec.setText("⏺ Grabar");
        if (f == null) return;
        final String nombre = "Cancion_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        new Thread(() -> {
            String msg;
            try {
                Store.saveFile(this, f, "Grabaciones", nombre + ".m4a", "audio/mp4");
                if (mm != null && !mm.empty()) {
                    File mf = new File(getCacheDir(), "grabando.mid");
                    mm.save(mf);
                    Store.saveFile(this, mf, "Grabaciones", nombre + ".mid", "audio/midi");
                    mf.delete();
                }
                msg = "✅ Guardado en Descargas/MiBarra/ChepeEstudio/Grabaciones";
            } catch (Exception e) {
                msg = "No se pudo guardar: " + e.getMessage();
            }
            f.delete();
            final String m = msg;
            ui.post(() -> toast(m));
        }).start();
    }
}
