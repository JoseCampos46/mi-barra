package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Mi Inventor: estructuras en tubo, ángulo y platina, en 3D, con lista de corte para comprar barras de 6 m. */
public class InventorActivity extends Activity {

    private static final String ULTIMO = "_ultimo";
    private static final float BARRA = 6000f, DISCO = 3f;   // barra de 6 m y lo que se come el disco al cortar

    private final List<Pieza> piezas = new ArrayList<>();
    private Vista3D vista;
    private LinearLayout lista;
    private String nombreProyecto = "Sin nombre";
    private int escogida = -1;

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF151A26);
        getWindow().setNavigationBarColor(0xFF151A26);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF151A26);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));

        vista = new Vista3D(this);
        vista.piezas = piezas;
        vista.alEscoger = id -> { escogida = id; pintarLista(); };
        raiz.addView(vista, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        LinearLayout vistas = new LinearLayout(this);
        vistas.addView(boton("🧊 3D", 0xFF37474F, () -> vista.vista(-35, 25)), peso());
        vistas.addView(boton("Frente", 0xFF37474F, () -> vista.vista(0, 0)), peso());
        vistas.addView(boton("Lado", 0xFF37474F, () -> vista.vista(-90, 0)), peso());
        vistas.addView(boton("Arriba", 0xFF37474F, () -> vista.vista(0, 89)), peso());
        vistas.addView(boton("⛶ Todo", 0xFF37474F, () -> vista.encuadrar()), peso());
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(40));
        vp.topMargin = dp(4);
        raiz.addView(vistas, vp);

        LinearLayout acciones = new LinearLayout(this);
        acciones.addView(boton("➕\nPieza", 0xFF00897B, () -> editar(null)), peso());
        acciones.addView(boton("✏\nEditar", 0xFF1E88E5, () -> { Pieza p = porId(escogida); if (p == null) aviso("Toque primero una pieza"); else editar(p); }), peso());
        acciones.addView(boton("⧉\nCopiar", 0xFF5E35B1, this::copiarEscogida), peso());
        acciones.addView(boton("📋\nCorte", 0xFF43A047, this::listaCorte), peso());
        acciones.addView(boton("📂\nProyecto", 0xFF6D4C41, this::menuProyecto), peso());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(54));
        ap.topMargin = dp(4);
        raiz.addView(acciones, ap);

        ScrollView sv = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        sv.addView(lista);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 0.85f);
        lp.topMargin = dp(4);
        raiz.addView(sv, lp);
        setContentView(raiz);

        abrir(ULTIMO, true);
        refrescar();
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardar(ULTIMO, true);
    }

    // ---------------- Ayudas ----------------

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private Pieza porId(int id) {
        for (Pieza p : piezas) if (p.id == id) return p;
        return null;
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    private int nuevoId() {
        int m = 0;
        for (Pieza p : piezas) m = Math.max(m, p.id);
        return m + 1;
    }

    private void refrescar() {
        vista.escogida = escogida;
        vista.invalidate();
        pintarLista();
    }

    private String resumen(Pieza p) {
        StringBuilder s = new StringBuilder();
        s.append(p.nombre()).append(" · ").append(p.referencia()).append("\n")
                .append(Pieza.n(p.largo)).append(" mm · ").append(Pieza.DIRS[p.dir].substring(0, 1));
        if (Math.abs(p.incl) > 0.01f) s.append(" inclinado ").append(Pieza.n(p.incl)).append("°");
        Pieza pp = porId(p.padre);
        if (pp != null) {
            s.append(" · unido a ").append(pp.nombre()).append(p.punto == 0 ? " (inicio)" : p.punto == 1 ? " (final)" : " (a " + Pieza.n(p.aMm) + " mm)");
            if (Math.abs(p.sep) > 0.01f) s.append(" · separ. ").append(Pieza.n(p.sep)).append(" mm");
        }
        if (!p.huecos.isEmpty()) s.append(" · ").append(p.huecos.size()).append(p.huecos.size() == 1 ? " hueco" : " huecos");
        return s.toString();
    }

    private void pintarLista() {
        lista.removeAllViews();
        if (piezas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Toque ➕ Pieza para empezar.\n\nCada pieza arranca en el punto 0 o pegada a otra pieza (al inicio, al final o a una medida), "
                    + "y puede quedar separada los milímetros que usted diga.\n\nEn el dibujo: un dedo gira, dos dedos acercan y corren, y tocar una pieza la escoge.");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            lista.addView(t);
            return;
        }
        for (Pieza p : piezas) {
            TextView t = new TextView(this);
            t.setText(resumen(p));
            t.setTextColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            t.setTextSize(14);
            t.setPadding(dp(10), dp(7), dp(8), dp(7));
            GradientDrawable g = new GradientDrawable();
            g.setColor(p.id == escogida ? 0xFFFFB300 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34);
            g.setCornerRadius(dp(8));
            t.setBackground(g);
            t.setOnClickListener(v -> { escogida = p.id; refrescar(); });
            t.setOnLongClickListener(v -> { escogida = p.id; refrescar(); opcionesPieza(p); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            lista.addView(t, lp);
        }
    }

    private void opcionesPieza(Pieza p) {
        new AlertDialog.Builder(this).setTitle(p.nombre())
                .setItems(new String[]{"✏ Editar", "⧉ Copiar (queda pegada al final de esta)", "🗑 Eliminar"}, (d, w) -> {
                    if (w == 0) editar(p);
                    else if (w == 1) copiarEscogida();
                    else eliminar(p);
                }).show();
    }

    private void copiarEscogida() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        Pieza c = p.copia(nuevoId());
        if (c == null) return;
        c.padre = p.id;
        c.punto = 1;
        c.sep = 0;
        c.cx = c.cy = c.cz = 0;
        piezas.add(c);
        escogida = c.id;
        vista.encuadrar();
        refrescar();
        aviso("Copia " + c.nombre() + " pegada al final de " + p.nombre());
    }

    /** Al eliminar, lo que estaba unido a esa pieza se queda en su puesto. */
    private void eliminar(Pieza p) {
        new AlertDialog.Builder(this).setMessage("¿Eliminar " + p.nombre() + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    Map<Integer, Pieza> m = mapa();
                    for (Pieza h : piezas) {
                        if (h.padre != p.id) continue;
                        float[] ini = h.inicio(m, 0), dir = h.direccion();
                        h.padre = -1;
                        h.cx = ini[0] - dir[0] * h.sep;
                        h.cy = ini[1] - dir[1] * h.sep;
                        h.cz = ini[2] - dir[2] * h.sep;
                    }
                    piezas.remove(p);
                    escogida = -1;
                    refrescar();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Formulario de una pieza ----------------

    private EditText numero(LinearLayout l, String etiqueta, float valor, boolean signo) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        e.setText(Pieza.n(valor));
        e.setTextSize(17);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | (signo ? InputType.TYPE_NUMBER_FLAG_SIGNED : 0));
        l.addView(e);
        return e;
    }

    /** Varias casillas de números en una sola fila (ancho, alto, espesor…). */
    private EditText[] filaNumeros(LinearLayout l, String[] etiquetas, float[] valores, boolean signo) {
        LinearLayout fila = new LinearLayout(this);
        EditText[] r = new EditText[etiquetas.length];
        for (int i = 0; i < etiquetas.length; i++) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            r[i] = numero(c, etiquetas[i], valores[i], signo);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.setMargins(0, 0, dp(6), 0);
            fila.addView(c, p);
        }
        l.addView(fila);
        return r;
    }

    private Spinner lista(LinearLayout l, String etiqueta, String[] items, int sel) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(Math.max(0, Math.min(items.length - 1, sel)));
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
        return s;
    }

    private static float leer(EditText e, float porDefecto) {
        try { return Float.parseFloat(e.getText().toString().trim().replace(',', '.')); } catch (Exception x) { return porDefecto; }
    }

    private static String[] nombresMedidas(int tipo) {
        Object[][] m = Pieza.MEDIDAS[tipo];
        String[] r = new String[m.length + 1];
        for (int i = 0; i < m.length; i++) r[i] = (String) m[i][0];
        r[m.length] = "Otra medida (escríbala abajo)";
        return r;
    }

    private void titulo(LinearLayout l, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(2));
        l.addView(t);
    }

    private void editar(Pieza original) {
        final boolean nueva = original == null;
        final Pieza p;
        if (nueva) {
            p = new Pieza();
            p.id = nuevoId();
            Pieza ult = piezas.isEmpty() ? null : piezas.get(piezas.size() - 1);
            if (ult != null) {   // por comodidad: la nueva sale igual a la anterior y pegada a su final
                p.tipo = ult.tipo; p.medida = ult.medida; p.a = ult.a; p.b = ult.b; p.t = ult.t; p.calibre = ult.calibre;
                p.padre = ult.id; p.punto = 1;
            }
        } else p = original;

        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), dp(10));
        sv.addView(l);

        titulo(l, "1. El perfil");
        Spinner sTipo = lista(l, "Perfil", Pieza.TIPOS, p.tipo);
        int iMed = Arrays.asList(nombresMedidas(p.tipo)).indexOf(p.medida);
        Spinner sMed = lista(l, "Medida", nombresMedidas(p.tipo), iMed < 0 ? Pieza.MEDIDAS[p.tipo].length : iMed);
        EditText[] dims = filaNumeros(l, new String[]{"Ancho mm", "Alto mm", "Espesor mm"}, new float[]{p.a, p.b, p.t}, false);
        TextView tc = new TextView(this);
        tc.setText("Calibre (para pedirlo en la ferretería)");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setPadding(0, dp(8), 0, 0);
        l.addView(tc);
        EditText eCal = new EditText(this);
        eCal.setText(p.calibre);
        l.addView(eCal);
        final int[] tipoAntes = {p.tipo};
        sTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                if (pos == tipoAntes[0]) return;
                tipoAntes[0] = pos;
                sMed.setAdapter(new ArrayAdapter<>(InventorActivity.this, android.R.layout.simple_spinner_dropdown_item, nombresMedidas(pos)));
                sMed.setSelection(Math.min(2, Pieza.MEDIDAS[pos].length - 1));
                eCal.setText(pos <= 2 ? "Cal 18" : "");
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });
        sMed.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                Object[][] m = Pieza.MEDIDAS[sTipo.getSelectedItemPosition()];
                if (pos >= m.length) return;
                dims[0].setText(Pieza.n((Float) m[pos][1]));
                dims[1].setText(Pieza.n((Float) m[pos][2]));
                dims[2].setText(Pieza.n((Float) m[pos][3]));
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });

        titulo(l, "2. Largo y hacia dónde va");
        EditText eLargo = numero(l, "Largo de corte (mm)", p.largo, false);
        Spinner sDir = lista(l, "Dirección", Pieza.DIRS, p.dir);
        EditText eIncl = numero(l, "Inclinación (grados, 0 = derecho)", p.incl, true);
        Spinner sGiro = lista(l, "Girar la sección (para ángulo o platina)", new String[]{"0°", "90°", "180°", "270°"}, p.giro);

        titulo(l, "3. Dónde se une");
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (x.id < p.id) posibles.add(x);
        String[] nomPadres = new String[posibles.size() + 1];
        nomPadres[0] = "En el punto 0 (suelta)";
        int selPadre = 0;
        for (int i = 0; i < posibles.size(); i++) {
            nomPadres[i + 1] = posibles.get(i).nombre() + " · " + posibles.get(i).referencia();
            if (posibles.get(i).id == p.padre) selPadre = i + 1;
        }
        Spinner sPadre = lista(l, "Va pegada a", nomPadres, selPadre);
        Spinner sPunto = lista(l, "En qué punto de esa pieza", new String[]{"Al inicio", "Al final", "A una medida del inicio"}, p.punto);
        EditText eAmm = numero(l, "Medida desde el inicio (mm), si escogió «a una medida»", p.aMm, false);
        EditText eSep = numero(l, "Separación (mm) — luz entre las dos piezas", p.sep, true);
        EditText[] corr = filaNumeros(l, new String[]{"Correr X", "Correr Y", "Correr Z"}, new float[]{p.cx, p.cy, p.cz}, true);

        titulo(l, "4. Cortes de las puntas");
        EditText[] cortes = filaNumeros(l, new String[]{"Inicio (°)", "Final (°)"}, new float[]{p.corteIni, p.corteFin}, true);

        titulo(l, "5. Huecos y ranuras");
        LinearLayout cajaHuecos = new LinearLayout(this);
        cajaHuecos.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHuecos);
        List<Object[]> filasHueco = new ArrayList<>();
        for (Pieza.Hueco h : p.huecos) agregarFilaHueco(cajaHuecos, filasHueco, h);
        TextView masH = boton("➕ Agregar hueco", 0xFF37474F, () -> agregarFilaHueco(cajaHuecos, filasHueco, new Pieza.Hueco()));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(44));
        mp.topMargin = dp(6);
        l.addView(masH, mp);

        new AlertDialog.Builder(this).setTitle(nueva ? "➕ Pieza nueva " + p.nombre() : "✏ " + p.nombre()).setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    float largo = leer(eLargo, p.largo);
                    if (largo <= 0) { aviso("El largo debe ser mayor que 0"); return; }
                    p.tipo = sTipo.getSelectedItemPosition();
                    int im = sMed.getSelectedItemPosition();
                    p.a = Math.max(1, leer(dims[0], p.a));
                    p.b = Math.max(1, leer(dims[1], p.b));
                    p.t = Math.max(0.3f, leer(dims[2], p.t));
                    p.medida = im < Pieza.MEDIDAS[p.tipo].length ? (String) Pieza.MEDIDAS[p.tipo][im][0]
                            : Pieza.n(p.a) + "x" + Pieza.n(p.b) + " mm";
                    p.calibre = eCal.getText().toString();
                    p.largo = largo;
                    p.dir = sDir.getSelectedItemPosition();
                    p.incl = leer(eIncl, 0);
                    p.giro = sGiro.getSelectedItemPosition();
                    int ip = sPadre.getSelectedItemPosition();
                    p.padre = ip == 0 ? -1 : posibles.get(ip - 1).id;
                    p.punto = sPunto.getSelectedItemPosition();
                    p.aMm = leer(eAmm, 0);
                    p.sep = leer(eSep, 0);
                    p.cx = leer(corr[0], 0); p.cy = leer(corr[1], 0); p.cz = leer(corr[2], 0);
                    p.corteIni = leer(cortes[0], 0); p.corteFin = leer(cortes[1], 0);
                    p.huecos.clear();
                    for (Object[] f : filasHueco) {
                        if (!((View) f[5]).isShown() && ((View) f[5]).getParent() == null) continue;
                        Pieza.Hueco h = new Pieza.Hueco();
                        h.tipo = ((Spinner) f[0]).getSelectedItemPosition();
                        h.d1 = Math.max(1, leer((EditText) f[1], 10));
                        h.d2 = Math.max(1, leer((EditText) f[2], 8));
                        h.pos = leer((EditText) f[3], 50);
                        h.cara = ((Spinner) f[4]).getSelectedItemPosition();
                        p.huecos.add(h);
                    }
                    if (nueva) piezas.add(p);
                    escogida = p.id;
                    vista.encuadrar();
                    refrescar();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Una fila de hueco: tipo, medidas, posición y cara. f[5] es la fila misma (si se quita, no cuenta). */
    private void agregarFilaHueco(LinearLayout caja, List<Object[]> filas, Pieza.Hueco h) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(8), dp(4), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        f.setBackground(g);
        Spinner sT = lista(f, "Hueco " + (filas.size() + 1), Pieza.HUECOS, h.tipo);
        EditText[] m = filaNumeros(f, new String[]{"Ø / lado / largo", "Ancho ranura", "A mm del inicio"}, new float[]{h.d1, h.d2, h.pos}, false);
        Spinner sC = lista(f, "En qué cara", Pieza.CARAS, h.cara);
        Object[] reg = {sT, m[0], m[1], m[2], sC, f};
        TextView quitar = boton("✕ Quitar este hueco", 0xFFC62828, () -> { caja.removeView(f); filas.remove(reg); });
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, dp(38));
        qp.topMargin = dp(6);
        f.addView(quitar, qp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        caja.addView(f, lp);
        filas.add(reg);
    }

    // ---------------- Lista de corte ----------------

    private String textoCorte() {
        Map<String, List<Pieza>> grupos = new LinkedHashMap<>();
        for (Pieza p : piezas) {
            List<Pieza> g = grupos.get(p.referencia());
            if (g == null) { g = new ArrayList<>(); grupos.put(p.referencia(), g); }
            g.add(p);
        }
        StringBuilder s = new StringBuilder();
        s.append("MI INVENTOR - LISTA DE CORTE\n");
        s.append("Proyecto: ").append(nombreProyecto).append("\n");
        s.append(new SimpleDateFormat("dd/MM/yyyy h:mm a", new Locale("es", "CO")).format(new Date())).append("\n");
        s.append("Barras de 6 m · se descuentan 3 mm por cada corte\n");
        int totalBarras = 0;
        for (Map.Entry<String, List<Pieza>> en : grupos.entrySet()) {
            s.append("\n========================================\n");
            s.append(en.getKey().toUpperCase(new Locale("es", "CO"))).append("\n");
            s.append("========================================\n");
            float metros = 0;
            List<Float> largos = new ArrayList<>();
            List<String> largas = new ArrayList<>();
            for (Pieza p : en.getValue()) {
                metros += p.largo;
                s.append(String.format(Locale.US, "%-4s %6s mm", p.nombre(), Pieza.n(p.largo)));
                if (Math.abs(p.corteIni) > 0.01f || Math.abs(p.corteFin) > 0.01f)
                    s.append("  cortes ").append(Pieza.n(p.corteIni)).append("° / ").append(Pieza.n(p.corteFin)).append("°");
                else s.append("  cortes rectos (90°)");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(h.texto()).append("\n");
                if (p.largo > BARRA) largas.add(p.nombre() + " (" + Pieza.n(p.largo) + " mm)");
                else largos.add(p.largo);
            }
            // acomodar los cortes en barras: primero los más largos
            largos.sort((x, y) -> Float.compare(y, x));
            List<List<Float>> barras = new ArrayList<>();
            List<Float> libre = new ArrayList<>();
            for (float L : largos) {
                int k = -1;
                for (int i = 0; i < barras.size(); i++) if (libre.get(i) >= L + (barras.get(i).isEmpty() ? 0 : DISCO)) { k = i; break; }
                if (k < 0) { barras.add(new ArrayList<>()); libre.add(BARRA); k = barras.size() - 1; }
                libre.set(k, libre.get(k) - L - (barras.get(k).isEmpty() ? 0 : DISCO));
                barras.get(k).add(L);
            }
            int extra = 0;
            for (String x : largas) {
                float L = 0;
                for (Pieza p : en.getValue()) if (x.startsWith(p.nombre() + " ")) L = p.largo;
                extra += (int) Math.ceil(L / BARRA);
            }
            s.append("\nMetros lineales: ").append(String.format(Locale.US, "%.2f", metros / 1000f)).append(" m\n");
            for (int i = 0; i < barras.size(); i++) {
                s.append("Barra ").append(i + 1).append(": ");
                List<Float> b = barras.get(i);
                for (int j = 0; j < b.size(); j++) s.append(j == 0 ? "" : " + ").append(Pieza.n(b.get(j)));
                s.append("  (sobran ").append(Pieza.n(Math.max(0, libre.get(i)))).append(" mm)\n");
            }
            if (!largas.isEmpty()) s.append("Más largas que 6 m (van empatadas): ").append(String.join(", ", largas)).append("\n");
            int comprar = barras.size() + extra;
            totalBarras += comprar;
            s.append(">> COMPRAR: ").append(comprar).append(comprar == 1 ? " barra de 6 m\n" : " barras de 6 m\n");
        }
        s.append("\n----------------------------------------\n");
        s.append("TOTAL: ").append(totalBarras).append(" barras de 6 m\n");
        return s.toString();
    }

    private void listaCorte() {
        if (piezas.isEmpty()) { aviso("Todavía no hay piezas"); return; }
        String txt = textoCorte();
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(Color.WHITE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("📋 Lista de corte").setView(sv)
                .setPositiveButton("📄 PDF carta", (d, w) -> pdf(txt))
                .setNeutralButton("📲 WhatsApp", (d, w) -> compartirTexto(txt))
                .setNegativeButton("Cerrar", null).show();
    }

    private void compartirTexto(String txt) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) { try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {} }
    }

    /** La lista en PDF tamaño carta, letras negras nítidas. Queda en Descargas/MiInventor. */
    private void pdf(String txt) {
        try {
            PdfDocument doc = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(10.5f);
            String[] lineas = txt.split("\n");
            float alto = 14, arriba = 50, abajo = 792 - 45;
            int num = 1, i = 0;
            while (i < lineas.length) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                float y = arriba;
                while (i < lineas.length && y < abajo) {
                    String ln = lineas[i++];
                    p.setFakeBoldText(ln.startsWith(">>") || ln.startsWith("TOTAL") || ln.startsWith("MI INVENTOR") || (i > 1 && ln.equals(ln.toUpperCase()) && !ln.startsWith("=")));
                    c.drawText(ln, 45, y, p);
                    y += alto;
                }
                p.setFakeBoldText(false);
                c.drawText("Página " + num, 520, 775, p);
                doc.finishPage(pg);
                num++;
            }
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_Corte_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                    + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".pdf";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { doc.writeTo(o); }
            doc.close();
            aviso("✔ PDF guardado en Descargas/MiInventor");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Proyectos ----------------

    private File carpeta() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private void menuProyecto() {
        new AlertDialog.Builder(this).setTitle("📂 Proyecto: " + nombreProyecto)
                .setItems(new String[]{"💾 Guardar con nombre", "📂 Abrir uno guardado", "📄 Empezar uno nuevo (vacío)"}, (d, w) -> {
                    if (w == 0) pedirNombre();
                    else if (w == 1) listaProyectos();
                    else new AlertDialog.Builder(this).setMessage("¿Empezar vacío? Lo que no haya guardado con nombre se pierde.")
                                .setPositiveButton("Empezar", (d2, w2) -> { piezas.clear(); escogida = -1; nombreProyecto = "Sin nombre"; vista.encuadrar(); refrescar(); })
                                .setNegativeButton("Cancelar", null).show();
                }).show();
    }

    private void pedirNombre() {
        EditText e = new EditText(this);
        e.setText("Sin nombre".equals(nombreProyecto) ? "" : nombreProyecto);
        e.setHint("Por ejemplo: escalera 55-21");
        new AlertDialog.Builder(this).setTitle("Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty() || n.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    nombreProyecto = n;
                    guardar(n, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void guardar(String nombre, boolean callado) {
        try {
            JSONObject o = new JSONObject();
            o.put("nombre", nombreProyecto);
            JSONArray a = new JSONArray();
            for (Pieza p : piezas) a.put(p.json());
            o.put("piezas", a);
            try (FileWriter w = new FileWriter(new File(carpeta(), nombre + ".json"))) { w.write(o.toString()); }
            if (!callado) aviso("✔ Guardado «" + nombre + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo guardar");
        }
    }

    private void abrir(String nombre, boolean callado) {
        try {
            File f = new File(carpeta(), nombre + ".json");
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            JSONArray a = o.getJSONArray("piezas");
            piezas.clear();
            for (int i = 0; i < a.length(); i++) piezas.add(Pieza.deJson(a.getJSONObject(i)));
            nombreProyecto = o.optString("nombre", nombre);
            escogida = -1;
            vista.encuadrar();
            refrescar();
            if (!callado) aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo abrir");
        }
    }

    private void listaProyectos() {
        File[] fs = carpeta().listFiles(x -> x.getName().endsWith(".json") && !x.getName().startsWith("_"));
        if (fs == null || fs.length == 0) { aviso("Todavía no hay proyectos guardados con nombre"); return; }
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] nom = new String[fs.length];
        for (int i = 0; i < fs.length; i++) nom[i] = fs[i].getName().replace(".json", "");
        new AlertDialog.Builder(this).setTitle("📂 Proyectos").setItems(nom, (d, w) ->
                new AlertDialog.Builder(this).setTitle(nom[w]).setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                    if (w2 == 0) abrir(nom[w], false);
                    else new AlertDialog.Builder(this).setMessage("¿Borrar «" + nom[w] + "» para siempre?")
                            .setPositiveButton("Borrar", (d3, w3) -> { fs[w].delete(); aviso("Borrado"); })
                            .setNegativeButton("Cancelar", null).show();
                }).show()).show();
    }
}
