package co.jose.fotoshop;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * ChpFoto (antes Foto Shop): hoja carta con capas, quitar fondo, varita, lazo, recortar, pincel,
 * cuentagotas, clonar, corrector, plantillas, escáner y botón Claude.
 */
public class FotoShopActivity extends Activity implements Lienzo.Oyente {

    public static final String VERSION = "v2.0";

    private static final int PEDIR_FOTO = 7, PEDIR_ESCANER = 8, PEDIR_ADJUNTOS = 9, PEDIR_RESPUESTA = 10;
    private static final String ULTIMO = "_ultimo";
    private static final String CARPETA = Environment.DIRECTORY_DOWNLOADS + "/MiBarra/ChpFoto";

    private final Handler h = new Handler(Looper.getMainLooper());
    private FrameLayout raiz;
    private View editor;
    private ScrollView inicio;
    private Lienzo lienzo;
    private LinearLayout listaCapas, filaHerr, filaRecientes;
    private final List<TextView> pestanas = new ArrayList<>();
    private TextView txtPincel, lblPincel, muestraColor;
    private SeekBar barraPincel, barraOpacidad;
    private int grupo = 0;
    private int fotos = 0, textos = 0;
    private boolean guardando, listo, nuevaAlCargar;
    private String nombreProyecto = null;
    private SharedPreferences prefs;

    /** Una herramienta: su ícono, su nombre, lo que hace y (si es de dedo) cuál es en el lienzo. */
    private static class Herr {
        final String id, icono, nombre;
        final Runnable accion;
        final int modo;
        Herr(String id, String icono, String nombre, int modo, Runnable accion) {
            this.id = id; this.icono = icono; this.nombre = nombre; this.modo = modo; this.accion = accion;
        }
    }

    private final List<List<Herr>> grupos = new ArrayList<>();
    private final String[] nombresGrupos = {"✂ Selección", "🖌 Retoque", "➕ Insertar", "💾 Salida"};

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("chpfoto", MODE_PRIVATE);
        getWindow().setStatusBarColor(0xFF151A26);
        getWindow().setNavigationBarColor(0xFF151A26);
        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(0xFF151A26);
        armarHerramientas();
        editor = armarEditor();
        raiz.addView(editor, new FrameLayout.LayoutParams(-1, -1));
        inicio = new ScrollView(this);
        inicio.setBackgroundColor(0xFF151A26);
        inicio.setFillViewport(true);
        raiz.addView(inicio, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);

        herramienta(Lienzo.MOVER);
        lienzo.nuevaHoja();
        listo = true;
        mostrarInicio();
        recibirCompartido(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        recibirCompartido(i);
    }

    /** Si le comparten una foto desde la galería o WhatsApp, entra como capa nueva. */
    private void recibirCompartido(Intent i) {
        if (i == null || !Intent.ACTION_SEND.equals(i.getAction())) return;
        Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        mostrarEditor();
        cargarFoto(u);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (editor.getVisibility() == View.VISIBLE) guardarProyecto(ULTIMO, true, false);   // se guarda solo
    }

    @Override
    public void onBackPressed() {
        if (editor.getVisibility() == View.VISIBLE) {
            guardarProyecto(ULTIMO, true, false);
            mostrarInicio();
        } else {
            moveTaskToBack(true);   // no se cierra: queda abierta como las demás apps
        }
    }

    private void cerrar() {
        if (editor.getVisibility() == View.VISIBLE) guardarProyecto(ULTIMO, true, false);
        h.postDelayed(this::finishAndRemoveTask, 400);
    }

    // =====================================================================
    // Herramientas por grupos
    // =====================================================================

    private void armarHerramientas() {
        List<Herr> sel = new ArrayList<>();
        sel.add(new Herr("mover", "✋", "Mover", Lienzo.MOVER, null));
        sel.add(new Herr("fondo", "✂", "Quitar fondo", -1, this::quitarFondo));
        sel.add(new Herr("varita", "🪄", "Varita", Lienzo.VARITA, null));
        sel.add(new Herr("lazo", "➰", "Lazo", Lienzo.LAZO, null));
        sel.add(new Herr("recortar", "⛶", "Recortar", Lienzo.RECORTAR, null));
        sel.add(new Herr("girar", "🔄", "Girar", -1, () -> lienzo.girar90()));
        sel.add(new Herr("espejo", "⇋", "Espejo", -1, () -> lienzo.espejo()));
        List<Herr> ret = new ArrayList<>();
        ret.add(new Herr("pincel", "🖌", "Pincel", Lienzo.PINCEL, null));
        ret.add(new Herr("borrar", "🧽", "Borrador", Lienzo.BORRAR, null));
        ret.add(new Herr("restaurar", "♻", "Restaurar", Lienzo.RESTAURAR, null));
        ret.add(new Herr("gotero", "💧", "Cuenta-gotas", Lienzo.GOTERO, null));
        ret.add(new Herr("clonar", "📍", "Clonar", Lienzo.CLONAR, null));
        ret.add(new Herr("corrector", "🩹", "Corrector", Lienzo.CORRECTOR, null));
        ret.add(new Herr("linea", "📏", "Línea", Lienzo.LINEA, null));
        List<Herr> ins = new ArrayList<>();
        ins.add(new Herr("foto", "🖼", "Foto", -1, this::pedirFoto));
        ins.add(new Herr("escaner", "📷", "Escáner", -1, this::escanear));
        ins.add(new Herr("texto", "🔤", "Texto", -1, this::pedirTexto));
        ins.add(new Herr("vacia", "✏", "Capa vacía", -1, () -> lienzo.capaVacia("Capa vacía")));
        ins.add(new Herr("respuesta", "📦", "De Claude", -1, this::pedirRespuesta));
        List<Herr> sal = new ArrayList<>();
        sal.add(new Herr("proyecto", "💾", "Proyecto", -1, this::guardarRapido));
        sal.add(new Herr("plantilla", "⭐", "Plantilla", -1, this::pedirNombrePlantilla));
        sal.add(new Herr("png", "🖼", "Imagen", -1, () -> exportarPng(lienzo.componer(), "Hoja", false)));
        sal.add(new Herr("pdf", "📄", "PDF carta", -1, this::exportarPdf));
        sal.add(new Herr("whatsapp", "📲", "WhatsApp", -1, () -> exportarPng(lienzo.componer(), "Hoja", true)));
        sal.add(new Herr("recorte", "✂", "Solo capa", -1, () -> { Capa c = lienzo.capaSel(); if (c != null) exportarPng(c.bmp, c.nombre, false); }));
        grupos.add(sel);
        grupos.add(ret);
        grupos.add(ins);
        grupos.add(sal);
    }

    private Herr buscarHerr(String id) {
        for (List<Herr> g : grupos) for (Herr x : g) if (x.id.equals(id)) return x;
        return null;
    }

    private void usar(Herr x) {
        if (x.modo >= 0) {
            if (x.modo == Lienzo.CLONAR && lienzo.herramienta == Lienzo.CLONAR) {
                lienzo.reiniciarOrigen();
                aviso("📍 Toque el punto de donde quiere copiar");
            }
            herramienta(x.modo);
        } else if (x.accion != null) {
            x.accion.run();
        }
        anotarReciente(x.id);
    }

    // =====================================================================
    // Pantalla del editor
    // =====================================================================

    private View armarEditor() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(3), dp(3), dp(3), dp(3));

        // Arriba: ☰, nombre y versión, deshacer, rehacer, ver toda la hoja, guardar, X
        LinearLayout arriba = new LinearLayout(this);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        arriba.addView(iconoBoton("☰", this::menuTresRayas), new LinearLayout.LayoutParams(dp(44), -1));
        TextView titulo = new TextView(this);
        titulo.setText("ChpFoto " + VERSION);
        titulo.setTextColor(Color.WHITE);
        titulo.setTextSize(15);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setPadding(dp(4), 0, 0, 0);
        arriba.addView(titulo, new LinearLayout.LayoutParams(0, -1, 1f));
        titulo.setGravity(Gravity.CENTER_VERTICAL);
        arriba.addView(iconoBoton("↩", () -> { if (!lienzo.deshacer()) aviso("No hay nada más para deshacer"); }), new LinearLayout.LayoutParams(dp(42), -1));
        arriba.addView(iconoBoton("↪", () -> { if (!lienzo.rehacer()) aviso("No hay nada para rehacer"); }), new LinearLayout.LayoutParams(dp(42), -1));
        arriba.addView(iconoBoton("🔍", () -> { lienzo.ajustarVista(); aviso("Hoja completa. Dos dedos para acercar"); }), new LinearLayout.LayoutParams(dp(42), -1));
        arriba.addView(iconoBoton("💾", this::guardarRapido), new LinearLayout.LayoutParams(dp(42), -1));
        arriba.addView(iconoBoton("✕", this::cerrar), new LinearLayout.LayoutParams(dp(40), -1));
        col.addView(arriba, new LinearLayout.LayoutParams(-1, dp(44)));

        // Centro: la hoja y, a la derecha, las capas
        LinearLayout centro = new LinearLayout(this);
        lienzo = new Lienzo(this);
        lienzo.oyente = this;
        centro.addView(lienzo, new LinearLayout.LayoutParams(0, -1, 1f));
        LinearLayout colCapas = new LinearLayout(this);
        colCapas.setOrientation(LinearLayout.VERTICAL);
        TextView tc = new TextView(this);
        tc.setText("Capas");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setTypeface(Typeface.DEFAULT_BOLD);
        tc.setGravity(Gravity.CENTER);
        colCapas.addView(tc);
        ScrollView sv = new ScrollView(this);
        listaCapas = new LinearLayout(this);
        listaCapas.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listaCapas);
        colCapas.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView to = new TextView(this);
        to.setText("Opacidad");
        to.setTextColor(0xFFB0BEC5);
        to.setTextSize(11);
        to.setGravity(Gravity.CENTER);
        colCapas.addView(to);
        barraOpacidad = new SeekBar(this);
        barraOpacidad.setMax(100);
        barraOpacidad.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (!u) return;
                Capa c = lienzo.capaSel();
                if (c == null) return;
                c.opacidad = Math.max(5, v);
                lienzo.invalidate();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) { cambio(); }
        });
        colCapas.addView(barraOpacidad, new LinearLayout.LayoutParams(-1, dp(30)));
        LinearLayout botCapas = new LinearLayout(this);
        botCapas.addView(boton("➕", 0xFF00897B, this::menuNuevaCapa), peso());
        botCapas.addView(boton("⧉", 0xFF3949AB, () -> lienzo.duplicar()), peso());
        botCapas.addView(boton("🗑", 0xFFC62828, () -> {
            Capa c = lienzo.capaSel();
            if (c == null) return;
            new AlertDialog.Builder(this).setMessage("¿Eliminar la capa «" + c.nombre + "»? (Se puede deshacer con ↩)")
                    .setPositiveButton("Eliminar", (d, w) -> lienzo.eliminar(lienzo.sel))
                    .setNegativeButton("Cancelar", null).show();
        }), peso());
        colCapas.addView(botCapas, new LinearLayout.LayoutParams(-1, dp(36)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(104), -1);
        cp.leftMargin = dp(3);
        centro.addView(colCapas, cp);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, 0, 1f);
        cl.topMargin = dp(2);
        col.addView(centro, cl);

        // Recientes
        filaRecientes = new LinearLayout(this);
        filaRecientes.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(34));
        rp.topMargin = dp(3);
        col.addView(filaRecientes, rp);

        // Pestañas de grupos
        LinearLayout tabs = new LinearLayout(this);
        for (int i = 0; i < nombresGrupos.length; i++) {
            final int g = i;
            TextView t = boton(nombresGrupos[i], 0xFF2B3459, () -> escogerGrupo(g));
            t.setTextSize(12);
            pestanas.add(t);
            tabs.addView(t, peso());
        }
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(36));
        tp.topMargin = dp(3);
        col.addView(tabs, tp);

        // Herramientas del grupo escogido
        filaHerr = new LinearLayout(this);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(54));
        hp.topMargin = dp(3);
        col.addView(filaHerr, hp);

        // Pincel (o tolerancia de la varita) y color
        LinearLayout filaP = new LinearLayout(this);
        filaP.setGravity(Gravity.CENTER_VERTICAL);
        lblPincel = new TextView(this);
        lblPincel.setText("Pincel");
        lblPincel.setTextColor(Color.WHITE);
        lblPincel.setTextSize(13);
        lblPincel.setPadding(dp(6), 0, dp(4), 0);
        filaP.addView(lblPincel);
        barraPincel = new SeekBar(this);
        barraPincel.setMax(99);
        barraPincel.setProgress(29);
        barraPincel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (lienzo.herramienta == Lienzo.VARITA) { lienzo.tolerancia = v + 1; txtPincel.setText(String.valueOf(v + 1)); }
                else { lienzo.pincelPx = v + 1; txtPincel.setText((v + 1) + " px"); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        filaP.addView(barraPincel, new LinearLayout.LayoutParams(0, dp(40), 1f));
        txtPincel = new TextView(this);
        txtPincel.setText("30 px");
        txtPincel.setTextColor(0xFFFFD54A);
        txtPincel.setTextSize(13);
        txtPincel.setMinWidth(dp(48));
        filaP.addView(txtPincel);
        muestraColor = new TextView(this);
        muestraColor.setText("Color");
        muestraColor.setTextSize(11);
        muestraColor.setGravity(Gravity.CENTER);
        muestraColor.setOnClickListener(v -> escogerColor());
        LinearLayout.LayoutParams mc = new LinearLayout.LayoutParams(dp(62), dp(34));
        mc.leftMargin = dp(4);
        filaP.addView(muestraColor, mc);
        pintarMuestraColor();
        col.addView(filaP, new LinearLayout.LayoutParams(-1, dp(42)));

        escogerGrupo(0);
        pintarRecientes();
        return col;
    }

    private void escogerGrupo(int g) {
        grupo = g;
        for (int i = 0; i < pestanas.size(); i++)
            ((GradientDrawable) pestanas.get(i).getBackground()).setColor(i == g ? 0xFF1E88E5 : 0xFF2B3459);
        filaHerr.removeAllViews();
        for (Herr x : grupos.get(g)) {
            TextView t = boton(x.icono + "\n" + x.nombre, 0xFF2B3459, () -> usar(x));
            t.setTextSize(11);
            t.setTag(x.modo);
            filaHerr.addView(t, peso());
        }
        marcarHerramienta();
    }

    private void marcarHerramienta() {
        for (int i = 0; i < filaHerr.getChildCount(); i++) {
            View v = filaHerr.getChildAt(i);
            Object tag = v.getTag();
            boolean es = tag instanceof Integer && ((Integer) tag) >= 0 && ((Integer) tag) == lienzo.herramienta;
            ((GradientDrawable) v.getBackground()).setColor(es ? 0xFFFB8C00 : 0xFF2B3459);
        }
        for (int i = 0; i < filaRecientes.getChildCount(); i++) {
            View v = filaRecientes.getChildAt(i);
            Object tag = v.getTag();
            if (!(tag instanceof Integer)) continue;
            boolean es = ((Integer) tag) >= 0 && ((Integer) tag) == lienzo.herramienta;
            ((GradientDrawable) v.getBackground()).setColor(es ? 0xFFFB8C00 : 0xFF37474F);
        }
    }

    private void anotarReciente(String id) {
        String[] r = prefs.getString("recientes", "mover,fondo,pincel").split(",");
        List<String> l = new ArrayList<>();
        l.add(id);
        for (String s : r) if (!s.isEmpty() && !s.equals(id) && l.size() < 5) l.add(s);
        prefs.edit().putString("recientes", String.join(",", l)).apply();
        pintarRecientes();
    }

    private void pintarRecientes() {
        filaRecientes.removeAllViews();
        TextView et = new TextView(this);
        et.setText("Recientes");
        et.setTextColor(0xFFB0BEC5);
        et.setTextSize(11);
        et.setPadding(dp(4), 0, dp(4), 0);
        filaRecientes.addView(et);
        for (String id : prefs.getString("recientes", "mover,fondo,pincel").split(",")) {
            Herr x = buscarHerr(id);
            if (x == null) continue;
            TextView t = boton(x.icono + " " + x.nombre, 0xFF37474F, () -> usar(x));
            t.setTextSize(11);
            t.setSingleLine(true);
            t.setTag(x.modo);
            filaRecientes.addView(t, peso());
        }
        marcarHerramienta();
    }

    private void herramienta(int k) {
        lienzo.herramienta = k;
        if (k != Lienzo.LAZO && k != Lienzo.RECORTAR) lienzo.cancelarLazo();
        if (k == Lienzo.VARITA) {
            lblPincel.setText("Parecido");
            barraPincel.setProgress(lienzo.tolerancia - 1);
            txtPincel.setText(String.valueOf(lienzo.tolerancia));
        } else {
            lblPincel.setText("Pincel");
            barraPincel.setProgress(Math.round(lienzo.pincelPx) - 1);
            txtPincel.setText(Math.round(lienzo.pincelPx) + " px");
        }
        marcarHerramienta();
        lienzo.invalidate();
        if (!listo) return;
        switch (k) {
            case Lienzo.MOVER: aviso("Mover: un dedo arrastra la capa; dos dedos la agrandan y la giran"); break;
            case Lienzo.VARITA: aviso("Varita: toque un color y se borra todo lo parecido. La barra dice qué tan parecido"); break;
            case Lienzo.LAZO: aviso("Lazo: rodee con el dedo lo que quiere"); break;
            case Lienzo.RECORTAR: aviso("Recortar: arrastre un recuadro sobre la foto"); break;
            case Lienzo.PINCEL: aviso("Pincel: pinte con el color de abajo. Mejor en una ✏ capa vacía"); break;
            case Lienzo.GOTERO: aviso("Cuenta-gotas: toque un color de la hoja y queda escogido"); break;
            case Lienzo.CLONAR: aviso("Clonar: toque primero de DÓNDE copiar; luego pinte donde quiere la copia. Toque 📍 otra vez para escoger otro origen"); break;
            case Lienzo.CORRECTOR: aviso("Corrector: pase el dedo por rayones y manchas y se emparejan con lo de alrededor"); break;
            case Lienzo.RESTAURAR: aviso("Restaurar: devuelve lo que se borró de la foto"); break;
        }
    }

    // ---------------- Lazo y recorte ----------------

    @Override
    public void lazoListo() {
        new AlertDialog.Builder(this).setTitle("➰ Lo que quedó dentro del lazo")
                .setItems(new String[]{"✅ Dejar solo lo de adentro", "🧽 Borrar lo de adentro", "⧉ Copiar lo de adentro a una capa nueva", "Cancelar"}, (d, w) -> {
                    if (w <= 2) lienzo.aplicarLazo(w); else lienzo.cancelarLazo();
                    if (w == 2) herramienta(Lienzo.MOVER);
                })
                .setOnCancelListener(d -> lienzo.cancelarLazo())
                .show();
    }

    @Override
    public void recorteListo() {
        new AlertDialog.Builder(this).setMessage("¿Recortar la capa escogida a ese recuadro?")
                .setPositiveButton("⛶ Recortar", (d, w) -> lienzo.aplicarRecorte())
                .setNegativeButton("Cancelar", (d, w) -> lienzo.cancelarLazo())
                .setOnCancelListener(d -> lienzo.cancelarLazo())
                .show();
    }

    @Override
    public void colorTomado(int color) {
        lienzo.color = color;
        pintarMuestraColor();
        aviso("💧 Color tomado. Ya puede pintar con él");
    }

    // =====================================================================
    // Pantalla de inicio
    // =====================================================================

    private void mostrarEditor() {
        inicio.setVisibility(View.GONE);
        editor.setVisibility(View.VISIBLE);
        lienzo.ajustarVista();
    }

    private void mostrarInicio() {
        editor.setVisibility(View.GONE);
        inicio.setVisibility(View.VISIBLE);
        h.postDelayed(this::armarInicio, 150);   // espera a que termine el guardado automático
    }

    private void armarInicio() {
        inicio.removeAllViews();
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(4), dp(8), dp(12));

        LinearLayout arriba = new LinearLayout(this);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        arriba.addView(iconoBoton("☰", this::menuTresRayas), new LinearLayout.LayoutParams(dp(44), -1));
        TextView t = new TextView(this);
        t.setText("ChpFoto  " + VERSION);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        arriba.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
        arriba.addView(iconoBoton("✕", this::cerrar), new LinearLayout.LayoutParams(dp(44), -1));
        col.addView(arriba, new LinearLayout.LayoutParams(-1, dp(50)));

        LinearLayout f1 = new LinearLayout(this);
        f1.addView(boton("📄\nNueva hoja carta", 0xFF1E88E5, () -> { empezarNuevo(); mostrarEditor(); }), peso());
        f1.addView(boton("🖼\nGalería", 0xFF00897B, () -> { empezarNuevo(); mostrarEditor(); pedirFoto(); }), peso());
        col.addView(f1, new LinearLayout.LayoutParams(-1, dp(84)));
        LinearLayout f2 = new LinearLayout(this);
        f2.addView(boton("📷\nEscáner", 0xFF5E35B1, () -> { empezarNuevo(); mostrarEditor(); escanear(); }), peso());
        f2.addView(boton("✉\nClaude", 0xFFD97757, this::cuadernoClaude), peso());
        LinearLayout.LayoutParams f2p = new LinearLayout.LayoutParams(-1, dp(84));
        f2p.topMargin = dp(6);
        col.addView(f2, f2p);

        if (new File(new File(carpetaProyectos(), ULTIMO), "capas.txt").exists()) {
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(52));
            sp.topMargin = dp(8);
            col.addView(boton("▶  Seguir con el último trabajo", 0xFF43A047, () -> {
                cargarProyecto(new File(carpetaProyectos(), ULTIMO), false, false);
                mostrarEditor();
            }), sp);
        }

        col.addView(titulo("⭐ Mis plantillas"));
        File[] pl = listar(carpetaPlantillas());
        if (pl.length == 0) col.addView(nota("Todavía no hay plantillas. En el editor: 💾 Salida → ⭐ Plantilla. Guarde ahí su dirección, letreros o formatos y la próxima vez solo cambia la foto."));
        else agregarRejilla(col, pl, true);

        col.addView(titulo("📁 Proyectos"));
        File[] pr = listar(carpetaProyectos());
        if (pr.length == 0) col.addView(nota("Los trabajos que guarde con 💾 aparecen aquí."));
        else agregarRejilla(col, pr, false);

        col.addView(nota("Imágenes, PDF y envíos a Claude quedan en Descargas/MiBarra/ChpFoto"));
        inicio.addView(col);
    }

    private File[] listar(File base) {
        File[] d = base.listFiles(f -> f.isDirectory() && !f.getName().endsWith(".tmp") && !f.getName().startsWith("_"));
        if (d == null) return new File[0];
        Arrays.sort(d, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return d;
    }

    private TextView titulo(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(2), dp(14), 0, dp(6));
        return t;
    }

    private TextView nota(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFCFD8DC);
        t.setTextSize(13);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        return t;
    }

    /** Dos por fila: la miniatura y el nombre. Tocar = abrir; dejar el dedo = borrar. */
    private void agregarRejilla(LinearLayout col, File[] dirs, boolean plantilla) {
        LinearLayout fila = null;
        for (int i = 0; i < dirs.length; i++) {
            if (i % 2 == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
                fp.topMargin = dp(6);
                col.addView(fila, fp);
            }
            final File dir = dirs[i];
            LinearLayout tarjeta = new LinearLayout(this);
            tarjeta.setOrientation(LinearLayout.VERTICAL);
            tarjeta.setPadding(dp(6), dp(6), dp(6), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF232B3E);
            g.setCornerRadius(dp(10));
            g.setStroke(dp(1), 0xFF37474F);
            tarjeta.setBackground(g);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            File mini = new File(dir, "mini.png");
            if (mini.exists()) iv.setImageBitmap(BitmapFactory.decodeFile(mini.getPath()));
            else iv.setBackgroundColor(Color.WHITE);
            tarjeta.addView(iv, new LinearLayout.LayoutParams(-1, dp(120)));
            TextView n = new TextView(this);
            n.setText(dir.getName());
            n.setTextColor(Color.WHITE);
            n.setTextSize(13);
            n.setSingleLine(true);
            n.setGravity(Gravity.CENTER);
            tarjeta.addView(n);
            tarjeta.setOnClickListener(v -> {
                cargarProyecto(dir, false, plantilla);
                mostrarEditor();
            });
            tarjeta.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle(dir.getName())
                        .setItems(new String[]{"Abrir", "🗑 Borrar"}, (d, w) -> {
                            if (w == 0) { cargarProyecto(dir, false, plantilla); mostrarEditor(); }
                            else new AlertDialog.Builder(this).setMessage("¿Borrar «" + dir.getName() + "» para siempre?")
                                    .setPositiveButton("Borrar", (d2, w2) -> { borrarCarpeta(dir); armarInicio(); })
                                    .setNegativeButton("Cancelar", null).show();
                        }).show();
                return true;
            });
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
            tp.setMargins(dp(3), 0, dp(3), 0);
            fila.addView(tarjeta, tp);
        }
        if (dirs.length % 2 == 1 && fila != null) fila.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
    }

    private void empezarNuevo() {
        lienzo.nuevaHoja();
        fotos = 0;
        textos = 0;
        nombreProyecto = null;
        herramienta(Lienzo.MOVER);
    }

    // =====================================================================
    // Menú ☰ y ayuda
    // =====================================================================

    private void menuTresRayas() {
        String[] ops = {"🏠 Inicio", "❓ Ayuda: cómo se usa", "📂 ¿Dónde quedan mis archivos?", "ℹ Versión"};
        new AlertDialog.Builder(this).setTitle("☰ ChpFoto " + VERSION).setItems(ops, (d, w) -> {
            switch (w) {
                case 0:
                    if (editor.getVisibility() == View.VISIBLE) guardarProyecto(ULTIMO, true, false);
                    mostrarInicio();
                    break;
                case 1: ayuda(); break;
                case 2:
                    mensaje("📂 Archivos", "• Imágenes y PDF: Descargas/MiBarra/ChpFoto\n• Envíos a Claude: Descargas/MiBarra/ChpFoto/Claude/Enviados\n"
                            + "• Proyectos y plantillas: dentro de la app (aparecen en el inicio).\n\nSi mueve la carpeta a la nube, la app la vuelve a crear.");
                    break;
                case 3:
                    mensaje("ℹ ChpFoto " + VERSION, "Antes «Foto Shop». Esta versión trae: inicio con plantillas y proyectos, capas con opacidad, bloquear y duplicar, "
                            + "quitar fondo, varita, lazo, recortar, espejo, pincel, borrador, restaurar, cuenta-gotas, clonar, corrector, escáner, "
                            + "botón Claude, deshacer y rehacer.\n\nPróxima versión: todo el texto profesional (3D, curva, borde, sombra, fuentes).");
                    break;
            }
        }).show();
    }

    private void ayuda() {
        mensaje("❓ Cómo se usa ChpFoto",
                "1. En el inicio toque 📄 Nueva hoja carta, 🖼 Galería o 📷 Escáner.\n"
                        + "2. A la derecha están las capas: tóquela para escogerla; deje el dedo para más opciones (esconder, bloquear, subir, bajar, nombre).\n"
                        + "3. Abajo escoja el grupo: ✂ Selección, 🖌 Retoque, ➕ Insertar o 💾 Salida.\n"
                        + "4. La fila «Recientes» guarda las últimas herramientas que usó.\n"
                        + "5. Dos dedos acercan la hoja. 🔍 arriba muestra la hoja completa.\n"
                        + "6. ↩ deshace y ↪ rehace.\n"
                        + "7. Para restaurar fotos viejas: 🩹 Corrector sobre rayones y manchas, 📍 Clonar para tapar huecos copiando de al lado.\n"
                        + "8. ⭐ Plantilla guarda un trabajo para repetirlo: la próxima vez solo cambia la foto o el texto.\n"
                        + "9. ✉ Claude arma un solo archivo liviano con su mensaje y la hoja, para subirlo al chat del proyecto ChpFoto.");
    }

    private void mensaje(String t, String m) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("Entendido", null).show();
    }

    // =====================================================================
    // Botones y avisos
    // =====================================================================

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView iconoBoton(String txt, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    @Override public void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    /** Cada vez que cambia algo se redibuja la lista de capas (la de arriba primero). */
    @Override
    public void cambio() {
        listaCapas.removeAllViews();
        for (int i = lienzo.capas.size() - 1; i >= 0; i--) {
            final int idx = i;
            Capa c = lienzo.capas.get(i);
            TextView t = new TextView(this);
            String estado = (c.visible ? "👁" : "🙈") + (c.bloqueada ? " 🔒" : "") + " " + c.opacidad + "%";
            t.setText(c.icono() + " " + c.nombre + "\n" + estado);
            t.setTextColor(Color.WHITE);
            t.setTextSize(11);
            t.setPadding(dp(5), dp(5), dp(3), dp(5));
            GradientDrawable g = new GradientDrawable();
            g.setColor(idx == lienzo.sel ? 0xFF3949AB : 0xFF2B3459);
            g.setCornerRadius(dp(8));
            if (idx == lienzo.sel) g.setStroke(dp(2), 0xFFFFD54A);
            t.setBackground(g);
            t.setOnClickListener(v -> { lienzo.sel = idx; cambio(); lienzo.invalidate(); });
            t.setOnLongClickListener(v -> { lienzo.sel = idx; cambio(); opcionesCapa(idx); return true; });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(3);
            listaCapas.addView(t, p);
        }
        Capa s = lienzo.capaSel();
        if (s != null) barraOpacidad.setProgress(s.opacidad);
    }

    private void opcionesCapa(int i) {
        Capa c = lienzo.capas.get(i);
        String[] ops = {c.visible ? "🙈 Esconder" : "👁 Mostrar", c.bloqueada ? "🔓 Desbloquear" : "🔒 Bloquear",
                "⬆ Subir", "⬇ Bajar", "⧉ Duplicar", "✏ Cambiar nombre", "🗑 Eliminar capa"};
        new AlertDialog.Builder(this).setTitle(c.icono() + " " + c.nombre).setItems(ops, (d, w) -> {
            switch (w) {
                case 0: c.visible = !c.visible; cambio(); lienzo.invalidate(); break;
                case 1: c.bloqueada = !c.bloqueada; cambio(); break;
                case 2: lienzo.mover(i, 1); break;
                case 3: lienzo.mover(i, -1); break;
                case 4: lienzo.sel = i; lienzo.duplicar(); break;
                case 5: renombrar(c); break;
                case 6: lienzo.eliminar(i); break;
            }
        }).show();
    }

    private void menuNuevaCapa() {
        new AlertDialog.Builder(this).setTitle("➕ Capa nueva")
                .setItems(new String[]{"🖼 Foto de la galería", "📷 Escáner", "🔤 Texto", "✏ Capa vacía (para pintar)"}, (d, w) -> {
                    if (w == 0) pedirFoto();
                    else if (w == 1) escanear();
                    else if (w == 2) pedirTexto();
                    else lienzo.capaVacia("Capa vacía");
                }).show();
    }

    private void renombrar(Capa c) {
        EditText e = new EditText(this);
        e.setText(c.nombre);
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Nombre de la capa").setView(e)
                .setPositiveButton("Listo", (d, w) -> { String n = e.getText().toString().trim(); if (!n.isEmpty()) c.nombre = n; cambio(); })
                .setNegativeButton("Cancelar", null).show();
    }

    // =====================================================================
    // Fotos, escáner y respuestas de Claude
    // =====================================================================

    private void pedirFoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*");
        try { startActivityForResult(Intent.createChooser(i, "Escoja la foto"), PEDIR_FOTO); }
        catch (Exception e) { aviso("No se pudo abrir la galería"); }
    }

    /** El escáner de Google: recorta la hoja, la endereza y la pone como capa. */
    private void escanear() {
        try {
            GmsDocumentScannerOptions op = new GmsDocumentScannerOptions.Builder()
                    .setGalleryImportAllowed(true)
                    .setPageLimit(1)
                    .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                    .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                    .build();
            GmsDocumentScanner sc = GmsDocumentScanning.getClient(op);
            sc.getStartScanIntent(this)
                    .addOnSuccessListener(is -> {
                        try { startIntentSenderForResult(is, PEDIR_ESCANER, null, 0, 0, 0); }
                        catch (IntentSender.SendIntentException e) { aviso("No se pudo abrir el escáner"); }
                    })
                    .addOnFailureListener(e -> mensaje("📷 Escáner",
                            "La primera vez el celular necesita internet para bajar el escáner de Google (es una sola vez). Conéctese e intente de nuevo."));
        } catch (Throwable t) {
            aviso("Este celular no pudo abrir el escáner");
        }
    }

    private void pedirRespuesta() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*");
        try { startActivityForResult(Intent.createChooser(i, "Escoja la respuesta de Claude (imagen o .zip)"), PEDIR_RESPUESTA); }
        catch (Exception e) { aviso("No se pudo abrir el selector"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (res != RESULT_OK || d == null) return;
        if (req == PEDIR_FOTO && d.getData() != null) cargarFoto(d.getData());
        else if (req == PEDIR_ESCANER) {
            try {
                GmsDocumentScanningResult r = GmsDocumentScanningResult.fromActivityResultIntent(d);
                if (r != null && r.getPages() != null && !r.getPages().isEmpty()) cargarFoto(r.getPages().get(0).getImageUri());
            } catch (Throwable t) { aviso("No se pudo leer el escaneo"); }
        } else if (req == PEDIR_ADJUNTOS) {
            ClipData cd = d.getClipData();
            if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) adjuntos.add(cd.getItemAt(i).getUri());
            else if (d.getData() != null) adjuntos.add(d.getData());
            if (txtAdjuntos != null) txtAdjuntos.setText("📎 " + adjuntos.size() + " archivo(s) agregado(s)");
        } else if (req == PEDIR_RESPUESTA && d.getData() != null) {
            abrirRespuesta(d.getData());
        }
    }

    /** Lee una foto (máximo 2048 puntos de lado) ya derecha. */
    private Bitmap leerFoto(Uri u, int maximo) throws Exception {
        ContentResolver cr = getContentResolver();
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = cr.openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int lado = Math.max(o.outWidth, o.outHeight), muestra = 1;
        while (lado / muestra > maximo) muestra *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = muestra;
        Bitmap b;
        try (InputStream in = cr.openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
        if (b == null) throw new Exception("sin imagen");
        int giro = 0;
        try (InputStream in = cr.openInputStream(u)) {
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            giro = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
        } catch (Exception ignored) {}
        if (giro != 0) {
            Matrix mm = new Matrix();
            mm.postRotate(giro);
            b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mm, true);
        }
        return b.copy(Bitmap.Config.ARGB_8888, true);
    }

    private void cargarFoto(Uri u) {
        aviso("Abriendo la foto…");
        new Thread(() -> {
            try {
                final Bitmap fin = leerFoto(u, 2048);
                h.post(() -> {
                    fotos++;
                    lienzo.agregar(new Capa("Foto " + fotos, "foto", fin), true);
                    herramienta(Lienzo.MOVER);
                });
            } catch (Throwable t) {
                h.post(() -> aviso("No se pudo abrir esa foto"));
            }
        }, "foto").start();
    }

    /** La respuesta de Claude: una imagen suelta o un .zip con imágenes; cada una entra como capa. */
    private void abrirRespuesta(Uri u) {
        new Thread(() -> {
            try {
                byte[] bytes;
                try (InputStream in = getContentResolver().openInputStream(u)) { bytes = leerTodo(in); }
                List<Bitmap> imgs = new ArrayList<>();
                List<String> nombres = new ArrayList<>();
                boolean esZip = bytes.length > 4 && bytes[0] == 0x50 && bytes[1] == 0x4B;
                if (esZip) {
                    try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(bytes))) {
                        ZipEntry e;
                        while ((e = z.getNextEntry()) != null) {
                            String n = e.getName().toLowerCase(Locale.US);
                            if (e.isDirectory() || !(n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp"))) continue;
                            byte[] b = leerTodo(z);
                            Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length);
                            if (bm != null) { imgs.add(bm.copy(Bitmap.Config.ARGB_8888, true)); nombres.add(e.getName().replaceAll(".*/", "").replaceAll("\\.[^.]+$", "")); }
                        }
                    }
                } else {
                    Bitmap bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bm != null) { imgs.add(bm.copy(Bitmap.Config.ARGB_8888, true)); nombres.add("De Claude"); }
                }
                h.post(() -> {
                    if (imgs.isEmpty()) { aviso("Ese archivo no trae imágenes"); return; }
                    for (int i = 0; i < imgs.size(); i++) lienzo.agregar(new Capa(nombres.get(i), "foto", imgs.get(i)), true);
                    herramienta(Lienzo.MOVER);
                    aviso("✔ " + imgs.size() + " imagen(es) de Claude puestas como capas");
                });
            } catch (Throwable t) {
                h.post(() -> aviso("No se pudo abrir ese archivo"));
            }
        }, "respuesta").start();
    }

    private static byte[] leerTodo(InputStream in) throws Exception {
        ByteArrayOutputStream s = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) s.write(buf, 0, n);
        return s.toByteArray();
    }

    // ---------------- Quitar fondo (programa de Google) ----------------

    private void quitarFondo() {
        Capa c = lienzo.capaSel();
        if (c == null || "hoja".equals(c.tipo)) { aviso("Escoja a la derecha la capa de la foto"); return; }
        if (c.bloqueada) { aviso("🔒 Esa capa está bloqueada"); return; }
        aviso("✂ Quitando el fondo… espere unos segundos");
        try {
            SubjectSegmenter seg = SubjectSegmentation.getClient(
                    new SubjectSegmenterOptions.Builder().enableForegroundBitmap().build());
            seg.process(InputImage.fromBitmap(c.original, 0))
                    .addOnSuccessListener(r -> {
                        Bitmap fg = r.getForegroundBitmap();
                        if (fg == null) { aviso("No encontré una persona u objeto claro en la foto"); seg.close(); return; }
                        Bitmap nuevo = fg.copy(Bitmap.Config.ARGB_8888, true);
                        if (nuevo.getWidth() != c.original.getWidth() || nuevo.getHeight() != c.original.getHeight())
                            nuevo = Bitmap.createScaledBitmap(nuevo, c.original.getWidth(), c.original.getHeight(), true);
                        lienzo.reemplazar(c, nuevo);
                        aviso("✔ Fondo quitado. Si quitó de más, use ♻ Restaurar");
                        seg.close();
                    })
                    .addOnFailureListener(e -> {
                        mensaje("✂ Quitar fondo", "La primera vez el celular necesita internet para bajar el programa de Google que quita el fondo (es una sola vez). "
                                + "Conéctese y vuelva a tocar ✂ en un minuto.\n\nMientras tanto puede usar 🪄 Varita o ➰ Lazo.");
                        seg.close();
                    });
        } catch (Throwable t) {
            aviso("Este celular no pudo quitar el fondo; use 🪄 Varita o ➰ Lazo");
        }
    }

    // ---------------- Texto y color ----------------

    private void pedirTexto() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(8), dp(18), 0);
        EditText e = new EditText(this);
        e.setHint("Escriba aquí");
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        l.addView(e);
        TextView tt = new TextView(this);
        tt.setText("Tamaño: 60");
        l.addView(tt);
        SeekBar s = new SeekBar(this);
        s.setMax(200);
        s.setProgress(60);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { tt.setText("Tamaño: " + Math.max(14, p)); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(44)));
        new AlertDialog.Builder(this).setTitle("🔤 Texto (sale en el color de abajo)").setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String txt = e.getText().toString();
                    if (txt.trim().isEmpty()) return;
                    textos++;
                    Capa c = new Capa("Texto " + textos, "texto", imagenTexto(txt, Math.max(14, s.getProgress())));
                    lienzo.agregar(c, true);
                    herramienta(Lienzo.MOVER);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private Bitmap imagenTexto(String txt, int tam) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(tam);
        p.setColor(lienzo.color);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        String[] lineas = txt.split("\n");
        int ancho = 1;
        for (String s : lineas) ancho = Math.max(ancho, Math.round(p.measureText(s)));
        Paint.FontMetrics fm = p.getFontMetrics();
        float altoLinea = fm.descent - fm.ascent;
        int pad = tam / 4;
        Bitmap b = Bitmap.createBitmap(ancho + pad * 2, Math.round(altoLinea * lineas.length) + pad * 2, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        for (int i = 0; i < lineas.length; i++) c.drawText(lineas[i], pad, pad - fm.ascent + i * altoLinea, p);
        return b;
    }

    private void pintarMuestraColor() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(lienzo.color);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(2), Color.WHITE);
        muestraColor.setBackground(g);
        int c = lienzo.color;
        boolean claro = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 > 140;
        muestraColor.setTextColor(claro ? Color.BLACK : Color.WHITE);
    }

    private void escogerColor() {
        final int[] colores = {Color.BLACK, Color.WHITE, 0xFF9E9E9E, 0xFF795548,
                0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
                0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA,
                0xFFD81B60, 0xFFFFCCBC, 0xFFF5DEB3, 0xFF6D4C41};
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(10), dp(14), dp(4));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int f = 0; f < 4; f++) {
            LinearLayout fila = new LinearLayout(this);
            for (int k = 0; k < 4; k++) {
                final int col = colores[f * 4 + k];
                View v = new View(this);
                GradientDrawable g = new GradientDrawable();
                g.setColor(col);
                g.setCornerRadius(dp(10));
                g.setStroke(dp(col == lienzo.color ? 4 : 1), col == lienzo.color ? 0xFFFFB300 : 0xFF888888);
                v.setBackground(g);
                v.setOnClickListener(x -> { lienzo.color = col; pintarMuestraColor(); if (dlg[0] != null) dlg[0].dismiss(); });
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
                p.setMargins(dp(4), dp(4), dp(4), dp(4));
                fila.addView(v, p);
            }
            l.addView(fila);
        }
        dlg[0] = new AlertDialog.Builder(this).setTitle("🎨 Color (o use 💧 Cuenta-gotas)").setView(l).show();
    }

    // =====================================================================
    // Botón Claude: un solo archivo liviano para subir al chat del proyecto
    // =====================================================================

    private final List<Uri> adjuntos = new ArrayList<>();
    private TextView txtAdjuntos;

    private void cuadernoClaude() {
        adjuntos.clear();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(8), dp(18), 0);
        TextView para = new TextView(this);
        para.setText("Para: Claude (proyecto ChpFoto)");
        para.setTypeface(Typeface.DEFAULT_BOLD);
        l.addView(para);
        EditText asunto = new EditText(this);
        asunto.setHint("Asunto");
        asunto.setSingleLine(true);
        l.addView(asunto);
        EditText msg = new EditText(this);
        msg.setHint("Mensaje: qué quiere que haga Claude");
        msg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        msg.setMinLines(3);
        l.addView(msg);
        CheckBox conHoja = new CheckBox(this);
        conHoja.setText("Adjuntar la hoja que estoy trabajando");
        conHoja.setChecked(editor.getVisibility() == View.VISIBLE || lienzo.capas.size() > 1);
        l.addView(conHoja);
        txtAdjuntos = new TextView(this);
        txtAdjuntos.setText("📎 Sin archivos extra");
        l.addView(txtAdjuntos);
        TextView agregar = boton("📎 Agregar fotos, audios o archivos", 0xFF00897B, () -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try { startActivityForResult(Intent.createChooser(i, "Escoja los archivos"), PEDIR_ADJUNTOS); }
            catch (Exception e) { aviso("No se pudo abrir el selector"); }
        });
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(44));
        ap.topMargin = dp(6);
        l.addView(agregar, ap);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("✉ Escribirle a Claude").setView(sv)
                .setPositiveButton("Comprimir", (d, w) -> armarPaquete(asunto.getText().toString(), msg.getText().toString(), conHoja.isChecked()))
                .setNegativeButton("Cancelar", null).show();
    }

    private void armarPaquete(String asunto, String msg, boolean conHoja) {
        aviso("Comprimiendo…");
        final Bitmap hoja = conHoja ? lienzo.componer() : null;
        final List<Uri> lista = new ArrayList<>(adjuntos);
        new Thread(() -> {
            try {
                String nombre = "ChpFoto_" + fecha() + ".zip";
                Uri destino = nuevoArchivo(nombre, "application/zip", "/Claude/Enviados");
                try (OutputStream o = getContentResolver().openOutputStream(destino); ZipOutputStream z = new ZipOutputStream(o)) {
                    String leeme = "Hola, Claude. Este archivo lo armó la app ChpFoto " + VERSION + " en el celular de Jose (Android).\n"
                            + "Asunto: " + asunto + "\n\nMensaje:\n" + msg + "\n\n"
                            + "Si devuelve imágenes (PNG con fondo transparente si aplica), Jose las abre en ChpFoto con ➕ Insertar → 📦 De Claude, "
                            + "sueltas o dentro de un .zip, y cada una entra como capa.\n";
                    meter(z, "LEEME_CLAUDE.txt", leeme.getBytes("UTF-8"));
                    String json = "{\"para\":\"Claude\",\"app\":\"ChpFoto\",\"version\":\"" + VERSION + "\",\"fecha\":\"" + fecha()
                            + "\",\"asunto\":\"" + jsonTexto(asunto) + "\",\"mensaje\":\"" + jsonTexto(msg) + "\"}";
                    meter(z, "correo.json", json.getBytes("UTF-8"));
                    if (hoja != null) {
                        ByteArrayOutputStream s = new ByteArrayOutputStream();
                        hoja.compress(Bitmap.CompressFormat.JPEG, 78, s);
                        meter(z, "hoja.jpg", s.toByteArray());
                    }
                    int k = 0;
                    for (Uri u : lista) {
                        k++;
                        String n = nombreDe(u);
                        String tipo = getContentResolver().getType(u);
                        if (tipo != null && tipo.startsWith("image/")) {
                            try {
                                Bitmap b = leerFoto(u, 1400);
                                ByteArrayOutputStream s = new ByteArrayOutputStream();
                                b.compress(Bitmap.CompressFormat.JPEG, 75, s);
                                meter(z, "adjuntos/" + k + "_" + n.replaceAll("\\.[^.]+$", "") + ".jpg", s.toByteArray());
                                continue;
                            } catch (Throwable ignored) {}
                        }
                        byte[] b;
                        try (InputStream in = getContentResolver().openInputStream(u)) { b = leerTodo(in); }
                        if (b.length <= 8 * 1024 * 1024) meter(z, "adjuntos/" + k + "_" + n, b);
                    }
                }
                h.post(() -> mensaje("✔ Listo para Claude",
                        "Se guardó «" + nombre + "».\n\n"
                                + "1. Abra Claude y entre al proyecto ChpFoto (o un chat nuevo ahí).\n"
                                + "2. Toque el clip 📎 o el ＋.\n"
                                + "3. Suba el archivo de Descargas/MiBarra/ChpFoto/Claude/Enviados.\n"
                                + "4. Si Claude le devuelve imágenes, ábralas con ➕ Insertar → 📦 De Claude."));
            } catch (Throwable t) {
                h.post(() -> aviso("No se pudo armar el archivo para Claude"));
            }
        }, "claude").start();
    }

    private static void meter(ZipOutputStream z, String nombre, byte[] datos) throws Exception {
        z.putNextEntry(new ZipEntry(nombre));
        z.write(datos);
        z.closeEntry();
    }

    private static String jsonTexto(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private String nombreDe(Uri u) {
        String n = "archivo";
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) n = c.getString(0);
        } catch (Throwable ignored) {}
        return n == null ? "archivo" : n.replaceAll("[/\\\\:*?\"<>|]", "-");
    }

    // =====================================================================
    // Guardar imágenes y PDF en Descargas/MiBarra/ChpFoto
    // =====================================================================

    private String fecha() { return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()); }

    private Uri nuevoArchivo(String nombre, String tipo, String sub) {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, tipo);
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, CARPETA + sub);
        return getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
    }

    private void exportarPng(Bitmap b, String base, boolean compartir) {
        aviso("Guardando…");
        new Thread(() -> {
            try {
                String nom = "ChpFoto_" + base.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_" + fecha() + ".png";
                Uri u = nuevoArchivo(nom, "image/png", "");
                try (OutputStream o = getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.PNG, 100, o); }
                h.post(() -> {
                    aviso("✔ Guardado en Descargas/MiBarra/ChpFoto");
                    if (compartir) compartir(u, "image/png");
                });
            } catch (Throwable t) { h.post(() -> aviso("No se pudo guardar")); }
        }, "png").start();
    }

    private void exportarPdf() {
        aviso("Haciendo el PDF…");
        Bitmap hoja = lienzo.componer();
        new Thread(() -> {
            try {
                PdfDocument pdf = new PdfDocument();
                PdfDocument.Page pg = pdf.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create()); // carta en puntos
                Canvas c = pg.getCanvas();
                c.drawColor(Color.WHITE);
                c.drawBitmap(hoja, null, new Rect(0, 0, 612, 792), new Paint(Paint.FILTER_BITMAP_FLAG));
                pdf.finishPage(pg);
                Uri u = nuevoArchivo("ChpFoto_Hoja_" + fecha() + ".pdf", "application/pdf", "");
                try (OutputStream o = getContentResolver().openOutputStream(u)) { pdf.writeTo(o); }
                pdf.close();
                h.post(() -> aviso("✔ PDF guardado en Descargas/MiBarra/ChpFoto"));
            } catch (Throwable t) { h.post(() -> aviso("No se pudo hacer el PDF")); }
        }, "pdf").start();
    }

    private void compartir(Uri u, String tipo) {
        Intent i = new Intent(Intent.ACTION_SEND).setType(tipo).putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) {
            try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {}
        }
    }

    // =====================================================================
    // Proyectos y plantillas (dentro de la app, con su miniatura)
    // =====================================================================

    private File carpetaProyectos() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private File carpetaPlantillas() {
        File f = new File(getFilesDir(), "plantillas");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    /** 💾: si el trabajo ya tiene nombre, guarda de una; si no, pregunta el nombre. */
    private void guardarRapido() {
        if (nombreProyecto != null) guardarProyecto(nombreProyecto, false, false);
        else pedirNombreProyecto();
    }

    private void pedirNombreProyecto() {
        EditText e = new EditText(this);
        e.setText("Proyecto " + new SimpleDateFormat("dd-MM HH.mm", Locale.US).format(new Date()));
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("💾 Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = limpiarNombre(e.getText().toString(), "Proyecto");
                    nombreProyecto = n;
                    guardarProyecto(n, false, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirNombrePlantilla() {
        EditText e = new EditText(this);
        e.setHint("Ej.: Mi dirección, Letrero negro");
        new AlertDialog.Builder(this).setTitle("⭐ Guardar como plantilla")
                .setMessage("Queda en el inicio para repetir este trabajo: la próxima vez solo cambia la foto o el texto.")
                .setView(e)
                .setPositiveButton("Guardar", (d, w) -> guardarProyecto(limpiarNombre(e.getText().toString(), "Plantilla"), false, true))
                .setNegativeButton("Cancelar", null).show();
    }

    private String limpiarNombre(String s, String porDefecto) {
        String n = s.trim().replaceAll("[/\\\\:*?\"<>|]", "-");
        if (n.isEmpty() || n.startsWith("_") || n.startsWith(".")) n = porDefecto;
        return n;
    }

    /** Guarda cada capa (lo que se ve y su copia completa), su posición y una miniatura. */
    private void guardarProyecto(String nombre, boolean callado, boolean plantilla) {
        if (guardando || lienzo == null || lienzo.capas.isEmpty()) return;
        guardando = true;
        final List<Capa> copia = new ArrayList<>(lienzo.capas);
        final int sel = lienzo.sel;
        final Bitmap mini = Bitmap.createScaledBitmap(lienzo.componer(), 255, 330, true);
        final File base = plantilla ? carpetaPlantillas() : carpetaProyectos();
        new Thread(() -> {
            try {
                File dir = new File(base, nombre);
                File tmp = new File(base, nombre + ".tmp");
                borrarCarpeta(tmp);
                tmp.mkdirs();
                StringBuilder sb = new StringBuilder();
                sb.append("sel|").append(sel).append('\n');
                for (int i = 0; i < copia.size(); i++) {
                    Capa c = copia.get(i);
                    try (FileOutputStream o = new FileOutputStream(new File(tmp, "capa" + i + ".png"))) { c.bmp.compress(Bitmap.CompressFormat.PNG, 100, o); }
                    try (FileOutputStream o = new FileOutputStream(new File(tmp, "orig" + i + ".png"))) { c.original.compress(Bitmap.CompressFormat.PNG, 100, o); }
                    float[] v = new float[9];
                    c.m.getValues(v);
                    sb.append(c.nombre.replace("|", " ")).append('|').append(c.tipo).append('|').append(c.opacidad).append('|').append(c.visible);
                    for (float x : v) sb.append('|').append(x);
                    sb.append('|').append(c.bloqueada);
                    sb.append('\n');
                }
                try (FileWriter w = new FileWriter(new File(tmp, "capas.txt"))) { w.write(sb.toString()); }
                try (FileOutputStream o = new FileOutputStream(new File(tmp, "mini.png"))) { mini.compress(Bitmap.CompressFormat.PNG, 90, o); }
                borrarCarpeta(dir);
                tmp.renameTo(dir);
                if (!callado) h.post(() -> aviso(plantilla ? "⭐ Plantilla «" + nombre + "» guardada" : "✔ Proyecto «" + nombre + "» guardado"));
            } catch (Throwable t) {
                if (!callado) h.post(() -> aviso("No se pudo guardar"));
            } finally { guardando = false; }
        }, "proyecto").start();
    }

    private void borrarCarpeta(File f) {
        if (f == null || !f.exists()) return;
        File[] hijos = f.listFiles();
        if (hijos != null) for (File x : hijos) x.delete();
        f.delete();
    }

    /** Abre un proyecto o una plantilla. La plantilla se abre como trabajo nuevo (no se daña la original). */
    private void cargarProyecto(File dir, boolean callado, boolean plantilla) {
        final String nombre = dir.getName();
        new Thread(() -> {
            try {
                List<Capa> nuevas = new ArrayList<>();
                int sel = 0;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inMutable = true;
                try (BufferedReader r = new BufferedReader(new FileReader(new File(dir, "capas.txt")))) {
                    String ln;
                    int i = 0;
                    while ((ln = r.readLine()) != null) {
                        String[] p = ln.split("\\|");
                        if (p[0].equals("sel")) { sel = Integer.parseInt(p[1]); continue; }
                        Bitmap b = BitmapFactory.decodeFile(new File(dir, "capa" + i + ".png").getPath(), o);
                        Bitmap or = BitmapFactory.decodeFile(new File(dir, "orig" + i + ".png").getPath(), o);
                        i++;
                        if (b == null) continue;
                        Capa c = new Capa(p[0], p[1], b);
                        if (or != null) c.original = or;
                        c.opacidad = Integer.parseInt(p[2]);
                        c.visible = Boolean.parseBoolean(p[3]);
                        float[] v = new float[9];
                        for (int k = 0; k < 9; k++) v[k] = Float.parseFloat(p[4 + k]);
                        c.m.setValues(v);
                        if (p.length > 13) c.bloqueada = Boolean.parseBoolean(p[13]);
                        nuevas.add(c);
                    }
                }
                if (nuevas.isEmpty()) throw new Exception("vacío");
                final int s = sel;
                h.post(() -> {
                    lienzo.capas.clear();
                    lienzo.capas.addAll(nuevas);
                    lienzo.sel = Math.min(s, nuevas.size() - 1);
                    lienzo.limpiarPasos();
                    fotos = 0; textos = 0;
                    for (Capa c : nuevas) { if ("foto".equals(c.tipo)) fotos++; if ("texto".equals(c.tipo)) textos++; }
                    nombreProyecto = (plantilla || ULTIMO.equals(nombre)) ? (ULTIMO.equals(nombre) ? nombreProyecto : null) : nombre;
                    lienzo.ajustarVista();
                    cambio();
                    if (plantilla) aviso("⭐ Plantilla abierta como trabajo nuevo");
                    else if (!callado) aviso("✔ Abierto");
                });
            } catch (Throwable t) {
                h.post(() -> { if (lienzo.capas.isEmpty()) lienzo.nuevaHoja(); if (!callado) aviso("No se pudo abrir"); });
            }
        }, "abrir").start();
    }
}
