package co.jose.fotoshop;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * La mesa de trabajo de ChpFoto: una hoja carta con capas encima.
 * Un dedo usa la herramienta; dos dedos acercan/alejan la hoja (o, en «Mover», agrandan y giran la capa).
 */
public class Lienzo extends View {

    /** Hoja carta a 150 puntos por pulgada (8,5 × 11 pulgadas). */
    public static final int ANCHO = 1275, ALTO = 1650;

    public static final int MOVER = 0, BORRAR = 1, RESTAURAR = 2, VARITA = 3, LINEA = 4, VER = 5,
            PINCEL = 6, CLONAR = 7, CORRECTOR = 8, LAZO = 9, RECORTAR = 10, GOTERO = 11;

    public interface Oyente {
        void cambio();
        void aviso(String s);
        void colorTomado(int color);
        void lazoListo();
        void recorteListo();
    }

    public final List<Capa> capas = new ArrayList<>();
    public int sel = 0;
    public int herramienta = MOVER;
    public float pincelPx = 30;         // grosor del pincel en la pantalla
    public int color = Color.BLACK;
    public int tolerancia = 46;         // varita: qué tan parecido debe ser el color
    public Oyente oyente;

    private final Matrix vista = new Matrix();
    private boolean vistaLista;
    private final Paint pBmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint pHoja = new Paint();
    private final Paint pBorde = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLinea = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLupa = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler h = new Handler(Looper.getMainLooper());

    // ---------------- Deshacer y rehacer ----------------
    private static class Paso {
        int tipo;          // 0 contenido o posición, 1 capa agregada, 2 capa eliminada
        Capa capa;
        Bitmap bmp, original;
        final Matrix m = new Matrix();
        int indice;
    }

    private final Deque<Paso> pasos = new ArrayDeque<>();
    private final Deque<Paso> rehechos = new ArrayDeque<>();
    private static final int MAX_PASOS = 8;

    public Lienzo(Context c) {
        super(c);
        pHoja.setColor(0xFFDDDDDD);
        pBorde.setStyle(Paint.Style.STROKE);
        pBorde.setColor(0xFFFFB300);
        pLinea.setStyle(Paint.Style.STROKE);
        pLinea.setStrokeCap(Paint.Cap.ROUND);
        pLupa.setStyle(Paint.Style.STROKE);
        pLupa.setColor(Color.WHITE);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    public Capa capaSel() {
        if (capas.isEmpty()) return null;
        sel = Math.max(0, Math.min(sel, capas.size() - 1));
        return capas.get(sel);
    }

    private void avisar(String s) { if (oyente != null) oyente.aviso(s); }

    // ---------------- Capas ----------------

    public void nuevaHoja() {
        capas.clear();
        Bitmap b = Bitmap.createBitmap(ANCHO, ALTO, Bitmap.Config.ARGB_8888);
        b.eraseColor(Color.WHITE);
        capas.add(new Capa("Hoja", "hoja", b));
        sel = 0;
        pasos.clear();
        rehechos.clear();
        ajustarVista();
        avisarCambio();
    }

    /** Agrega una capa encima de la escogida. Si centrar, la pone en la mitad de la hoja. */
    public void agregar(Capa c, boolean centrar) {
        if (centrar) {
            float esc = Math.min(1f, Math.min(ANCHO * 0.9f / c.bmp.getWidth(), ALTO * 0.9f / c.bmp.getHeight()));
            c.m.setScale(esc, esc);
            c.m.postTranslate((ANCHO - c.bmp.getWidth() * esc) / 2f, (ALTO - c.bmp.getHeight() * esc) / 2f);
        }
        int donde = capas.isEmpty() ? 0 : Math.min(sel + 1, capas.size());
        capas.add(donde, c);
        sel = donde;
        Paso p = new Paso();
        p.tipo = 1;
        p.capa = c;
        p.indice = donde;
        empujar(p);
        avisarCambio();
    }

    /** Capa transparente del tamaño de la hoja, para pintar o clonar sin dañar la foto. */
    public void capaVacia(String nombre) {
        Bitmap b = Bitmap.createBitmap(ANCHO, ALTO, Bitmap.Config.ARGB_8888);
        agregar(new Capa(nombre, "vacia", b), false);
    }

    public void duplicar() {
        Capa c = capaSel();
        if (c == null) return;
        Capa d = c.duplicar();
        d.m.postTranslate(20, 20);
        agregar(d, false);
    }

    public void eliminar(int i) {
        if (i < 0 || i >= capas.size()) return;
        if (capas.size() == 1) { avisar("Debe quedar al menos una capa"); return; }
        Paso p = new Paso();
        p.tipo = 2;
        p.capa = capas.remove(i);
        p.indice = i;
        empujar(p);
        sel = Math.min(sel, capas.size() - 1);
        avisarCambio();
    }

    public void mover(int i, int haciaArriba) {
        int j = i + haciaArriba;
        if (i < 0 || j < 0 || i >= capas.size() || j >= capas.size()) return;
        Capa a = capas.get(i);
        capas.set(i, capas.get(j));
        capas.set(j, a);
        sel = j;
        avisarCambio();
    }

    /** Cambia lo que se ve de la capa (por ejemplo, después de quitar el fondo). */
    public void reemplazar(Capa c, Bitmap nuevo) {
        guardarPaso(c, false);
        c.bmp = nuevo;
        avisarCambio();
    }

    private boolean libre(Capa c) {
        if (c == null) return false;
        if (c.bloqueada) { avisar("🔒 Esa capa está bloqueada. Desbloquéela en la lista de capas"); return false; }
        return true;
    }

    public void girar90() {
        Capa c = capaSel();
        if (!libre(c)) return;
        guardarPasoPosicion(c);
        float[] ct = c.centro();
        c.m.postRotate(90, ct[0], ct[1]);
        avisarCambio();
    }

    public void espejo() {
        Capa c = capaSel();
        if (!libre(c)) return;
        guardarPasoPosicion(c);
        float[] ct = c.centro();
        c.m.postScale(-1, 1, ct[0], ct[1]);
        avisarCambio();
    }

    private void avisarCambio() {
        invalidate();
        if (oyente != null) oyente.cambio();
    }

    // ---------------- Deshacer y rehacer ----------------

    private void guardarPaso(Capa c, boolean conOriginal) {
        Paso p = new Paso();
        p.tipo = 0;
        p.capa = c;
        p.bmp = c.bmp.copy(Bitmap.Config.ARGB_8888, true);
        if (conOriginal) p.original = c.original.copy(Bitmap.Config.ARGB_8888, true);
        p.m.set(c.m);
        empujar(p);
    }

    private void guardarPasoPosicion(Capa c) {
        Paso p = new Paso();
        p.tipo = 0;
        p.capa = c;
        p.m.set(c.m);
        empujar(p);
    }

    /** Cada cosa nueva que se hace borra lo que se podía rehacer. */
    private void empujar(Paso p) {
        pasos.push(p);
        rehechos.clear();
        while (pasos.size() > MAX_PASOS) pasos.removeLast();
    }

    /** Aplica un paso y devuelve el paso contrario (para poder volver). */
    private Paso aplicar(Paso p) {
        Paso inv = new Paso();
        inv.capa = p.capa;
        if (p.tipo == 0) {
            inv.tipo = 0;
            if (p.bmp != null) { inv.bmp = p.capa.bmp; p.capa.bmp = p.bmp; }
            if (p.original != null) { inv.original = p.capa.original; p.capa.original = p.original; }
            inv.m.set(p.capa.m);
            p.capa.m.set(p.m);
        } else if (p.tipo == 1) {
            inv.tipo = 2;
            inv.indice = Math.max(0, capas.indexOf(p.capa));
            capas.remove(p.capa);
        } else {
            inv.tipo = 1;
            int i = Math.min(p.indice, capas.size());
            capas.add(i, p.capa);
            inv.indice = i;
            sel = i;
        }
        return inv;
    }

    public boolean deshacer() {
        Paso p = pasos.poll();
        if (p == null) return false;
        rehechos.push(aplicar(p));
        sel = Math.max(0, Math.min(sel, capas.size() - 1));
        avisarCambio();
        return true;
    }

    public boolean rehacer() {
        Paso p = rehechos.poll();
        if (p == null) return false;
        pasos.push(aplicar(p));
        sel = Math.max(0, Math.min(sel, capas.size() - 1));
        avisarCambio();
        return true;
    }

    public void limpiarPasos() { pasos.clear(); rehechos.clear(); }

    // ---------------- Dibujo ----------------

    @Override
    protected void onSizeChanged(int w, int hh, int ow, int oh) {
        super.onSizeChanged(w, hh, ow, oh);
        ajustarVista();
    }

    /** La hoja completa, llenando la pantalla. */
    public void ajustarVista() {
        if (getWidth() == 0 || getHeight() == 0) return;
        float marg = dp(2);
        float s = Math.min((getWidth() - 2 * marg) / ANCHO, (getHeight() - 2 * marg) / ALTO);
        vista.setScale(s, s);
        vista.postTranslate((getWidth() - ANCHO * s) / 2f, (getHeight() - ALTO * s) / 2f);
        vistaLista = true;
        invalidate();
    }

    private float escalaVista() {
        float[] v = new float[9];
        vista.getValues(v);
        return (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
    }

    private boolean usaLupa() {
        return herramienta == BORRAR || herramienta == RESTAURAR || herramienta == VARITA || herramienta == LINEA
                || herramienta == PINCEL || herramienta == CLONAR || herramienta == CORRECTOR || herramienta == GOTERO;
    }

    private boolean usaPincel() {
        return herramienta == BORRAR || herramienta == RESTAURAR || herramienta == PINCEL || herramienta == CLONAR || herramienta == CORRECTOR;
    }

    private void escena(Canvas c, boolean conMarcas) {
        c.drawRect(0, 0, ANCHO, ALTO, pHoja);
        for (Capa k : capas) {
            if (!k.visible) continue;
            pBmp.setAlpha(Math.round(k.opacidad * 2.55f));
            c.drawBitmap(k.bmp, k.m, pBmp);
        }
        pBmp.setAlpha(255);
        if (!conMarcas) return;
        float sv = escalaVista();
        Capa s = capaSel();
        if ((herramienta == MOVER || herramienta == RECORTAR || herramienta == LAZO) && s != null && !"hoja".equals(s.tipo)) {
            Path borde = new Path();
            borde.addRect(new RectF(0, 0, s.bmp.getWidth(), s.bmp.getHeight()), Path.Direction.CW);
            borde.transform(s.m);
            pBorde.setColor(0xFFFFB300);
            pBorde.setStrokeWidth(dp(2) / sv);
            pBorde.setPathEffect(new DashPathEffect(new float[]{dp(8) / sv, dp(5) / sv}, 0));
            c.drawPath(borde, pBorde);
        }
        if (lineaViva) {
            pLinea.setColor(color);
            pLinea.setStrokeWidth(pincelPx / sv);
            c.drawLine(lx0, ly0, lx1, ly1, pLinea);
        }
        if (herramienta == LAZO && !lazo.isEmpty()) {
            pBorde.setColor(0xFF00E5FF);
            pBorde.setStrokeWidth(dp(2.5f) / sv);
            pBorde.setPathEffect(new DashPathEffect(new float[]{dp(7) / sv, dp(4) / sv}, 0));
            c.drawPath(lazo, pBorde);
        }
        if (herramienta == RECORTAR && recorte.width() > 0) {
            Paint sombra = new Paint();
            sombra.setColor(0x88000000);
            c.drawRect(0, 0, ANCHO, recorte.top, sombra);
            c.drawRect(0, recorte.bottom, ANCHO, ALTO, sombra);
            c.drawRect(0, recorte.top, recorte.left, recorte.bottom, sombra);
            c.drawRect(recorte.right, recorte.top, ANCHO, recorte.bottom, sombra);
            pBorde.setColor(0xFF00E5FF);
            pBorde.setStrokeWidth(dp(2.5f) / sv);
            pBorde.setPathEffect(null);
            c.drawRect(recorte, pBorde);
        }
        // la cruz del origen del clonador
        if (herramienta == CLONAR && origenListo && s != null) {
            float[] o = {origenX, origenY};
            if (clonando) { o[0] = cloneMarcaX; o[1] = cloneMarcaY; }
            s.m.mapPoints(o);
            pBorde.setColor(0xFFFF1744);
            pBorde.setPathEffect(null);
            pBorde.setStrokeWidth(dp(2) / sv);
            float r = dp(12) / sv;
            c.drawLine(o[0] - r, o[1], o[0] + r, o[1], pBorde);
            c.drawLine(o[0], o[1] - r, o[0], o[1] + r, pBorde);
            c.drawCircle(o[0], o[1], r * 0.6f, pBorde);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF2A2F3A);
        if (!vistaLista) ajustarVista();
        c.save();
        c.concat(vista);
        escena(c, true);
        c.restore();
        // Lupa: un círculo que muestra de cerca lo que está debajo del dedo
        if (tocando && !dosDedos && usaLupa()) {
            float r = dp(64);
            boolean izquierda = !(dedoX < r * 2.6f && dedoY < r * 2.6f);
            float cx = izquierda ? r + dp(8) : getWidth() - r - dp(8);
            float cy = r + dp(8);
            Path circ = new Path();
            circ.addCircle(cx, cy, r, Path.Direction.CW);
            c.save();
            c.clipPath(circ);
            c.drawColor(0xFF2A2F3A);
            c.translate(cx, cy);
            c.scale(3f, 3f);
            c.translate(-dedoX, -dedoY);
            c.concat(vista);
            escena(c, true);
            c.restore();
            pLupa.setStrokeWidth(dp(3));
            pLupa.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, pLupa);
            pLupa.setStrokeWidth(dp(1.5f));
            pLupa.setColor(herramienta == BORRAR ? 0xFFFF5252 : herramienta == RESTAURAR ? 0xFF69F0AE : 0xFFFFD54A);
            float rr = (herramienta == VARITA || herramienta == GOTERO) ? dp(6) : pincelPx * 3f / 2f;
            c.drawCircle(cx, cy, rr, pLupa);
        }
        if (tocando && !dosDedos && usaPincel()) {
            pLupa.setStrokeWidth(dp(1.5f));
            pLupa.setColor(Color.WHITE);
            c.drawCircle(dedoX, dedoY, pincelPx / 2f, pLupa);
        }
    }

    /** Toda la hoja como una sola imagen (para PNG o PDF). */
    public Bitmap componer() {
        Bitmap out = Bitmap.createBitmap(ANCHO, ALTO, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        for (Capa k : capas) {
            if (!k.visible) continue;
            pBmp.setAlpha(Math.round(k.opacidad * 2.55f));
            c.drawBitmap(k.bmp, k.m, pBmp);
        }
        pBmp.setAlpha(255);
        return out;
    }

    // ---------------- Dedos ----------------

    private boolean tocando, dosDedos, pintado, lineaViva, clonando;
    private float dedoX, dedoY, antX, antY;
    private float lx0, ly0, lx1, ly1;
    private final Matrix m0 = new Matrix();
    private float d0, a0, mx0, my0;

    // lazo y recorte, en medidas de la hoja
    public final Path lazo = new Path();
    private boolean lazoVivo;
    public final RectF recorte = new RectF();
    private float rx0, ry0;

    // clonador: origen en medidas de la capa
    private boolean origenListo;
    private float origenX, origenY, cloneDx, cloneDy, cloneMarcaX, cloneMarcaY;
    private Bitmap muestra;   // copia de la capa al empezar el trazo (clonar o corrector)

    public void reiniciarOrigen() { origenListo = false; invalidate(); }

    private float[] aHoja(float x, float y) {
        Matrix inv = new Matrix();
        vista.invert(inv);
        float[] p = {x, y};
        inv.mapPoints(p);
        return p;
    }

    /** De la pantalla a los puntos de la imagen de la capa. */
    private Matrix pantallaACapa(Capa c) {
        Matrix total = new Matrix(c.m);
        total.postConcat(vista);
        Matrix inv = new Matrix();
        total.invert(inv);
        return inv;
    }

    private boolean editaPixeles() {
        return usaPincel() || herramienta == VARITA || herramienta == LINEA || herramienta == LAZO || herramienta == RECORTAR;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        Capa c = capaSel();
        if (c == null) return true;
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                tocando = true;
                dosDedos = false;
                pintado = false;
                clonando = false;
                dedoX = antX = x;
                dedoY = antY = y;
                if (editaPixeles() && c.bloqueada) { avisar("🔒 Esa capa está bloqueada"); tocando = false; return true; }
                if (editaPixeles() && !c.visible) { avisar("Esa capa está escondida"); tocando = false; return true; }
                if (herramienta == MOVER) {
                    if ("hoja".equals(c.tipo)) avisar("Escoja a la derecha la capa que quiere mover");
                    else if (c.bloqueada) avisar("🔒 Esa capa está bloqueada");
                    else guardarPasoPosicion(c);
                } else if (herramienta == CLONAR) {
                    float[] p = {x, y};
                    pantallaACapa(c).mapPoints(p);
                    if (!origenListo) {
                        origenX = p[0];
                        origenY = p[1];
                        origenListo = true;
                        tocando = false;
                        avisar("📍 Origen listo. Ahora pinte donde quiere copiar");
                        invalidate();
                        return true;
                    }
                    cloneDx = origenX - p[0];
                    cloneDy = origenY - p[1];
                    cloneMarcaX = origenX;
                    cloneMarcaY = origenY;
                    muestra = c.bmp.copy(Bitmap.Config.ARGB_8888, false);
                    clonando = true;
                    guardarPaso(c, false);
                    pintado = true;
                    pintar(c, x, y, x, y);
                } else if (herramienta == CORRECTOR) {
                    muestra = difuminada(c.bmp);
                    guardarPaso(c, false);
                    pintado = true;
                    pintar(c, x, y, x, y);
                } else if (herramienta == BORRAR || herramienta == RESTAURAR || herramienta == PINCEL) {
                    guardarPaso(c, false);
                    pintado = true;
                    pintar(c, x, y, x, y);
                } else if (herramienta == LINEA) {
                    float[] p = aHoja(x, y);
                    lx0 = lx1 = p[0];
                    ly0 = ly1 = p[1];
                    lineaViva = true;
                } else if (herramienta == LAZO) {
                    float[] p = aHoja(x, y);
                    lazo.reset();
                    lazo.moveTo(p[0], p[1]);
                    lazoVivo = true;
                } else if (herramienta == RECORTAR) {
                    float[] p = aHoja(x, y);
                    rx0 = p[0];
                    ry0 = p[1];
                    recorte.set(rx0, ry0, rx0, ry0);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dosDedos = true;
                    lineaViva = false;
                    if (lazoVivo) { lazoVivo = false; lazo.reset(); }
                    d0 = distancia(e);
                    a0 = angulo(e);
                    mx0 = (e.getX(0) + e.getX(1)) / 2f;
                    my0 = (e.getY(0) + e.getY(1)) / 2f;
                    if (herramienta == MOVER && !"hoja".equals(c.tipo) && !c.bloqueada) m0.set(c.m);
                    else m0.set(vista);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dosDedos) {
                    if (e.getPointerCount() < 2) return true;
                    float s = d0 > 0 ? distancia(e) / d0 : 1f;
                    float mx = (e.getX(0) + e.getX(1)) / 2f, my = (e.getY(0) + e.getY(1)) / 2f;
                    if (herramienta == MOVER && !"hoja".equals(c.tipo) && !c.bloqueada) {
                        float[] p0 = aHoja(mx0, my0), p1 = aHoja(mx, my);
                        c.m.set(m0);
                        c.m.postScale(s, s, p0[0], p0[1]);
                        c.m.postRotate(angulo(e) - a0, p0[0], p0[1]);
                        c.m.postTranslate(p1[0] - p0[0], p1[1] - p0[1]);
                    } else {
                        vista.set(m0);
                        vista.postScale(s, s, mx0, my0);
                        vista.postTranslate(mx - mx0, my - my0);
                        limitarVista();
                    }
                    invalidate();
                    return true;
                }
                if (!tocando) return true;
                dedoX = x;
                dedoY = y;
                if (herramienta == MOVER && !"hoja".equals(c.tipo) && !c.bloqueada) {
                    float sv = escalaVista();
                    c.m.postTranslate((x - antX) / sv, (y - antY) / sv);
                } else if (herramienta == VER || herramienta == MOVER) {
                    vista.postTranslate(x - antX, y - antY);
                } else if (pintado) {
                    pintar(c, antX, antY, x, y);
                    if (clonando) {
                        float[] p = {x, y};
                        pantallaACapa(c).mapPoints(p);
                        cloneMarcaX = p[0] + cloneDx;
                        cloneMarcaY = p[1] + cloneDy;
                    }
                } else if (lineaViva) {
                    float[] p = aHoja(x, y);
                    lx1 = p[0];
                    ly1 = p[1];
                } else if (lazoVivo) {
                    float[] p = aHoja(x, y);
                    lazo.lineTo(p[0], p[1]);
                } else if (herramienta == RECORTAR) {
                    float[] p = aHoja(x, y);
                    recorte.set(Math.min(rx0, p[0]), Math.min(ry0, p[1]), Math.max(rx0, p[0]), Math.max(ry0, p[1]));
                }
                antX = x;
                antY = y;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                boolean fueDos = dosDedos;
                boolean estaba = tocando;
                tocando = false;
                dosDedos = false;
                if (e.getActionMasked() == MotionEvent.ACTION_UP && !fueDos && estaba) {
                    if (herramienta == LINEA && lineaViva) ponerLinea(c);
                    else if (herramienta == VARITA) varita(c, x, y);
                    else if (herramienta == GOTERO) gotero(x, y);
                    else if (herramienta == LAZO && lazoVivo) {
                        lazo.close();
                        RectF b = new RectF();
                        lazo.computeBounds(b, true);
                        if (b.width() > 8 && b.height() > 8 && oyente != null) oyente.lazoListo();
                        else lazo.reset();
                    } else if (herramienta == RECORTAR && recorte.width() > 8 && recorte.height() > 8 && oyente != null) {
                        oyente.recorteListo();
                    }
                }
                lineaViva = false;
                lazoVivo = false;
                pintado = false;
                clonando = false;
                muestra = null;
                avisarCambio();
                return true;
        }
        return true;
    }

    private void limitarVista() {
        float sv = escalaVista();
        float minimo = Math.min(getWidth() / (float) ANCHO, getHeight() / (float) ALTO) * 0.5f;
        float maximo = minimo * 40f;
        if (sv < minimo) vista.postScale(minimo / sv, minimo / sv, getWidth() / 2f, getHeight() / 2f);
        else if (sv > maximo) vista.postScale(maximo / sv, maximo / sv, getWidth() / 2f, getHeight() / 2f);
    }

    private static float distancia(MotionEvent e) {
        return (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
    }

    private static float angulo(MotionEvent e) {
        return (float) Math.toDegrees(Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
    }

    // ---------------- Herramientas de pincel ----------------

    /** Una copia borrosa de la capa: el corrector pinta con ella y tapa rayones y manchas. */
    private static Bitmap difuminada(Bitmap b) {
        int w = b.getWidth(), hh = b.getHeight();
        int pw = Math.max(1, w / 12), ph = Math.max(1, hh / 12);
        Bitmap chica = Bitmap.createScaledBitmap(b, pw, ph, true);
        return Bitmap.createScaledBitmap(chica, w, hh, true);
    }

    /** Borra, restaura, pinta, clona o corrige un trazo, de la pantalla a la imagen de la capa. */
    private void pintar(Capa c, float x1, float y1, float x2, float y2) {
        Matrix inv = pantallaACapa(c);
        float[] p = {x1, y1, x2, y2};
        inv.mapPoints(p);
        float grosor = Math.max(1f, inv.mapRadius(pincelPx / 2f) * 2f);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.STROKE);
        pp.setStrokeCap(Paint.Cap.ROUND);
        pp.setStrokeJoin(Paint.Join.ROUND);
        pp.setStrokeWidth(grosor);
        if (herramienta == BORRAR) {
            pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        } else if (herramienta == RESTAURAR) {
            pp.setShader(new BitmapShader(c.original, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        } else if (herramienta == PINCEL) {
            pp.setColor(color);
        } else if ((herramienta == CLONAR || herramienta == CORRECTOR) && muestra != null) {
            BitmapShader sh = new BitmapShader(muestra, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            if (herramienta == CLONAR) {
                Matrix lm = new Matrix();
                lm.setTranslate(-cloneDx, -cloneDy);
                sh.setLocalMatrix(lm);
            }
            pp.setShader(sh);
        } else {
            return;
        }
        Canvas cv = new Canvas(c.bmp);
        if (p[0] == p[2] && p[1] == p[3]) cv.drawPoint(p[0], p[1], pp);
        else cv.drawLine(p[0], p[1], p[2], p[3], pp);
    }

    /** Línea recta en la capa escogida (también queda en su copia, para que «Restaurar» no la quite). */
    private void ponerLinea(Capa c) {
        if (Math.hypot(lx1 - lx0, ly1 - ly0) < 2) return;
        guardarPaso(c, true);
        Matrix inv = new Matrix();
        c.m.invert(inv);
        float[] p = {lx0, ly0, lx1, ly1};
        inv.mapPoints(p);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.STROKE);
        pp.setStrokeCap(Paint.Cap.ROUND);
        pp.setColor(color);
        pp.setStrokeWidth(Math.max(1f, inv.mapRadius(pincelPx / escalaVista() / 2f) * 2f));
        new Canvas(c.bmp).drawLine(p[0], p[1], p[2], p[3], pp);
        new Canvas(c.original).drawLine(p[0], p[1], p[2], p[3], pp);
    }

    /** Cuentagotas: toma el color que se ve en ese punto de la hoja. */
    private void gotero(float x, float y) {
        float[] p = aHoja(x, y);
        int px = (int) p[0], py = (int) p[1];
        if (px < 0 || py < 0 || px >= ANCHO || py >= ALTO) { avisar("Toque encima de la hoja"); return; }
        Bitmap todo = componer();
        int col = todo.getPixel(px, py) | 0xFF000000;
        color = col;
        if (oyente != null) oyente.colorTomado(col);
    }

    /** Varita: toca un color y se borra todo lo parecido que esté pegado a ese punto. */
    private void varita(Capa c, float x, float y) {
        Matrix inv = pantallaACapa(c);
        float[] p = {x, y};
        inv.mapPoints(p);
        final int px = (int) p[0], py = (int) p[1];
        final Bitmap b = c.bmp;
        final int w = b.getWidth(), hh = b.getHeight();
        if (px < 0 || py < 0 || px >= w || py >= hh) { avisar("Toque encima de la capa escogida"); return; }
        guardarPaso(c, false);
        avisar("🪄 Borrando ese color…");
        final int tol = tolerancia;
        new Thread(() -> {
            int[] px2 = new int[w * hh];
            b.getPixels(px2, 0, w, 0, 0, w, hh);
            int obj = px2[py * w + px];
            if (Color.alpha(obj) == 0) return;
            int[] cola = new int[w * hh];
            int ini = 0, fin = 0;
            cola[fin++] = py * w + px;
            px2[py * w + px] = 0;
            while (ini < fin) {
                int k = cola[ini++];
                int kx = k % w, ky = k / w;
                int[] vec = {kx > 0 ? k - 1 : -1, kx < w - 1 ? k + 1 : -1, ky > 0 ? k - w : -1, ky < hh - 1 ? k + w : -1};
                for (int v : vec) {
                    if (v < 0) continue;
                    int col = px2[v];
                    if (Color.alpha(col) == 0) continue;
                    if (Math.abs(Color.red(col) - Color.red(obj)) <= tol && Math.abs(Color.green(col) - Color.green(obj)) <= tol
                            && Math.abs(Color.blue(col) - Color.blue(obj)) <= tol) {
                        px2[v] = 0;
                        cola[fin++] = v;
                    }
                }
            }
            h.post(() -> {
                if (!b.isRecycled() && b.isMutable()) b.setPixels(px2, 0, w, 0, 0, w, hh);
                avisarCambio();
            });
        }, "varita").start();
    }

    // ---------------- Lazo y recorte ----------------

    /** El lazo pasado a medidas de la capa escogida. */
    private Path lazoEnCapa(Capa c) {
        Matrix inv = new Matrix();
        c.m.invert(inv);
        Path p = new Path(lazo);
        p.transform(inv);
        return p;
    }

    /** modo 0: dejar solo lo de adentro · 1: borrar lo de adentro · 2: copiar lo de adentro a una capa nueva. */
    public void aplicarLazo(int modo) {
        Capa c = capaSel();
        if (!libre(c) || lazo.isEmpty()) { lazo.reset(); invalidate(); return; }
        Path p = lazoEnCapa(c);
        if (modo == 0) {
            guardarPaso(c, false);
            Bitmap nuevo = Bitmap.createBitmap(c.bmp.getWidth(), c.bmp.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(nuevo);
            cv.clipPath(p);
            cv.drawBitmap(c.bmp, 0, 0, null);
            c.bmp = nuevo;
        } else if (modo == 1) {
            guardarPaso(c, false);
            Paint borra = new Paint(Paint.ANTI_ALIAS_FLAG);
            borra.setStyle(Paint.Style.FILL);
            borra.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            new Canvas(c.bmp).drawPath(p, borra);
        } else {
            RectF b = new RectF();
            p.computeBounds(b, true);
            Rect r = new Rect((int) Math.floor(b.left), (int) Math.floor(b.top), (int) Math.ceil(b.right), (int) Math.ceil(b.bottom));
            if (!r.intersect(0, 0, c.bmp.getWidth(), c.bmp.getHeight()) || r.width() < 2 || r.height() < 2) {
                avisar("El lazo quedó por fuera de la capa");
                lazo.reset();
                invalidate();
                return;
            }
            Bitmap pedazo = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(pedazo);
            cv.translate(-r.left, -r.top);
            cv.clipPath(p);
            cv.drawBitmap(c.bmp, 0, 0, null);
            Capa nueva = new Capa(c.nombre + " pedazo", "foto", pedazo);
            nueva.m.set(c.m);
            nueva.m.preTranslate(r.left, r.top);
            lazo.reset();
            agregar(nueva, false);
            return;
        }
        lazo.reset();
        avisarCambio();
    }

    public void cancelarLazo() { lazo.reset(); recorte.setEmpty(); invalidate(); }

    /** Recorta la capa escogida al rectángulo marcado. */
    public void aplicarRecorte() {
        Capa c = capaSel();
        if (!libre(c)) { recorte.setEmpty(); invalidate(); return; }
        if ("hoja".equals(c.tipo)) { avisar("Escoja a la derecha la capa de la foto que quiere recortar"); recorte.setEmpty(); invalidate(); return; }
        Matrix inv = new Matrix();
        c.m.invert(inv);
        RectF enCapa = new RectF(recorte);
        inv.mapRect(enCapa);
        Rect r = new Rect((int) Math.floor(enCapa.left), (int) Math.floor(enCapa.top), (int) Math.ceil(enCapa.right), (int) Math.ceil(enCapa.bottom));
        if (!r.intersect(0, 0, c.bmp.getWidth(), c.bmp.getHeight()) || r.width() < 2 || r.height() < 2) {
            avisar("El recuadro quedó por fuera de la capa");
            recorte.setEmpty();
            invalidate();
            return;
        }
        guardarPaso(c, true);
        c.bmp = Bitmap.createBitmap(c.bmp, r.left, r.top, r.width(), r.height()).copy(Bitmap.Config.ARGB_8888, true);
        c.original = Bitmap.createBitmap(c.original, r.left, r.top, r.width(), r.height()).copy(Bitmap.Config.ARGB_8888, true);
        c.m.preTranslate(r.left, r.top);
        recorte.setEmpty();
        avisarCambio();
    }
}
