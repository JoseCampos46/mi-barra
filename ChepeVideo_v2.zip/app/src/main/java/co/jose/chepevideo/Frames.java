package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

/** Sacar datos y cuadros de un video. */
public final class Frames {

    public static final class VInfo {
        public final long durMs; public final int w, h; public final float fps;
        VInfo(long d, int w, int h, float f) { durMs = d; this.w = w; this.h = h; fps = f; }
    }

    public static VInfo info(Context ctx, Uri uri) throws Exception {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            long d = parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            int w = (int) parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int h = (int) parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            int rot = (int) parseL(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            if (rot == 90 || rot == 270) { int t = w; w = h; h = t; }
            return new VInfo(d, w, h, fps(ctx, uri));
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
    }

    static float fps(Context ctx, Uri uri) {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(ctx, uri, null);
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("video/") && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                    float v;
                    try { v = f.getInteger(MediaFormat.KEY_FRAME_RATE); }
                    catch (ClassCastException e) { v = f.getFloat(MediaFormat.KEY_FRAME_RATE); }
                    if (v > 1f && v < 240f) return v;
                }
            }
        } catch (Exception ignored) {
        } finally {
            try { ex.release(); } catch (Exception ignored) {}
        }
        return 30f;
    }

    static long parseL(String s) {
        if (s == null) return 0;
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; }
    }

    public static MediaMetadataRetriever open(Context ctx, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        r.setDataSource(ctx, uri);
        return r;
    }

    /** Cuadro exacto en ese momento, reducido para que quepa en maxW x maxH. */
    public static Bitmap grab(MediaMetadataRetriever r, long tMs, int maxW, int maxH) {
        try {
            Bitmap b = r.getScaledFrameAtTime(Math.max(0, tMs) * 1000L,
                    MediaMetadataRetriever.OPTION_CLOSEST, Math.max(2, maxW), Math.max(2, maxH));
            return argb(b);
        } catch (Exception e) {
            return null;
        }
    }

    public static Bitmap argb(Bitmap b) {
        if (b == null) return null;
        if (b.getConfig() == Bitmap.Config.ARGB_8888) return b;
        Bitmap c = b.copy(Bitmap.Config.ARGB_8888, true);
        return c != null ? c : b;
    }

    private Frames() {}
}
