package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Línea de tiempo con inicio y fin del corte; acercar / alejar con + y − o abriendo y cerrando dos dedos. */
public class TimelineView extends View {

    public interface Listener {
        void onSeek(long ms);
        void onTrim(long startMs, long endMs);
    }

    public Listener listener;
    public long durMs, posMs, startMs, endMs;
    public float zoom = 1f;
    public boolean dark;
    public final List<long[]> ranges = new ArrayList<>();

    private long viewStart;
    private int drag;
    private boolean pinch;
    private float pz0, ps0;
    private long pm0;
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TimelineView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private long vis() { return Math.max(1, (long) (durMs / zoom)); }

    private void window() {
        long v = vis();
        viewStart = Math.max(0, Math.min(posMs - v / 2, durMs - v));
    }

    private float pad() { return 10 * dp; }

    private float x(long ms) {
        float w = getWidth() - 2 * pad();
        return pad() + (float) (ms - viewStart) / vis() * w;
    }

    private long ms(float xx) {
        float w = Math.max(1, getWidth() - 2 * pad());
        long m = viewStart + (long) ((xx - pad()) / w * vis());
        return Math.max(0, Math.min(durMs, m));
    }

    public void zoomIn() { zoom = Math.min(64f, zoom * 2f); window(); invalidate(); }

    public void zoomOut() { zoom = Math.max(1f, zoom / 2f); window(); invalidate(); }

    public void setPos(long ms) {
        posMs = ms;
        if (drag == 0) {
            long v = vis();
            if (ms < viewStart || ms > viewStart + v) window();
        }
        invalidate();
    }

    private float cl(float v) { return Math.max(pad(), Math.min(getWidth() - pad(), v)); }

    @Override
    protected void onDraw(Canvas c) {
        float top = 20 * dp, bot = getHeight() - 4 * dp, L = pad(), R = getWidth() - pad();
        p.setStyle(Paint.Style.FILL);
        p.setColor(dark ? 0xFF2C2C2A : 0xFFE1F5EE);
        c.drawRoundRect(L, top, R, bot, 6 * dp, 6 * dp, p);
        p.setTextSize(12.5f * dp);
        p.setColor(dark ? Color.WHITE : Color.BLACK);
        if (durMs <= 0) {
            c.drawText("Abra un video", L, 14 * dp, p);
            return;
        }
        float sx = cl(x(startMs)), ex = cl(x(endMs));
        p.setColor(0xFF5DCAA5);
        if (ex > sx) c.drawRect(sx, top, ex, bot - 9 * dp, p);
        for (long[] r : ranges) {
            p.setColor((int) r[2]);
            float a = cl(x(r[0])), b = cl(x(r[1]));
            if (b > a) c.drawRect(a, bot - 8 * dp, b, bot - 2 * dp, p);
        }
        p.setColor(0xFF085041);
        float xs = x(startMs), xe = x(endMs);
        if (xs >= L - 1 && xs <= R + 1) c.drawRoundRect(sx - 4 * dp, top - 2 * dp, sx + 4 * dp, bot, 2 * dp, 2 * dp, p);
        if (xe >= L - 1 && xe <= R + 1) c.drawRoundRect(ex - 4 * dp, top - 2 * dp, ex + 4 * dp, bot, 2 * dp, 2 * dp, p);
        float px = x(posMs);
        if (px >= L && px <= R) {
            p.setColor(0xFFE24B4A);
            c.drawRect(px - 1.5f * dp, top - 4 * dp, px + 1.5f * dp, bot, p);
        }
        p.setColor(dark ? Color.WHITE : Color.BLACK);
        c.drawText(fmt(posMs) + " / " + fmt(durMs), L, 14 * dp, p);
        String r = "Corte " + fmt(endMs - startMs) + (zoom > 1.05f ? String.format(Locale.US, "  ·  x%.1f", zoom) : "");
        c.drawText(r, R - p.measureText(r), 14 * dp, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (durMs <= 0) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                float tol = 22 * dp;
                float ds = Math.abs(e.getX() - x(startMs)), de = Math.abs(e.getX() - x(endMs));
                if (ds < tol && ds <= de) drag = 1;
                else if (de < tol) drag = 2;
                else drag = 3;
                move(e.getX());
                break;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    pinch = true;
                    drag = 0;
                    pz0 = zoom;
                    ps0 = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
                    pm0 = ms((e.getX(0) + e.getX(1)) / 2f);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (pinch) {
                    if (e.getPointerCount() >= 2) pinchTo(e);
                } else move(e.getX());
                break;
            case MotionEvent.ACTION_POINTER_UP:
                break;
            case MotionEvent.ACTION_UP:
                pinch = false;
                drag = 0;
                break;
            case MotionEvent.ACTION_CANCEL:
                drag = 0;
                break;
        }
        return true;
    }

    /** Dos dedos: el momento que quedó entre los dedos se queda debajo de ellos mientras acerca o aleja. */
    private void pinchTo(MotionEvent e) {
        float sp = Math.max(1f, Math.abs(e.getX(0) - e.getX(1)));
        zoom = Math.max(1f, Math.min(64f, pz0 * sp / ps0));
        float fx = (e.getX(0) + e.getX(1)) / 2f;
        float w = Math.max(1, getWidth() - 2 * pad());
        long v = vis();
        long st = pm0 - (long) ((fx - pad()) / w * v);
        viewStart = Math.max(0, Math.min(st, durMs - v));
        invalidate();
    }

    private void move(float xx) {
        long m = ms(xx);
        if (drag == 1) {
            startMs = Math.max(0, Math.min(m, endMs - 100));
            if (listener != null) { listener.onTrim(startMs, endMs); listener.onSeek(startMs); }
        } else if (drag == 2) {
            endMs = Math.min(durMs, Math.max(m, startMs + 100));
            if (listener != null) { listener.onTrim(startMs, endMs); listener.onSeek(endMs); }
        } else if (drag == 3) {
            posMs = m;
            if (listener != null) listener.onSeek(m);
        }
        invalidate();
    }

    public static String fmt(long ms) {
        if (ms < 0) ms = 0;
        return String.format(Locale.US, "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10);
    }
}
