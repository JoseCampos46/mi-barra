package co.jose.chepevideo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SonicAudioProcessor;
import androidx.media3.effect.Crop;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.google.android.gms.tasks.Tasks;
import com.google.common.collect.ImmutableList;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    static final int TEAL_L = 0xFFE1F5EE, TEAL_D = 0xFF0F6E56, TEAL_T = 0xFF085041;
    static final int AMB_L = 0xFFFAEEDA, AMB_T = 0xFF633806, AMB_B = 0xFFBA7517;
    static final int REQ_VIDEO = 1, REQ_IMAGE = 2, REQ_LAYER = 3, REQ_BG_IMG = 4, REQ_BG_VID = 5, REQ_MIC = 12;

    private ExoPlayer player;
    private PlayerView playerView;
    private OverlayView overlay;
    private TimelineView timeline;
    private ZoomFrame videoFrame;
    private long lastTapT;
    private LinearLayout topBar, ctxBox, ctxRow, thumbRow, timelineRow, panel;
    private HorizontalScrollView ctxScroll;
    private ScrollView gridScroll;
    private TextView titleView, statusView, openBtn, playBtn;
    private GridLayout grid;
    private final ImageView[] thumbs = new ImageView[5];
    private final EnumMap<Mode, TextView> modeBtns = new EnumMap<>(Mode.class);
    private final Mode[] order = {Mode.CUT, Mode.SPEED, Mode.MUTE, Mode.PHOTO, Mode.SUBS,
            Mode.IMAGE, Mode.CROP, Mode.BG, Mode.LAYER, Mode.EXPORT};

    private boolean landscape, menuVisible = true, exporting, previewBusy, subsBusy;
    private boolean photoCarta = true, bgGreen, layerGreen;
    private Mode mode = Mode.NONE;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private Compositor previewComp;
    private Seg imgSeg;
    private MediaMetadataRetriever thumbRet;
    private Uri thumbUri;
    private long lastThumbPos = -1;
    private Runnable pendingMic;

    private SpeechRecognizer micRec;
    private boolean micActive;
    private long micSegStart;

    // ------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        player = new ExoPlayer.Builder(this).build();
        player.setSeekParameters(SeekParameters.EXACT);
        buildViews();
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                playBtn.setText(isPlaying ? "⏸" : "▶");
                if (mode == Mode.PHOTO) refreshCtx();
                overlay.invalidate();
            }
        });
        landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyLayout();
        setMode(Mode.NONE);
        handleIntent(getIntent());
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() { onTick(); ui.postDelayed(this, 40); }
    };

    @Override protected void onResume() { super.onResume(); ui.removeCallbacks(tick); ui.post(tick); }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
        if (micActive) finishMic();
        player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        player.release();
        final Compositor pc = previewComp;
        final MediaMetadataRetriever tr = thumbRet;
        final Seg sg = imgSeg;
        exec.execute(() -> {
            if (pc != null) pc.release();
            if (sg != null) sg.close();
            if (tr != null) try { tr.release(); } catch (Exception ignored) {}
        });
        exec.shutdown();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        landscape = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyLayout();
        refreshCtx();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        else if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        if (u != null) loadVideo(u);
    }

    // ------------------------------------------------------------ pantalla

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    private TextView chip(String label, boolean active, Runnable r) {
        TextView t = tv(label, 14, active ? Color.WHITE : TEAL_T, true);
        t.setBackground(round(active ? TEAL_D : TEAL_L, 18));
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView lab(String s) {
        TextView t = tv(s, 13, Color.BLACK, true);
        t.setBackground(round(Color.WHITE, 8));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private TextView small(String s, Runnable r) {
        TextView t = tv(s, 22, TEAL_T, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(TEAL_L, 10));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void add(View v) { ctxRow.addView(v); }

    private void buildViews() {
        playerView = (PlayerView) getLayoutInflater().inflate(R.layout.reproductor, null, false);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setShutterBackgroundColor(Color.BLACK);
        playerView.setPlayer(player);

        overlay = new OverlayView(this);
        overlay.onTap = this::onVideoTap;
        overlay.onChanged = () -> { marks(); if (mode == Mode.CROP) refreshCtx(); };

        videoFrame = new ZoomFrame(this);
        videoFrame.gate = overlay::wantsPinch;
        videoFrame.box.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        videoFrame.box.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        titleView = tv("🎬 Chepe Video", 18, Color.BLACK, true);
        statusView = tv("", 12, TEAL_T, true);
        statusView.setBackground(round(TEAL_L, 8));
        statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
        statusView.setVisibility(View.GONE);
        openBtn = chip("📂 Abrir video", true, () -> pick(REQ_VIDEO, "video/*"));

        topBar = hbox();
        topBar.setPadding(dp(10), dp(6), dp(4), dp(6));

        ctxRow = hbox();
        ctxRow.setPadding(dp(6), dp(5), dp(6), dp(5));
        ctxScroll = new HorizontalScrollView(this);
        ctxScroll.setHorizontalScrollBarEnabled(false);
        ctxScroll.addView(ctxRow);

        thumbRow = hbox();
        thumbRow.setPadding(dp(6), 0, dp(6), dp(5));
        for (int i = 0; i < 5; i++) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(i == 2 ? TEAL_D : 0xFFB5D4F4, 4));
            int pd = dp(i == 2 ? 3 : 1);
            iv.setPadding(pd, pd, pd, pd);
            final int off = i - 2;
            iv.setOnClickListener(v -> step(off));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            lp.setMarginEnd(dp(4));
            thumbRow.addView(iv, lp);
            thumbs[i] = iv;
        }
        ctxBox = vbox();
        ctxBox.addView(ctxScroll);
        ctxBox.addView(thumbRow);

        timeline = new TimelineView(this);
        timeline.listener = new TimelineView.Listener() {
            @Override public void onSeek(long ms) { player.seekTo(ms); }
            @Override public void onTrim(long s, long e) { Proj.trimStart = s; Proj.trimEnd = e; if (mode == Mode.CUT) refreshCtx(); }
        };
        playBtn = small("▶", this::togglePlay);
        TextView minus = small("−", () -> timeline.zoomOut());
        TextView plus = small("+", () -> timeline.zoomIn());
        timelineRow = hbox();
        timelineRow.setPadding(dp(4), dp(2), dp(4), dp(2));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(46), dp(46));
        pl.setMarginEnd(dp(4));
        timelineRow.addView(playBtn, pl);
        timelineRow.addView(minus, new LinearLayout.LayoutParams(dp(36), dp(46)));
        timelineRow.addView(timeline, new LinearLayout.LayoutParams(0, dp(62), 1f));
        timelineRow.addView(plus, new LinearLayout.LayoutParams(dp(36), dp(46)));

        grid = new GridLayout(this);
        gridScroll = new ScrollView(this);
        addModeBtn(Mode.CUT, "✂️", "Cortar");
        addModeBtn(Mode.SPEED, "🐢", "Lento");
        addModeBtn(Mode.MUTE, "🔇", "Mudo");
        addModeBtn(Mode.PHOTO, "📷", "Foto");
        addModeBtn(Mode.SUBS, "💬", "Letrero");
        addModeBtn(Mode.IMAGE, "🖼️", "Imagen");
        addModeBtn(Mode.CROP, "🔲", "Cuadro");
        addModeBtn(Mode.BG, "🌄", "Fondo");
        addModeBtn(Mode.LAYER, "👥", "Encima");
        addModeBtn(Mode.EXPORT, "💾", "MP4");
    }

    private void addModeBtn(final Mode m, String icon, String label) {
        TextView t = tv(icon + "\n" + label, 12.5f, TEAL_T, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(2), dp(4), dp(2), dp(4));
        t.setOnClickListener(v -> onModeClick(m));
        modeBtns.put(m, t);
    }

    private void styleBtn(Mode m, boolean active) {
        TextView t = modeBtns.get(m);
        if (t == null) return;
        if (active) {
            t.setBackground(round(TEAL_D, 10));
            t.setTextColor(Color.WHITE);
        } else if (m == Mode.EXPORT) {
            t.setBackground(round(TEAL_D, 10));
            t.setTextColor(Color.WHITE);
        } else if (m == Mode.BG || m == Mode.LAYER) {
            GradientDrawable g = round(AMB_L, 10);
            g.setStroke(dp(1), AMB_B);
            t.setBackground(g);
            t.setTextColor(AMB_T);
        } else {
            t.setBackground(round(TEAL_L, 10));
            t.setTextColor(TEAL_T);
        }
        if (m == Mode.EXPORT && active) {
            GradientDrawable g = round(TEAL_D, 10);
            g.setStroke(dp(3), 0xFFEF9F27);
            t.setBackground(g);
        }
    }

    private static void detach(View v) {
        ViewParent p = v.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(v);
    }

    private void applyLayout() {
        if (panel != null) { panel.removeAllViews(); detach(panel); }
        gridScroll.removeAllViews();
        for (View v : new View[]{videoFrame, titleView, statusView, openBtn, ctxBox, timelineRow, grid, topBar, gridScroll}) detach(v);
        topBar.removeAllViews();
        grid.removeAllViews();
        grid.setColumnCount(landscape ? 2 : 5);
        for (Mode m : order) {
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(landscape ? 52 : 60);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(modeBtns.get(m), lp);
        }
        if (!landscape) {
            topBar.addView(titleView);
            topBar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
            sl.setMarginEnd(dp(6));
            topBar.addView(statusView, sl);
            topBar.addView(openBtn);
            LinearLayout root = vbox();
            root.setBackgroundColor(Color.WHITE);
            root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));
            root.addView(videoFrame, new LinearLayout.LayoutParams(-1, 0, 1f));
            root.addView(ctxBox, new LinearLayout.LayoutParams(-1, -2));
            root.addView(timelineRow, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
            gl.setMargins(dp(4), 0, dp(4), dp(6));
            root.addView(grid, gl);
            timelineRow.setBackgroundColor(Color.WHITE);
            timelineRow.setVisibility(View.VISIBLE);
            timeline.dark = false;
            panel = null;
            menuVisible = true;
            ui.removeCallbacks(autoHide);
            setContentView(root);
        } else {
            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.BLACK);
            root.addView(videoFrame, new FrameLayout.LayoutParams(-1, -1));
            panel = vbox();
            panel.setBackgroundColor(0xEE04342C);
            panel.setPadding(dp(4), dp(4), dp(4), dp(4));
            topBar.addView(openBtn);
            panel.addView(topBar);
            panel.addView(ctxBox);
            gridScroll.addView(grid, new FrameLayout.LayoutParams(-1, -2));
            panel.addView(gridScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
            root.addView(panel, new FrameLayout.LayoutParams(dp(250), -1, Gravity.END));
            FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            tl.rightMargin = dp(250);
            root.addView(timelineRow, tl);
            timelineRow.setBackgroundColor(0xCC000000);
            timeline.dark = true;
            FrameLayout.LayoutParams st = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
            st.setMargins(dp(8), dp(8), 0, 0);
            root.addView(statusView, st);
            setContentView(root);
            showMenu(true);
        }
    }

    private final Runnable autoHide = () -> { if (landscape && !exporting && !micActive) showMenu(false); };

    private void showMenu(boolean v) {
        if (!landscape || panel == null) return;
        menuVisible = v;
        panel.setVisibility(v ? View.VISIBLE : View.GONE);
        timelineRow.setVisibility(v ? View.VISIBLE : View.GONE);
        ui.removeCallbacks(autoHide);
        if (v) ui.postDelayed(autoHide, 4000);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (landscape && menuVisible && ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            ui.removeCallbacks(autoHide);
            ui.postDelayed(autoHide, 4000);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void onVideoTap() {
        long now = android.os.SystemClock.uptimeMillis();
        boolean dbl = now - lastTapT < 350;
        lastTapT = dbl ? 0 : now;
        if (dbl && videoFrame.zoomed()) videoFrame.reset();
        if (landscape) showMenu(!menuVisible);
        else togglePlay();
    }

    private void status(String s) {
        if (s == null || s.isEmpty()) { statusView.setVisibility(View.GONE); return; }
        statusView.setText(s);
        statusView.setVisibility(View.VISIBLE);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static String fmt(long ms) { return TimelineView.fmt(ms); }

    private static String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }

    private static int even(int v) { v = Math.max(2, v); return v % 2 == 0 ? v : v - 1; }

    // ------------------------------------------------------------ herramientas

    private void onModeClick(Mode m) {
        if (Proj.uri == null) { toast("Primero abra un video 📂"); pick(REQ_VIDEO, "video/*"); return; }
        if (m == Mode.MUTE) {
            if (mode != Mode.MUTE) setMode(Mode.MUTE);
            Proj.mute = !Proj.mute;
            player.setVolume(Proj.mute ? 0f : 1f);
            refreshCtx();
            return;
        }
        setMode(m == mode ? Mode.NONE : m);
    }

    private void setMode(Mode m) {
        Mode prev = mode;
        if (prev == Mode.PHOTO && m != Mode.PHOTO) player.setPlaybackParameters(new PlaybackParameters(Proj.speed));
        if (prev == Mode.CROP && m != Mode.CROP && isFullCrop()) Proj.crop = null;
        mode = m;
        overlay.mode = m;
        if (m == Mode.PHOTO) {
            player.pause();
            player.setPlaybackParameters(new PlaybackParameters(0.25f));
            lastThumbPos = -1;
        }
        if (m == Mode.CROP && Proj.crop == null) { Proj.crop = new RectF(0, 0, 1, 1); overlay.cropAspect = 0f; }
        for (Mode k : order) styleBtn(k, k == m);
        refreshCtx();
        overlay.invalidate();
    }

    private void refreshCtx() {
        ctxRow.removeAllViews();
        thumbRow.setVisibility(mode == Mode.PHOTO ? View.VISIBLE : View.GONE);
        if (Proj.uri == null) { add(lab("Toque 📂 Abrir video para empezar")); return; }
        switch (mode) {
            case NONE:
                add(lab("Escoja una herramienta"));
                add(lab(Proj.w + " × " + Proj.h + " · " + fmt(Proj.durMs)));
                break;
            case CUT:
                add(chip("⏮ Inicio aquí", false, () -> {
                    Proj.trimStart = Math.max(0, Math.min(player.getCurrentPosition(), Proj.trimEnd - 100));
                    syncTimeline(); refreshCtx();
                }));
                add(chip("Fin aquí ⏭", false, () -> {
                    Proj.trimEnd = Math.min(Proj.durMs, Math.max(player.getCurrentPosition(), Proj.trimStart + 100));
                    syncTimeline(); refreshCtx();
                }));
                add(lab("Inicio " + fmt(Proj.trimStart) + " · Fin " + fmt(Proj.trimEnd) + " · Dura " + fmt(Proj.trimEnd - Proj.trimStart)));
                add(chip("↺ Todo", false, () -> { Proj.trimStart = 0; Proj.trimEnd = Proj.durMs; syncTimeline(); refreshCtx(); }));
                break;
            case SPEED:
                for (float s : new float[]{2f, 1f, 0.5f, 0.25f}) {
                    final float sp = s;
                    add(chip(speedName(s), Proj.speed == s, () -> {
                        Proj.speed = sp;
                        player.setPlaybackParameters(new PlaybackParameters(sp));
                        refreshCtx();
                    }));
                }
                add(lab("Así queda el video final"));
                break;
            case MUTE:
                add(chip(Proj.mute ? "🔇 Sin sonido" : "🔊 Con sonido", true, () -> {
                    Proj.mute = !Proj.mute;
                    player.setVolume(Proj.mute ? 0f : 1f);
                    refreshCtx();
                }));
                add(lab("Toque para cambiar"));
                break;
            case PHOTO:
                add(chip("◀ Atrás 1", false, () -> step(-1)));
                add(chip(player.isPlaying() ? "⏸ 0.25x" : "▶ 0.25x", false, this::togglePlay));
                add(chip("Adelante 1 ▶", false, () -> step(1)));
                add(chip("📷 Tomar", true, this::takePhoto));
                add(chip(photoCarta ? "📄 Carta: Sí" : "📄 Carta: No", false, () -> { photoCarta = !photoCarta; refreshCtx(); }));
                break;
            case SUBS: {
                add(chip("en".equals(Proj.lang) ? "Video en: Inglés" : "Video en: Español", false, () -> {
                    Proj.lang = "en".equals(Proj.lang) ? "es" : "en";
                    refreshCtx();
                }));
                add(chip(micActive ? "⏹ Parar" : (subsBusy ? "⏳ Trabajando…" : "✨ Hacer letreros"), true, () -> {
                    if (micActive) finishMic(); else makeSubs();
                }));
                add(chip("🎤 Por micrófono", false, this::startMicSubs));
                add(chip("✏️ Corregir", false, this::editSubs));
                String[] sm = {"👁 Ambos", "👁 Solo original", "🚫 Ocultos"};
                add(chip(sm[Proj.subsMode], false, () -> { Proj.subsMode = (Proj.subsMode + 1) % 3; refreshCtx(); }));
                add(lab(Proj.subs.size() + " letreros"));
                break;
            }
            case IMAGE: {
                final Proj.ImageLayer im = Proj.image;
                add(chip("🖼 Escoger foto", im == null, () -> pick(REQ_IMAGE, "image/*")));
                if (im != null) {
                    add(chip(im.noBg ? "✂ Sin fondo: Sí" : "✂ Sin fondo: No", false, this::toggleImageBg));
                    add(chip("⏮ Desde aquí", false, () -> {
                        im.startMs = player.getCurrentPosition();
                        if (im.endMs <= im.startMs + 200) im.endMs = Math.min(Proj.durMs, im.startMs + 5000);
                        marks(); refreshCtx();
                    }));
                    add(chip("Hasta aquí ⏭", false, () -> {
                        im.endMs = Math.max(player.getCurrentPosition(), im.startMs + 200);
                        marks(); refreshCtx();
                    }));
                    add(lab(fmt(im.startMs) + " → " + fmt(im.endMs)));
                    add(chip("🗑 Quitar", false, () -> { Proj.image = null; marks(); refreshCtx(); }));
                    add(lab("Mueva con un dedo · agrande con dos"));
                }
                break;
            }
            case CROP: {
                String[] names = {"Todo", "Libre", "1:1", "9:16", "16:9", "4:5"};
                float[] asp = {-1f, 0f, 1f, 9f / 16f, 16f / 9f, 0.8f};
                boolean fullC = isFullCrop();
                for (int i = 0; i < names.length; i++) {
                    final float a = asp[i];
                    boolean act = a < 0 ? fullC : (!fullC && overlay.cropAspect == a);
                    add(chip(names[i], act, () -> setCrop(a)));
                }
                add(lab(cropInfo()));
                break;
            }
            case BG: {
                add(chip(bgGreen ? "🟩 Tela verde" : "🤖 Automático", false, () -> {
                    bgGreen = !bgGreen;
                    Proj.Background bg = Proj.bg;
                    if (bg != null) bg.green = bgGreen;
                    invalidatePreview(); refreshCtx();
                }));
                add(chip("🖼 Foto", false, () -> pick(REQ_BG_IMG, "image/*")));
                add(chip("🎨 Color", false, this::pickColor));
                add(chip("🎬 Video", false, () -> pick(REQ_BG_VID, "video/*")));
                if (Proj.bg != null) {
                    add(chip("🗑 Quitar", false, () -> { Proj.bg = null; invalidatePreview(); refreshCtx(); }));
                    add(lab("Pause el video para ver el fondo exacto"));
                } else {
                    add(lab("Escoja qué poner detrás de la persona"));
                }
                break;
            }
            case LAYER: {
                final Proj.VideoLayer L = Proj.layer;
                add(chip("🎬 Escoger video", L == null, () -> pick(REQ_LAYER, "video/*")));
                add(chip(layerGreen ? "🟩 Tela verde" : "🤖 Automático", false, () -> {
                    layerGreen = !layerGreen;
                    Proj.VideoLayer l2 = Proj.layer;
                    if (l2 != null) { l2.green = layerGreen; makeLayerStill(); }
                    invalidatePreview(); refreshCtx();
                }));
                if (L != null) {
                    add(chip("⏮ Empieza aquí", false, () -> {
                        L.startMs = player.getCurrentPosition();
                        marks(); invalidatePreview(); refreshCtx();
                    }));
                    add(lab(fmt(L.startMs) + " → " + fmt(L.startMs + L.durMs)));
                    add(chip("🗑 Quitar", false, () -> {
                        Proj.layer = null;
                        overlay.layerStill = null;
                        overlay.layerCut = null;
                        marks(); refreshCtx();
                    }));
                    add(lab("Mueva la persona con el dedo"));
                }
                break;
            }
            case EXPORT:
                for (int q = 0; q < 3; q++) {
                    final int qq = q;
                    add(chip(qName(q) + " · ≈ " + estMb(q), q == 0, () -> export(qq)));
                }
                add(lab("Se guarda en Descargas/MiBarra/ChepeVideo"));
                break;
        }
    }

    private static String speedName(float s) {
        if (s == 2f) return "⚡ 2x";
        if (s == 1f) return "Normal";
        if (s == 0.5f) return "🐢 0.5x";
        return "🐌 0.25x";
    }

    private static String qName(int q) {
        return q == 0 ? "💾 Liviano (WhatsApp)" : q == 1 ? "Buena" : "Máxima";
    }

    private String estMb(int q) {
        double secs = (Proj.trimEnd - Proj.trimStart) / 1000.0 / Math.max(0.1, Proj.speed);
        int vb = q == 0 ? 1_200_000 : q == 1 ? 2_500_000 : 6_000_000;
        double mb = secs * (vb + (Proj.mute ? 0 : 128_000)) / 8.0 / 1_000_000.0;
        return String.format(Locale.US, "%.1f MB", mb);
    }

    private void syncTimeline() {
        timeline.durMs = Proj.durMs;
        timeline.startMs = Proj.trimStart;
        timeline.endMs = Proj.trimEnd;
        timeline.invalidate();
    }

    private void marks() {
        timeline.ranges.clear();
        Proj.VideoLayer L = Proj.layer;
        if (L != null) timeline.ranges.add(new long[]{L.startMs, L.startMs + L.durMs, 0xFFEF9F27});
        Proj.ImageLayer im = Proj.image;
        if (im != null) timeline.ranges.add(new long[]{im.startMs, im.endMs, 0xFFD4537E});
        timeline.invalidate();
    }

    private void togglePlay() {
        if (Proj.uri == null) { pick(REQ_VIDEO, "video/*"); return; }
        if (player.isPlaying()) { player.pause(); return; }
        long p = player.getCurrentPosition();
        if (p >= Proj.trimEnd - 60 || p < Proj.trimStart || player.getPlaybackState() == Player.STATE_ENDED)
            player.seekTo(Proj.trimStart);
        player.play();
    }

    private void onTick() {
        if (Proj.uri == null) return;
        long pos = player.getCurrentPosition();
        boolean playing = player.isPlaying();
        if (playing && !micActive) {
            if (pos >= Proj.trimEnd) { player.pause(); player.seekTo(Proj.trimStart); pos = Proj.trimStart; playing = false; }
            else if (pos < Proj.trimStart - 150) player.seekTo(Proj.trimStart);
        }
        if (micActive && (pos >= Proj.trimEnd || player.getPlaybackState() == Player.STATE_ENDED)) finishMic();
        timeline.setPos(pos);
        overlay.posMs = pos;
        overlay.playing = playing;
        overlay.invalidate();
        if (!playing) {
            maybePreview(pos);
            if (mode == Mode.PHOTO && pos != lastThumbPos) { lastThumbPos = pos; loadThumbs(pos); }
        }
    }

    // ------------------------------------------------------------ vista previa en pausa

    private void invalidatePreview() {
        overlay.compositeTime = -1;
        overlay.layerCutTime = -1;
        overlay.invalidate();
    }

    private void maybePreview(final long pos) {
        if (previewBusy) return;
        final boolean needBg = Proj.bg != null && overlay.compositeTime != pos;
        Proj.VideoLayer L = Proj.layer;
        final boolean needLayer = L != null && pos >= L.startMs && pos < L.startMs + L.durMs && overlay.layerCutTime != pos;
        if (!needBg && !needLayer) return;
        previewBusy = true;
        if (previewComp == null) previewComp = new Compositor(this, false);
        final Compositor comp = previewComp;
        float sc = Math.min(1f, 640f / Math.max(1, Math.max(Proj.w, Proj.h)));
        final int pw = Math.max(2, Math.round(Proj.w * sc)), ph = Math.max(2, Math.round(Proj.h * sc));
        exec.execute(() -> {
            Bitmap bgB = null, lc = null;
            if (needBg) try { bgB = comp.composeBg(pw, ph, pos); } catch (Throwable ignored) {}
            if (needLayer) try { lc = comp.layerCut(pos, 480); } catch (Throwable ignored) {}
            final Bitmap fb = bgB, fl = lc;
            ui.post(() -> {
                previewBusy = false;
                if (needBg) { overlay.composite = fb; overlay.compositeTime = pos; }
                if (needLayer) { overlay.layerCut = fl; overlay.layerCutTime = pos; }
                overlay.invalidate();
            });
        });
    }

    // ------------------------------------------------------------ abrir archivos

    private void pick(int req, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType(type);
            try { startActivityForResult(Intent.createChooser(g, "Escoger"), req); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        switch (req) {
            case REQ_VIDEO: loadVideo(u); break;
            case REQ_IMAGE: loadImageLayer(u); break;
            case REQ_LAYER: loadVideoLayer(u); break;
            case REQ_BG_IMG: loadBgImage(u); break;
            case REQ_BG_VID: loadBgVideo(u); break;
        }
    }

    private void loadVideo(final Uri u) {
        status("Abriendo video…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                if (micActive) finishMic();
                Proj.reset(u, fi);
                overlay.vw = fi.w;
                overlay.vh = fi.h;
                overlay.composite = null;
                overlay.layerCut = null;
                overlay.layerStill = null;
                invalidatePreview();
                player.setMediaItem(MediaItem.fromUri(u));
                player.prepare();
                player.setVolume(1f);
                player.setPlaybackParameters(new PlaybackParameters(1f));
                syncTimeline();
                marks();
                setMode(Mode.NONE);
                toast("Video listo · " + fmt(fi.durMs));
            });
        });
    }

    private void loadImageLayer(final Uri u) {
        status("✂ Quitando el fondo de la foto…");
        final long pos = player.getCurrentPosition();
        exec.execute(() -> {
            Bitmap orig = Seg.load(this, u, 1600);
            Bitmap cut = null;
            String note = null;
            if (orig != null) {
                try {
                    if (Seg.hasTransparency(orig)) {
                        cut = Seg.trim(orig);
                    } else {
                        if (imgSeg == null) imgSeg = new Seg(false);
                        Bitmap c = Seg.trim(imgSeg.cutout(orig, false));
                        if (c != null && (long) c.getWidth() * c.getHeight() > (long) orig.getWidth() * orig.getHeight() / 50) cut = c;
                        else note = "No encontré una persona en la foto: queda con fondo";
                    }
                } catch (Exception e) {
                    note = "No se pudo quitar el fondo: queda con fondo";
                }
            }
            final Bitmap fo = orig, fc = cut;
            final String fn = note;
            ui.post(() -> {
                status(null);
                if (fo == null) { toast("No pude abrir la foto"); return; }
                Proj.image = new Proj.ImageLayer(fc != null ? fc : fo, fo, fc != null, pos, Math.min(Proj.durMs, pos + 5000));
                if (fn != null) toast(fn);
                marks();
                refreshCtx();
            });
        });
    }

    private void toggleImageBg() {
        final Proj.ImageLayer im = Proj.image;
        if (im == null) return;
        if (im.noBg) { im.bmp = im.original; im.noBg = false; refreshCtx(); return; }
        status("✂ Quitando el fondo…");
        exec.execute(() -> {
            Bitmap c = null;
            try {
                if (imgSeg == null) imgSeg = new Seg(false);
                c = Seg.trim(imgSeg.cutout(im.original, false));
            } catch (Exception ignored) {}
            final Bitmap fc = c;
            ui.post(() -> {
                status(null);
                if (fc != null) { im.bmp = fc; im.noBg = true; } else toast("No se pudo quitar el fondo");
                refreshCtx();
            });
        });
    }

    private Bitmap stillOf(Uri u, boolean green) {
        MediaMetadataRetriever r = null;
        try {
            r = Frames.open(this, u);
            Bitmap f = Frames.grab(r, 0, 480, 480);
            if (f == null) return null;
            if (imgSeg == null) imgSeg = new Seg(false);
            return imgSeg.cutout(f, green);
        } catch (Exception e) {
            return null;
        } finally {
            if (r != null) try { r.release(); } catch (Exception ignored) {}
        }
    }

    private void loadVideoLayer(final Uri u) {
        status("👥 Preparando el video de encima…");
        final long pos = player.getCurrentPosition();
        final boolean g = layerGreen;
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Bitmap still = inf == null ? null : stillOf(u, g);
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0 || fi.w <= 0) { toast("No pude abrir ese video"); return; }
                long st = Math.max(0, Math.min(pos, Proj.durMs - 500));
                Proj.layer = new Proj.VideoLayer(u, fi.durMs, g, st, (float) fi.h / fi.w);
                overlay.layerStill = still;
                invalidatePreview();
                marks();
                refreshCtx();
            });
        });
    }

    private void makeLayerStill() {
        final Proj.VideoLayer L = Proj.layer;
        if (L == null) return;
        exec.execute(() -> {
            final Bitmap s = stillOf(L.uri, L.green);
            ui.post(() -> { overlay.layerStill = s; overlay.invalidate(); });
        });
    }

    private void loadBgImage(final Uri u) {
        status("🌄 Cargando el fondo…");
        exec.execute(() -> {
            final Bitmap b = Seg.load(this, u, 1920);
            ui.post(() -> {
                status(null);
                if (b == null) { toast("No pude abrir la foto"); return; }
                Proj.bg = new Proj.Background(1, 0, b, null, bgGreen, 0);
                invalidatePreview();
                refreshCtx();
            });
        });
    }

    private void loadBgVideo(final Uri u) {
        status("🌄 Cargando el video de fondo…");
        exec.execute(() -> {
            Frames.VInfo inf = null;
            try { inf = Frames.info(this, u); } catch (Exception ignored) {}
            final Frames.VInfo fi = inf;
            ui.post(() -> {
                status(null);
                if (fi == null || fi.durMs <= 0) { toast("No pude abrir ese video"); return; }
                Proj.bg = new Proj.Background(2, 0, null, u, bgGreen, fi.durMs);
                invalidatePreview();
                refreshCtx();
            });
        });
    }

    private void pickColor() {
        final String[] names = {"⬜ Blanco", "⬛ Negro", "🟩 Verde", "🟦 Azul", "🟥 Rojo", "🟨 Amarillo", "◻️ Gris", "🟫 Café"};
        final int[] cols = {Color.WHITE, Color.BLACK, 0xFF3B6D11, 0xFF185FA5, 0xFFA32D2D, 0xFFEF9F27, 0xFF888780, 0xFF633806};
        new AlertDialog.Builder(this).setTitle("Color de fondo").setItems(names, (d, i) -> {
            Proj.bg = new Proj.Background(0, cols[i], null, null, bgGreen, 0);
            invalidatePreview();
            refreshCtx();
        }).show();
    }

    // ------------------------------------------------------------ cuadro (recorte)

    private boolean isFullCrop() {
        RectF c = Proj.crop;
        return c == null || (c.left < 0.002f && c.top < 0.002f && c.right > 0.998f && c.bottom > 0.998f);
    }

    private void setCrop(float a) {
        if (a < 0f) {
            Proj.crop = new RectF(0, 0, 1, 1);
            overlay.cropAspect = 0f;
        } else {
            overlay.cropAspect = a;
            if (a > 0f) {
                float vw = Proj.w, vh = Proj.h;
                float w = vw, h = w / a;
                if (h > vh) { h = vh; w = h * a; }
                float nw = w / vw, nh = h / vh;
                Proj.crop = new RectF((1 - nw) / 2f, (1 - nh) / 2f, (1 + nw) / 2f, (1 + nh) / 2f);
            } else if (isFullCrop()) {
                Proj.crop = new RectF(0.1f, 0.1f, 0.9f, 0.9f);
            }
        }
        overlay.invalidate();
        refreshCtx();
    }

    private String cropInfo() {
        RectF c = Proj.crop;
        if (c == null) return "Video completo";
        return "Queda de " + Math.round(Proj.w * c.width()) + " × " + Math.round(Proj.h * c.height()) + " · arrastre las esquinas";
    }

    // ------------------------------------------------------------ foto cuadro a cuadro

    private void step(int n) {
        player.pause();
        float fms = 1000f / Math.max(1f, Proj.fps);
        long t = player.getCurrentPosition() + Math.round(n * fms);
        player.seekTo(Math.max(0, Math.min(Proj.durMs, t)));
    }

    private void loadThumbs(final long pos) {
        final Uri u = Proj.uri;
        final float fms = 1000f / Math.max(1f, Proj.fps);
        exec.execute(() -> {
            try {
                if (thumbRet == null || !u.equals(thumbUri)) {
                    if (thumbRet != null) try { thumbRet.release(); } catch (Exception ignored) {}
                    thumbRet = Frames.open(this, u);
                    thumbUri = u;
                }
                final Bitmap[] bs = new Bitmap[5];
                for (int i = 0; i < 5; i++) bs[i] = Frames.grab(thumbRet, pos + Math.round((i - 2) * fms), 200, 200);
                ui.post(() -> { for (int i = 0; i < 5; i++) thumbs[i].setImageBitmap(bs[i]); });
            } catch (Exception ignored) {}
        });
    }

    private void takePhoto() {
        final long pos = player.getCurrentPosition();
        final Uri u = Proj.uri;
        final boolean carta = photoCarta;
        status("📷 Guardando foto…");
        exec.execute(() -> {
            String msg;
            MediaMetadataRetriever r = null;
            try {
                r = Frames.open(this, u);
                Bitmap b = Frames.argb(r.getFrameAtTime(pos * 1000L, MediaMetadataRetriever.OPTION_CLOSEST));
                if (b == null) throw new Exception("no salió el cuadro");
                String name = "foto_" + stamp();
                Store.saveJpg(this, b, "Fotos", name + ".jpg");
                if (carta) Store.saveJpg(this, Seg.carta(b), "Fotos", name + "_carta.jpg");
                msg = "📷 Foto guardada en Descargas/MiBarra/ChepeVideo/Fotos";
            } catch (Exception e) {
                msg = "No se pudo sacar la foto: " + e.getMessage();
            } finally {
                if (r != null) try { r.release(); } catch (Exception ignored) {}
            }
            final String m2 = msg;
            ui.post(() -> { status(null); toast(m2); });
        });
    }

    // ------------------------------------------------------------ letreros

    private String langTag() { return "en".equals(Proj.lang) ? "en-US" : "es-CO"; }

    private void needMic(Runnable r) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) r.run();
        else {
            pendingMic = r;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_MIC) return;
        Runnable r = pendingMic;
        pendingMic = null;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && r != null) r.run();
        else toast("Sin permiso del micrófono no se pueden hacer los letreros");
    }

    private void makeSubs() {
        if (subsBusy) { toast("Ya estoy haciendo los letreros"); return; }
        if (Build.VERSION.SDK_INT >= 33) needMic(this::subsFromFile);
        else askMicMode("En este celular los letreros se hacen así: el video suena en voz alta y el celular lo escucha. Suba el volumen y no hable mientras tanto. ¿Empezamos?");
    }

    private void askMicMode(String msg) {
        new AlertDialog.Builder(this).setTitle("🎤 Letreros por micrófono").setMessage(msg)
                .setPositiveButton("Empezar", (d, w) -> startMicSubs())
                .setNegativeButton("Cancelar", null).show();
    }

    private void subsFromFile() {
        final Uri u = Proj.uri;
        final long s0 = Proj.trimStart, s1 = Math.min(Proj.trimEnd, Proj.trimStart + 15 * 60_000L);
        final String lang = langTag(), src = Proj.lang;
        subsBusy = true;
        status("💬 Escuchando el video…");
        refreshCtx();
        new Thread(() -> {
            String err = null, note = null;
            List<Proj.Sub> out = new ArrayList<>();
            try {
                short[] pcm = AudioPcm.decode16k(this, u, s0, s1);
                List<int[]> segs = AudioPcm.segments(pcm);
                int fails = 0;
                for (int i = 0; i < segs.size(); i++) {
                    final int n = i + 1, tot = segs.size();
                    ui.post(() -> status("💬 Letreros " + n + " de " + tot + "…"));
                    int[] sg = segs.get(i);
                    String r = Recog.fromPcm(this, ui, pcm, sg[0], sg[1], lang);
                    if (r == null) {
                        fails++;
                        if (out.isEmpty() && fails >= 2) { err = "mic"; break; }
                        continue;
                    }
                    if (!r.trim().isEmpty())
                        out.add(new Proj.Sub(s0 + sg[0] * 1000L / 16000L, s0 + sg[1] * 1000L / 16000L, r.trim(), ""));
                }
                if (err == null && out.isEmpty()) err = segs.isEmpty() ? "No escuché voces en el video" : "mic";
                if (err == null) {
                    ui.post(() -> status("🌐 Traduciendo…"));
                    try { translate(out, src); } catch (Exception e) { note = "Letreros listos, pero sin traducción (revise el internet)"; }
                }
            } catch (Exception e) {
                err = "No se pudieron hacer los letreros: " + e.getMessage();
            }
            final String fe = err, fn = note;
            final List<Proj.Sub> fo = out;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                if (fe == null) {
                    Proj.subs.clear();
                    Proj.subs.addAll(fo);
                    toast(fn != null ? fn : "💬 " + fo.size() + " letreros listos");
                } else if ("mic".equals(fe)) {
                    askMicMode("Este celular no deja leer el sonido directo del archivo. Lo hacemos por micrófono: el video suena y el celular escucha. Suba el volumen. ¿Empezamos?");
                } else {
                    toast(fe);
                }
                refreshCtx();
            });
        }).start();
    }

    /** Traduce (se llama desde un hilo de trabajo). */
    private void translate(List<Proj.Sub> list, String src) throws Exception {
        if (list.isEmpty()) return;
        boolean en = "en".equals(src);
        TranslatorOptions o = new TranslatorOptions.Builder()
                .setSourceLanguage(en ? TranslateLanguage.ENGLISH : TranslateLanguage.SPANISH)
                .setTargetLanguage(en ? TranslateLanguage.SPANISH : TranslateLanguage.ENGLISH)
                .build();
        Translator t = Translation.getClient(o);
        try {
            Tasks.await(t.downloadModelIfNeeded(), 180, TimeUnit.SECONDS);
            for (Proj.Sub s : list) {
                if (s.text == null || s.text.trim().isEmpty()) continue;
                s.trans = Tasks.await(t.translate(s.text), 30, TimeUnit.SECONDS);
            }
        } finally {
            t.close();
        }
    }

    private void startMicSubs() {
        needMic(() -> {
            if (micActive) return;
            if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Este celular no tiene reconocimiento de voz"); return; }
            Proj.subs.clear();
            micActive = true;
            player.setVolume(1f);
            player.setPlaybackParameters(new PlaybackParameters(1f));
            player.seekTo(Proj.trimStart);
            player.play();
            micRec = SpeechRecognizer.createSpeechRecognizer(this);
            micRec.setRecognitionListener(micListener);
            micListen();
            status("🎤 Escuchando… suba el volumen y no hable");
            if (mode != Mode.SUBS) setMode(Mode.SUBS); else refreshCtx();
        });
    }

    private void micListen() {
        if (!micActive || micRec == null) return;
        micSegStart = player.getCurrentPosition();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try { micRec.startListening(i); } catch (Exception e) { ui.postDelayed(this::micListen, 400); }
    }

    private final RecognitionListener micListener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle p) {}
        @Override public void onBeginningOfSpeech() { micSegStart = Math.max(Proj.trimStart, player.getCurrentPosition() - 300); }
        @Override public void onRmsChanged(float v) {}
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onError(int e) { if (micActive) ui.postDelayed(MainActivity.this::micListen, 250); }
        @Override public void onResults(Bundle b) {
            ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (l != null && !l.isEmpty() && l.get(0) != null && !l.get(0).trim().isEmpty()) {
                long end = player.getCurrentPosition();
                Proj.subs.add(new Proj.Sub(micSegStart, Math.max(end, micSegStart + 1200), l.get(0).trim(), ""));
                if (mode == Mode.SUBS) refreshCtx();
            }
            if (micActive) micListen();
        }
        @Override public void onPartialResults(Bundle b) {}
        @Override public void onEvent(int t, Bundle b) {}
    };

    private void finishMic() {
        if (!micActive) return;
        micActive = false;
        try { if (micRec != null) { micRec.cancel(); micRec.destroy(); } } catch (Exception ignored) {}
        micRec = null;
        player.pause();
        player.setVolume(Proj.mute ? 0f : 1f);
        player.setPlaybackParameters(new PlaybackParameters(mode == Mode.PHOTO ? 0.25f : Proj.speed));
        final List<Proj.Sub> list = new ArrayList<>(Proj.subs);
        final String src = Proj.lang;
        if (list.isEmpty()) { status(null); toast("No escuché voces. Suba el volumen e intente otra vez"); refreshCtx(); return; }
        status("🌐 Traduciendo…");
        subsBusy = true;
        refreshCtx();
        new Thread(() -> {
            String note = null;
            try { translate(list, src); } catch (Exception e) { note = "Letreros listos, pero sin traducción (revise el internet)"; }
            final String fn = note;
            ui.post(() -> {
                subsBusy = false;
                status(null);
                toast(fn != null ? fn : "💬 " + list.size() + " letreros listos");
                refreshCtx();
            });
        }).start();
    }

    private void editSubs() {
        final long pos = player.getCurrentPosition();
        final LinearLayout box = vbox();
        box.setPadding(dp(14), dp(6), dp(14), dp(6));
        final List<Object[]> rows = new ArrayList<>();
        TextView addB = chip("➕ Agregar letrero en " + fmt(pos), false, null);
        box.addView(addB);
        if (Proj.subs.isEmpty()) box.addView(tv("Todavía no hay letreros. Use ✨ Hacer letreros o agregue uno aquí.", 14, Color.BLACK, false));
        for (Proj.Sub s : Proj.subs) addSubRow(box, rows, s);
        addB.setOnClickListener(v -> addSubRow(box, rows, new Proj.Sub(pos, pos + 3000, "", "")));
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this).setTitle("✏️ Corregir letreros").setView(sv)
                .setPositiveButton("Guardar", (d, w) -> applySubRows(rows, false))
                .setNeutralButton("Guardar y traducir", (d, w) -> applySubRows(rows, true))
                .setNegativeButton("Cancelar", null).show();
    }

    private void addSubRow(LinearLayout box, List<Object[]> rows, Proj.Sub s) {
        TextView t = tv("⏱ " + fmt(s.startMs) + " – " + fmt(s.endMs), 13, TEAL_T, true);
        t.setPadding(0, dp(10), 0, 0);
        EditText e1 = new EditText(this);
        e1.setText(s.text);
        e1.setTextColor(Color.BLACK);
        e1.setTextSize(16);
        e1.setHint("Lo que se dice");
        EditText e2 = new EditText(this);
        e2.setText(s.trans);
        e2.setTextColor(AMB_T);
        e2.setTextSize(16);
        e2.setHint("Traducción");
        box.addView(t);
        box.addView(e1);
        box.addView(e2);
        rows.add(new Object[]{s, e1, e2});
    }

    private void applySubRows(List<Object[]> rows, boolean retranslate) {
        final List<Proj.Sub> list = new ArrayList<>();
        for (Object[] r : rows) {
            Proj.Sub s = (Proj.Sub) r[0];
            s.text = ((EditText) r[1]).getText().toString().trim();
            s.trans = ((EditText) r[2]).getText().toString().trim();
            if (!s.text.isEmpty() || !s.trans.isEmpty()) list.add(s);
        }
        Collections.sort(list, (a, b) -> Long.compare(a.startMs, b.startMs));
        Proj.subs.clear();
        Proj.subs.addAll(list);
        refreshCtx();
        if (!retranslate) return;
        final String src = Proj.lang;
        status("🌐 Traduciendo…");
        new Thread(() -> {
            String note = null;
            try { translate(list, src); } catch (Exception e) { note = "No se pudo traducir (revise el internet)"; }
            final String fn = note;
            ui.post(() -> { status(null); toast(fn != null ? fn : "Traducción lista"); refreshCtx(); });
        }).start();
    }

    // ------------------------------------------------------------ guardar MP4

    private void export(int q) {
        if (exporting) { toast("Ya estoy guardando, espere"); return; }
        final Uri u = Proj.uri;
        if (u == null) return;
        if (micActive) finishMic();
        player.pause();
        RectF crop = isFullCrop() ? null : Proj.crop;
        int srcW = Proj.w, srcH = Proj.h;
        float cw = srcW * (crop != null ? crop.width() : 1f), ch = srcH * (crop != null ? crop.height() : 1f);
        int target = q == 0 ? 480 : q == 1 ? 720 : 1080;
        int bitrate = q == 0 ? 1_200_000 : q == 1 ? 2_500_000 : 6_000_000;
        float sc = Math.min(1f, target / Math.max(1f, Math.min(cw, ch)));
        int outW = even(Math.round(cw * sc)), outH = even(Math.round(ch * sc));

        MediaItem item = new MediaItem.Builder().setUri(u)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(Proj.trimStart).setEndPositionMs(Proj.trimEnd).build())
                .build();
        List<Effect> fx = new ArrayList<>();
        boolean subsOn = !Proj.subs.isEmpty() && Proj.subsMode != 2;
        boolean dynamic = Proj.bg != null || Proj.layer != null;
        final ExportOverlay ov = (dynamic || Proj.image != null || subsOn)
                ? new ExportOverlay(this, srcW, srcH, Proj.trimStart, dynamic) : null;
        if (ov != null) fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(ov)));
        if (crop != null) fx.add(new Crop(crop.left * 2f - 1f, crop.right * 2f - 1f, 1f - crop.bottom * 2f, 1f - crop.top * 2f));
        if (Proj.speed != 1f) fx.add(new SpeedChangeEffect(Proj.speed));
        fx.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT));
        List<AudioProcessor> ap = new ArrayList<>();
        if (Proj.speed != 1f && !Proj.mute) {
            SonicAudioProcessor son = new SonicAudioProcessor();
            son.setSpeed(Proj.speed);
            ap.add(son);
        }
        EditedMediaItem edited = new EditedMediaItem.Builder(item)
                .setRemoveAudio(Proj.mute)
                .setEffects(new Effects(ap, fx))
                .build();

        final File out = new File(getCacheDir(), "chepe_export.mp4");
        if (out.exists()) out.delete();
        final Transformer tr;
        try {
            tr = new Transformer.Builder(this)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(new DefaultEncoderFactory.Builder(this)
                            .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                            .setEnableFallback(true)
                            .build())
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition c, ExportResult r) { exportDone(out, null, ov); }
                        @Override public void onError(Composition c, ExportResult r, ExportException e) { exportDone(out, e, ov); }
                    })
                    .build();
        } catch (Exception e) {
            if (ov != null) new Thread(ov::release).start();
            toast("No se pudo empezar: " + e.getMessage());
            return;
        }
        exporting = true;
        status("💾 Guardando… 0 %");
        try {
            tr.start(edited, out.getAbsolutePath());
        } catch (Exception e) {
            exportDone(out, e, ov);
            return;
        }
        final ProgressHolder ph = new ProgressHolder();
        ui.post(new Runnable() {
            @Override public void run() {
                if (!exporting) return;
                try {
                    if (tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) status("💾 Guardando… " + ph.progress + " %");
                } catch (Exception ignored) {}
                ui.postDelayed(this, 500);
            }
        });
    }

    private void exportDone(final File out, Exception e, ExportOverlay ov) {
        if (!exporting) return;
        exporting = false;
        if (ov != null) new Thread(ov::release).start();
        if (e != null) {
            status(null);
            String code = (e instanceof ExportException) ? ((ExportException) e).getErrorCodeName() : String.valueOf(e.getMessage());
            new AlertDialog.Builder(this).setTitle("No se pudo guardar")
                    .setMessage("Error: " + code + "\n\nMándeme un pantallazo de este letrero para arreglarlo.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        status("💾 Pasando a Descargas…");
        final String name = "ChepeVideo_" + stamp() + ".mp4";
        exec.execute(() -> {
            Uri saved = null;
            String err = null;
            try { saved = Store.saveFile(this, out, "", name, "video/mp4"); } catch (Exception ex) { err = ex.getMessage(); }
            final long size = out.length();
            out.delete();
            final Uri fs = saved;
            final String fe = err;
            ui.post(() -> {
                status(null);
                if (fs == null) { toast("No se pudo pasar a Descargas: " + fe); return; }
                showSaved(fs, name, size);
            });
        });
    }

    private void showSaved(final Uri u, String name, long size) {
        String mb = String.format(Locale.US, "%.1f MB", size / 1_000_000.0);
        new AlertDialog.Builder(this).setTitle("✅ Video listo")
                .setMessage("Quedó en Descargas/MiBarra/ChepeVideo\n\n" + name + "\nPesa " + mb)
                .setPositiveButton("📤 Compartir", (d, w) -> {
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType("video/mp4");
                    s.putExtra(Intent.EXTRA_STREAM, u);
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(s, "Compartir video")); } catch (Exception ignored) {}
                })
                .setNeutralButton("▶ Ver", (d, w) -> {
                    Intent v = new Intent(Intent.ACTION_VIEW);
                    v.setDataAndType(u, "video/mp4");
                    v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(v); } catch (Exception ignored) {}
                })
                .setNegativeButton("OK", null).show();
    }
}
