package co.jose.chepevideo;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Saca el sonido del video (16 kHz, mono) y lo parte donde hay pausas. */
public final class AudioPcm {

    public static short[] decode16k(Context ctx, Uri uri, long startMs, long endMs) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(ctx, uri, null);
        int ti = -1;
        MediaFormat fmt = null;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat f = ex.getTrackFormat(i);
            String m = f.getString(MediaFormat.KEY_MIME);
            if (m != null && m.startsWith("audio/")) { ti = i; fmt = f; break; }
        }
        if (ti < 0) { ex.release(); throw new Exception("el video no tiene sonido"); }
        ex.selectTrack(ti);
        ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        String mime = fmt.getString(MediaFormat.KEY_MIME);
        MediaCodec codec = MediaCodec.createDecoderByType(mime);
        codec.configure(fmt, null, null, 0);
        codec.start();
        int sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        int ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
        boolean isFloat = false;
        long startUs = startMs * 1000L, endUs = endMs * 1000L;
        float[] mono = new float[1 << 20];
        int n = 0;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inDone = false, outDone = false;
        int idle = 0;
        try {
            while (!outDone && idle < 500) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer buf = codec.getInputBuffer(ii);
                        int sz = buf == null ? -1 : ex.readSampleData(buf, 0);
                        if (sz < 0 || ex.getSampleTime() > endUs) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (of.containsKey(MediaFormat.KEY_PCM_ENCODING))
                        isFloat = of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT;
                } else if (oi >= 0) {
                    idle = 0;
                    if (info.size > 0 && info.presentationTimeUs >= startUs && info.presentationTimeUs <= endUs) {
                        ByteBuffer ob = codec.getOutputBuffer(oi);
                        if (ob != null) {
                            ob.position(info.offset);
                            ob.limit(info.offset + info.size);
                            ob = ob.slice().order(ByteOrder.nativeOrder());
                            int cc = Math.max(1, ch);
                            if (isFloat) {
                                FloatBuffer fb = ob.asFloatBuffer();
                                int frames = fb.remaining() / cc;
                                if (n + frames > mono.length) mono = Arrays.copyOf(mono, Math.max(mono.length * 2, n + frames));
                                for (int f = 0; f < frames; f++) {
                                    float s = 0;
                                    for (int k = 0; k < cc; k++) s += fb.get();
                                    mono[n++] = s / cc;
                                }
                            } else {
                                ShortBuffer sb = ob.asShortBuffer();
                                int frames = sb.remaining() / cc;
                                if (n + frames > mono.length) mono = Arrays.copyOf(mono, Math.max(mono.length * 2, n + frames));
                                for (int f = 0; f < frames; f++) {
                                    float s = 0;
                                    for (int k = 0; k < cc; k++) s += sb.get() / 32768f;
                                    mono[n++] = s / cc;
                                }
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                } else if (inDone) {
                    idle++;
                }
            }
        } finally {
            try { codec.stop(); } catch (Exception ignored) {}
            try { codec.release(); } catch (Exception ignored) {}
            try { ex.release(); } catch (Exception ignored) {}
        }
        if (n == 0) return new short[0];
        int outLen = (int) ((long) n * 16000L / Math.max(1, sr));
        short[] out = new short[outLen];
        double ratio = sr / 16000.0;
        for (int i = 0; i < outLen; i++) {
            double p = i * ratio;
            int i0 = (int) p;
            float fr = (float) (p - i0);
            float a = mono[Math.min(i0, n - 1)], b = mono[Math.min(i0 + 1, n - 1)];
            float v = a + (b - a) * fr;
            if (v > 1f) v = 1f; else if (v < -1f) v = -1f;
            out[i] = (short) (v * 32767f);
        }
        return out;
    }

    /** Pedazos de habla: {desde, hasta} en muestras. Máximo 8 s cada uno. */
    public static List<int[]> segments(short[] pcm) {
        List<int[]> res = new ArrayList<>();
        int fr = 320; // 20 ms
        int nf = pcm.length / fr;
        if (nf < 10) return res;
        float[] e = new float[nf];
        for (int i = 0; i < nf; i++) {
            double s = 0;
            for (int j = 0; j < fr; j++) { double v = pcm[i * fr + j]; s += v * v; }
            e[i] = (float) Math.sqrt(s / fr);
        }
        float[] sorted = e.clone();
        Arrays.sort(sorted);
        float noise = sorted[(int) (nf * 0.2f)];
        float loud = sorted[Math.min(nf - 1, (int) (nf * 0.9f))];
        float th = Math.max(Math.max(noise * 2f, noise + (loud - noise) * 0.15f), 200f);
        int st = -1, silence = 0;
        for (int i = 0; i < nf; i++) {
            boolean sp = e[i] > th;
            if (sp) { if (st < 0) st = i; silence = 0; }
            else if (st >= 0) silence++;
            if (st >= 0) {
                int len = i - st;
                if (silence >= 25 || len >= 400 || i == nf - 1) {
                    int en = i - silence + 1;
                    if (en - st >= 15) res.add(new int[]{Math.max(0, st - 10) * fr, Math.min(nf, en + 10) * fr});
                    st = -1;
                    silence = 0;
                }
            }
        }
        return res;
    }

    private AudioPcm() {}
}
