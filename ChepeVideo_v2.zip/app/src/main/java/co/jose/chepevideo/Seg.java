package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;

import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

/** Quitar el fondo: automático (persona) o tela verde. También utilidades de fotos. */
public final class Seg {

    private final Segmenter client;

    public Seg(boolean stream) {
        client = Segmentation.getClient(new SelfieSegmenterOptions.Builder()
                .setDetectorMode(stream ? SelfieSegmenterOptions.STREAM_MODE : SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build());
    }

    /** Devuelve la misma imagen con el fondo transparente. */
    public Bitmap cutout(Bitmap src0, boolean green) throws Exception {
        Bitmap src = Frames.argb(src0);
        if (green) return chroma(src);
        int sw = src.getWidth(), sh = src.getHeight();
        float sc = Math.min(1f, 512f / Math.max(sw, sh));
        Bitmap small = sc < 1f
                ? Bitmap.createScaledBitmap(src, Math.max(1, Math.round(sw * sc)), Math.max(1, Math.round(sh * sc)), true)
                : src;
        SegmentationMask mask = Tasks.await(client.process(InputImage.fromBitmap(small, 0)), 15, TimeUnit.SECONDS);
        int mw = mask.getWidth(), mh = mask.getHeight();
        ByteBuffer buf = mask.getBuffer();
        buf.rewind();
        float[] conf = new float[mw * mh];
        buf.asFloatBuffer().get(conf);

        int[] px = new int[sw * sh];
        src.getPixels(px, 0, sw, 0, 0, sw, sh);
        int[] xi = new int[sw];
        for (int x = 0; x < sw; x++) xi[x] = Math.min(mw - 1, (int) ((long) x * mw / sw));
        for (int y = 0; y < sh; y++) {
            int my = Math.min(mh - 1, (int) ((long) y * mh / sh)) * mw;
            int row = y * sw;
            for (int x = 0; x < sw; x++) {
                float a = (conf[my + xi[x]] - 0.35f) / 0.4f;
                if (a < 0f) a = 0f; else if (a > 1f) a = 1f;
                int ai = (int) (a * 255f);
                int i = row + x;
                px[i] = (ai << 24) | (px[i] & 0x00FFFFFF);
            }
        }
        return Bitmap.createBitmap(px, sw, sh, Bitmap.Config.ARGB_8888);
    }

    /** Tela verde: lo verde se vuelve transparente y se le quita el reflejo verde al borde. */
    public static Bitmap chroma(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int m = Math.max(r, b);
            int d = g - m;
            if (g > 70 && d > 25) {
                int a = 255 - (d - 25) * 6;
                if (a < 0) a = 0;
                px[i] = (a << 24) | (r << 16) | (m << 8) | b;
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
    }

    public void close() {
        try { client.close(); } catch (Exception ignored) {}
    }

    // ---------- utilidades de fotos ----------

    public static Bitmap load(Context ctx, Uri uri, final int maxSide) {
        try {
            ImageDecoder.Source s = ImageDecoder.createSource(ctx.getContentResolver(), uri);
            Bitmap b = ImageDecoder.decodeBitmap(s, (dec, info, src) -> {
                dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                float sc = Math.min(1f, (float) maxSide / Math.max(w, h));
                if (sc < 1f) dec.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc)));
            });
            return Frames.argb(b);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean hasTransparency(Bitmap b) {
        if (!b.hasAlpha()) return false;
        int w = b.getWidth(), h = b.getHeight(), n = 0, t = 0;
        for (int y = 0; y < h; y += Math.max(1, h / 40))
            for (int x = 0; x < w; x += Math.max(1, w / 40)) {
                n++;
                if (Color.alpha(b.getPixel(x, y)) < 200) t++;
            }
        return n > 0 && t * 50 > n;
    }

    /** Recorta lo transparente que sobra alrededor. Devuelve null si no queda nada. */
    public static Bitmap trim(Bitmap b) {
        if (b == null) return null;
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int l = w, t = h, r = -1, bo = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if ((px[row + x] >>> 24) > 20) {
                    if (x < l) l = x;
                    if (x > r) r = x;
                    if (y < t) t = y;
                    if (y > bo) bo = y;
                }
            }
        }
        if (r < 0) return null;
        int pad = 4;
        l = Math.max(0, l - pad); t = Math.max(0, t - pad);
        r = Math.min(w - 1, r + pad); bo = Math.min(h - 1, bo + pad);
        return Bitmap.createBitmap(b, l, t, r - l + 1, bo - t + 1);
    }

    /** Pone la foto en una hoja carta (300 ppp) con margen blanco. */
    public static Bitmap carta(Bitmap src) {
        boolean land = src.getWidth() > src.getHeight();
        int W = land ? 3300 : 2550, H = land ? 2550 : 3300;
        Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(Color.WHITE);
        float m = 120f;
        float s = Math.min((W - 2 * m) / src.getWidth(), (H - 2 * m) / src.getHeight());
        float dw = src.getWidth() * s, dh = src.getHeight() * s;
        c.drawBitmap(src, null, new RectF((W - dw) / 2f, (H - dh) / 2f, (W + dw) / 2f, (H + dh) / 2f),
                new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return out;
    }
}
