package co.jose.chepevideo;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Reconoce lo que se dice en un pedazo de sonido (Android 13 o más nuevo, con internet). */
public final class Recog {

    private static final class Waiter implements RecognitionListener {
        final CountDownLatch latch = new CountDownLatch(1);
        volatile String result = null;
        volatile boolean finished = false;

        void finish(String r) {
            if (finished) return;
            finished = true;
            result = r;
            latch.countDown();
        }

        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onError(int error) {
            finish(error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "" : null);
        }
        @Override public void onResults(Bundle b) {
            ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            finish(l != null && !l.isEmpty() && l.get(0) != null ? l.get(0) : "");
        }
        @Override public void onPartialResults(Bundle partialResults) {}
        @Override public void onEvent(int eventType, Bundle params) {}
    }

    /** Se llama desde un hilo de trabajo. null = el celular no lo permite; "" = no se escuchó nada. */
    public static String fromPcm(final Context ctx, Handler main, final short[] pcm, final int from, final int to, final String lang) {
        final ParcelFileDescriptor[] pipe;
        try { pipe = ParcelFileDescriptor.createPipe(); } catch (Exception e) { return null; }
        final Waiter w = new Waiter();
        final SpeechRecognizer[] holder = new SpeechRecognizer[1];
        main.post(() -> {
            try {
                SpeechRecognizer rec = SpeechRecognizer.createSpeechRecognizer(ctx);
                holder[0] = rec;
                rec.setRecognitionListener(w);
                Intent it = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                it.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                it.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                it.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0]);
                it.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1);
                it.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
                it.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16000);
                rec.startListening(it);
                new Thread(() -> {
                    try (OutputStream os = new ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])) {
                        int len = Math.max(0, to - from);
                        ByteBuffer bb = ByteBuffer.allocate(len * 2).order(ByteOrder.LITTLE_ENDIAN);
                        for (int i = from; i < to; i++) bb.putShort(pcm[i]);
                        os.write(bb.array());
                        os.write(new byte[32000]); // 1 s de silencio para que sepa que terminó
                    } catch (Exception ignored) {}
                }).start();
            } catch (Exception e) {
                w.finish(null);
            }
        });
        try { w.latch.await(30, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        main.post(() -> {
            SpeechRecognizer r = holder[0];
            if (r != null) {
                try { r.cancel(); } catch (Exception ignored) {}
                try { r.destroy(); } catch (Exception ignored) {}
            }
        });
        try { pipe[0].close(); } catch (Exception ignored) {}
        return w.result;
    }

    private Recog() {}
}
