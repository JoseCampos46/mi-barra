package co.jose.chepevideo;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * Marco del video con zoom de dos dedos: abrir los dedos acerca, cerrarlos aleja,
 * moverlos juntos desplaza la imagen. Solo cambia lo que se ve en pantalla, no el video que se guarda.
 * Doble toque o el letrero de arriba devuelven al tamaño normal.
 */
public class ZoomFrame extends FrameLayout {

    public interface Gate { boolean overlayWantsPinch(); }

    public final FrameLayout box;
    public Gate gate;
    private final TextView badge;
    private float z = 1f, tx, ty;
    private boolean pinching;
    private float z0, span0, px0, py0;

    public ZoomFrame(Context c) {
        super(c);
        float dp = c.getResources().getDisplayMetrics().density;
        setBackgroundColor(Color.BLACK);
        setClipChildren(true);
        box = new FrameLayout(c);
        box.setPivotX(0);
        box.setPivotY(0);
        addView(box, new LayoutParams(-1, -1));
        badge = new TextView(c);
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(13);
        badge.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        badge.setBackgroundColor(0xCC085041);
        int p = (int) (6 * dp);
        badge.setPadding(p + p / 2, p / 2, p + p / 2, p / 2);
        badge.setVisibility(GONE);
        badge.setOnClickListener(v -> reset());
        LayoutParams bl = new LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        bl.topMargin = (int) (8 * dp);
        addView(badge, bl);
    }

    public boolean zoomed() { return z > 1.01f; }

    public void reset() {
        z = 1f; tx = 0; ty = 0;
        apply();
    }

    private static float span(MotionEvent e) {
        float dx = e.getX(0) - e.getX(1), dy = e.getY(0) - e.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float fx(MotionEvent e) { return (e.getX(0) + e.getX(1)) / 2f; }

    private static float fy(MotionEvent e) { return (e.getY(0) + e.getY(1)) / 2f; }

    private void start(MotionEvent e) {
        pinching = true;
        z0 = z;
        span0 = Math.max(1f, span(e));
        px0 = (fx(e) - tx) / z;
        py0 = (fy(e) - ty) / z;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() == 2
                && (gate == null || !gate.overlayWantsPinch())) {
            start(e);
            getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) start(e);
                break;
            case MotionEvent.ACTION_MOVE:
                if (pinching && e.getPointerCount() >= 2) {
                    z = Math.max(1f, Math.min(8f, z0 * span(e) / span0));
                    tx = fx(e) - z * px0;
                    ty = fy(e) - z * py0;
                    apply();
                }
                break;
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pinching = false;
                break;
        }
        return true;
    }

    private void apply() {
        float w = getWidth(), h = getHeight();
        if (z <= 1.01f) { z = 1f; tx = 0; ty = 0; }
        tx = Math.max(w - z * w, Math.min(0, tx));
        ty = Math.max(h - z * h, Math.min(0, ty));
        box.setScaleX(z);
        box.setScaleY(z);
        box.setTranslationX(tx);
        box.setTranslationY(ty);
        if (zoomed()) {
            badge.setText(String.format(Locale.US, "🔍 x%.1f   ✕ tamaño normal", z));
            badge.setVisibility(VISIBLE);
        } else {
            badge.setVisibility(GONE);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        post(this::apply);
    }
}
