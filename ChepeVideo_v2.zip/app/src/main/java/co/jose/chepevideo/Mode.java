package co.jose.chepevideo;

public enum Mode { NONE, CUT, SPEED, MUTE, PHOTO, SUBS, IMAGE, CROP, BG, LAYER, EXPORT }
