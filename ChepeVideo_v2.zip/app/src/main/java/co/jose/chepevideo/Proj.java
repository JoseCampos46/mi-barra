package co.jose.chepevideo;

import android.graphics.Bitmap;
import android.graphics.RectF;
import android.net.Uri;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Todo lo que el usuario va armando sobre el video. */
public final class Proj {

    public static final class Sub {
        public long startMs, endMs;
        public volatile String text, trans;
        public Sub(long s, long e, String t, String tr) { startMs = s; endMs = e; text = t; trans = tr; }
    }

    public static final class ImageLayer {
        public volatile Bitmap bmp;
        public final Bitmap original;
        public volatile boolean noBg;
        public volatile long startMs, endMs;
        public volatile float cx = 0.5f, cy = 0.55f, scale = 0.4f;
        public ImageLayer(Bitmap b, Bitmap orig, boolean nb, long s, long e) { bmp = b; original = orig; noBg = nb; startMs = s; endMs = e; }
    }

    public static final class VideoLayer {
        public final Uri uri;
        public final long durMs;
        public final float aspect; // alto / ancho
        public volatile boolean green;
        public volatile long startMs;
        public volatile float cx = 0.72f, cy = 0.62f, scale = 0.45f;
        public VideoLayer(Uri u, long d, boolean g, long s, float a) { uri = u; durMs = d; green = g; startMs = s; aspect = a; }
    }

    /** type: 0 color, 1 foto, 2 video */
    public static final class Background {
        public final int type, color;
        public final Bitmap bmp;
        public final Uri uri;
        public final long durMs;
        public volatile boolean green;
        public Background(int t, int c, Bitmap b, Uri u, boolean g, long d) { type = t; color = c; bmp = b; uri = u; green = g; durMs = d; }
    }

    public static volatile Uri uri;
    public static volatile long durMs;
    public static volatile int w, h;
    public static volatile float fps = 30f;
    public static volatile long trimStart, trimEnd;
    public static volatile float speed = 1f;
    public static volatile boolean mute;
    public static volatile RectF crop;
    public static final List<Sub> subs = new CopyOnWriteArrayList<>();
    public static volatile int subsMode; // 0 ambos, 1 solo original, 2 ocultos
    public static volatile String lang = "en";
    public static volatile ImageLayer image;
    public static volatile VideoLayer layer;
    public static volatile Background bg;

    public static void reset(Uri u, Frames.VInfo i) {
        uri = u; durMs = i.durMs; w = i.w; h = i.h; fps = i.fps;
        trimStart = 0; trimEnd = i.durMs; speed = 1f; mute = false; crop = null;
        subs.clear(); image = null; layer = null; bg = null;
    }

    private Proj() {}
}
