package co.jose.chepevideo;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Guarda en Descargas/MiBarra/ChepeVideo (si la carpeta no existe, se crea sola). */
public final class Store {

    public static final String BASE = "MiBarra/ChepeVideo";

    public static Uri saveFile(Context ctx, File src, String sub, String name, String mime) throws Exception {
        try (InputStream in = new FileInputStream(src)) {
            return save(ctx, in, sub, name, mime);
        }
    }

    public static Uri saveJpg(Context ctx, Bitmap b, String sub, String name) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 95, bo);
        return save(ctx, new ByteArrayInputStream(bo.toByteArray()), sub, name, "image/jpeg");
    }

    private static Uri save(Context ctx, InputStream in, String sub, String name, String mime) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/" + BASE + (sub.isEmpty() ? "" : "/" + sub));
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        ContentResolver cr = ctx.getContentResolver();
        Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("no se pudo crear el archivo");
        try (OutputStream os = cr.openOutputStream(u)) {
            if (os == null) throw new IOException("no se pudo escribir");
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
        v.clear();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(u, v, null, null);
        return u;
    }

    private Store() {}
}
