package co.jose.chepevideo;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import java.util.ArrayList;
import java.util.List;

/** Dibuja los letreros: arriba lo que se dice, abajo la traducción. */
public final class SubPainter {

    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgp = new Paint(Paint.ANTI_ALIAS_FLAG);

    public SubPainter() {
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        bgp.setColor(0xAA000000);
    }

    public static Proj.Sub at(long t) {
        for (Proj.Sub s : Proj.subs) if (t >= s.startMs && t < s.endMs) return s;
        return null;
    }

    public void draw(Canvas c, float left, float top, float W, float H, long t) {
        int mode = Proj.subsMode;
        if (mode == 2 || W < 10 || H < 10) return;
        Proj.Sub s = at(t);
        if (s == null) return;
        float size = Math.min(W, H) * 0.055f;
        tp.setTextSize(size);
        List<String> txt = new ArrayList<>();
        List<Integer> col = new ArrayList<>();
        String a = s.text, b = s.trans;
        if (a != null && !a.trim().isEmpty()) { txt.add(a.trim()); col.add(0xFFFFFFFF); }
        if (mode == 0 && b != null && !b.trim().isEmpty()) { txt.add(b.trim()); col.add(0xFFFAC775); }
        float y = top + H - size * 0.5f;
        int maxW = Math.max(50, (int) (W * 0.92f));
        for (int i = txt.size() - 1; i >= 0; i--) {
            String one = txt.get(i);
            tp.setColor(col.get(i));
            StaticLayout lay = StaticLayout.Builder.obtain(one, 0, one.length(), tp, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).build();
            float lh = lay.getHeight();
            y -= lh;
            float lw = 0;
            for (int k = 0; k < lay.getLineCount(); k++) lw = Math.max(lw, lay.getLineWidth(k));
            float cx = left + W / 2f;
            c.drawRoundRect(cx - lw / 2f - size * 0.3f, y - size * 0.12f, cx + lw / 2f + size * 0.3f,
                    y + lh + size * 0.12f, size * 0.25f, size * 0.25f, bgp);
            c.save();
            c.translate(left + (W - maxW) / 2f, y);
            lay.draw(c);
            c.restore();
            y -= size * 0.3f;
        }
    }
}
