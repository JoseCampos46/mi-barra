package co.jose.mibarra;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Grabadora de conversaciones: botón rojo, contador, rayita de señal y lista numerada. */
public class GrabadoraActivity extends Base {

    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView boton, tiempo, estado;
    private View nivel;
    private LinearLayout lista;
    private Switch lejos;
    private Runnable tic;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        List<String> p = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 1);

        LinearLayout l = vertical();
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        tiempo = new TextView(this);
        tiempo.setTextSize(64);
        tiempo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tiempo.setTextColor(Color.BLACK);
        tiempo.setGravity(Gravity.CENTER);
        l.addView(tiempo);
        estado = new TextView(this);
        estado.setTextSize(18);
        estado.setGravity(Gravity.CENTER);
        l.addView(estado);

        LinearLayout barra = new LinearLayout(this);
        GradientDrawable fb = new GradientDrawable();
        fb.setColor(0xFFE0E0E0);
        fb.setCornerRadius(dp(8));
        barra.setBackground(fb);
        nivel = new View(this);
        GradientDrawable fn = new GradientDrawable();
        fn.setColor(0xFF2E7D32);
        fn.setCornerRadius(dp(8));
        nivel.setBackground(fn);
        barra.addView(nivel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18));
        bp.setMargins(dp(20), dp(10), dp(20), dp(4));
        l.addView(barra, bp);
        TextView ayuda = new TextView(this);
        ayuda.setText("Si la rayita se mueve poco, acerque el celular a quien habla");
        ayuda.setTextSize(13);
        ayuda.setTextColor(0xFF78909C);
        l.addView(ayuda);

        boton = new TextView(this);
        boton.setGravity(Gravity.CENTER);
        boton.setTextSize(26);
        boton.setTextColor(Color.WHITE);
        boton.setTypeface(Typeface.DEFAULT_BOLD);
        boton.setOnClickListener(v -> alternar());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(dp(190), dp(190));
        op.topMargin = dp(18);
        l.addView(boton, op);

        lejos = new Switch(this);
        lejos.setText("  Modo lejos (sube el micrófono para voces lejanas o con ruido)");
        lejos.setTextSize(15);
        lejos.setChecked(getSharedPreferences("barra", MODE_PRIVATE).getBoolean("grabLejos", false));
        lejos.setOnCheckedChangeListener((c, v) -> getSharedPreferences("barra", MODE_PRIVATE).edit().putBoolean("grabLejos", v).apply());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(16);
        l.addView(lejos, sp);

        TextView tl = titulo("\nMis grabaciones");
        tl.setTextSize(19);
        l.addView(tl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        lista = vertical();
        l.addView(lista, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
        pintar();
        llenarLista();
        tic = new Runnable() { @Override public void run() { refrescar(); h.postDelayed(this, 120); } };
    }

    @Override protected void onResume() { super.onResume(); h.post(tic); pintar(); llenarLista(); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tic); }

    private void alternar() {
        if (GrabadoraService.grabando) {
            startService(new Intent(this, GrabadoraService.class).setAction(GrabadoraService.PARAR));
            h.postDelayed(() -> { pintar(); llenarLista(); }, 600);
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                return;
            }
            startForegroundService(new Intent(this, GrabadoraService.class).putExtra("lejos", lejos.isChecked()));
            h.postDelayed(this::pintar, 400);
        }
    }

    private void pintar() {
        boolean g = GrabadoraService.grabando;
        GradientDrawable o = new GradientDrawable();
        o.setShape(GradientDrawable.OVAL);
        o.setColor(g ? 0xFF455A64 : 0xFFE53935);
        o.setStroke(dp(6), g ? 0xFFE53935 : 0xFFFFCDD2);
        boton.setBackground(o);
        boton.setText(g ? "⏹\nPARAR" : "●\nGRABAR");
        int sig = getSharedPreferences("barra", MODE_PRIVATE).getInt("numGrab", 0) + (g ? 0 : 1);
        estado.setText(g ? String.format(Locale.US, "🔴 Grabando · Grabación %03d", GrabadoraService.numero)
                : String.format(Locale.US, "La próxima será la Grabación %03d", sig));
        estado.setTextColor(g ? 0xFFC62828 : 0xFF546E7A);
        if (!g) { tiempo.setText("00:00:00"); ancho(0); }
    }

    private void refrescar() {
        if (!GrabadoraService.grabando) return;
        long s = (System.currentTimeMillis() - GrabadoraService.inicio) / 1000;
        tiempo.setText(String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60));
        int amp = 0;
        try { if (GrabadoraService.mr != null) amp = GrabadoraService.mr.getMaxAmplitude(); } catch (Exception ignored) {}
        double f = amp <= 0 ? 0 : Math.min(1, Math.log10(amp) / Math.log10(32767));
        ancho(f);
    }

    private void ancho(double f) {
        View p = (View) nivel.getParent();
        int w = (int) (p.getWidth() * f);
        ViewGroup.LayoutParams lp = nivel.getLayoutParams();
        lp.width = w;
        nivel.setLayoutParams(lp);
        ((GradientDrawable) nivel.getBackground()).setColor(f > 0.85 ? 0xFFF9A825 : f < 0.35 ? 0xFFB0BEC5 : 0xFF2E7D32);
    }

    // ---------------- Lista ----------------

    private List<String[]> leer() {
        List<String[]> r = new ArrayList<>();
        try {
            for (String l : Files.readAllLines(GrabadoraService.indice(this).toPath(), StandardCharsets.UTF_8)) {
                String[] p = l.split("\t", -1);
                if (p.length >= 6) r.add(p);
            }
        } catch (Exception ignored) {}
        Collections.reverse(r);
        return r;
    }

    private void escribir(List<String[]> todas) {
        List<String[]> c = new ArrayList<>(todas);
        Collections.reverse(c);
        StringBuilder s = new StringBuilder();
        for (String[] p : c) s.append(String.join("\t", p)).append('\n');
        try { Files.write(GrabadoraService.indice(this).toPath(), s.toString().getBytes(StandardCharsets.UTF_8)); } catch (Exception ignored) {}
    }

    private void llenarLista() {
        lista.removeAllViews();
        List<String[]> todas = leer();
        if (todas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay grabaciones.");
            lista.addView(t);
        }
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm a", new Locale("es", "CO"));
        for (String[] g : todas) {
            int n = Integer.parseInt(g[1]);
            long dur = Long.parseLong(g[4]) / 1000;
            LinearLayout c = vertical();
            GradientDrawable fondo = new GradientDrawable();
            fondo.setColor(0xFFF1F4F7);
            fondo.setCornerRadius(dp(10));
            c.setBackground(fondo);
            c.setPadding(dp(10), dp(6), dp(10), dp(6));
            TextView t = new TextView(this);
            t.setText(String.format(Locale.US, "%03d", n) + (g[2].isEmpty() ? "" : " · " + g[2]) + "\n"
                    + df.format(new Date(Long.parseLong(g[3]))) + " · " + (dur / 60) + " min " + (dur % 60) + " s");
            t.setTextSize(16);
            t.setTextColor(Color.BLACK);
            c.addView(t);
            LinearLayout f = horizontal();
            f.addView(chico("▶ Oír", () -> {
                Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(g[0]), "audio/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(i); } catch (Exception e) { aviso("No hay reproductor de audio"); }
            }), peso(1));
            f.addView(chico("✎ Nombre", () -> renombrar(todas, g)), peso(1));
            f.addView(chico("💬 WhatsApp", () -> enviar(WHATSAPP, "audio/mp4", Uri.parse(g[0]))), peso(1));
            c.addView(f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(8);
            lista.addView(c, lp);
        }
    }

    private Button chico(String t, Runnable r) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setOnClickListener(v -> r.run());
        return b;
    }

    /** Le agrega un nombre sin perder el número: "001 · Pedro Gómez · cotización baño". */
    private void renombrar(List<String[]> todas, String[] g) {
        EditText e = campoTexto("Cliente o tema", g[2]);
        new AlertDialog.Builder(this).setTitle(String.format(Locale.US, "Grabación %03d", Integer.parseInt(g[1])))
                .setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    g[2] = limpio(e.getText().toString());
                    String archivo = String.format(Locale.US, "Grabacion %03d", Integer.parseInt(g[1]))
                            + (g[2].isEmpty() ? "" : " - " + g[2].replaceAll("[\\\\/:*?\"<>|]", " ")) + ".m4a";
                    try {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, archivo);
                        getContentResolver().update(Uri.parse(g[0]), v, null, null);
                        g[5] = archivo;
                    } catch (Exception ignored) {}
                    escribir(todas);
                    llenarLista();
                }).setNegativeButton("Cancelar", null).show();
    }
}
