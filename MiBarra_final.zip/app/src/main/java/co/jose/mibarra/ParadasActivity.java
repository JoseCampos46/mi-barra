package co.jose.mibarra;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Rutas con paradas: viaje de ciudad a ciudad (orden fijo) y reparto (varias direcciones). */
public class ParadasActivity extends Base {

    static final class Parada {
        double lat, lon;
        String nombre = "", nota = "", tel = "";
        boolean hecha;
    }

    private File carpeta, actual;
    private String nombre = "", modo = "viaje";
    private final List<Parada> paradas = new ArrayList<>();
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        carpeta = new File(getFilesDir(), "paradas");
        carpeta.mkdirs();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        String m = getIntent().getStringExtra("modo");
        if (m != null) nueva(m); else mostrarLista();
    }

    @Override
    public void onBackPressed() {
        if (actual != null) { guardar(); mostrarLista(); } else super.onBackPressed();
    }

    @Override
    protected void onPause() { super.onPause(); guardar(); }

    // ================= Lista =================

    private void mostrarLista() {
        actual = null;
        LinearLayout l = vertical();
        int p = dp(14);
        l.setPadding(p, p, p, p);
        l.addView(titulo("🗺 Rutas y repartos"));
        Button v = boton("＋  Ruta de ciudad a ciudad (orden fijo)", 0xFF1565C0);
        v.setOnClickListener(x -> nueva("viaje"));
        l.addView(v, ancho(58));
        Button r = boton("＋  Reparto (varias direcciones)", 0xFF2E7D32);
        r.setOnClickListener(x -> nueva("reparto"));
        l.addView(r, ancho(58));
        for (File f : archivos(carpeta)) {
            if (!leer(f)) continue;
            int hechas = 0;
            for (Parada q : paradas) if (q.hecha) hechas++;
            String sub = "reparto".equals(modo) ? "📦 " + hechas + " de " + paradas.size() + " entregados" : "🗺 " + paradas.size() + " puntos";
            Button bt = boton(nombre + "\n" + sub, 0xFF37474F);
            bt.setOnClickListener(x -> { leer(f); actual = f; mostrarEditor(); });
            l.addView(bt, ancho(68));
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }

    private void nueva(String m) {
        modo = m;
        paradas.clear();
        nombre = "viaje".equals(m) ? "Viaje " : "Reparto ";
        nombre += new java.text.SimpleDateFormat("dd/MM/yyyy", Locale.US).format(new java.util.Date());
        actual = new File(carpeta, System.currentTimeMillis() + ".txt");
        mostrarEditor();
    }

    // ================= Editor =================

    private void mostrarEditor() {
        boolean reparto = "reparto".equals(modo);
        LinearLayout l = vertical();
        int p = dp(12);
        l.setPadding(p, p, p, p);

        EditText en = campoTexto("Nombre", nombre);
        en.setTextSize(19);
        en.setTypeface(Typeface.DEFAULT_BOLD);
        en.setOnFocusChangeListener((v, f) -> { if (!f) nombre = en.getText().toString().trim(); });
        l.addView(en);

        if (reparto) {
            int hechas = 0;
            for (Parada q : paradas) if (q.hecha) hechas++;
            TextView pr = new TextView(this);
            pr.setText("📦 " + hechas + " de " + paradas.size() + " entregados");
            pr.setTextSize(18);
            pr.setTypeface(Typeface.DEFAULT_BOLD);
            pr.setTextColor(0xFF2E7D32);
            l.addView(pr);
            Button sig = boton("➡  IR A LA SIGUIENTE PARADA", 0xFF2E7D32);
            sig.setTextSize(18);
            sig.setOnClickListener(v -> siguiente());
            l.addView(sig, ancho(64));
            Button ord = boton("🔀  Ordenar: la más cercana primero", 0xFF546E7A);
            ord.setOnClickListener(v -> ordenarPorCercania());
            l.addView(ord, ancho(50));
        } else {
            Button todo = boton("🗺  Abrir la ruta completa en Google Maps", 0xFF1565C0);
            todo.setTextSize(17);
            todo.setOnClickListener(v -> abrirRuta());
            l.addView(todo, ancho(60));
            Button grab = boton("🛣️  Grabar el recorrido mientras viajo", 0xFF546E7A);
            grab.setOnClickListener(v -> startActivity(new Intent(this, RecorridoActivity.class)));
            l.addView(grab, ancho(50));
        }

        for (int i = 0; i < paradas.size(); i++) l.addView(tarjeta(i, reparto));

        TextView ag = new TextView(this);
        ag.setText("\nAgregar " + (reparto ? "dirección" : "punto (ciudad, parada, destino)") + ":");
        ag.setTextSize(16);
        ag.setTypeface(Typeface.DEFAULT_BOLD);
        l.addView(ag);
        Button aqui = boton("📍  Donde estoy ahora", 0xFF37474F);
        aqui.setOnClickListener(v -> agregarAqui());
        l.addView(aqui, ancho(50));
        Button bus = boton("🔎  Escribir dirección o ciudad", 0xFF37474F);
        bus.setOnClickListener(v -> buscarDireccion());
        l.addView(bus, ancho(50));
        Button peg = boton("📋  Pegar enlace de Google Maps o ubicación de WhatsApp", 0xFF37474F);
        peg.setOnClickListener(v -> pegarEnlace());
        l.addView(peg, ancho(58));

        Button comp = boton("💬  Compartir la lista por WhatsApp", 0xFF25A244);
        comp.setOnClickListener(v -> compartir());
        l.addView(comp, ancho(54));
        Button borrar = boton("🗑  Borrar", 0xFFC62828);
        borrar.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("¿Borrar esta lista?")
                .setPositiveButton("Sí", (d, w) -> { actual.delete(); actual = null; mostrarLista(); })
                .setNegativeButton("No", null).show());
        l.addView(borrar, ancho(50));

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }

    private LinearLayout tarjeta(int i, boolean reparto) {
        Parada q = paradas.get(i);
        LinearLayout c = vertical();
        GradientDrawable g = new GradientDrawable();
        g.setColor(q.hecha ? 0xFFC8E6C9 : 0xFFF1F4F7);
        g.setCornerRadius(dp(10));
        c.setBackground(g);
        c.setPadding(dp(10), dp(6), dp(10), dp(6));
        TextView t = new TextView(this);
        String letra = reparto ? (i + 1) + "." : (i == 0 ? "🟢 Salida:" : i == paradas.size() - 1 ? "🔴 Destino:" : "⚪ " + i + ".");
        t.setText(letra + " " + (q.hecha ? "✔ " : "") + q.nombre + (q.nota.isEmpty() ? "" : "\n   " + q.nota)
                + (q.tel.isEmpty() ? "" : "\n   📞 " + q.tel));
        t.setTextSize(16);
        t.setTextColor(Color.BLACK);
        c.addView(t);
        LinearLayout f = horizontal();
        f.addView(mini("🧭", () -> navegar(q)), peso(1));
        if (!q.tel.isEmpty()) {
            f.addView(mini("📞", () -> startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + q.tel)))), peso(1));
            f.addView(mini("💬", () -> whatsappA(q.tel)), peso(1));
        }
        if (reparto) f.addView(mini(q.hecha ? "↺" : "✔", () -> { q.hecha = !q.hecha; guardar(); mostrarEditor(); }), peso(1));
        f.addView(mini("✎", () -> editar(q)), peso(1));
        if (i > 0) f.addView(mini("↑", () -> { paradas.add(i - 1, paradas.remove(i)); guardar(); mostrarEditor(); }), peso(1));
        f.addView(mini("✕", () -> { paradas.remove(i); guardar(); mostrarEditor(); }), peso(1));
        c.addView(f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        c.setLayoutParams(lp);
        return c;
    }

    private Button mini(String t, Runnable r) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(18);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setOnClickListener(v -> r.run());
        return b;
    }

    // ================= Agregar puntos =================

    private void agregar(double lat, double lon, String sugerido) {
        LinearLayout c = vertical();
        c.setPadding(dp(16), 0, dp(16), 0);
        EditText n = campoTexto("Nombre (cliente, ciudad, sitio)", sugerido);
        EditText no = campoTexto("Nota (pedido, dirección, referencia)", "");
        EditText te = campoTexto("Teléfono (opcional)", "");
        te.setInputType(InputType.TYPE_CLASS_PHONE);
        c.addView(n); c.addView(no); c.addView(te);
        new AlertDialog.Builder(this).setTitle("Nuevo punto").setView(c)
                .setPositiveButton("Agregar", (d, w) -> {
                    Parada q = new Parada();
                    q.lat = lat; q.lon = lon;
                    q.nombre = n.getText().toString().trim().isEmpty() ? "Punto " + (paradas.size() + 1) : n.getText().toString().trim();
                    q.nota = no.getText().toString().trim();
                    q.tel = te.getText().toString().trim();
                    paradas.add(q);
                    guardar();
                    mostrarEditor();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void editar(Parada q) {
        LinearLayout c = vertical();
        c.setPadding(dp(16), 0, dp(16), 0);
        EditText n = campoTexto("Nombre", q.nombre);
        EditText no = campoTexto("Nota", q.nota);
        EditText te = campoTexto("Teléfono", q.tel);
        te.setInputType(InputType.TYPE_CLASS_PHONE);
        c.addView(n); c.addView(no); c.addView(te);
        new AlertDialog.Builder(this).setTitle("Editar punto").setView(c)
                .setPositiveButton("Guardar", (d, w) -> {
                    q.nombre = n.getText().toString().trim();
                    q.nota = no.getText().toString().trim();
                    q.tel = te.getText().toString().trim();
                    guardar();
                    mostrarEditor();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void agregarAqui() {
        aviso("📍 Buscando su ubicación…");
        ubicacion(l -> new Thread(() -> {
            String lugar = Lugar.describir(this, l.getLatitude(), l.getLongitude());
            String corto = lugar.split("\n")[0];
            runOnUiThread(() -> agregar(l.getLatitude(), l.getLongitude(), corto));
        }).start());
    }

    private void buscarDireccion() {
        EditText e = campoTexto("Ej: Calle 5 # 38-20, Cali · o · Buga", "");
        new AlertDialog.Builder(this).setTitle("¿Dónde queda?").setView(e)
                .setPositiveButton("Buscar", (d, w) -> {
                    String q = e.getText().toString().trim();
                    if (q.isEmpty()) return;
                    aviso("🔎 Buscando…");
                    new Thread(() -> {
                        List<Address> rs = null;
                        try {
                            String consulta = q.toLowerCase(Locale.ROOT).contains("colombia") ? q : q + ", Colombia";
                            rs = new Geocoder(this, new Locale("es", "CO")).getFromLocationName(consulta, 5);
                        } catch (Exception ignored) {}
                        List<Address> fin = rs;
                        runOnUiThread(() -> elegirResultado(q, fin));
                    }).start();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void elegirResultado(String q, List<Address> rs) {
        if (rs == null || rs.isEmpty()) {
            aviso("No la encontré. Revise que tenga internet, o use 'Pegar enlace de Google Maps'.");
            return;
        }
        String[] op = new String[rs.size()];
        for (int i = 0; i < rs.size(); i++) {
            Address a = rs.get(i);
            op[i] = a.getMaxAddressLineIndex() >= 0 ? a.getAddressLine(0) : q;
        }
        new AlertDialog.Builder(this).setTitle("¿Cuál es?")
                .setItems(op, (d, w) -> agregar(rs.get(w).getLatitude(), rs.get(w).getLongitude(), q))
                .setNegativeButton("Cancelar", null).show();
    }

    private void pegarEnlace() {
        EditText e = campoTexto("Pegue aquí el enlace o las coordenadas", "");
        android.content.ClipboardManager cb = getSystemService(android.content.ClipboardManager.class);
        if (cb != null && cb.hasPrimaryClip() && cb.getPrimaryClip().getItemCount() > 0) {
            CharSequence t = cb.getPrimaryClip().getItemAt(0).getText();
            if (t != null) e.setText(t);
        }
        new AlertDialog.Builder(this).setTitle("Enlace o ubicación").setView(e)
                .setPositiveButton("Agregar", (d, w) -> {
                    String txt = e.getText().toString();
                    new Thread(() -> {
                        double[] ll = coordenadas(txt);
                        if (ll == null) ll = coordenadas(abrirEnlaceCorto(txt));
                        double[] fin = ll;
                        runOnUiThread(() -> {
                            if (fin == null) aviso("Ese enlace no trae coordenadas. En Google Maps deje presionado el sitio y copie los números que salen arriba.");
                            else agregar(fin[0], fin[1], "");
                        });
                    }).start();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Los enlaces cortos (maps.app.goo.gl) esconden las coordenadas: se sigue la redirección. */
    static String abrirEnlaceCorto(String txt) {
        Matcher m = Pattern.compile("https?://\\S+").matcher(txt);
        if (!m.find()) return "";
        String url = m.group();
        try {
            for (int k = 0; k < 4; k++) {
                java.net.HttpURLConnection h = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                h.setInstanceFollowRedirects(false);
                h.setConnectTimeout(6000);
                h.setReadTimeout(6000);
                String sig = h.getHeaderField("Location");
                h.disconnect();
                if (sig == null) break;
                url = java.net.URLDecoder.decode(sig, "UTF-8");
                if (coordenadas(url) != null) return url;
            }
        } catch (Exception ignored) {}
        return url;
    }

    /** Saca las coordenadas de un texto: "3.45,-76.53", "…@3.45,-76.53,15z", "…q=3.45,-76.53". */
    static double[] coordenadas(String s) {
        Matcher m = Pattern.compile("(-?\\d{1,2}\\.\\d{3,})\\s*,\\s*(-?\\d{1,3}\\.\\d{3,})").matcher(s);
        if (m.find()) {
            double la = Double.parseDouble(m.group(1)), lo = Double.parseDouble(m.group(2));
            if (Math.abs(la) <= 90 && Math.abs(lo) <= 180) return new double[]{la, lo};
        }
        return null;
    }

    // ================= Navegar =================

    private void navegar(Parada q) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.US, "google.navigation:q=%.6f,%.6f", q.lat, q.lon)));
        i.setPackage("com.google.android.apps.maps");
        try { startActivity(i); }
        catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.US,
                    "https://www.google.com/maps/dir/?api=1&destination=%.6f,%.6f", q.lat, q.lon))));
        }
    }

    private void siguiente() {
        for (Parada q : paradas) if (!q.hecha) { aviso("➡ Vamos a: " + q.nombre); navegar(q); return; }
        aviso(paradas.isEmpty() ? "Primero agregue las direcciones" : "🎉 ¡Todo entregado!");
    }

    private void abrirRuta() {
        if (paradas.size() < 2) { aviso("Agregue al menos la salida y el destino"); return; }
        StringBuilder u = new StringBuilder("https://www.google.com/maps/dir/?api=1");
        Parada a = paradas.get(0), z = paradas.get(paradas.size() - 1);
        u.append(String.format(Locale.US, "&origin=%.6f,%.6f&destination=%.6f,%.6f", a.lat, a.lon, z.lat, z.lon));
        if (paradas.size() > 2) {
            u.append("&waypoints=");
            for (int i = 1; i < paradas.size() - 1 && i <= 9; i++) {
                if (i > 1) u.append("%7C");
                u.append(String.format(Locale.US, "%.6f,%.6f", paradas.get(i).lat, paradas.get(i).lon));
            }
        }
        u.append("&travelmode=driving");
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u.toString()));
        i.setPackage("com.google.android.apps.maps");
        try { startActivity(i); } catch (ActivityNotFoundException e) { i.setPackage(null); startActivity(i); }
    }

    private void ordenarPorCercania() {
        aviso("📍 Ordenando desde donde está…");
        ubicacion(l -> {
            List<Parada> pend = new ArrayList<>(), hechas = new ArrayList<>(), orden = new ArrayList<>();
            for (Parada q : paradas) (q.hecha ? hechas : pend).add(q);
            double la = l.getLatitude(), lo = l.getLongitude();
            while (!pend.isEmpty()) {
                Parada mejor = pend.get(0);
                double dm = Double.MAX_VALUE;
                for (Parada q : pend) {
                    double d = Recorrido.distancia(la, lo, q.lat, q.lon);
                    if (d < dm) { dm = d; mejor = q; }
                }
                orden.add(mejor);
                pend.remove(mejor);
                la = mejor.lat; lo = mejor.lon;
            }
            paradas.clear();
            paradas.addAll(hechas);
            paradas.addAll(orden);
            guardar();
            mostrarEditor();
            aviso("🔀 Listo: quedó la más cercana primero");
        });
    }

    private void ubicacion(Consumer<Location> listo) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            aviso("Permita la ubicación y vuelva a tocar");
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        LocationManager lm = getSystemService(LocationManager.class);
        boolean[] hecho = {false};
        Location[] mejor = {null};
        LocationListener ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                if (mejor[0] == null || l.getAccuracy() < mejor[0].getAccuracy()) mejor[0] = l;
                if (!hecho[0] && l.getAccuracy() <= 30) { hecho[0] = true; lm.removeUpdates(this); listo.accept(l); }
            }
            @Override public void onStatusChanged(String p, int s, Bundle b) {}
            @Override public void onProviderEnabled(String p) {}
            @Override public void onProviderDisabled(String p) {}
        };
        try {
            for (String pr : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                Location u = lm.getLastKnownLocation(pr);
                if (u != null && System.currentTimeMillis() - u.getTime() < 60000 && u.getAccuracy() <= 30) {
                    listo.accept(u);
                    return;
                }
                if (lm.isProviderEnabled(pr)) lm.requestLocationUpdates(pr, 1000, 0, ll, Looper.getMainLooper());
            }
        } catch (SecurityException e) { return; }
        h.postDelayed(() -> {
            if (hecho[0]) return;
            hecho[0] = true;
            lm.removeUpdates(ll);
            if (mejor[0] != null) listo.accept(mejor[0]); else aviso("No encontré señal de GPS");
        }, 15000);
    }

    private void whatsappA(String tel) {
        String n = tel.replaceAll("[^0-9]", "");
        if (n.length() == 10) n = "57" + n;
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + n)));
    }

    private void compartir() {
        StringBuilder s = new StringBuilder(("reparto".equals(modo) ? "📦 " : "🗺 ") + nombre + "\n\n");
        for (int i = 0; i < paradas.size(); i++) {
            Parada q = paradas.get(i);
            s.append(i + 1).append(". ").append(q.hecha ? "✔ " : "").append(q.nombre).append('\n');
            if (!q.nota.isEmpty()) s.append("   ").append(q.nota).append('\n');
            if (!q.tel.isEmpty()) s.append("   📞 ").append(q.tel).append('\n');
            s.append(String.format(Locale.US, "   https://maps.google.com/?q=%.6f,%.6f\n", q.lat, q.lon));
        }
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, s.toString());
        i.setPackage(WHATSAPP);
        try { startActivity(i); } catch (ActivityNotFoundException e) { i.setPackage(null); startActivity(Intent.createChooser(i, "Compartir")); }
    }

    // ================= Guardar / leer =================

    private void guardar() {
        if (actual == null) return;
        if (paradas.isEmpty() && !actual.exists()) return;
        StringBuilder s = new StringBuilder("N\t").append(limpio(nombre)).append("\nM\t").append(modo).append('\n');
        for (Parada q : paradas)
            s.append(String.format(Locale.US, "S\t%.6f\t%.6f\t", q.lat, q.lon)).append(limpio(q.nombre)).append('\t')
             .append(limpio(q.nota)).append('\t').append(limpio(q.tel)).append('\t').append(q.hecha ? 1 : 0).append('\n');
        try { Files.write(actual.toPath(), s.toString().getBytes(StandardCharsets.UTF_8)); } catch (Exception ignored) {}
    }

    private boolean leer(File f) {
        try {
            paradas.clear();
            nombre = "Lista"; modo = "viaje";
            for (String l : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                String[] p = l.split("\t", -1);
                if (p[0].equals("N") && p.length > 1) nombre = p[1];
                else if (p[0].equals("M") && p.length > 1) modo = p[1];
                else if (p[0].equals("S") && p.length >= 7) {
                    Parada q = new Parada();
                    q.lat = Double.parseDouble(p[1]); q.lon = Double.parseDouble(p[2]);
                    q.nombre = p[3]; q.nota = p[4]; q.tel = p[5]; q.hecha = "1".equals(p[6]);
                    paradas.add(q);
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
