package co.jose.mibarra;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

/** Pide el permiso de grabar la pantalla y arranca la grabación. */
public class GrabarActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), 1);
    }

    @Override
    protected void onActivityResult(int pedido, int resultado, Intent datos) {
        super.onActivityResult(pedido, resultado, datos);
        if (resultado == RESULT_OK && datos != null) {
            Intent i = new Intent(this, GrabarService.class)
                    .putExtra("codigo", resultado)
                    .putExtra("datos", datos);
            startForegroundService(i);
        } else {
            Toast.makeText(this, "Grabación cancelada", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}
