package co.jose.mibarra;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** La barrita lateral izquierda con todos los atajos. */
public class BarraService extends AccessibilityService {

    private WindowManager wm;
    private Handler h;
    private SharedPreferences prefs;
    private View pestana, pestanaDer, panel, filtro;
    private TextView botonDetener;

    // Copiar a Word
    private boolean copiando, bajando;
    private List<String> acumulado = new ArrayList<>();
    private int sinNuevas, vueltas;
    private String origen = "";
    private final Runnable pasoR = this::paso;

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        h = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences("barra_servicio", MODE_PRIVATE);
        aplicarFiltro(prefs.getInt("luz", 0));
        pestana = crearPestana(false);
        pestanaDer = crearPestana(true);
        mantenerViva();
    }

    /** Un aviso fijo en notificaciones hace que Xiaomi y otros no maten la barra. */
    private void mantenerViva() {
        try {
            android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
            nm.createNotificationChannel(new android.app.NotificationChannel("barra", "Mi Barra activa",
                    android.app.NotificationManager.IMPORTANCE_MIN));
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(this, 0,
                    new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification n = new android.app.Notification.Builder(this, "barra")
                    .setContentTitle("Mi Barra está activa")
                    .setContentText("Deslice desde el borde izquierdo o derecho")
                    .setSmallIcon(android.R.drawable.ic_menu_sort_by_size)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (android.os.Build.VERSION.SDK_INT >= 34)
                startForeground(21, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else
                startForeground(21, n);
        } catch (Throwable ignored) {
            // Si el celular no lo permite, la barra sigue funcionando igual
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        copiando = false;
        quitar(pestana); quitar(pestanaDer); quitar(panel); quitar(filtro); quitar(botonDetener);
        super.onDestroy();
    }

    private void quitar(View v) {
        if (v != null && v.isAttachedToWindow()) {
            try { wm.removeView(v); } catch (Exception ignored) {}
        }
    }

    private WindowManager.LayoutParams lp(int w, int alto, int flags) {
        return new WindowManager.LayoutParams(w, alto,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private int dimSistema(String nombre) {
        int id = getResources().getIdentifier(nombre, "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    // ---------------- Pestañitas (izquierda: herramientas · derecha: en la vía) ----------------

    private View crearPestana(boolean derecha) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(derecha ? 0x992E7D32 : 0x996B7B8C);
        float r = Util.dp(this, 8);
        g.setCornerRadii(derecha ? new float[]{r, r, 0, 0, 0, 0, r, r} : new float[]{0, 0, r, r, r, r, 0, 0});
        v.setBackground(g);
        WindowManager.LayoutParams p = lp(Util.dp(this, 14), Util.dp(this, 110),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        p.gravity = (derecha ? Gravity.END : Gravity.START) | Gravity.TOP;
        p.x = 0;
        p.y = (int) (getResources().getDisplayMetrics().heightPixels * 0.35f);
        v.addOnLayoutChangeListener((vv, l, t, rr, b, ol, ot, or, ob) ->
                vv.setSystemGestureExclusionRects(Collections.singletonList(new Rect(0, 0, rr - l, b - t))));
        final float[] x0 = new float[1];
        v.setOnTouchListener((vv, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    x0[0] = ev.getRawX();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = ev.getRawX() - x0[0];
                    if ((derecha ? -dx : dx) > Util.dp(this, 20)) { abrirPanel(derecha); x0[0] = derecha ? -1e9f : 1e9f; }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(ev.getRawX() - x0[0]) < Util.dp(this, 12)) abrirPanel(derecha);
                    return true;
            }
            return false;
        });
        wm.addView(v, p);
        return v;
    }

    // ---------------- Paneles con secciones ----------------

    private static final String[] SEC_IZQ = {"⚡\nAtajos", "📝\nOficina", "🧮\nObra", "📷\nCámara"};
    private static final String[] SEC_DER = {"🛣️\nViaje", "📍\nUbicación", "🔎\nBuscar"};
    private boolean ladoDerecha;
    private LinearLayout contenido;
    private Button[] pestanasSec;

    private void abrirPanel(boolean derecha) {
        if (panel != null) return;
        ladoDerecha = derecha;
        int pad = Util.dp(this, 6);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setPadding(pad, pad, pad, pad);
        GradientDrawable g = new GradientDrawable();
        g.setColor(derecha ? 0xF01B2A20 : 0xF0202830);
        float r = Util.dp(this, 16);
        g.setCornerRadii(derecha ? new float[]{r, r, 0, 0, 0, 0, r, r} : new float[]{0, 0, r, r, r, r, 0, 0});
        raiz.setBackground(g);

        String[] secs = derecha ? SEC_DER : SEC_IZQ;
        LinearLayout tabs = new LinearLayout(this);
        pestanasSec = new Button[secs.length];
        for (int i = 0; i < secs.length; i++) {
            final int k = i;
            Button b = new Button(this);
            b.setText(secs[i]);
            b.setAllCaps(false);
            b.setTextSize(11);
            b.setTextColor(Color.WHITE);
            b.setPadding(0, Util.dp(this, 4), 0, Util.dp(this, 4));
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setOnClickListener(v -> ponerSeccion(k));
            pestanasSec[i] = b;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Util.dp(this, 58), 1f);
            lp.setMargins(Util.dp(this, 2), 0, Util.dp(this, 2), 0);
            tabs.addView(b, lp);
        }
        raiz.addView(tabs);

        ScrollView sv = new ScrollView(this);
        contenido = new LinearLayout(this);
        contenido.setOrientation(LinearLayout.VERTICAL);
        sv.addView(contenido);
        raiz.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout pie = new LinearLayout(this);
        pie.setOrientation(LinearLayout.VERTICAL);
        boton(pie, "✕  Cerrar", this::cerrarPanel);
        raiz.addView(pie);

        raiz.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) { cerrarPanel(); return true; }
            return false;
        });
        // No tapa la barra de estado de arriba ni los botones ■ ● ◀ de abajo
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int arriba = dimSistema("status_bar_height"), abajo = dimSistema("navigation_bar_height");
        WindowManager.LayoutParams p = lp(Util.dp(this, 270), dm.heightPixels - arriba - abajo,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        p.gravity = (derecha ? Gravity.END : Gravity.START) | Gravity.TOP;
        p.y = arriba;
        wm.addView(raiz, p);
        panel = raiz;
        ponerSeccion(Math.min(prefs.getInt(derecha ? "secDer" : "secIzq", 0), secs.length - 1));
    }

    private void ponerSeccion(int k) {
        prefs.edit().putInt(ladoDerecha ? "secDer" : "secIzq", k).apply();
        for (int i = 0; i < pestanasSec.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == k ? (ladoDerecha ? 0xFF2E7D32 : 0xFF1565C0) : 0xFF34404C);
            g.setCornerRadius(Util.dp(this, 10));
            pestanasSec[i].setBackground(g);
        }
        contenido.removeAllViews();
        if (ladoDerecha) {
            if (k == 0) seccionViaje(contenido);
            else if (k == 1) seccionUbicacion(contenido);
            else seccionBuscar(contenido);
        } else {
            if (k == 0) seccionAtajos(contenido, Util.dp(this, 8));
            else if (k == 1) seccionOficina(contenido);
            else if (k == 2) seccionCalculo(contenido);
            else seccionCamara(contenido);
        }
    }

    private void seccionAtajos(LinearLayout lista, int pad) {
        boton(lista, linternaPrendida ? "🔦  Apagar linterna" : "🔦  Linterna", this::linterna);
        boton(lista, "💌  Saludos y memes", () -> abrir(new Intent(this, SaludosActivity.class)));
        boton(lista, "🎵  Grabadora de voz", () -> abrir(new Intent(this, GrabadoraActivity.class)));
        boton(lista, "📸  Pantallazo", this::pantallazo);
        boton(lista, "📄  Copiar a Word ⬇ bajando", () -> copiar(true));
        boton(lista, "📄  Copiar a Word ⬆ subiendo", () -> copiar(false));
        boton(lista, "🖨  Imprimir pantalla", this::imprimirPantalla);
        boton(lista, "🔊  Volumen +", () -> volumen(AudioManager.ADJUST_RAISE));
        boton(lista, "🔉  Volumen −", () -> volumen(AudioManager.ADJUST_LOWER));
        boton(lista, "🔇  Silencio", () -> volumen(AudioManager.ADJUST_TOGGLE_MUTE));
        boton(lista, "📶  Wi‑Fi", () -> abrir(new Intent(Settings.Panel.ACTION_WIFI)));
        boton(lista, "📱  Datos móviles", () -> abrir(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)));
        boton(lista, "📴  Apagar / Reiniciar", () -> {
            cerrarPanel();
            performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
        });

        final TextView tl = new TextView(this);
        tl.setTextColor(Color.WHITE);
        tl.setTextSize(16);
        tl.setPadding(pad, Util.dp(this, 12), pad, 0);
        int luz = prefs.getInt("luz", 0);
        tl.setText("🌙  Luz azul: " + luz + "%");
        lista.addView(tl);
        SeekBar sb = new SeekBar(this);
        sb.setMax(80);
        sb.setProgress(luz);
        sb.setPadding(Util.dp(this, 16), Util.dp(this, 14), Util.dp(this, 16), Util.dp(this, 14));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                tl.setText("🌙  Luz azul: " + p + "%");
                aplicarFiltro(p);
                prefs.edit().putInt("luz", p).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        lista.addView(sb);
    }

    private void seccionOficina(LinearLayout lista) {
        boton(lista, "📝  Cuaderno (mini Word)", () -> abrir(new Intent(this, NotasActivity.class)));
        boton(lista, "📊  Cuentas (mini Excel)", () -> abrir(new Intent(this, HojaActivity.class)));
        boton(lista, "🧾  Cuenta de cobro", () -> abrir(new Intent(this, CobroActivity.class)));
        boton(lista, "🛒  Lista de compras", () -> abrir(new Intent(this, ComprasActivity.class)));
        boton(lista, "📑  PDF: unir, separar, fotos", () -> abrir(new Intent(this, MainActivity.class)));
    }

    private void seccionCalculo(LinearLayout lista) {
        boton(lista, "🧮  Calculadora", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 0)));
        boton(lista, "📏  mm ↔ pulgadas", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 1)));
        boton(lista, "🏗️  Concreto", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 2)));
        boton(lista, "🧱  Ladrillo / farol", () -> abrir(new Intent(this, CalculadoraActivity.class).putExtra("pestana", 3)));
        boton(lista, "📐  Nivel (burbuja digital)", () -> abrir(new Intent(this, NivelActivity.class)));
    }

    private void seccionCamara(LinearLayout lista) {
        boton(lista, "📄  Escáner con nivel", () -> abrir(new Intent(this, EscanerActivity.class)));
        boton(lista, "📷  Tomar foto", () -> abrir(new Intent(this, CamaraActivity.class)));
        boton(lista, "🎬  Grabar video (cámara)", () -> abrir(new Intent(this, CamaraActivity.class).putExtra("video", true)));
        boton(lista, GrabarService.grabando ? "⏹  Parar grabación de pantalla" : "🎥  Grabar la pantalla", this::grabar);
    }

    private boolean grabandoRecorrido() { return RecorridoService.estado(this).exists(); }

    private void seccionViaje(LinearLayout lista) {
        boolean rec = grandandoSeguro();
        boton(lista, rec ? "🔴  Recorrido (grabando)" : "🛣️  Grabar recorrido", () -> abrir(new Intent(this, RecorridoActivity.class)));
        if (rec) boton(lista, "📌  Marcar boya aquí", () -> abrir(new Intent(this, RecorridoActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("boya", true)));
        boton(lista, "🗺  Ruta de ciudad a ciudad", () -> abrir(new Intent(this, ParadasActivity.class).putExtra("modo", "viaje")));
        boton(lista, "📦  Reparto (varias paradas)", () -> abrir(new Intent(this, ParadasActivity.class).putExtra("modo", "reparto")));
        boton(lista, "📂  Mis rutas y repartos", () -> abrir(new Intent(this, ParadasActivity.class)));
    }

    private void seccionUbicacion(LinearLayout lista) {
        boton(lista, "📍  Aquí estoy (mapa + dirección)", () -> abrir(new Intent(this, AquiEstoyActivity.class)));
        if (grandandoSeguro()) boton(lista, "📌  Marcar boya aquí", () -> abrir(new Intent(this, RecorridoActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("boya", true)));
        boton(lista, "🛣️  Mis recorridos", () -> abrir(new Intent(this, RecorridoActivity.class)));
    }

    private void seccionBuscar(LinearLayout lista) {
        boton(lista, "⛽  Gasolinera cerca", () -> buscarCerca("gasolinera"));
        boton(lista, "🍽  Restaurante cerca", () -> buscarCerca("restaurante"));
        boton(lista, "🏥  Hospital cerca", () -> buscarCerca("hospital"));
        boton(lista, "🔧  Taller de motos", () -> buscarCerca("taller de motos"));
        boton(lista, "🚗  Taller de carros", () -> buscarCerca("taller mecánico"));
        boton(lista, "🏧  Cajero", () -> buscarCerca("cajero automático"));
        boton(lista, "💊  Droguería", () -> buscarCerca("droguería"));
        boton(lista, "🔩  Ferretería", () -> buscarCerca("ferretería"));
    }

    private boolean grandandoSeguro() {
        try { return grabandoRecorrido(); } catch (Exception e) { return false; }
    }

    private void buscarCerca(String que) {
        Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=" + android.net.Uri.encode(que)));
        i.setPackage("com.google.android.apps.maps");
        if (i.resolveActivity(getPackageManager()) == null) {
            i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/maps/search/"
                    + android.net.Uri.encode(que + " cerca de mí")));
        }
        abrir(i);
    }

    private void cerrarPanel() {
        quitar(panel);
        panel = null;
    }

    private Button boton(LinearLayout l, String t, Runnable accion) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(Util.dp(this, 14), 0, Util.dp(this, 8), 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF34404C);
        g.setCornerRadius(Util.dp(this, 10));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Util.dp(this, 50));
        p.topMargin = Util.dp(this, 6);
        b.setOnClickListener(v -> accion.run());
        l.addView(b, p);
        return b;
    }

    // ---------------- Linterna (no necesita permiso de cámara) ----------------

    private boolean linternaPrendida;
    private android.hardware.camera2.CameraManager.TorchCallback vigiaLinterna;

    private String camaraConFlash(android.hardware.camera2.CameraManager cm) throws Exception {
        for (String id : cm.getCameraIdList()) {
            android.hardware.camera2.CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            Boolean f = ch.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
            Integer lado = ch.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
            if (Boolean.TRUE.equals(f) && lado != null && lado == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        return null;
    }

    private void linterna() {
        try {
            android.hardware.camera2.CameraManager cm = getSystemService(android.hardware.camera2.CameraManager.class);
            String id = camaraConFlash(cm);
            if (id == null) { Toast.makeText(this, "Este celular no tiene linterna", Toast.LENGTH_SHORT).show(); return; }
            if (vigiaLinterna == null) {
                final String cid = id;
                vigiaLinterna = new android.hardware.camera2.CameraManager.TorchCallback() {
                    @Override public void onTorchModeChanged(String camId, boolean prendida) {
                        if (camId.equals(cid)) linternaPrendida = prendida;
                    }
                };
                cm.registerTorchCallback(vigiaLinterna, new android.os.Handler(android.os.Looper.getMainLooper()));
            }
            cm.setTorchMode(id, !linternaPrendida);
            linternaPrendida = !linternaPrendida;
            cerrarPanel();
        } catch (Exception e) {
            Toast.makeText(this, "La linterna está ocupada (¿cámara abierta?)", Toast.LENGTH_SHORT).show();
        }
    }

    private void abrir(Intent i) {
        cerrarPanel();
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { aviso("No se pudo abrir"); }
    }

    // ---------------- Acciones sencillas ----------------

    private void volumen(int dir) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        try {
            am.adjustSuggestedStreamVolume(dir, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
        } catch (Exception e) {
            try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI); }
            catch (Exception ignored) { aviso("El celular no permitió cambiar el volumen"); }
        }
    }

    private void grabar() {
        cerrarPanel();
        if (GrabarService.grabando) {
            startService(new Intent(this, GrabarService.class).setAction(GrabarService.PARAR));
        } else {
            abrir(new Intent(this, GrabarActivity.class));
        }
    }

    // ---------------- Luz azul ----------------

    private void aplicarFiltro(int pct) {
        if (pct <= 0) {
            quitar(filtro);
            filtro = null;
            return;
        }
        int a = Math.round(pct / 100f * 200);
        int color = (a << 24) | 0x00FF8A20;
        if (filtro == null) {
            filtro = new View(this);
            WindowManager.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            wm.addView(filtro, p);
        }
        filtro.setBackgroundColor(color);
    }

    // ---------------- Pantallazo e imprimir ----------------

    private interface AlCapturar { void listo(Bitmap b); }

    private void capturar(AlCapturar cb) {
        cerrarPanel();
        final boolean habiaFiltro = filtro != null;
        if (habiaFiltro) filtro.setVisibility(View.GONE);
        if (pestana != null) pestana.setVisibility(View.GONE);
        if (pestanaDer != null) pestanaDer.setVisibility(View.GONE);
        h.postDelayed(() -> takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                restaurar(habiaFiltro);
                HardwareBuffer hb = r.getHardwareBuffer();
                Bitmap b = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                Bitmap c = b == null ? null : b.copy(Bitmap.Config.ARGB_8888, false);
                hb.close();
                if (c == null) { aviso("No se pudo tomar el pantallazo"); return; }
                cb.listo(c);
            }
            @Override public void onFailure(int codigo) {
                restaurar(habiaFiltro);
                // Plan B: el pantallazo normal del celular
                performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
            }
        }), 450);
    }

    private void restaurar(boolean habiaFiltro) {
        if (habiaFiltro && filtro != null) filtro.setVisibility(View.VISIBLE);
        if (pestana != null) pestana.setVisibility(View.VISIBLE);
        if (pestanaDer != null) pestanaDer.setVisibility(View.VISIBLE);
    }

    private void pantallazo() {
        capturar(b -> new Thread(() -> {
            try {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 100, o);
                Util.guardarBytes(this, "Pantallazo_" + Util.fecha() + ".png", "image/png", o.toByteArray());
                h.post(() -> aviso("📸 Pantallazo guardado en Descargas"));
            } catch (Exception e) {
                h.post(() -> aviso("Error al guardar: " + e.getMessage()));
            }
        }).start());
    }

    private void imprimirPantalla() {
        capturar(b -> {
            try {
                File f = new File(getCacheDir(), "imprimir.png");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    b.compress(Bitmap.CompressFormat.PNG, 100, o);
                }
                Intent i = new Intent(this, PrintActivity.class)
                        .putExtra("imagen", f.getAbsolutePath())
                        .putExtra("titulo", "Pantalla " + Util.fecha());
                abrir(i);
            } catch (Exception e) {
                aviso("Error: " + e.getMessage());
            }
        });
    }

    // ---------------- Copiar a Word con desplazamiento ----------------

    private void copiar(boolean abajo) {
        if (copiando) return;
        cerrarPanel();
        copiando = true;
        bajando = abajo;
        acumulado = new ArrayList<>();
        sinNuevas = 0;
        vueltas = 0;
        origen = "";
        mostrarDetener();
        h.postDelayed(pasoR, 600);
    }

    private void mostrarDetener() {
        TextView t = new TextView(this);
        t.setText("⏹ Detener y guardar");
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        int p = Util.dp(this, 12);
        t.setPadding(p * 2, p, p * 2, p);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xEEC62828);
        g.setCornerRadius(Util.dp(this, 24));
        t.setBackground(g);
        t.setOnClickListener(v -> terminarCopia());
        WindowManager.LayoutParams lp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = Util.dp(this, 36);
        wm.addView(t, lp);
        botonDetener = t;
    }

    private void paso() {
        if (!copiando) return;
        AccessibilityNodeInfo raiz = getRootInActiveWindow();
        List<String> nuevas = new ArrayList<>();
        if (raiz != null) {
            if (origen.isEmpty() && raiz.getPackageName() != null) origen = raiz.getPackageName().toString();
            AccessibilityNodeInfo zona = desplazable(raiz);
            juntar(zona != null ? zona : raiz, nuevas);
        }
        int antes = acumulado.size();
        unir(nuevas);
        sinNuevas = (acumulado.size() == antes) ? sinNuevas + 1 : 0;
        vueltas++;
        if (botonDetener != null) botonDetener.setText("⏹ Detener y guardar (" + acumulado.size() + " líneas)");
        if (sinNuevas >= 3 || vueltas > 600) { terminarCopia(); return; }
        deslizar();
        h.postDelayed(pasoR, 1100);
    }

    /** Busca la zona que se desplaza (la conversación o la página), la más grande. */
    private AccessibilityNodeInfo desplazable(AccessibilityNodeInfo raiz) {
        AccessibilityNodeInfo[] mejor = new AccessibilityNodeInfo[1];
        long[] area = new long[1];
        buscar(raiz, mejor, area, 0);
        return mejor[0];
    }

    private void buscar(AccessibilityNodeInfo n, AccessibilityNodeInfo[] mejor, long[] area, int nivel) {
        if (n == null || nivel > 60) return;
        if (n.isScrollable()) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            long a = (long) r.width() * r.height();
            if (a > area[0]) { area[0] = a; mejor[0] = n; }
        }
        for (int i = 0; i < n.getChildCount(); i++) buscar(n.getChild(i), mejor, area, nivel + 1);
    }

    private void juntar(AccessibilityNodeInfo n, List<String> out) {
        if (n == null) return;
        CharSequence pk = n.getPackageName();
        if (pk != null && getPackageName().contentEquals(pk)) return;
        if (!n.isEditable()) {
            CharSequence t = n.getText();
            if (t != null) {
                for (String l : t.toString().split("\n")) {
                    l = l.trim();
                    if (!l.isEmpty()) out.add(l);
                }
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) juntar(n.getChild(i), out);
    }

    private void unir(List<String> nuevas) {
        if (nuevas.isEmpty()) return;
        if (acumulado.isEmpty()) { acumulado.addAll(nuevas); return; }
        if (bajando) {
            int k = solape(acumulado, nuevas);
            acumulado.addAll(nuevas.subList(k, nuevas.size()));
        } else {
            int k = solape(nuevas, acumulado);
            acumulado.addAll(0, nuevas.subList(0, nuevas.size() - k));
        }
    }

    /** Cuántas líneas del final de "a" coinciden con el comienzo de "b". */
    private static int solape(List<String> a, List<String> b) {
        int max = Math.min(a.size(), b.size());
        for (int k = max; k > 0; k--) {
            boolean ok = true;
            for (int i = 0; i < k; i++) {
                if (!a.get(a.size() - k + i).equals(b.get(i))) { ok = false; break; }
            }
            if (ok) return k;
        }
        return 0;
    }

    /** Desliza el dedo despacio (sin "lanzar") para avanzar menos de una pantalla. */
    private void deslizar() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.6f;
        float y1 = dm.heightPixels * 0.70f, y2 = dm.heightPixels * 0.35f;
        Path p = new Path();
        if (bajando) { p.moveTo(x, y1); p.lineTo(x, y2); }
        else { p.moveTo(x, y2); p.lineTo(x, y1); }
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 600)).build(), null, null);
    }

    private void terminarCopia() {
        if (!copiando) return;
        copiando = false;
        h.removeCallbacks(pasoR);
        quitar(botonDetener);
        botonDetener = null;
        final List<String> l = new ArrayList<>(acumulado);
        if (l.isEmpty()) { aviso("No encontré texto para copiar en esta pantalla"); return; }
        final String titulo = "Copiado de " + nombreApp(origen) + " — "
                + new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(new Date());
        aviso("⏳ Guardando el Word…");
        new Thread(() -> {
            try {
                Util.guardarBytes(this, "Copia_" + Util.fecha() + ".docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        Util.crearDocx(titulo, l));
                h.post(() -> aviso("📄 Word guardado en Descargas (" + l.size() + " líneas)"));
            } catch (Exception e) {
                h.post(() -> aviso("Error al guardar: " + e.getMessage()));
            }
        }).start();
    }

    private static String nombreApp(String pk) {
        if (pk == null || pk.isEmpty()) return "la pantalla";
        if (pk.startsWith("com.whatsapp")) return "WhatsApp";
        if (pk.equals("com.android.chrome")) return "Chrome";
        if (pk.contains("browser")) return "el navegador";
        return pk;
    }
}
