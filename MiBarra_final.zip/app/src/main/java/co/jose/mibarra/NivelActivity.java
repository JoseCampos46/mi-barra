package co.jose.mibarra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Nivel digital: modo plano (mesa), barra (farol, de canto) y plomada (columna). */
public class NivelActivity extends Base implements SensorEventListener {

    private static final String[] MODOS = {"● Plano", "▬ Barra", "┃ Plomada"};
    private static final double VERDE = 0.25; // grados para considerar nivelado

    private SensorManager sm;
    private final float[] g = new float[3];
    private boolean hayDato, congelado, sonido, estabaVerde;
    private int modo;
    private SharedPreferences prefs;
    private NivelView vista;
    private TextView tA, tB, tAyuda;
    private Button[] bModos = new Button[3];
    private Button bCong, bSon;
    private EditText largo;
    private ToneGenerator tono;
    private final Handler h = new Handler(Looper.getMainLooper());
    private long ultimoPito;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("barra", MODE_PRIVATE);
        modo = prefs.getInt("nivelModo", 0);
        sm = getSystemService(SensorManager.class);

        LinearLayout l = vertical();
        l.setBackgroundColor(0xFF10161C);
        l.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout mr = horizontal();
        for (int i = 0; i < 3; i++) {
            final int k = i;
            Button bt = boton(MODOS[i], 0xFF263238);
            bt.setOnClickListener(v -> { modo = k; prefs.edit().putInt("nivelModo", k).apply(); pintarModos(); });
            bModos[i] = bt;
            mr.addView(bt, new LinearLayout.LayoutParams(0, dp(46), 1f) {{ setMargins(dp(3), 0, dp(3), 0); }});
        }
        l.addView(mr);

        vista = new NivelView(this);
        l.addView(vista, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout lect = horizontal();
        tA = lectura(lect);
        tB = lectura(lect);
        l.addView(lect);
        tAyuda = new TextView(this);
        tAyuda.setTextSize(18);
        tAyuda.setTextColor(0xFF222222);
        tAyuda.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable ga = new GradientDrawable();
        ga.setColor(0xFFFFF59D);
        ga.setCornerRadius(dp(12));
        tAyuda.setBackground(ga);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(6);
        l.addView(tAyuda, ap);

        LinearLayout fl = horizontal();
        fl.setGravity(Gravity.CENTER_VERTICAL);
        TextView tl = new TextView(this);
        tl.setText("Largo del farol o pieza (cm): ");
        tl.setTextColor(0xFFB0BEC5);
        fl.addView(tl);
        largo = campoTexto("30", String.valueOf(prefs.getInt("nivelLargo", 30)));
        largo.setTextColor(Color.WHITE);
        largo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        fl.addView(largo, new LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT));
        l.addView(fl);

        LinearLayout bot = horizontal();
        Button cal = boton("🎯 Calibrar", 0xFF455A64);
        cal.setOnClickListener(v -> calibrar());
        bCong = boton("🔒 Congelar", 0xFF6A1B9A);
        bCong.setOnClickListener(v -> { congelado = !congelado; bCong.setText(congelado ? "🔓 Seguir" : "🔒 Congelar"); });
        bSon = boton("🔊 Sonido", 0xFF2E7D32);
        bSon.setOnClickListener(v -> { sonido = !sonido; bSon.setText(sonido ? "🔇 Sin sonido" : "🔊 Sonido"); });
        for (Button x : new Button[]{cal, bCong, bSon})
            bot.addView(x, new LinearLayout.LayoutParams(0, dp(52), 1f) {{ setMargins(dp(3), dp(6), dp(3), 0); }});
        l.addView(bot);
        setContentView(l);
        pintarModos();
        try { tono = new ToneGenerator(AudioManager.STREAM_MUSIC, 70); } catch (Exception ignored) {}
    }

    private TextView lectura(LinearLayout fila) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(6), 0, dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF1E272E);
        g.setCornerRadius(dp(12));
        t.setBackground(g);
        fila.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) {{ setMargins(dp(3), dp(6), dp(3), 0); }});
        return t;
    }

    private void pintarModos() {
        for (int i = 0; i < 3; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == modo ? 0xFF2E7D32 : 0xFF263238);
            g.setCornerRadius(dp(20));
            bModos[i].setBackground(g);
        }
        tB.setVisibility(modo == 1 ? View.GONE : View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sensor s = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
        else aviso("Este celular no tiene sensor de inclinación");
    }

    @Override
    protected void onPause() {
        super.onPause();
        sm.unregisterListener(this);
        try { prefs.edit().putInt("nivelLargo", Integer.parseInt(largo.getText().toString().trim())).apply(); } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        if (tono != null) tono.release();
        super.onDestroy();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (congelado) return;
        float a = hayDato ? 0.12f : 1f; // suavizado para que no tiemble
        for (int i = 0; i < 3; i++) g[i] += a * (e.values[i] - g[i]);
        hayDato = true;
        actualizar();
    }

    @Override public void onAccuracyChanged(Sensor s, int a) {}

    // ----- Ángulos -----

    /** Plano: {x, y} en grados. x>0 = lado derecho alto; y>0 = lado de arriba alto. */
    private double[] plano() {
        return new double[]{Math.toDegrees(Math.atan2(g[0], g[2])) - off("px"), Math.toDegrees(Math.atan2(g[1], g[2])) - off("py")};
    }

    /** Barra: desviación en grados respecto al eje del celular más cercano a horizontal, y el eje usado. */
    private double[] barra() {
        boolean ejeX = Math.abs(g[0]) < Math.abs(g[1]); // celular parado: la barra va a lo largo de X
        double alto = ejeX ? g[0] : g[1], otro = ejeX ? g[1] : g[0];
        double d = Math.toDegrees(Math.atan2(alto, Math.abs(otro))) - off(ejeX ? "bx" : "by");
        return new double[]{d, ejeX ? 0 : 1, Math.signum(otro)};
    }

    /** Plomada: {lado, adelante-atrás} en grados con el celular parado contra la columna. */
    private double[] plomada() {
        return new double[]{Math.toDegrees(Math.atan2(g[0], g[1])) - off("lx"), Math.toDegrees(Math.atan2(g[2], g[1])) - off("lz")};
    }

    private double off(String k) { return prefs.getFloat("cal_" + k, 0f); }

    private void calibrar() {
        if (!hayDato) return;
        SharedPreferences.Editor ed = prefs.edit();
        if (modo == 0) {
            ed.putFloat("cal_px", (float) Math.toDegrees(Math.atan2(g[0], g[2])));
            ed.putFloat("cal_py", (float) Math.toDegrees(Math.atan2(g[1], g[2])));
        } else if (modo == 1) {
            boolean ejeX = Math.abs(g[0]) < Math.abs(g[1]);
            double alto = ejeX ? g[0] : g[1], otro = ejeX ? g[1] : g[0];
            ed.putFloat(ejeX ? "cal_bx" : "cal_by", (float) Math.toDegrees(Math.atan2(alto, Math.abs(otro))));
        } else {
            ed.putFloat("cal_lx", (float) Math.toDegrees(Math.atan2(g[0], g[1])));
            ed.putFloat("cal_lz", (float) Math.toDegrees(Math.atan2(g[2], g[1])));
        }
        ed.apply();
        aviso("🎯 Calibrado. Póngalo sobre una superficie que sepa que está nivelada antes de calibrar.");
    }

    private static String gr(double d) { return CalculadoraActivity.dec(Math.abs(d), 2) + "°"; }
    private static long mmPorMetro(double d) { return Math.round(Math.abs(Math.tan(Math.toRadians(d))) * 1000); }

    private void actualizar() {
        int cm = 30;
        try { cm = Integer.parseInt(largo.getText().toString().trim()); } catch (Exception ignored) {}
        boolean verde;
        double peor;
        if (modo == 0) {
            double[] p = plano();
            tA.setText("Izq ↔ der\n" + gr(p[0]) + "\n" + mmPorMetro(p[0]) + " mm/m");
            tB.setText("Arriba ↔ abajo\n" + gr(p[1]) + "\n" + mmPorMetro(p[1]) + " mm/m");
            verde = Math.abs(p[0]) < VERDE && Math.abs(p[1]) < VERDE;
            peor = Math.max(Math.abs(p[0]), Math.abs(p[1]));
            StringBuilder s = new StringBuilder();
            if (verde) s.append("✅ ¡NIVELADO!");
            else {
                if (Math.abs(p[0]) >= VERDE) s.append("➜ Baje el lado ").append(p[0] > 0 ? "DERECHO " : "IZQUIERDO ").append(mmPorMetro(p[0])).append(" mm por metro");
                if (Math.abs(p[1]) >= VERDE) { if (s.length() > 0) s.append('\n'); s.append("➜ Baje el lado de ").append(p[1] > 0 ? "ARRIBA " : "ABAJO ").append(mmPorMetro(p[1])).append(" mm por metro"); }
            }
            tAyuda.setText(s);
            vista.plano(p[0], p[1], verde);
        } else if (modo == 1) {
            double[] b = barra();
            long mmPieza = Math.round(Math.abs(Math.tan(Math.toRadians(b[0]))) * cm * 10);
            tA.setText(gr(b[0]) + "  ·  " + mmPorMetro(b[0]) + " mm por metro  ·  en " + cm + " cm: " + mmPieza + " mm");
            verde = Math.abs(b[0]) < VERDE;
            peor = Math.abs(b[0]);
            tAyuda.setText(verde ? "✅ ¡NIVELADO!" : "⬇ Golpee hacia abajo el extremo donde está la burbuja, unos " + mmPieza + " mm");
            vista.barra(b[0], b[1] == 1, b[2], verde);
        } else {
            double[] p = plomada();
            tA.setText("De lado\n" + gr(p[0]) + "\n" + mmPorMetro(p[0]) + " mm/m");
            tB.setText("Adelante ↔ atrás\n" + gr(p[1]) + "\n" + mmPorMetro(p[1]) + " mm/m");
            verde = Math.abs(p[0]) < VERDE && Math.abs(p[1]) < VERDE;
            peor = Math.max(Math.abs(p[0]), Math.abs(p[1]));
            tAyuda.setText(verde ? "✅ ¡A PLOMO!" : "Ponga la espalda del celular contra la columna o el muro.\nMueva la parte de arriba hasta que la burbuja quede en el centro.");
            vista.plano(p[0], -p[1], verde);
        }
        if (verde && !estabaVerde) {
            Vibrator vb = getSystemService(Vibrator.class);
            if (vb != null) vb.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE));
        }
        estabaVerde = verde;
        if (sonido && tono != null) {
            long ahora = System.currentTimeMillis();
            long cada = verde ? 150 : (long) Math.min(1200, 150 + peor * 300);
            if (ahora - ultimoPito > cada) {
                ultimoPito = ahora;
                tono.startTone(verde ? ToneGenerator.TONE_PROP_BEEP2 : ToneGenerator.TONE_PROP_BEEP, verde ? 120 : 60);
            }
        }
    }

    // ----- Dibujo -----

    static final class NivelView extends View {
        private int modo;
        private double a, b, signo;
        private boolean vertical, verde;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        NivelView(Context c) { super(c); }

        void plano(double x, double y, boolean v) { modo = 0; a = x; b = y; verde = v; invalidate(); }
        void barra(double d, boolean vert, double sg, boolean v) { modo = 1; a = d; vertical = vert; signo = sg; verde = v; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2;
            float d = Util.dp(getContext(), 1);
            int verdeLima = verde ? 0xFF7CFF5A : 0xFFC8F040;
            if (modo == 0) {
                float r = Math.min(w, h) / 2 - 10 * d;
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFE8EEF2);
                c.drawCircle(cx, cy, r + 6 * d, p);
                p.setColor(verdeLima);
                c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFF222222);
                p.setStrokeWidth(2 * d);
                float r1 = r / 3f;            // cada aro = 1°
                c.drawCircle(cx, cy, r1, p);
                c.drawCircle(cx, cy, r1 * 2, p);
                c.drawLine(cx - r, cy, cx + r, cy, p);
                c.drawLine(cx, cy - r, cx, cy + r, p);
                p.setColor(0xFF2E7D32);
                p.setStrokeWidth(3 * d);
                c.drawCircle(cx, cy, r1 * 0.7f, p); // la burbuja cabe aquí cuando está a menos de 0,25°
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF222222);
                p.setTextSize(14 * d);
                c.drawText("1°", cx + r1 + 3 * d, cy - 4 * d, p);
                c.drawText("2°", cx + r1 * 2 + 3 * d, cy - 4 * d, p);
                // La burbuja va hacia el lado alto (máx. 3°)
                double bx = Math.max(-3, Math.min(3, a)), by = Math.max(-3, Math.min(3, b));
                float px = (float) (cx + bx * r1), py = (float) (cy - by * r1);
                p.setColor(0xEEFFFFFF);
                c.drawCircle(px, py, r1 * 0.45f, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFF66BB88);
                p.setStrokeWidth(2 * d);
                c.drawCircle(px, py, r1 * 0.45f, p);
            } else {
                float largo = (vertical ? h : w) - 30 * d, grueso = 70 * d;
                RectF tubo = vertical ? new RectF(cx - grueso / 2, cy - largo / 2, cx + grueso / 2, cy + largo / 2)
                        : new RectF(cx - largo / 2, cy - grueso / 2, cx + largo / 2, cy + grueso / 2);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFE8EEF2);
                c.drawRoundRect(tubo, grueso / 2, grueso / 2, p);
                RectF in = new RectF(tubo.left + 6 * d, tubo.top + 6 * d, tubo.right - 6 * d, tubo.bottom - 6 * d);
                p.setColor(verdeLima);
                c.drawRoundRect(in, grueso / 2, grueso / 2, p);
                p.setColor(0xFF2E7D32);
                p.setStrokeWidth(3 * d);
                float marca = 26 * d;
                if (vertical) { c.drawLine(in.left, cy - marca, in.right, cy - marca, p); c.drawLine(in.left, cy + marca, in.right, cy + marca, p); }
                else { c.drawLine(cx - marca, in.top, cx - marca, in.bottom, p); c.drawLine(cx + marca, in.top, cx + marca, in.bottom, p); }
                // burbuja hacia el extremo alto; 1° = 60 dp
                double desp = Math.max(-4, Math.min(4, a)) * 60 * d;
                float bx = vertical ? cx : (float) (cx + desp);
                float by = vertical ? (float) (cy - desp) : cy;
                p.setColor(0xEEFFFFFF);
                RectF bur = vertical ? new RectF(bx - grueso / 3, by - grueso / 2, bx + grueso / 3, by + grueso / 2)
                        : new RectF(bx - grueso / 2, by - grueso / 3, bx + grueso / 2, by + grueso / 3);
                c.drawOval(bur, p);
                p.setColor(Color.WHITE);
                p.setTextSize(64 * d);
                p.setTypeface(Typeface.DEFAULT_BOLD);
                p.setTextAlign(Paint.Align.CENTER);
                p.setColor(verde ? 0xFF7CFF5A : 0xFFFFB300);
                String txt = String.format(Locale.US, "%.1f°", Math.abs(a)).replace('.', ',');
                c.drawText(txt, cx, vertical ? cy - largo / 4 : cy - grueso - 20 * d, p);
                p.setTextAlign(Paint.Align.LEFT);
                p.setTypeface(Typeface.DEFAULT);
            }
        }
    }
}
